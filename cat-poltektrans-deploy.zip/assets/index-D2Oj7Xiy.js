(function(){const c=document.createElement("link").relList;if(c&&c.supports&&c.supports("modulepreload"))return;for(const h of document.querySelectorAll('link[rel="modulepreload"]'))o(h);new MutationObserver(h=>{for(const m of h)if(m.type==="childList")for(const x of m.addedNodes)x.tagName==="LINK"&&x.rel==="modulepreload"&&o(x)}).observe(document,{childList:!0,subtree:!0});function u(h){const m={};return h.integrity&&(m.integrity=h.integrity),h.referrerPolicy&&(m.referrerPolicy=h.referrerPolicy),h.crossOrigin==="use-credentials"?m.credentials="include":h.crossOrigin==="anonymous"?m.credentials="omit":m.credentials="same-origin",m}function o(h){if(h.ep)return;h.ep=!0;const m=u(h);fetch(h.href,m)}})();var bo={exports:{}},ls={};var up;function u0(){if(up)return ls;up=1;var r=Symbol.for("react.transitional.element"),c=Symbol.for("react.fragment");function u(o,h,m){var x=null;if(m!==void 0&&(x=""+m),h.key!==void 0&&(x=""+h.key),"key"in h){m={};for(var g in h)g!=="key"&&(m[g]=h[g])}else m=h;return h=m.ref,{$$typeof:r,type:o,key:x,ref:h!==void 0?h:null,props:m}}return ls.Fragment=c,ls.jsx=u,ls.jsxs=u,ls}var mp;function m0(){return mp||(mp=1,bo.exports=u0()),bo.exports}var a=m0(),jo={exports:{}},de={};var hp;function h0(){if(hp)return de;hp=1;var r=Symbol.for("react.transitional.element"),c=Symbol.for("react.portal"),u=Symbol.for("react.fragment"),o=Symbol.for("react.strict_mode"),h=Symbol.for("react.profiler"),m=Symbol.for("react.consumer"),x=Symbol.for("react.context"),g=Symbol.for("react.forward_ref"),b=Symbol.for("react.suspense"),p=Symbol.for("react.memo"),z=Symbol.for("react.lazy"),N=Symbol.for("react.activity"),S=Symbol.iterator;function A(M){return M===null||typeof M!="object"?null:(M=S&&M[S]||M["@@iterator"],typeof M=="function"?M:null)}var v={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},R=Object.assign,j={};function w(M,Z,ee){this.props=M,this.context=Z,this.refs=j,this.updater=ee||v}w.prototype.isReactComponent={},w.prototype.setState=function(M,Z){if(typeof M!="object"&&typeof M!="function"&&M!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,M,Z,"setState")},w.prototype.forceUpdate=function(M){this.updater.enqueueForceUpdate(this,M,"forceUpdate")};function C(){}C.prototype=w.prototype;function k(M,Z,ee){this.props=M,this.context=Z,this.refs=j,this.updater=ee||v}var Q=k.prototype=new C;Q.constructor=k,R(Q,w.prototype),Q.isPureReactComponent=!0;var $=Array.isArray;function _(){}var U={H:null,A:null,T:null,S:null},L=Object.prototype.hasOwnProperty;function K(M,Z,ee){var te=ee.ref;return{$$typeof:r,type:M,key:Z,ref:te!==void 0?te:null,props:ee}}function V(M,Z){return K(M.type,Z,M.props)}function X(M){return typeof M=="object"&&M!==null&&M.$$typeof===r}function se(M){var Z={"=":"=0",":":"=2"};return"$"+M.replace(/[=:]/g,function(ee){return Z[ee]})}var xe=/\/+/g;function ve(M,Z){return typeof M=="object"&&M!==null&&M.key!=null?se(""+M.key):Z.toString(36)}function Oe(M){switch(M.status){case"fulfilled":return M.value;case"rejected":throw M.reason;default:switch(typeof M.status=="string"?M.then(_,_):(M.status="pending",M.then(function(Z){M.status==="pending"&&(M.status="fulfilled",M.value=Z)},function(Z){M.status==="pending"&&(M.status="rejected",M.reason=Z)})),M.status){case"fulfilled":return M.value;case"rejected":throw M.reason}}throw M}function I(M,Z,ee,te,ue){var pe=typeof M;(pe==="undefined"||pe==="boolean")&&(M=null);var ze=!1;if(M===null)ze=!0;else switch(pe){case"bigint":case"string":case"number":ze=!0;break;case"object":switch(M.$$typeof){case r:case c:ze=!0;break;case z:return ze=M._init,I(ze(M._payload),Z,ee,te,ue)}}if(ze)return ue=ue(M),ze=te===""?"."+ve(M,0):te,$(ue)?(ee="",ze!=null&&(ee=ze.replace(xe,"$&/")+"/"),I(ue,Z,ee,"",function(ul){return ul})):ue!=null&&(X(ue)&&(ue=V(ue,ee+(ue.key==null||M&&M.key===ue.key?"":(""+ue.key).replace(xe,"$&/")+"/")+ze)),Z.push(ue)),1;ze=0;var ca=te===""?".":te+":";if($(M))for(var qe=0;qe<M.length;qe++)te=M[qe],pe=ca+ve(te,qe),ze+=I(te,Z,ee,pe,ue);else if(qe=A(M),typeof qe=="function")for(M=qe.call(M),qe=0;!(te=M.next()).done;)te=te.value,pe=ca+ve(te,qe++),ze+=I(te,Z,ee,pe,ue);else if(pe==="object"){if(typeof M.then=="function")return I(Oe(M),Z,ee,te,ue);throw Z=String(M),Error("Objects are not valid as a React child (found: "+(Z==="[object Object]"?"object with keys {"+Object.keys(M).join(", ")+"}":Z)+"). If you meant to render a collection of children, use an array instead.")}return ze}function G(M,Z,ee){if(M==null)return M;var te=[],ue=0;return I(M,te,"","",function(pe){return Z.call(ee,pe,ue++)}),te}function W(M){if(M._status===-1){var Z=M._result;Z=Z(),Z.then(function(ee){(M._status===0||M._status===-1)&&(M._status=1,M._result=ee)},function(ee){(M._status===0||M._status===-1)&&(M._status=2,M._result=ee)}),M._status===-1&&(M._status=0,M._result=Z)}if(M._status===1)return M._result.default;throw M._result}var oe=typeof reportError=="function"?reportError:function(M){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var Z=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof M=="object"&&M!==null&&typeof M.message=="string"?String(M.message):String(M),error:M});if(!window.dispatchEvent(Z))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",M);return}console.error(M)},Ne={map:G,forEach:function(M,Z,ee){G(M,function(){Z.apply(this,arguments)},ee)},count:function(M){var Z=0;return G(M,function(){Z++}),Z},toArray:function(M){return G(M,function(Z){return Z})||[]},only:function(M){if(!X(M))throw Error("React.Children.only expected to receive a single React element child.");return M}};return de.Activity=N,de.Children=Ne,de.Component=w,de.Fragment=u,de.Profiler=h,de.PureComponent=k,de.StrictMode=o,de.Suspense=b,de.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=U,de.__COMPILER_RUNTIME={__proto__:null,c:function(M){return U.H.useMemoCache(M)}},de.cache=function(M){return function(){return M.apply(null,arguments)}},de.cacheSignal=function(){return null},de.cloneElement=function(M,Z,ee){if(M==null)throw Error("The argument must be a React element, but you passed "+M+".");var te=R({},M.props),ue=M.key;if(Z!=null)for(pe in Z.key!==void 0&&(ue=""+Z.key),Z)!L.call(Z,pe)||pe==="key"||pe==="__self"||pe==="__source"||pe==="ref"&&Z.ref===void 0||(te[pe]=Z[pe]);var pe=arguments.length-2;if(pe===1)te.children=ee;else if(1<pe){for(var ze=Array(pe),ca=0;ca<pe;ca++)ze[ca]=arguments[ca+2];te.children=ze}return K(M.type,ue,te)},de.createContext=function(M){return M={$$typeof:x,_currentValue:M,_currentValue2:M,_threadCount:0,Provider:null,Consumer:null},M.Provider=M,M.Consumer={$$typeof:m,_context:M},M},de.createElement=function(M,Z,ee){var te,ue={},pe=null;if(Z!=null)for(te in Z.key!==void 0&&(pe=""+Z.key),Z)L.call(Z,te)&&te!=="key"&&te!=="__self"&&te!=="__source"&&(ue[te]=Z[te]);var ze=arguments.length-2;if(ze===1)ue.children=ee;else if(1<ze){for(var ca=Array(ze),qe=0;qe<ze;qe++)ca[qe]=arguments[qe+2];ue.children=ca}if(M&&M.defaultProps)for(te in ze=M.defaultProps,ze)ue[te]===void 0&&(ue[te]=ze[te]);return K(M,pe,ue)},de.createRef=function(){return{current:null}},de.forwardRef=function(M){return{$$typeof:g,render:M}},de.isValidElement=X,de.lazy=function(M){return{$$typeof:z,_payload:{_status:-1,_result:M},_init:W}},de.memo=function(M,Z){return{$$typeof:p,type:M,compare:Z===void 0?null:Z}},de.startTransition=function(M){var Z=U.T,ee={};U.T=ee;try{var te=M(),ue=U.S;ue!==null&&ue(ee,te),typeof te=="object"&&te!==null&&typeof te.then=="function"&&te.then(_,oe)}catch(pe){oe(pe)}finally{Z!==null&&ee.types!==null&&(Z.types=ee.types),U.T=Z}},de.unstable_useCacheRefresh=function(){return U.H.useCacheRefresh()},de.use=function(M){return U.H.use(M)},de.useActionState=function(M,Z,ee){return U.H.useActionState(M,Z,ee)},de.useCallback=function(M,Z){return U.H.useCallback(M,Z)},de.useContext=function(M){return U.H.useContext(M)},de.useDebugValue=function(){},de.useDeferredValue=function(M,Z){return U.H.useDeferredValue(M,Z)},de.useEffect=function(M,Z){return U.H.useEffect(M,Z)},de.useEffectEvent=function(M){return U.H.useEffectEvent(M)},de.useId=function(){return U.H.useId()},de.useImperativeHandle=function(M,Z,ee){return U.H.useImperativeHandle(M,Z,ee)},de.useInsertionEffect=function(M,Z){return U.H.useInsertionEffect(M,Z)},de.useLayoutEffect=function(M,Z){return U.H.useLayoutEffect(M,Z)},de.useMemo=function(M,Z){return U.H.useMemo(M,Z)},de.useOptimistic=function(M,Z){return U.H.useOptimistic(M,Z)},de.useReducer=function(M,Z,ee){return U.H.useReducer(M,Z,ee)},de.useRef=function(M){return U.H.useRef(M)},de.useState=function(M){return U.H.useState(M)},de.useSyncExternalStore=function(M,Z,ee){return U.H.useSyncExternalStore(M,Z,ee)},de.useTransition=function(){return U.H.useTransition()},de.version="19.2.3",de}var pp;function Zo(){return pp||(pp=1,jo.exports=h0()),jo.exports}var y=Zo(),yo={exports:{}},ss={},No={exports:{}},ko={};var fp;function p0(){return fp||(fp=1,(function(r){function c(I,G){var W=I.length;I.push(G);e:for(;0<W;){var oe=W-1>>>1,Ne=I[oe];if(0<h(Ne,G))I[oe]=G,I[W]=Ne,W=oe;else break e}}function u(I){return I.length===0?null:I[0]}function o(I){if(I.length===0)return null;var G=I[0],W=I.pop();if(W!==G){I[0]=W;e:for(var oe=0,Ne=I.length,M=Ne>>>1;oe<M;){var Z=2*(oe+1)-1,ee=I[Z],te=Z+1,ue=I[te];if(0>h(ee,W))te<Ne&&0>h(ue,ee)?(I[oe]=ue,I[te]=W,oe=te):(I[oe]=ee,I[Z]=W,oe=Z);else if(te<Ne&&0>h(ue,W))I[oe]=ue,I[te]=W,oe=te;else break e}}return G}function h(I,G){var W=I.sortIndex-G.sortIndex;return W!==0?W:I.id-G.id}if(r.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var m=performance;r.unstable_now=function(){return m.now()}}else{var x=Date,g=x.now();r.unstable_now=function(){return x.now()-g}}var b=[],p=[],z=1,N=null,S=3,A=!1,v=!1,R=!1,j=!1,w=typeof setTimeout=="function"?setTimeout:null,C=typeof clearTimeout=="function"?clearTimeout:null,k=typeof setImmediate<"u"?setImmediate:null;function Q(I){for(var G=u(p);G!==null;){if(G.callback===null)o(p);else if(G.startTime<=I)o(p),G.sortIndex=G.expirationTime,c(b,G);else break;G=u(p)}}function $(I){if(R=!1,Q(I),!v)if(u(b)!==null)v=!0,_||(_=!0,se());else{var G=u(p);G!==null&&Oe($,G.startTime-I)}}var _=!1,U=-1,L=5,K=-1;function V(){return j?!0:!(r.unstable_now()-K<L)}function X(){if(j=!1,_){var I=r.unstable_now();K=I;var G=!0;try{e:{v=!1,R&&(R=!1,C(U),U=-1),A=!0;var W=S;try{a:{for(Q(I),N=u(b);N!==null&&!(N.expirationTime>I&&V());){var oe=N.callback;if(typeof oe=="function"){N.callback=null,S=N.priorityLevel;var Ne=oe(N.expirationTime<=I);if(I=r.unstable_now(),typeof Ne=="function"){N.callback=Ne,Q(I),G=!0;break a}N===u(b)&&o(b),Q(I)}else o(b);N=u(b)}if(N!==null)G=!0;else{var M=u(p);M!==null&&Oe($,M.startTime-I),G=!1}}break e}finally{N=null,S=W,A=!1}G=void 0}}finally{G?se():_=!1}}}var se;if(typeof k=="function")se=function(){k(X)};else if(typeof MessageChannel<"u"){var xe=new MessageChannel,ve=xe.port2;xe.port1.onmessage=X,se=function(){ve.postMessage(null)}}else se=function(){w(X,0)};function Oe(I,G){U=w(function(){I(r.unstable_now())},G)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(I){I.callback=null},r.unstable_forceFrameRate=function(I){0>I||125<I?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):L=0<I?Math.floor(1e3/I):5},r.unstable_getCurrentPriorityLevel=function(){return S},r.unstable_next=function(I){switch(S){case 1:case 2:case 3:var G=3;break;default:G=S}var W=S;S=G;try{return I()}finally{S=W}},r.unstable_requestPaint=function(){j=!0},r.unstable_runWithPriority=function(I,G){switch(I){case 1:case 2:case 3:case 4:case 5:break;default:I=3}var W=S;S=I;try{return G()}finally{S=W}},r.unstable_scheduleCallback=function(I,G,W){var oe=r.unstable_now();switch(typeof W=="object"&&W!==null?(W=W.delay,W=typeof W=="number"&&0<W?oe+W:oe):W=oe,I){case 1:var Ne=-1;break;case 2:Ne=250;break;case 5:Ne=1073741823;break;case 4:Ne=1e4;break;default:Ne=5e3}return Ne=W+Ne,I={id:z++,callback:G,priorityLevel:I,startTime:W,expirationTime:Ne,sortIndex:-1},W>oe?(I.sortIndex=W,c(p,I),u(b)===null&&I===u(p)&&(R?(C(U),U=-1):R=!0,Oe($,W-oe))):(I.sortIndex=Ne,c(b,I),v||A||(v=!0,_||(_=!0,se()))),I},r.unstable_shouldYield=V,r.unstable_wrapCallback=function(I){var G=S;return function(){var W=S;S=G;try{return I.apply(this,arguments)}finally{S=W}}}})(ko)),ko}var gp;function f0(){return gp||(gp=1,No.exports=p0()),No.exports}var So={exports:{}},ia={};var xp;function g0(){if(xp)return ia;xp=1;var r=Zo();function c(b){var p="https://react.dev/errors/"+b;if(1<arguments.length){p+="?args[]="+encodeURIComponent(arguments[1]);for(var z=2;z<arguments.length;z++)p+="&args[]="+encodeURIComponent(arguments[z])}return"Minified React error #"+b+"; visit "+p+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function u(){}var o={d:{f:u,r:function(){throw Error(c(522))},D:u,C:u,L:u,m:u,X:u,S:u,M:u},p:0,findDOMNode:null},h=Symbol.for("react.portal");function m(b,p,z){var N=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:h,key:N==null?null:""+N,children:b,containerInfo:p,implementation:z}}var x=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function g(b,p){if(b==="font")return"";if(typeof p=="string")return p==="use-credentials"?p:""}return ia.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=o,ia.createPortal=function(b,p){var z=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!p||p.nodeType!==1&&p.nodeType!==9&&p.nodeType!==11)throw Error(c(299));return m(b,p,null,z)},ia.flushSync=function(b){var p=x.T,z=o.p;try{if(x.T=null,o.p=2,b)return b()}finally{x.T=p,o.p=z,o.d.f()}},ia.preconnect=function(b,p){typeof b=="string"&&(p?(p=p.crossOrigin,p=typeof p=="string"?p==="use-credentials"?p:"":void 0):p=null,o.d.C(b,p))},ia.prefetchDNS=function(b){typeof b=="string"&&o.d.D(b)},ia.preinit=function(b,p){if(typeof b=="string"&&p&&typeof p.as=="string"){var z=p.as,N=g(z,p.crossOrigin),S=typeof p.integrity=="string"?p.integrity:void 0,A=typeof p.fetchPriority=="string"?p.fetchPriority:void 0;z==="style"?o.d.S(b,typeof p.precedence=="string"?p.precedence:void 0,{crossOrigin:N,integrity:S,fetchPriority:A}):z==="script"&&o.d.X(b,{crossOrigin:N,integrity:S,fetchPriority:A,nonce:typeof p.nonce=="string"?p.nonce:void 0})}},ia.preinitModule=function(b,p){if(typeof b=="string")if(typeof p=="object"&&p!==null){if(p.as==null||p.as==="script"){var z=g(p.as,p.crossOrigin);o.d.M(b,{crossOrigin:z,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0})}}else p==null&&o.d.M(b)},ia.preload=function(b,p){if(typeof b=="string"&&typeof p=="object"&&p!==null&&typeof p.as=="string"){var z=p.as,N=g(z,p.crossOrigin);o.d.L(b,z,{crossOrigin:N,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,type:typeof p.type=="string"?p.type:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0,referrerPolicy:typeof p.referrerPolicy=="string"?p.referrerPolicy:void 0,imageSrcSet:typeof p.imageSrcSet=="string"?p.imageSrcSet:void 0,imageSizes:typeof p.imageSizes=="string"?p.imageSizes:void 0,media:typeof p.media=="string"?p.media:void 0})}},ia.preloadModule=function(b,p){if(typeof b=="string")if(p){var z=g(p.as,p.crossOrigin);o.d.m(b,{as:typeof p.as=="string"&&p.as!=="script"?p.as:void 0,crossOrigin:z,integrity:typeof p.integrity=="string"?p.integrity:void 0})}else o.d.m(b)},ia.requestFormReset=function(b){o.d.r(b)},ia.unstable_batchedUpdates=function(b,p){return b(p)},ia.useFormState=function(b,p,z){return x.H.useFormState(b,p,z)},ia.useFormStatus=function(){return x.H.useHostTransitionStatus()},ia.version="19.2.3",ia}var vp;function x0(){if(vp)return So.exports;vp=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(c){console.error(c)}}return r(),So.exports=g0(),So.exports}var bp;function v0(){if(bp)return ss;bp=1;var r=f0(),c=Zo(),u=x0();function o(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function h(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function m(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,(t.flags&4098)!==0&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function x(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function g(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function b(e){if(m(e)!==e)throw Error(o(188))}function p(e){var t=e.alternate;if(!t){if(t=m(e),t===null)throw Error(o(188));return t!==e?null:e}for(var n=e,l=t;;){var s=n.return;if(s===null)break;var i=s.alternate;if(i===null){if(l=s.return,l!==null){n=l;continue}break}if(s.child===i.child){for(i=s.child;i;){if(i===n)return b(s),e;if(i===l)return b(s),t;i=i.sibling}throw Error(o(188))}if(n.return!==l.return)n=s,l=i;else{for(var d=!1,f=s.child;f;){if(f===n){d=!0,n=s,l=i;break}if(f===l){d=!0,l=s,n=i;break}f=f.sibling}if(!d){for(f=i.child;f;){if(f===n){d=!0,n=i,l=s;break}if(f===l){d=!0,l=i,n=s;break}f=f.sibling}if(!d)throw Error(o(189))}}if(n.alternate!==l)throw Error(o(190))}if(n.tag!==3)throw Error(o(188));return n.stateNode.current===n?e:t}function z(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=z(e),t!==null)return t;e=e.sibling}return null}var N=Object.assign,S=Symbol.for("react.element"),A=Symbol.for("react.transitional.element"),v=Symbol.for("react.portal"),R=Symbol.for("react.fragment"),j=Symbol.for("react.strict_mode"),w=Symbol.for("react.profiler"),C=Symbol.for("react.consumer"),k=Symbol.for("react.context"),Q=Symbol.for("react.forward_ref"),$=Symbol.for("react.suspense"),_=Symbol.for("react.suspense_list"),U=Symbol.for("react.memo"),L=Symbol.for("react.lazy"),K=Symbol.for("react.activity"),V=Symbol.for("react.memo_cache_sentinel"),X=Symbol.iterator;function se(e){return e===null||typeof e!="object"?null:(e=X&&e[X]||e["@@iterator"],typeof e=="function"?e:null)}var xe=Symbol.for("react.client.reference");function ve(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===xe?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case R:return"Fragment";case w:return"Profiler";case j:return"StrictMode";case $:return"Suspense";case _:return"SuspenseList";case K:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case v:return"Portal";case k:return e.displayName||"Context";case C:return(e._context.displayName||"Context")+".Consumer";case Q:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case U:return t=e.displayName||null,t!==null?t:ve(e.type)||"Memo";case L:t=e._payload,e=e._init;try{return ve(e(t))}catch{}}return null}var Oe=Array.isArray,I=c.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,G=u.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,W={pending:!1,data:null,method:null,action:null},oe=[],Ne=-1;function M(e){return{current:e}}function Z(e){0>Ne||(e.current=oe[Ne],oe[Ne]=null,Ne--)}function ee(e,t){Ne++,oe[Ne]=e.current,e.current=t}var te=M(null),ue=M(null),pe=M(null),ze=M(null);function ca(e,t){switch(ee(pe,t),ee(ue,e),ee(te,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?Rh(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=Rh(t),e=Uh(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}Z(te),ee(te,e)}function qe(){Z(te),Z(ue),Z(pe)}function ul(e){e.memoizedState!==null&&ee(ze,e);var t=te.current,n=Uh(t,e.type);t!==n&&(ee(ue,e),ee(te,n))}function js(e){ue.current===e&&(Z(te),Z(ue)),ze.current===e&&(Z(ze),es._currentValue=W)}var er,dd;function Wt(e){if(er===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);er=t&&t[1]||"",dd=-1<n.stack.indexOf(`
    at`)?" (<anonymous>)":-1<n.stack.indexOf("@")?"@unknown:0:0":""}return`
`+er+e+dd}var ar=!1;function tr(e,t){if(!e||ar)return"";ar=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var l={DetermineComponentFrameRoot:function(){try{if(t){var J=function(){throw Error()};if(Object.defineProperty(J.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(J,[])}catch(q){var B=q}Reflect.construct(e,[],J)}else{try{J.call()}catch(q){B=q}e.call(J.prototype)}}else{try{throw Error()}catch(q){B=q}(J=e())&&typeof J.catch=="function"&&J.catch(function(){})}}catch(q){if(q&&B&&typeof q.stack=="string")return[q.stack,B.stack]}return[null,null]}};l.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var s=Object.getOwnPropertyDescriptor(l.DetermineComponentFrameRoot,"name");s&&s.configurable&&Object.defineProperty(l.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var i=l.DetermineComponentFrameRoot(),d=i[0],f=i[1];if(d&&f){var T=d.split(`
`),H=f.split(`
`);for(s=l=0;l<T.length&&!T[l].includes("DetermineComponentFrameRoot");)l++;for(;s<H.length&&!H[s].includes("DetermineComponentFrameRoot");)s++;if(l===T.length||s===H.length)for(l=T.length-1,s=H.length-1;1<=l&&0<=s&&T[l]!==H[s];)s--;for(;1<=l&&0<=s;l--,s--)if(T[l]!==H[s]){if(l!==1||s!==1)do if(l--,s--,0>s||T[l]!==H[s]){var P=`
`+T[l].replace(" at new "," at ");return e.displayName&&P.includes("<anonymous>")&&(P=P.replace("<anonymous>",e.displayName)),P}while(1<=l&&0<=s);break}}}finally{ar=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:"")?Wt(n):""}function qf(e,t){switch(e.tag){case 26:case 27:case 5:return Wt(e.type);case 16:return Wt("Lazy");case 13:return e.child!==t&&t!==null?Wt("Suspense Fallback"):Wt("Suspense");case 19:return Wt("SuspenseList");case 0:case 15:return tr(e.type,!1);case 11:return tr(e.type.render,!1);case 1:return tr(e.type,!0);case 31:return Wt("Activity");default:return""}}function ud(e){try{var t="",n=null;do t+=qf(e,n),n=e,e=e.return;while(e);return t}catch(l){return`
Error generating stack: `+l.message+`
`+l.stack}}var nr=Object.prototype.hasOwnProperty,lr=r.unstable_scheduleCallback,sr=r.unstable_cancelCallback,If=r.unstable_shouldYield,Pf=r.unstable_requestPaint,ja=r.unstable_now,Gf=r.unstable_getCurrentPriorityLevel,md=r.unstable_ImmediatePriority,hd=r.unstable_UserBlockingPriority,ys=r.unstable_NormalPriority,Qf=r.unstable_LowPriority,pd=r.unstable_IdlePriority,Yf=r.log,Xf=r.unstable_setDisableYieldValue,ml=null,ya=null;function St(e){if(typeof Yf=="function"&&Xf(e),ya&&typeof ya.setStrictMode=="function")try{ya.setStrictMode(ml,e)}catch{}}var Na=Math.clz32?Math.clz32:Zf,Vf=Math.log,Jf=Math.LN2;function Zf(e){return e>>>=0,e===0?32:31-(Vf(e)/Jf|0)|0}var Ns=256,ks=262144,Ss=4194304;function Ft(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function ws(e,t,n){var l=e.pendingLanes;if(l===0)return 0;var s=0,i=e.suspendedLanes,d=e.pingedLanes;e=e.warmLanes;var f=l&134217727;return f!==0?(l=f&~i,l!==0?s=Ft(l):(d&=f,d!==0?s=Ft(d):n||(n=f&~e,n!==0&&(s=Ft(n))))):(f=l&~i,f!==0?s=Ft(f):d!==0?s=Ft(d):n||(n=l&~e,n!==0&&(s=Ft(n)))),s===0?0:t!==0&&t!==s&&(t&i)===0&&(i=s&-s,n=t&-t,i>=n||i===32&&(n&4194048)!==0)?t:s}function hl(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function Wf(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function fd(){var e=Ss;return Ss<<=1,(Ss&62914560)===0&&(Ss=4194304),e}function ir(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function pl(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function Ff(e,t,n,l,s,i){var d=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var f=e.entanglements,T=e.expirationTimes,H=e.hiddenUpdates;for(n=d&~n;0<n;){var P=31-Na(n),J=1<<P;f[P]=0,T[P]=-1;var B=H[P];if(B!==null)for(H[P]=null,P=0;P<B.length;P++){var q=B[P];q!==null&&(q.lane&=-536870913)}n&=~J}l!==0&&gd(e,l,0),i!==0&&s===0&&e.tag!==0&&(e.suspendedLanes|=i&~(d&~t))}function gd(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var l=31-Na(t);e.entangledLanes|=t,e.entanglements[l]=e.entanglements[l]|1073741824|n&261930}function xd(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var l=31-Na(n),s=1<<l;s&t|e[l]&t&&(e[l]|=t),n&=~s}}function vd(e,t){var n=t&-t;return n=(n&42)!==0?1:rr(n),(n&(e.suspendedLanes|t))!==0?0:n}function rr(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function cr(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function bd(){var e=G.p;return e!==0?e:(e=window.event,e===void 0?32:lp(e.type))}function jd(e,t){var n=G.p;try{return G.p=e,t()}finally{G.p=n}}var wt=Math.random().toString(36).slice(2),aa="__reactFiber$"+wt,ua="__reactProps$"+wt,yn="__reactContainer$"+wt,or="__reactEvents$"+wt,eg="__reactListeners$"+wt,ag="__reactHandles$"+wt,yd="__reactResources$"+wt,fl="__reactMarker$"+wt;function dr(e){delete e[aa],delete e[ua],delete e[or],delete e[eg],delete e[ag]}function Nn(e){var t=e[aa];if(t)return t;for(var n=e.parentNode;n;){if(t=n[yn]||n[aa]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=qh(e);e!==null;){if(n=e[aa])return n;e=qh(e)}return t}e=n,n=e.parentNode}return null}function kn(e){if(e=e[aa]||e[yn]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function gl(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(o(33))}function Sn(e){var t=e[yd];return t||(t=e[yd]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function Fe(e){e[fl]=!0}var Nd=new Set,kd={};function en(e,t){wn(e,t),wn(e+"Capture",t)}function wn(e,t){for(kd[e]=t,e=0;e<t.length;e++)Nd.add(t[e])}var tg=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Sd={},wd={};function ng(e){return nr.call(wd,e)?!0:nr.call(Sd,e)?!1:tg.test(e)?wd[e]=!0:(Sd[e]=!0,!1)}function zs(e,t,n){if(ng(t))if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var l=t.toLowerCase().slice(0,5);if(l!=="data-"&&l!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,""+n)}}function Ts(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,""+n)}}function tt(e,t,n,l){if(l===null)e.removeAttribute(n);else{switch(typeof l){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttributeNS(t,n,""+l)}}function _a(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function zd(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function lg(e,t,n){var l=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof l<"u"&&typeof l.get=="function"&&typeof l.set=="function"){var s=l.get,i=l.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return s.call(this)},set:function(d){n=""+d,i.call(this,d)}}),Object.defineProperty(e,t,{enumerable:l.enumerable}),{getValue:function(){return n},setValue:function(d){n=""+d},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function ur(e){if(!e._valueTracker){var t=zd(e)?"checked":"value";e._valueTracker=lg(e,t,""+e[t])}}function Td(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),l="";return e&&(l=zd(e)?e.checked?"true":"false":e.value),e=l,e!==n?(t.setValue(e),!0):!1}function As(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var sg=/[\n"\\]/g;function Ma(e){return e.replace(sg,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function mr(e,t,n,l,s,i,d,f){e.name="",d!=null&&typeof d!="function"&&typeof d!="symbol"&&typeof d!="boolean"?e.type=d:e.removeAttribute("type"),t!=null?d==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+_a(t)):e.value!==""+_a(t)&&(e.value=""+_a(t)):d!=="submit"&&d!=="reset"||e.removeAttribute("value"),t!=null?hr(e,d,_a(t)):n!=null?hr(e,d,_a(n)):l!=null&&e.removeAttribute("value"),s==null&&i!=null&&(e.defaultChecked=!!i),s!=null&&(e.checked=s&&typeof s!="function"&&typeof s!="symbol"),f!=null&&typeof f!="function"&&typeof f!="symbol"&&typeof f!="boolean"?e.name=""+_a(f):e.removeAttribute("name")}function Ad(e,t,n,l,s,i,d,f){if(i!=null&&typeof i!="function"&&typeof i!="symbol"&&typeof i!="boolean"&&(e.type=i),t!=null||n!=null){if(!(i!=="submit"&&i!=="reset"||t!=null)){ur(e);return}n=n!=null?""+_a(n):"",t=t!=null?""+_a(t):n,f||t===e.value||(e.value=t),e.defaultValue=t}l=l??s,l=typeof l!="function"&&typeof l!="symbol"&&!!l,e.checked=f?e.checked:!!l,e.defaultChecked=!!l,d!=null&&typeof d!="function"&&typeof d!="symbol"&&typeof d!="boolean"&&(e.name=d),ur(e)}function hr(e,t,n){t==="number"&&As(e.ownerDocument)===e||e.defaultValue===""+n||(e.defaultValue=""+n)}function zn(e,t,n,l){if(e=e.options,t){t={};for(var s=0;s<n.length;s++)t["$"+n[s]]=!0;for(n=0;n<e.length;n++)s=t.hasOwnProperty("$"+e[n].value),e[n].selected!==s&&(e[n].selected=s),s&&l&&(e[n].defaultSelected=!0)}else{for(n=""+_a(n),t=null,s=0;s<e.length;s++){if(e[s].value===n){e[s].selected=!0,l&&(e[s].defaultSelected=!0);return}t!==null||e[s].disabled||(t=e[s])}t!==null&&(t.selected=!0)}}function Cd(e,t,n){if(t!=null&&(t=""+_a(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n!=null?""+_a(n):""}function Dd(e,t,n,l){if(t==null){if(l!=null){if(n!=null)throw Error(o(92));if(Oe(l)){if(1<l.length)throw Error(o(93));l=l[0]}n=l}n==null&&(n=""),t=n}n=_a(t),e.defaultValue=n,l=e.textContent,l===n&&l!==""&&l!==null&&(e.value=l),ur(e)}function Tn(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var ig=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function _d(e,t,n){var l=t.indexOf("--")===0;n==null||typeof n=="boolean"||n===""?l?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":l?e.setProperty(t,n):typeof n!="number"||n===0||ig.has(t)?t==="float"?e.cssFloat=n:e[t]=(""+n).trim():e[t]=n+"px"}function Md(e,t,n){if(t!=null&&typeof t!="object")throw Error(o(62));if(e=e.style,n!=null){for(var l in n)!n.hasOwnProperty(l)||t!=null&&t.hasOwnProperty(l)||(l.indexOf("--")===0?e.setProperty(l,""):l==="float"?e.cssFloat="":e[l]="");for(var s in t)l=t[s],t.hasOwnProperty(s)&&n[s]!==l&&_d(e,s,l)}else for(var i in t)t.hasOwnProperty(i)&&_d(e,i,t[i])}function pr(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var rg=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),cg=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Cs(e){return cg.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function nt(){}var fr=null;function gr(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var An=null,Cn=null;function Ed(e){var t=kn(e);if(t&&(e=t.stateNode)){var n=e[ua]||null;e:switch(e=t.stateNode,t.type){case"input":if(mr(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll('input[name="'+Ma(""+t)+'"][type="radio"]'),t=0;t<n.length;t++){var l=n[t];if(l!==e&&l.form===e.form){var s=l[ua]||null;if(!s)throw Error(o(90));mr(l,s.value,s.defaultValue,s.defaultValue,s.checked,s.defaultChecked,s.type,s.name)}}for(t=0;t<n.length;t++)l=n[t],l.form===e.form&&Td(l)}break e;case"textarea":Cd(e,n.value,n.defaultValue);break e;case"select":t=n.value,t!=null&&zn(e,!!n.multiple,t,!1)}}}var xr=!1;function Rd(e,t,n){if(xr)return e(t,n);xr=!0;try{var l=e(t);return l}finally{if(xr=!1,(An!==null||Cn!==null)&&(gi(),An&&(t=An,e=Cn,Cn=An=null,Ed(t),e)))for(t=0;t<e.length;t++)Ed(e[t])}}function xl(e,t){var n=e.stateNode;if(n===null)return null;var l=n[ua]||null;if(l===null)return null;n=l[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(l=!l.disabled)||(e=e.type,l=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!l;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(o(231,t,typeof n));return n}var lt=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),vr=!1;if(lt)try{var vl={};Object.defineProperty(vl,"passive",{get:function(){vr=!0}}),window.addEventListener("test",vl,vl),window.removeEventListener("test",vl,vl)}catch{vr=!1}var zt=null,br=null,Ds=null;function Ud(){if(Ds)return Ds;var e,t=br,n=t.length,l,s="value"in zt?zt.value:zt.textContent,i=s.length;for(e=0;e<n&&t[e]===s[e];e++);var d=n-e;for(l=1;l<=d&&t[n-l]===s[i-l];l++);return Ds=s.slice(e,1<l?1-l:void 0)}function _s(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Ms(){return!0}function Ld(){return!1}function ma(e){function t(n,l,s,i,d){this._reactName=n,this._targetInst=s,this.type=l,this.nativeEvent=i,this.target=d,this.currentTarget=null;for(var f in e)e.hasOwnProperty(f)&&(n=e[f],this[f]=n?n(i):i[f]);return this.isDefaultPrevented=(i.defaultPrevented!=null?i.defaultPrevented:i.returnValue===!1)?Ms:Ld,this.isPropagationStopped=Ld,this}return N(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=Ms)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=Ms)},persist:function(){},isPersistent:Ms}),t}var an={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Es=ma(an),bl=N({},an,{view:0,detail:0}),og=ma(bl),jr,yr,jl,Rs=N({},bl,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:kr,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==jl&&(jl&&e.type==="mousemove"?(jr=e.screenX-jl.screenX,yr=e.screenY-jl.screenY):yr=jr=0,jl=e),jr)},movementY:function(e){return"movementY"in e?e.movementY:yr}}),Od=ma(Rs),dg=N({},Rs,{dataTransfer:0}),ug=ma(dg),mg=N({},bl,{relatedTarget:0}),Nr=ma(mg),hg=N({},an,{animationName:0,elapsedTime:0,pseudoElement:0}),pg=ma(hg),fg=N({},an,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),gg=ma(fg),xg=N({},an,{data:0}),Hd=ma(xg),vg={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},bg={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},jg={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function yg(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=jg[e])?!!t[e]:!1}function kr(){return yg}var Ng=N({},bl,{key:function(e){if(e.key){var t=vg[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=_s(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?bg[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:kr,charCode:function(e){return e.type==="keypress"?_s(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?_s(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),kg=ma(Ng),Sg=N({},Rs,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Kd=ma(Sg),wg=N({},bl,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:kr}),zg=ma(wg),Tg=N({},an,{propertyName:0,elapsedTime:0,pseudoElement:0}),Ag=ma(Tg),Cg=N({},Rs,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Dg=ma(Cg),_g=N({},an,{newState:0,oldState:0}),Mg=ma(_g),Eg=[9,13,27,32],Sr=lt&&"CompositionEvent"in window,yl=null;lt&&"documentMode"in document&&(yl=document.documentMode);var Rg=lt&&"TextEvent"in window&&!yl,Bd=lt&&(!Sr||yl&&8<yl&&11>=yl),$d=" ",qd=!1;function Id(e,t){switch(e){case"keyup":return Eg.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Pd(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var Dn=!1;function Ug(e,t){switch(e){case"compositionend":return Pd(t);case"keypress":return t.which!==32?null:(qd=!0,$d);case"textInput":return e=t.data,e===$d&&qd?null:e;default:return null}}function Lg(e,t){if(Dn)return e==="compositionend"||!Sr&&Id(e,t)?(e=Ud(),Ds=br=zt=null,Dn=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Bd&&t.locale!=="ko"?null:t.data;default:return null}}var Og={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Gd(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Og[e.type]:t==="textarea"}function Qd(e,t,n,l){An?Cn?Cn.push(l):Cn=[l]:An=l,t=ki(t,"onChange"),0<t.length&&(n=new Es("onChange","change",null,n,l),e.push({event:n,listeners:t}))}var Nl=null,kl=null;function Hg(e){Ah(e,0)}function Us(e){var t=gl(e);if(Td(t))return e}function Yd(e,t){if(e==="change")return t}var Xd=!1;if(lt){var wr;if(lt){var zr="oninput"in document;if(!zr){var Vd=document.createElement("div");Vd.setAttribute("oninput","return;"),zr=typeof Vd.oninput=="function"}wr=zr}else wr=!1;Xd=wr&&(!document.documentMode||9<document.documentMode)}function Jd(){Nl&&(Nl.detachEvent("onpropertychange",Zd),kl=Nl=null)}function Zd(e){if(e.propertyName==="value"&&Us(kl)){var t=[];Qd(t,kl,e,gr(e)),Rd(Hg,t)}}function Kg(e,t,n){e==="focusin"?(Jd(),Nl=t,kl=n,Nl.attachEvent("onpropertychange",Zd)):e==="focusout"&&Jd()}function Bg(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Us(kl)}function $g(e,t){if(e==="click")return Us(t)}function qg(e,t){if(e==="input"||e==="change")return Us(t)}function Ig(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var ka=typeof Object.is=="function"?Object.is:Ig;function Sl(e,t){if(ka(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),l=Object.keys(t);if(n.length!==l.length)return!1;for(l=0;l<n.length;l++){var s=n[l];if(!nr.call(t,s)||!ka(e[s],t[s]))return!1}return!0}function Wd(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Fd(e,t){var n=Wd(e);e=0;for(var l;n;){if(n.nodeType===3){if(l=e+n.textContent.length,e<=t&&l>=t)return{node:n,offset:t-e};e=l}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=Wd(n)}}function eu(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?eu(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function au(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=As(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=As(e.document)}return t}function Tr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var Pg=lt&&"documentMode"in document&&11>=document.documentMode,_n=null,Ar=null,wl=null,Cr=!1;function tu(e,t,n){var l=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Cr||_n==null||_n!==As(l)||(l=_n,"selectionStart"in l&&Tr(l)?l={start:l.selectionStart,end:l.selectionEnd}:(l=(l.ownerDocument&&l.ownerDocument.defaultView||window).getSelection(),l={anchorNode:l.anchorNode,anchorOffset:l.anchorOffset,focusNode:l.focusNode,focusOffset:l.focusOffset}),wl&&Sl(wl,l)||(wl=l,l=ki(Ar,"onSelect"),0<l.length&&(t=new Es("onSelect","select",null,t,n),e.push({event:t,listeners:l}),t.target=_n)))}function tn(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var Mn={animationend:tn("Animation","AnimationEnd"),animationiteration:tn("Animation","AnimationIteration"),animationstart:tn("Animation","AnimationStart"),transitionrun:tn("Transition","TransitionRun"),transitionstart:tn("Transition","TransitionStart"),transitioncancel:tn("Transition","TransitionCancel"),transitionend:tn("Transition","TransitionEnd")},Dr={},nu={};lt&&(nu=document.createElement("div").style,"AnimationEvent"in window||(delete Mn.animationend.animation,delete Mn.animationiteration.animation,delete Mn.animationstart.animation),"TransitionEvent"in window||delete Mn.transitionend.transition);function nn(e){if(Dr[e])return Dr[e];if(!Mn[e])return e;var t=Mn[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in nu)return Dr[e]=t[n];return e}var lu=nn("animationend"),su=nn("animationiteration"),iu=nn("animationstart"),Gg=nn("transitionrun"),Qg=nn("transitionstart"),Yg=nn("transitioncancel"),ru=nn("transitionend"),cu=new Map,_r="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");_r.push("scrollEnd");function Ia(e,t){cu.set(e,t),en(t,[e])}var Ls=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Ea=[],En=0,Mr=0;function Os(){for(var e=En,t=Mr=En=0;t<e;){var n=Ea[t];Ea[t++]=null;var l=Ea[t];Ea[t++]=null;var s=Ea[t];Ea[t++]=null;var i=Ea[t];if(Ea[t++]=null,l!==null&&s!==null){var d=l.pending;d===null?s.next=s:(s.next=d.next,d.next=s),l.pending=s}i!==0&&ou(n,s,i)}}function Hs(e,t,n,l){Ea[En++]=e,Ea[En++]=t,Ea[En++]=n,Ea[En++]=l,Mr|=l,e.lanes|=l,e=e.alternate,e!==null&&(e.lanes|=l)}function Er(e,t,n,l){return Hs(e,t,n,l),Ks(e)}function ln(e,t){return Hs(e,null,null,t),Ks(e)}function ou(e,t,n){e.lanes|=n;var l=e.alternate;l!==null&&(l.lanes|=n);for(var s=!1,i=e.return;i!==null;)i.childLanes|=n,l=i.alternate,l!==null&&(l.childLanes|=n),i.tag===22&&(e=i.stateNode,e===null||e._visibility&1||(s=!0)),e=i,i=i.return;return e.tag===3?(i=e.stateNode,s&&t!==null&&(s=31-Na(n),e=i.hiddenUpdates,l=e[s],l===null?e[s]=[t]:l.push(t),t.lane=n|536870912),i):null}function Ks(e){if(50<Yl)throw Yl=0,qc=null,Error(o(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Rn={};function Xg(e,t,n,l){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=l,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Sa(e,t,n,l){return new Xg(e,t,n,l)}function Rr(e){return e=e.prototype,!(!e||!e.isReactComponent)}function st(e,t){var n=e.alternate;return n===null?(n=Sa(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&65011712,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function du(e,t){e.flags&=65011714;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function Bs(e,t,n,l,s,i){var d=0;if(l=e,typeof e=="function")Rr(e)&&(d=1);else if(typeof e=="string")d=Fx(e,n,te.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(e){case K:return e=Sa(31,n,t,s),e.elementType=K,e.lanes=i,e;case R:return sn(n.children,s,i,t);case j:d=8,s|=24;break;case w:return e=Sa(12,n,t,s|2),e.elementType=w,e.lanes=i,e;case $:return e=Sa(13,n,t,s),e.elementType=$,e.lanes=i,e;case _:return e=Sa(19,n,t,s),e.elementType=_,e.lanes=i,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case k:d=10;break e;case C:d=9;break e;case Q:d=11;break e;case U:d=14;break e;case L:d=16,l=null;break e}d=29,n=Error(o(130,e===null?"null":typeof e,"")),l=null}return t=Sa(d,n,t,s),t.elementType=e,t.type=l,t.lanes=i,t}function sn(e,t,n,l){return e=Sa(7,e,l,t),e.lanes=n,e}function Ur(e,t,n){return e=Sa(6,e,null,t),e.lanes=n,e}function uu(e){var t=Sa(18,null,null,0);return t.stateNode=e,t}function Lr(e,t,n){return t=Sa(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var mu=new WeakMap;function Ra(e,t){if(typeof e=="object"&&e!==null){var n=mu.get(e);return n!==void 0?n:(t={value:e,source:t,stack:ud(t)},mu.set(e,t),t)}return{value:e,source:t,stack:ud(t)}}var Un=[],Ln=0,$s=null,zl=0,Ua=[],La=0,Tt=null,Qa=1,Ya="";function it(e,t){Un[Ln++]=zl,Un[Ln++]=$s,$s=e,zl=t}function hu(e,t,n){Ua[La++]=Qa,Ua[La++]=Ya,Ua[La++]=Tt,Tt=e;var l=Qa;e=Ya;var s=32-Na(l)-1;l&=~(1<<s),n+=1;var i=32-Na(t)+s;if(30<i){var d=s-s%5;i=(l&(1<<d)-1).toString(32),l>>=d,s-=d,Qa=1<<32-Na(t)+s|n<<s|l,Ya=i+e}else Qa=1<<i|n<<s|l,Ya=e}function Or(e){e.return!==null&&(it(e,1),hu(e,1,0))}function Hr(e){for(;e===$s;)$s=Un[--Ln],Un[Ln]=null,zl=Un[--Ln],Un[Ln]=null;for(;e===Tt;)Tt=Ua[--La],Ua[La]=null,Ya=Ua[--La],Ua[La]=null,Qa=Ua[--La],Ua[La]=null}function pu(e,t){Ua[La++]=Qa,Ua[La++]=Ya,Ua[La++]=Tt,Qa=t.id,Ya=t.overflow,Tt=e}var ta=null,Re=null,ye=!1,At=null,Oa=!1,Kr=Error(o(519));function Ct(e){var t=Error(o(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Tl(Ra(t,e)),Kr}function fu(e){var t=e.stateNode,n=e.type,l=e.memoizedProps;switch(t[aa]=e,t[ua]=l,n){case"dialog":ge("cancel",t),ge("close",t);break;case"iframe":case"object":case"embed":ge("load",t);break;case"video":case"audio":for(n=0;n<Vl.length;n++)ge(Vl[n],t);break;case"source":ge("error",t);break;case"img":case"image":case"link":ge("error",t),ge("load",t);break;case"details":ge("toggle",t);break;case"input":ge("invalid",t),Ad(t,l.value,l.defaultValue,l.checked,l.defaultChecked,l.type,l.name,!0);break;case"select":ge("invalid",t);break;case"textarea":ge("invalid",t),Dd(t,l.value,l.defaultValue,l.children)}n=l.children,typeof n!="string"&&typeof n!="number"&&typeof n!="bigint"||t.textContent===""+n||l.suppressHydrationWarning===!0||Mh(t.textContent,n)?(l.popover!=null&&(ge("beforetoggle",t),ge("toggle",t)),l.onScroll!=null&&ge("scroll",t),l.onScrollEnd!=null&&ge("scrollend",t),l.onClick!=null&&(t.onclick=nt),t=!0):t=!1,t||Ct(e,!0)}function gu(e){for(ta=e.return;ta;)switch(ta.tag){case 5:case 31:case 13:Oa=!1;return;case 27:case 3:Oa=!0;return;default:ta=ta.return}}function On(e){if(e!==ta)return!1;if(!ye)return gu(e),ye=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=!(n!=="form"&&n!=="button")||no(e.type,e.memoizedProps)),n=!n),n&&Re&&Ct(e),gu(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(o(317));Re=$h(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(o(317));Re=$h(e)}else t===27?(t=Re,It(e.type)?(e=co,co=null,Re=e):Re=t):Re=ta?Ka(e.stateNode.nextSibling):null;return!0}function rn(){Re=ta=null,ye=!1}function Br(){var e=At;return e!==null&&(ga===null?ga=e:ga.push.apply(ga,e),At=null),e}function Tl(e){At===null?At=[e]:At.push(e)}var $r=M(null),cn=null,rt=null;function Dt(e,t,n){ee($r,t._currentValue),t._currentValue=n}function ct(e){e._currentValue=$r.current,Z($r)}function qr(e,t,n){for(;e!==null;){var l=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,l!==null&&(l.childLanes|=t)):l!==null&&(l.childLanes&t)!==t&&(l.childLanes|=t),e===n)break;e=e.return}}function Ir(e,t,n,l){var s=e.child;for(s!==null&&(s.return=e);s!==null;){var i=s.dependencies;if(i!==null){var d=s.child;i=i.firstContext;e:for(;i!==null;){var f=i;i=s;for(var T=0;T<t.length;T++)if(f.context===t[T]){i.lanes|=n,f=i.alternate,f!==null&&(f.lanes|=n),qr(i.return,n,e),l||(d=null);break e}i=f.next}}else if(s.tag===18){if(d=s.return,d===null)throw Error(o(341));d.lanes|=n,i=d.alternate,i!==null&&(i.lanes|=n),qr(d,n,e),d=null}else d=s.child;if(d!==null)d.return=s;else for(d=s;d!==null;){if(d===e){d=null;break}if(s=d.sibling,s!==null){s.return=d.return,d=s;break}d=d.return}s=d}}function Hn(e,t,n,l){e=null;for(var s=t,i=!1;s!==null;){if(!i){if((s.flags&524288)!==0)i=!0;else if((s.flags&262144)!==0)break}if(s.tag===10){var d=s.alternate;if(d===null)throw Error(o(387));if(d=d.memoizedProps,d!==null){var f=s.type;ka(s.pendingProps.value,d.value)||(e!==null?e.push(f):e=[f])}}else if(s===ze.current){if(d=s.alternate,d===null)throw Error(o(387));d.memoizedState.memoizedState!==s.memoizedState.memoizedState&&(e!==null?e.push(es):e=[es])}s=s.return}e!==null&&Ir(t,e,n,l),t.flags|=262144}function qs(e){for(e=e.firstContext;e!==null;){if(!ka(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function on(e){cn=e,rt=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function na(e){return xu(cn,e)}function Is(e,t){return cn===null&&on(e),xu(e,t)}function xu(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},rt===null){if(e===null)throw Error(o(308));rt=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else rt=rt.next=t;return n}var Vg=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(n,l){e.push(l)}};this.abort=function(){t.aborted=!0,e.forEach(function(n){return n()})}},Jg=r.unstable_scheduleCallback,Zg=r.unstable_NormalPriority,Ge={$$typeof:k,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Pr(){return{controller:new Vg,data:new Map,refCount:0}}function Al(e){e.refCount--,e.refCount===0&&Jg(Zg,function(){e.controller.abort()})}var Cl=null,Gr=0,Kn=0,Bn=null;function Wg(e,t){if(Cl===null){var n=Cl=[];Gr=0,Kn=Xc(),Bn={status:"pending",value:void 0,then:function(l){n.push(l)}}}return Gr++,t.then(vu,vu),t}function vu(){if(--Gr===0&&Cl!==null){Bn!==null&&(Bn.status="fulfilled");var e=Cl;Cl=null,Kn=0,Bn=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function Fg(e,t){var n=[],l={status:"pending",value:null,reason:null,then:function(s){n.push(s)}};return e.then(function(){l.status="fulfilled",l.value=t;for(var s=0;s<n.length;s++)(0,n[s])(t)},function(s){for(l.status="rejected",l.reason=s,s=0;s<n.length;s++)(0,n[s])(void 0)}),l}var bu=I.S;I.S=function(e,t){th=ja(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&Wg(e,t),bu!==null&&bu(e,t)};var dn=M(null);function Qr(){var e=dn.current;return e!==null?e:Me.pooledCache}function Ps(e,t){t===null?ee(dn,dn.current):ee(dn,t.pool)}function ju(){var e=Qr();return e===null?null:{parent:Ge._currentValue,pool:e}}var $n=Error(o(460)),Yr=Error(o(474)),Gs=Error(o(542)),Qs={then:function(){}};function yu(e){return e=e.status,e==="fulfilled"||e==="rejected"}function Nu(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(nt,nt),t=n),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Su(e),e;default:if(typeof t.status=="string")t.then(nt,nt);else{if(e=Me,e!==null&&100<e.shellSuspendCounter)throw Error(o(482));e=t,e.status="pending",e.then(function(l){if(t.status==="pending"){var s=t;s.status="fulfilled",s.value=l}},function(l){if(t.status==="pending"){var s=t;s.status="rejected",s.reason=l}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Su(e),e}throw mn=t,$n}}function un(e){try{var t=e._init;return t(e._payload)}catch(n){throw n!==null&&typeof n=="object"&&typeof n.then=="function"?(mn=n,$n):n}}var mn=null;function ku(){if(mn===null)throw Error(o(459));var e=mn;return mn=null,e}function Su(e){if(e===$n||e===Gs)throw Error(o(483))}var qn=null,Dl=0;function Ys(e){var t=Dl;return Dl+=1,qn===null&&(qn=[]),Nu(qn,e,t)}function _l(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function Xs(e,t){throw t.$$typeof===S?Error(o(525)):(e=Object.prototype.toString.call(t),Error(o(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function wu(e){function t(E,D){if(e){var O=E.deletions;O===null?(E.deletions=[D],E.flags|=16):O.push(D)}}function n(E,D){if(!e)return null;for(;D!==null;)t(E,D),D=D.sibling;return null}function l(E){for(var D=new Map;E!==null;)E.key!==null?D.set(E.key,E):D.set(E.index,E),E=E.sibling;return D}function s(E,D){return E=st(E,D),E.index=0,E.sibling=null,E}function i(E,D,O){return E.index=O,e?(O=E.alternate,O!==null?(O=O.index,O<D?(E.flags|=67108866,D):O):(E.flags|=67108866,D)):(E.flags|=1048576,D)}function d(E){return e&&E.alternate===null&&(E.flags|=67108866),E}function f(E,D,O,Y){return D===null||D.tag!==6?(D=Ur(O,E.mode,Y),D.return=E,D):(D=s(D,O),D.return=E,D)}function T(E,D,O,Y){var le=O.type;return le===R?P(E,D,O.props.children,Y,O.key):D!==null&&(D.elementType===le||typeof le=="object"&&le!==null&&le.$$typeof===L&&un(le)===D.type)?(D=s(D,O.props),_l(D,O),D.return=E,D):(D=Bs(O.type,O.key,O.props,null,E.mode,Y),_l(D,O),D.return=E,D)}function H(E,D,O,Y){return D===null||D.tag!==4||D.stateNode.containerInfo!==O.containerInfo||D.stateNode.implementation!==O.implementation?(D=Lr(O,E.mode,Y),D.return=E,D):(D=s(D,O.children||[]),D.return=E,D)}function P(E,D,O,Y,le){return D===null||D.tag!==7?(D=sn(O,E.mode,Y,le),D.return=E,D):(D=s(D,O),D.return=E,D)}function J(E,D,O){if(typeof D=="string"&&D!==""||typeof D=="number"||typeof D=="bigint")return D=Ur(""+D,E.mode,O),D.return=E,D;if(typeof D=="object"&&D!==null){switch(D.$$typeof){case A:return O=Bs(D.type,D.key,D.props,null,E.mode,O),_l(O,D),O.return=E,O;case v:return D=Lr(D,E.mode,O),D.return=E,D;case L:return D=un(D),J(E,D,O)}if(Oe(D)||se(D))return D=sn(D,E.mode,O,null),D.return=E,D;if(typeof D.then=="function")return J(E,Ys(D),O);if(D.$$typeof===k)return J(E,Is(E,D),O);Xs(E,D)}return null}function B(E,D,O,Y){var le=D!==null?D.key:null;if(typeof O=="string"&&O!==""||typeof O=="number"||typeof O=="bigint")return le!==null?null:f(E,D,""+O,Y);if(typeof O=="object"&&O!==null){switch(O.$$typeof){case A:return O.key===le?T(E,D,O,Y):null;case v:return O.key===le?H(E,D,O,Y):null;case L:return O=un(O),B(E,D,O,Y)}if(Oe(O)||se(O))return le!==null?null:P(E,D,O,Y,null);if(typeof O.then=="function")return B(E,D,Ys(O),Y);if(O.$$typeof===k)return B(E,D,Is(E,O),Y);Xs(E,O)}return null}function q(E,D,O,Y,le){if(typeof Y=="string"&&Y!==""||typeof Y=="number"||typeof Y=="bigint")return E=E.get(O)||null,f(D,E,""+Y,le);if(typeof Y=="object"&&Y!==null){switch(Y.$$typeof){case A:return E=E.get(Y.key===null?O:Y.key)||null,T(D,E,Y,le);case v:return E=E.get(Y.key===null?O:Y.key)||null,H(D,E,Y,le);case L:return Y=un(Y),q(E,D,O,Y,le)}if(Oe(Y)||se(Y))return E=E.get(O)||null,P(D,E,Y,le,null);if(typeof Y.then=="function")return q(E,D,O,Ys(Y),le);if(Y.$$typeof===k)return q(E,D,O,Is(D,Y),le);Xs(D,Y)}return null}function ae(E,D,O,Y){for(var le=null,ke=null,ne=D,he=D=0,je=null;ne!==null&&he<O.length;he++){ne.index>he?(je=ne,ne=null):je=ne.sibling;var Se=B(E,ne,O[he],Y);if(Se===null){ne===null&&(ne=je);break}e&&ne&&Se.alternate===null&&t(E,ne),D=i(Se,D,he),ke===null?le=Se:ke.sibling=Se,ke=Se,ne=je}if(he===O.length)return n(E,ne),ye&&it(E,he),le;if(ne===null){for(;he<O.length;he++)ne=J(E,O[he],Y),ne!==null&&(D=i(ne,D,he),ke===null?le=ne:ke.sibling=ne,ke=ne);return ye&&it(E,he),le}for(ne=l(ne);he<O.length;he++)je=q(ne,E,he,O[he],Y),je!==null&&(e&&je.alternate!==null&&ne.delete(je.key===null?he:je.key),D=i(je,D,he),ke===null?le=je:ke.sibling=je,ke=je);return e&&ne.forEach(function(Xt){return t(E,Xt)}),ye&&it(E,he),le}function re(E,D,O,Y){if(O==null)throw Error(o(151));for(var le=null,ke=null,ne=D,he=D=0,je=null,Se=O.next();ne!==null&&!Se.done;he++,Se=O.next()){ne.index>he?(je=ne,ne=null):je=ne.sibling;var Xt=B(E,ne,Se.value,Y);if(Xt===null){ne===null&&(ne=je);break}e&&ne&&Xt.alternate===null&&t(E,ne),D=i(Xt,D,he),ke===null?le=Xt:ke.sibling=Xt,ke=Xt,ne=je}if(Se.done)return n(E,ne),ye&&it(E,he),le;if(ne===null){for(;!Se.done;he++,Se=O.next())Se=J(E,Se.value,Y),Se!==null&&(D=i(Se,D,he),ke===null?le=Se:ke.sibling=Se,ke=Se);return ye&&it(E,he),le}for(ne=l(ne);!Se.done;he++,Se=O.next())Se=q(ne,E,he,Se.value,Y),Se!==null&&(e&&Se.alternate!==null&&ne.delete(Se.key===null?he:Se.key),D=i(Se,D,he),ke===null?le=Se:ke.sibling=Se,ke=Se);return e&&ne.forEach(function(d0){return t(E,d0)}),ye&&it(E,he),le}function _e(E,D,O,Y){if(typeof O=="object"&&O!==null&&O.type===R&&O.key===null&&(O=O.props.children),typeof O=="object"&&O!==null){switch(O.$$typeof){case A:e:{for(var le=O.key;D!==null;){if(D.key===le){if(le=O.type,le===R){if(D.tag===7){n(E,D.sibling),Y=s(D,O.props.children),Y.return=E,E=Y;break e}}else if(D.elementType===le||typeof le=="object"&&le!==null&&le.$$typeof===L&&un(le)===D.type){n(E,D.sibling),Y=s(D,O.props),_l(Y,O),Y.return=E,E=Y;break e}n(E,D);break}else t(E,D);D=D.sibling}O.type===R?(Y=sn(O.props.children,E.mode,Y,O.key),Y.return=E,E=Y):(Y=Bs(O.type,O.key,O.props,null,E.mode,Y),_l(Y,O),Y.return=E,E=Y)}return d(E);case v:e:{for(le=O.key;D!==null;){if(D.key===le)if(D.tag===4&&D.stateNode.containerInfo===O.containerInfo&&D.stateNode.implementation===O.implementation){n(E,D.sibling),Y=s(D,O.children||[]),Y.return=E,E=Y;break e}else{n(E,D);break}else t(E,D);D=D.sibling}Y=Lr(O,E.mode,Y),Y.return=E,E=Y}return d(E);case L:return O=un(O),_e(E,D,O,Y)}if(Oe(O))return ae(E,D,O,Y);if(se(O)){if(le=se(O),typeof le!="function")throw Error(o(150));return O=le.call(O),re(E,D,O,Y)}if(typeof O.then=="function")return _e(E,D,Ys(O),Y);if(O.$$typeof===k)return _e(E,D,Is(E,O),Y);Xs(E,O)}return typeof O=="string"&&O!==""||typeof O=="number"||typeof O=="bigint"?(O=""+O,D!==null&&D.tag===6?(n(E,D.sibling),Y=s(D,O),Y.return=E,E=Y):(n(E,D),Y=Ur(O,E.mode,Y),Y.return=E,E=Y),d(E)):n(E,D)}return function(E,D,O,Y){try{Dl=0;var le=_e(E,D,O,Y);return qn=null,le}catch(ne){if(ne===$n||ne===Gs)throw ne;var ke=Sa(29,ne,null,E.mode);return ke.lanes=Y,ke.return=E,ke}}}var hn=wu(!0),zu=wu(!1),_t=!1;function Xr(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Vr(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Mt(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Et(e,t,n){var l=e.updateQueue;if(l===null)return null;if(l=l.shared,(we&2)!==0){var s=l.pending;return s===null?t.next=t:(t.next=s.next,s.next=t),l.pending=t,t=Ks(e),ou(e,null,n),t}return Hs(e,l,t,n),Ks(e)}function Ml(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194048)!==0)){var l=t.lanes;l&=e.pendingLanes,n|=l,t.lanes=n,xd(e,n)}}function Jr(e,t){var n=e.updateQueue,l=e.alternate;if(l!==null&&(l=l.updateQueue,n===l)){var s=null,i=null;if(n=n.firstBaseUpdate,n!==null){do{var d={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};i===null?s=i=d:i=i.next=d,n=n.next}while(n!==null);i===null?s=i=t:i=i.next=t}else s=i=t;n={baseState:l.baseState,firstBaseUpdate:s,lastBaseUpdate:i,shared:l.shared,callbacks:l.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var Zr=!1;function El(){if(Zr){var e=Bn;if(e!==null)throw e}}function Rl(e,t,n,l){Zr=!1;var s=e.updateQueue;_t=!1;var i=s.firstBaseUpdate,d=s.lastBaseUpdate,f=s.shared.pending;if(f!==null){s.shared.pending=null;var T=f,H=T.next;T.next=null,d===null?i=H:d.next=H,d=T;var P=e.alternate;P!==null&&(P=P.updateQueue,f=P.lastBaseUpdate,f!==d&&(f===null?P.firstBaseUpdate=H:f.next=H,P.lastBaseUpdate=T))}if(i!==null){var J=s.baseState;d=0,P=H=T=null,f=i;do{var B=f.lane&-536870913,q=B!==f.lane;if(q?(be&B)===B:(l&B)===B){B!==0&&B===Kn&&(Zr=!0),P!==null&&(P=P.next={lane:0,tag:f.tag,payload:f.payload,callback:null,next:null});e:{var ae=e,re=f;B=t;var _e=n;switch(re.tag){case 1:if(ae=re.payload,typeof ae=="function"){J=ae.call(_e,J,B);break e}J=ae;break e;case 3:ae.flags=ae.flags&-65537|128;case 0:if(ae=re.payload,B=typeof ae=="function"?ae.call(_e,J,B):ae,B==null)break e;J=N({},J,B);break e;case 2:_t=!0}}B=f.callback,B!==null&&(e.flags|=64,q&&(e.flags|=8192),q=s.callbacks,q===null?s.callbacks=[B]:q.push(B))}else q={lane:B,tag:f.tag,payload:f.payload,callback:f.callback,next:null},P===null?(H=P=q,T=J):P=P.next=q,d|=B;if(f=f.next,f===null){if(f=s.shared.pending,f===null)break;q=f,f=q.next,q.next=null,s.lastBaseUpdate=q,s.shared.pending=null}}while(!0);P===null&&(T=J),s.baseState=T,s.firstBaseUpdate=H,s.lastBaseUpdate=P,i===null&&(s.shared.lanes=0),Ht|=d,e.lanes=d,e.memoizedState=J}}function Tu(e,t){if(typeof e!="function")throw Error(o(191,e));e.call(t)}function Au(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)Tu(n[e],t)}var In=M(null),Vs=M(0);function Cu(e,t){e=xt,ee(Vs,e),ee(In,t),xt=e|t.baseLanes}function Wr(){ee(Vs,xt),ee(In,In.current)}function Fr(){xt=Vs.current,Z(In),Z(Vs)}var wa=M(null),Ha=null;function Rt(e){var t=e.alternate;ee(Ie,Ie.current&1),ee(wa,e),Ha===null&&(t===null||In.current!==null||t.memoizedState!==null)&&(Ha=e)}function ec(e){ee(Ie,Ie.current),ee(wa,e),Ha===null&&(Ha=e)}function Du(e){e.tag===22?(ee(Ie,Ie.current),ee(wa,e),Ha===null&&(Ha=e)):Ut()}function Ut(){ee(Ie,Ie.current),ee(wa,wa.current)}function za(e){Z(wa),Ha===e&&(Ha=null),Z(Ie)}var Ie=M(0);function Js(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||io(n)||ro(n)))return t}else if(t.tag===19&&(t.memoizedProps.revealOrder==="forwards"||t.memoizedProps.revealOrder==="backwards"||t.memoizedProps.revealOrder==="unstable_legacy-backwards"||t.memoizedProps.revealOrder==="together")){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var ot=0,me=null,Ce=null,Qe=null,Zs=!1,Pn=!1,pn=!1,Ws=0,Ul=0,Gn=null,ex=0;function Be(){throw Error(o(321))}function ac(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!ka(e[n],t[n]))return!1;return!0}function tc(e,t,n,l,s,i){return ot=i,me=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,I.H=e===null||e.memoizedState===null?hm:xc,pn=!1,i=n(l,s),pn=!1,Pn&&(i=Mu(t,n,l,s)),_u(e),i}function _u(e){I.H=Hl;var t=Ce!==null&&Ce.next!==null;if(ot=0,Qe=Ce=me=null,Zs=!1,Ul=0,Gn=null,t)throw Error(o(300));e===null||Ye||(e=e.dependencies,e!==null&&qs(e)&&(Ye=!0))}function Mu(e,t,n,l){me=e;var s=0;do{if(Pn&&(Gn=null),Ul=0,Pn=!1,25<=s)throw Error(o(301));if(s+=1,Qe=Ce=null,e.updateQueue!=null){var i=e.updateQueue;i.lastEffect=null,i.events=null,i.stores=null,i.memoCache!=null&&(i.memoCache.index=0)}I.H=pm,i=t(n,l)}while(Pn);return i}function ax(){var e=I.H,t=e.useState()[0];return t=typeof t.then=="function"?Ll(t):t,e=e.useState()[0],(Ce!==null?Ce.memoizedState:null)!==e&&(me.flags|=1024),t}function nc(){var e=Ws!==0;return Ws=0,e}function lc(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function sc(e){if(Zs){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Zs=!1}ot=0,Qe=Ce=me=null,Pn=!1,Ul=Ws=0,Gn=null}function oa(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Qe===null?me.memoizedState=Qe=e:Qe=Qe.next=e,Qe}function Pe(){if(Ce===null){var e=me.alternate;e=e!==null?e.memoizedState:null}else e=Ce.next;var t=Qe===null?me.memoizedState:Qe.next;if(t!==null)Qe=t,Ce=e;else{if(e===null)throw me.alternate===null?Error(o(467)):Error(o(310));Ce=e,e={memoizedState:Ce.memoizedState,baseState:Ce.baseState,baseQueue:Ce.baseQueue,queue:Ce.queue,next:null},Qe===null?me.memoizedState=Qe=e:Qe=Qe.next=e}return Qe}function Fs(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Ll(e){var t=Ul;return Ul+=1,Gn===null&&(Gn=[]),e=Nu(Gn,e,t),t=me,(Qe===null?t.memoizedState:Qe.next)===null&&(t=t.alternate,I.H=t===null||t.memoizedState===null?hm:xc),e}function ei(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return Ll(e);if(e.$$typeof===k)return na(e)}throw Error(o(438,String(e)))}function ic(e){var t=null,n=me.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var l=me.alternate;l!==null&&(l=l.updateQueue,l!==null&&(l=l.memoCache,l!=null&&(t={data:l.data.map(function(s){return s.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),n===null&&(n=Fs(),me.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),l=0;l<e;l++)n[l]=V;return t.index++,n}function dt(e,t){return typeof t=="function"?t(e):t}function ai(e){var t=Pe();return rc(t,Ce,e)}function rc(e,t,n){var l=e.queue;if(l===null)throw Error(o(311));l.lastRenderedReducer=n;var s=e.baseQueue,i=l.pending;if(i!==null){if(s!==null){var d=s.next;s.next=i.next,i.next=d}t.baseQueue=s=i,l.pending=null}if(i=e.baseState,s===null)e.memoizedState=i;else{t=s.next;var f=d=null,T=null,H=t,P=!1;do{var J=H.lane&-536870913;if(J!==H.lane?(be&J)===J:(ot&J)===J){var B=H.revertLane;if(B===0)T!==null&&(T=T.next={lane:0,revertLane:0,gesture:null,action:H.action,hasEagerState:H.hasEagerState,eagerState:H.eagerState,next:null}),J===Kn&&(P=!0);else if((ot&B)===B){H=H.next,B===Kn&&(P=!0);continue}else J={lane:0,revertLane:H.revertLane,gesture:null,action:H.action,hasEagerState:H.hasEagerState,eagerState:H.eagerState,next:null},T===null?(f=T=J,d=i):T=T.next=J,me.lanes|=B,Ht|=B;J=H.action,pn&&n(i,J),i=H.hasEagerState?H.eagerState:n(i,J)}else B={lane:J,revertLane:H.revertLane,gesture:H.gesture,action:H.action,hasEagerState:H.hasEagerState,eagerState:H.eagerState,next:null},T===null?(f=T=B,d=i):T=T.next=B,me.lanes|=J,Ht|=J;H=H.next}while(H!==null&&H!==t);if(T===null?d=i:T.next=f,!ka(i,e.memoizedState)&&(Ye=!0,P&&(n=Bn,n!==null)))throw n;e.memoizedState=i,e.baseState=d,e.baseQueue=T,l.lastRenderedState=i}return s===null&&(l.lanes=0),[e.memoizedState,l.dispatch]}function cc(e){var t=Pe(),n=t.queue;if(n===null)throw Error(o(311));n.lastRenderedReducer=e;var l=n.dispatch,s=n.pending,i=t.memoizedState;if(s!==null){n.pending=null;var d=s=s.next;do i=e(i,d.action),d=d.next;while(d!==s);ka(i,t.memoizedState)||(Ye=!0),t.memoizedState=i,t.baseQueue===null&&(t.baseState=i),n.lastRenderedState=i}return[i,l]}function Eu(e,t,n){var l=me,s=Pe(),i=ye;if(i){if(n===void 0)throw Error(o(407));n=n()}else n=t();var d=!ka((Ce||s).memoizedState,n);if(d&&(s.memoizedState=n,Ye=!0),s=s.queue,uc(Lu.bind(null,l,s,e),[e]),s.getSnapshot!==t||d||Qe!==null&&Qe.memoizedState.tag&1){if(l.flags|=2048,Qn(9,{destroy:void 0},Uu.bind(null,l,s,n,t),null),Me===null)throw Error(o(349));i||(ot&127)!==0||Ru(l,t,n)}return n}function Ru(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=me.updateQueue,t===null?(t=Fs(),me.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Uu(e,t,n,l){t.value=n,t.getSnapshot=l,Ou(t)&&Hu(e)}function Lu(e,t,n){return n(function(){Ou(t)&&Hu(e)})}function Ou(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!ka(e,n)}catch{return!0}}function Hu(e){var t=ln(e,2);t!==null&&xa(t,e,2)}function oc(e){var t=oa();if(typeof e=="function"){var n=e;if(e=n(),pn){St(!0);try{n()}finally{St(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:dt,lastRenderedState:e},t}function Ku(e,t,n,l){return e.baseState=n,rc(e,Ce,typeof l=="function"?l:dt)}function tx(e,t,n,l,s){if(li(e))throw Error(o(485));if(e=t.action,e!==null){var i={payload:s,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(d){i.listeners.push(d)}};I.T!==null?n(!0):i.isTransition=!1,l(i),n=t.pending,n===null?(i.next=t.pending=i,Bu(t,i)):(i.next=n.next,t.pending=n.next=i)}}function Bu(e,t){var n=t.action,l=t.payload,s=e.state;if(t.isTransition){var i=I.T,d={};I.T=d;try{var f=n(s,l),T=I.S;T!==null&&T(d,f),$u(e,t,f)}catch(H){dc(e,t,H)}finally{i!==null&&d.types!==null&&(i.types=d.types),I.T=i}}else try{i=n(s,l),$u(e,t,i)}catch(H){dc(e,t,H)}}function $u(e,t,n){n!==null&&typeof n=="object"&&typeof n.then=="function"?n.then(function(l){qu(e,t,l)},function(l){return dc(e,t,l)}):qu(e,t,n)}function qu(e,t,n){t.status="fulfilled",t.value=n,Iu(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Bu(e,n)))}function dc(e,t,n){var l=e.pending;if(e.pending=null,l!==null){l=l.next;do t.status="rejected",t.reason=n,Iu(t),t=t.next;while(t!==l)}e.action=null}function Iu(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Pu(e,t){return t}function Gu(e,t){if(ye){var n=Me.formState;if(n!==null){e:{var l=me;if(ye){if(Re){a:{for(var s=Re,i=Oa;s.nodeType!==8;){if(!i){s=null;break a}if(s=Ka(s.nextSibling),s===null){s=null;break a}}i=s.data,s=i==="F!"||i==="F"?s:null}if(s){Re=Ka(s.nextSibling),l=s.data==="F!";break e}}Ct(l)}l=!1}l&&(t=n[0])}}return n=oa(),n.memoizedState=n.baseState=t,l={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Pu,lastRenderedState:t},n.queue=l,n=dm.bind(null,me,l),l.dispatch=n,l=oc(!1),i=gc.bind(null,me,!1,l.queue),l=oa(),s={state:t,dispatch:null,action:e,pending:null},l.queue=s,n=tx.bind(null,me,s,i,n),s.dispatch=n,l.memoizedState=e,[t,n,!1]}function Qu(e){var t=Pe();return Yu(t,Ce,e)}function Yu(e,t,n){if(t=rc(e,t,Pu)[0],e=ai(dt)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var l=Ll(t)}catch(d){throw d===$n?Gs:d}else l=t;t=Pe();var s=t.queue,i=s.dispatch;return n!==t.memoizedState&&(me.flags|=2048,Qn(9,{destroy:void 0},nx.bind(null,s,n),null)),[l,i,e]}function nx(e,t){e.action=t}function Xu(e){var t=Pe(),n=Ce;if(n!==null)return Yu(t,n,e);Pe(),t=t.memoizedState,n=Pe();var l=n.queue.dispatch;return n.memoizedState=e,[t,l,!1]}function Qn(e,t,n,l){return e={tag:e,create:n,deps:l,inst:t,next:null},t=me.updateQueue,t===null&&(t=Fs(),me.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(l=n.next,n.next=e,e.next=l,t.lastEffect=e),e}function Vu(){return Pe().memoizedState}function ti(e,t,n,l){var s=oa();me.flags|=e,s.memoizedState=Qn(1|t,{destroy:void 0},n,l===void 0?null:l)}function ni(e,t,n,l){var s=Pe();l=l===void 0?null:l;var i=s.memoizedState.inst;Ce!==null&&l!==null&&ac(l,Ce.memoizedState.deps)?s.memoizedState=Qn(t,i,n,l):(me.flags|=e,s.memoizedState=Qn(1|t,i,n,l))}function Ju(e,t){ti(8390656,8,e,t)}function uc(e,t){ni(2048,8,e,t)}function lx(e){me.flags|=4;var t=me.updateQueue;if(t===null)t=Fs(),me.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function Zu(e){var t=Pe().memoizedState;return lx({ref:t,nextImpl:e}),function(){if((we&2)!==0)throw Error(o(440));return t.impl.apply(void 0,arguments)}}function Wu(e,t){return ni(4,2,e,t)}function Fu(e,t){return ni(4,4,e,t)}function em(e,t){if(typeof t=="function"){e=e();var n=t(e);return function(){typeof n=="function"?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function am(e,t,n){n=n!=null?n.concat([e]):null,ni(4,4,em.bind(null,t,e),n)}function mc(){}function tm(e,t){var n=Pe();t=t===void 0?null:t;var l=n.memoizedState;return t!==null&&ac(t,l[1])?l[0]:(n.memoizedState=[e,t],e)}function nm(e,t){var n=Pe();t=t===void 0?null:t;var l=n.memoizedState;if(t!==null&&ac(t,l[1]))return l[0];if(l=e(),pn){St(!0);try{e()}finally{St(!1)}}return n.memoizedState=[l,t],l}function hc(e,t,n){return n===void 0||(ot&1073741824)!==0&&(be&261930)===0?e.memoizedState=t:(e.memoizedState=n,e=lh(),me.lanes|=e,Ht|=e,n)}function lm(e,t,n,l){return ka(n,t)?n:In.current!==null?(e=hc(e,n,l),ka(e,t)||(Ye=!0),e):(ot&42)===0||(ot&1073741824)!==0&&(be&261930)===0?(Ye=!0,e.memoizedState=n):(e=lh(),me.lanes|=e,Ht|=e,t)}function sm(e,t,n,l,s){var i=G.p;G.p=i!==0&&8>i?i:8;var d=I.T,f={};I.T=f,gc(e,!1,t,n);try{var T=s(),H=I.S;if(H!==null&&H(f,T),T!==null&&typeof T=="object"&&typeof T.then=="function"){var P=Fg(T,l);Ol(e,t,P,Ca(e))}else Ol(e,t,l,Ca(e))}catch(J){Ol(e,t,{then:function(){},status:"rejected",reason:J},Ca())}finally{G.p=i,d!==null&&f.types!==null&&(d.types=f.types),I.T=d}}function sx(){}function pc(e,t,n,l){if(e.tag!==5)throw Error(o(476));var s=im(e).queue;sm(e,s,t,W,n===null?sx:function(){return rm(e),n(l)})}function im(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:W,baseState:W,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:dt,lastRenderedState:W},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:dt,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function rm(e){var t=im(e);t.next===null&&(t=e.alternate.memoizedState),Ol(e,t.next.queue,{},Ca())}function fc(){return na(es)}function cm(){return Pe().memoizedState}function om(){return Pe().memoizedState}function ix(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=Ca();e=Mt(n);var l=Et(t,e,n);l!==null&&(xa(l,t,n),Ml(l,t,n)),t={cache:Pr()},e.payload=t;return}t=t.return}}function rx(e,t,n){var l=Ca();n={lane:l,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},li(e)?um(t,n):(n=Er(e,t,n,l),n!==null&&(xa(n,e,l),mm(n,t,l)))}function dm(e,t,n){var l=Ca();Ol(e,t,n,l)}function Ol(e,t,n,l){var s={lane:l,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(li(e))um(t,s);else{var i=e.alternate;if(e.lanes===0&&(i===null||i.lanes===0)&&(i=t.lastRenderedReducer,i!==null))try{var d=t.lastRenderedState,f=i(d,n);if(s.hasEagerState=!0,s.eagerState=f,ka(f,d))return Hs(e,t,s,0),Me===null&&Os(),!1}catch{}if(n=Er(e,t,s,l),n!==null)return xa(n,e,l),mm(n,t,l),!0}return!1}function gc(e,t,n,l){if(l={lane:2,revertLane:Xc(),gesture:null,action:l,hasEagerState:!1,eagerState:null,next:null},li(e)){if(t)throw Error(o(479))}else t=Er(e,n,l,2),t!==null&&xa(t,e,2)}function li(e){var t=e.alternate;return e===me||t!==null&&t===me}function um(e,t){Pn=Zs=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function mm(e,t,n){if((n&4194048)!==0){var l=t.lanes;l&=e.pendingLanes,n|=l,t.lanes=n,xd(e,n)}}var Hl={readContext:na,use:ei,useCallback:Be,useContext:Be,useEffect:Be,useImperativeHandle:Be,useLayoutEffect:Be,useInsertionEffect:Be,useMemo:Be,useReducer:Be,useRef:Be,useState:Be,useDebugValue:Be,useDeferredValue:Be,useTransition:Be,useSyncExternalStore:Be,useId:Be,useHostTransitionStatus:Be,useFormState:Be,useActionState:Be,useOptimistic:Be,useMemoCache:Be,useCacheRefresh:Be};Hl.useEffectEvent=Be;var hm={readContext:na,use:ei,useCallback:function(e,t){return oa().memoizedState=[e,t===void 0?null:t],e},useContext:na,useEffect:Ju,useImperativeHandle:function(e,t,n){n=n!=null?n.concat([e]):null,ti(4194308,4,em.bind(null,t,e),n)},useLayoutEffect:function(e,t){return ti(4194308,4,e,t)},useInsertionEffect:function(e,t){ti(4,2,e,t)},useMemo:function(e,t){var n=oa();t=t===void 0?null:t;var l=e();if(pn){St(!0);try{e()}finally{St(!1)}}return n.memoizedState=[l,t],l},useReducer:function(e,t,n){var l=oa();if(n!==void 0){var s=n(t);if(pn){St(!0);try{n(t)}finally{St(!1)}}}else s=t;return l.memoizedState=l.baseState=s,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:s},l.queue=e,e=e.dispatch=rx.bind(null,me,e),[l.memoizedState,e]},useRef:function(e){var t=oa();return e={current:e},t.memoizedState=e},useState:function(e){e=oc(e);var t=e.queue,n=dm.bind(null,me,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:mc,useDeferredValue:function(e,t){var n=oa();return hc(n,e,t)},useTransition:function(){var e=oc(!1);return e=sm.bind(null,me,e.queue,!0,!1),oa().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var l=me,s=oa();if(ye){if(n===void 0)throw Error(o(407));n=n()}else{if(n=t(),Me===null)throw Error(o(349));(be&127)!==0||Ru(l,t,n)}s.memoizedState=n;var i={value:n,getSnapshot:t};return s.queue=i,Ju(Lu.bind(null,l,i,e),[e]),l.flags|=2048,Qn(9,{destroy:void 0},Uu.bind(null,l,i,n,t),null),n},useId:function(){var e=oa(),t=Me.identifierPrefix;if(ye){var n=Ya,l=Qa;n=(l&~(1<<32-Na(l)-1)).toString(32)+n,t="_"+t+"R_"+n,n=Ws++,0<n&&(t+="H"+n.toString(32)),t+="_"}else n=ex++,t="_"+t+"r_"+n.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:fc,useFormState:Gu,useActionState:Gu,useOptimistic:function(e){var t=oa();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=gc.bind(null,me,!0,n),n.dispatch=t,[e,t]},useMemoCache:ic,useCacheRefresh:function(){return oa().memoizedState=ix.bind(null,me)},useEffectEvent:function(e){var t=oa(),n={impl:e};return t.memoizedState=n,function(){if((we&2)!==0)throw Error(o(440));return n.impl.apply(void 0,arguments)}}},xc={readContext:na,use:ei,useCallback:tm,useContext:na,useEffect:uc,useImperativeHandle:am,useInsertionEffect:Wu,useLayoutEffect:Fu,useMemo:nm,useReducer:ai,useRef:Vu,useState:function(){return ai(dt)},useDebugValue:mc,useDeferredValue:function(e,t){var n=Pe();return lm(n,Ce.memoizedState,e,t)},useTransition:function(){var e=ai(dt)[0],t=Pe().memoizedState;return[typeof e=="boolean"?e:Ll(e),t]},useSyncExternalStore:Eu,useId:cm,useHostTransitionStatus:fc,useFormState:Qu,useActionState:Qu,useOptimistic:function(e,t){var n=Pe();return Ku(n,Ce,e,t)},useMemoCache:ic,useCacheRefresh:om};xc.useEffectEvent=Zu;var pm={readContext:na,use:ei,useCallback:tm,useContext:na,useEffect:uc,useImperativeHandle:am,useInsertionEffect:Wu,useLayoutEffect:Fu,useMemo:nm,useReducer:cc,useRef:Vu,useState:function(){return cc(dt)},useDebugValue:mc,useDeferredValue:function(e,t){var n=Pe();return Ce===null?hc(n,e,t):lm(n,Ce.memoizedState,e,t)},useTransition:function(){var e=cc(dt)[0],t=Pe().memoizedState;return[typeof e=="boolean"?e:Ll(e),t]},useSyncExternalStore:Eu,useId:cm,useHostTransitionStatus:fc,useFormState:Xu,useActionState:Xu,useOptimistic:function(e,t){var n=Pe();return Ce!==null?Ku(n,Ce,e,t):(n.baseState=e,[e,n.queue.dispatch])},useMemoCache:ic,useCacheRefresh:om};pm.useEffectEvent=Zu;function vc(e,t,n,l){t=e.memoizedState,n=n(l,t),n=n==null?t:N({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var bc={enqueueSetState:function(e,t,n){e=e._reactInternals;var l=Ca(),s=Mt(l);s.payload=t,n!=null&&(s.callback=n),t=Et(e,s,l),t!==null&&(xa(t,e,l),Ml(t,e,l))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var l=Ca(),s=Mt(l);s.tag=1,s.payload=t,n!=null&&(s.callback=n),t=Et(e,s,l),t!==null&&(xa(t,e,l),Ml(t,e,l))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=Ca(),l=Mt(n);l.tag=2,t!=null&&(l.callback=t),t=Et(e,l,n),t!==null&&(xa(t,e,n),Ml(t,e,n))}};function fm(e,t,n,l,s,i,d){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(l,i,d):t.prototype&&t.prototype.isPureReactComponent?!Sl(n,l)||!Sl(s,i):!0}function gm(e,t,n,l){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,l),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,l),t.state!==e&&bc.enqueueReplaceState(t,t.state,null)}function fn(e,t){var n=t;if("ref"in t){n={};for(var l in t)l!=="ref"&&(n[l]=t[l])}if(e=e.defaultProps){n===t&&(n=N({},n));for(var s in e)n[s]===void 0&&(n[s]=e[s])}return n}function xm(e){Ls(e)}function vm(e){console.error(e)}function bm(e){Ls(e)}function si(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(l){setTimeout(function(){throw l})}}function jm(e,t,n){try{var l=e.onCaughtError;l(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(s){setTimeout(function(){throw s})}}function jc(e,t,n){return n=Mt(n),n.tag=3,n.payload={element:null},n.callback=function(){si(e,t)},n}function ym(e){return e=Mt(e),e.tag=3,e}function Nm(e,t,n,l){var s=n.type.getDerivedStateFromError;if(typeof s=="function"){var i=l.value;e.payload=function(){return s(i)},e.callback=function(){jm(t,n,l)}}var d=n.stateNode;d!==null&&typeof d.componentDidCatch=="function"&&(e.callback=function(){jm(t,n,l),typeof s!="function"&&(Kt===null?Kt=new Set([this]):Kt.add(this));var f=l.stack;this.componentDidCatch(l.value,{componentStack:f!==null?f:""})})}function cx(e,t,n,l,s){if(n.flags|=32768,l!==null&&typeof l=="object"&&typeof l.then=="function"){if(t=n.alternate,t!==null&&Hn(t,n,s,!0),n=wa.current,n!==null){switch(n.tag){case 31:case 13:return Ha===null?xi():n.alternate===null&&$e===0&&($e=3),n.flags&=-257,n.flags|=65536,n.lanes=s,l===Qs?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([l]):t.add(l),Gc(e,l,s)),!1;case 22:return n.flags|=65536,l===Qs?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([l])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([l]):n.add(l)),Gc(e,l,s)),!1}throw Error(o(435,n.tag))}return Gc(e,l,s),xi(),!1}if(ye)return t=wa.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=s,l!==Kr&&(e=Error(o(422),{cause:l}),Tl(Ra(e,n)))):(l!==Kr&&(t=Error(o(423),{cause:l}),Tl(Ra(t,n))),e=e.current.alternate,e.flags|=65536,s&=-s,e.lanes|=s,l=Ra(l,n),s=jc(e.stateNode,l,s),Jr(e,s),$e!==4&&($e=2)),!1;var i=Error(o(520),{cause:l});if(i=Ra(i,n),Ql===null?Ql=[i]:Ql.push(i),$e!==4&&($e=2),t===null)return!0;l=Ra(l,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=s&-s,n.lanes|=e,e=jc(n.stateNode,l,e),Jr(n,e),!1;case 1:if(t=n.type,i=n.stateNode,(n.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||i!==null&&typeof i.componentDidCatch=="function"&&(Kt===null||!Kt.has(i))))return n.flags|=65536,s&=-s,n.lanes|=s,s=ym(s),Nm(s,e,n,l),Jr(n,s),!1}n=n.return}while(n!==null);return!1}var yc=Error(o(461)),Ye=!1;function la(e,t,n,l){t.child=e===null?zu(t,null,n,l):hn(t,e.child,n,l)}function km(e,t,n,l,s){n=n.render;var i=t.ref;if("ref"in l){var d={};for(var f in l)f!=="ref"&&(d[f]=l[f])}else d=l;return on(t),l=tc(e,t,n,d,i,s),f=nc(),e!==null&&!Ye?(lc(e,t,s),ut(e,t,s)):(ye&&f&&Or(t),t.flags|=1,la(e,t,l,s),t.child)}function Sm(e,t,n,l,s){if(e===null){var i=n.type;return typeof i=="function"&&!Rr(i)&&i.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=i,wm(e,t,i,l,s)):(e=Bs(n.type,null,l,t,t.mode,s),e.ref=t.ref,e.return=t,t.child=e)}if(i=e.child,!Cc(e,s)){var d=i.memoizedProps;if(n=n.compare,n=n!==null?n:Sl,n(d,l)&&e.ref===t.ref)return ut(e,t,s)}return t.flags|=1,e=st(i,l),e.ref=t.ref,e.return=t,t.child=e}function wm(e,t,n,l,s){if(e!==null){var i=e.memoizedProps;if(Sl(i,l)&&e.ref===t.ref)if(Ye=!1,t.pendingProps=l=i,Cc(e,s))(e.flags&131072)!==0&&(Ye=!0);else return t.lanes=e.lanes,ut(e,t,s)}return Nc(e,t,n,l,s)}function zm(e,t,n,l){var s=l.children,i=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),l.mode==="hidden"){if((t.flags&128)!==0){if(i=i!==null?i.baseLanes|n:n,e!==null){for(l=t.child=e.child,s=0;l!==null;)s=s|l.lanes|l.childLanes,l=l.sibling;l=s&~i}else l=0,t.child=null;return Tm(e,t,i,n,l)}if((n&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&Ps(t,i!==null?i.cachePool:null),i!==null?Cu(t,i):Wr(),Du(t);else return l=t.lanes=536870912,Tm(e,t,i!==null?i.baseLanes|n:n,n,l)}else i!==null?(Ps(t,i.cachePool),Cu(t,i),Ut(),t.memoizedState=null):(e!==null&&Ps(t,null),Wr(),Ut());return la(e,t,s,n),t.child}function Kl(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Tm(e,t,n,l,s){var i=Qr();return i=i===null?null:{parent:Ge._currentValue,pool:i},t.memoizedState={baseLanes:n,cachePool:i},e!==null&&Ps(t,null),Wr(),Du(t),e!==null&&Hn(e,t,l,!0),t.childLanes=s,null}function ii(e,t){return t=ci({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function Am(e,t,n){return hn(t,e.child,null,n),e=ii(t,t.pendingProps),e.flags|=2,za(t),t.memoizedState=null,e}function ox(e,t,n){var l=t.pendingProps,s=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(ye){if(l.mode==="hidden")return e=ii(t,l),t.lanes=536870912,Kl(null,e);if(ec(t),(e=Re)?(e=Bh(e,Oa),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Tt!==null?{id:Qa,overflow:Ya}:null,retryLane:536870912,hydrationErrors:null},n=uu(e),n.return=t,t.child=n,ta=t,Re=null)):e=null,e===null)throw Ct(t);return t.lanes=536870912,null}return ii(t,l)}var i=e.memoizedState;if(i!==null){var d=i.dehydrated;if(ec(t),s)if(t.flags&256)t.flags&=-257,t=Am(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(o(558));else if(Ye||Hn(e,t,n,!1),s=(n&e.childLanes)!==0,Ye||s){if(l=Me,l!==null&&(d=vd(l,n),d!==0&&d!==i.retryLane))throw i.retryLane=d,ln(e,d),xa(l,e,d),yc;xi(),t=Am(e,t,n)}else e=i.treeContext,Re=Ka(d.nextSibling),ta=t,ye=!0,At=null,Oa=!1,e!==null&&pu(t,e),t=ii(t,l),t.flags|=4096;return t}return e=st(e.child,{mode:l.mode,children:l.children}),e.ref=t.ref,t.child=e,e.return=t,e}function ri(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!="function"&&typeof n!="object")throw Error(o(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function Nc(e,t,n,l,s){return on(t),n=tc(e,t,n,l,void 0,s),l=nc(),e!==null&&!Ye?(lc(e,t,s),ut(e,t,s)):(ye&&l&&Or(t),t.flags|=1,la(e,t,n,s),t.child)}function Cm(e,t,n,l,s,i){return on(t),t.updateQueue=null,n=Mu(t,l,n,s),_u(e),l=nc(),e!==null&&!Ye?(lc(e,t,i),ut(e,t,i)):(ye&&l&&Or(t),t.flags|=1,la(e,t,n,i),t.child)}function Dm(e,t,n,l,s){if(on(t),t.stateNode===null){var i=Rn,d=n.contextType;typeof d=="object"&&d!==null&&(i=na(d)),i=new n(l,i),t.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,i.updater=bc,t.stateNode=i,i._reactInternals=t,i=t.stateNode,i.props=l,i.state=t.memoizedState,i.refs={},Xr(t),d=n.contextType,i.context=typeof d=="object"&&d!==null?na(d):Rn,i.state=t.memoizedState,d=n.getDerivedStateFromProps,typeof d=="function"&&(vc(t,n,d,l),i.state=t.memoizedState),typeof n.getDerivedStateFromProps=="function"||typeof i.getSnapshotBeforeUpdate=="function"||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(d=i.state,typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount(),d!==i.state&&bc.enqueueReplaceState(i,i.state,null),Rl(t,l,i,s),El(),i.state=t.memoizedState),typeof i.componentDidMount=="function"&&(t.flags|=4194308),l=!0}else if(e===null){i=t.stateNode;var f=t.memoizedProps,T=fn(n,f);i.props=T;var H=i.context,P=n.contextType;d=Rn,typeof P=="object"&&P!==null&&(d=na(P));var J=n.getDerivedStateFromProps;P=typeof J=="function"||typeof i.getSnapshotBeforeUpdate=="function",f=t.pendingProps!==f,P||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(f||H!==d)&&gm(t,i,l,d),_t=!1;var B=t.memoizedState;i.state=B,Rl(t,l,i,s),El(),H=t.memoizedState,f||B!==H||_t?(typeof J=="function"&&(vc(t,n,J,l),H=t.memoizedState),(T=_t||fm(t,n,T,l,B,H,d))?(P||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount()),typeof i.componentDidMount=="function"&&(t.flags|=4194308)):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=l,t.memoizedState=H),i.props=l,i.state=H,i.context=d,l=T):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),l=!1)}else{i=t.stateNode,Vr(e,t),d=t.memoizedProps,P=fn(n,d),i.props=P,J=t.pendingProps,B=i.context,H=n.contextType,T=Rn,typeof H=="object"&&H!==null&&(T=na(H)),f=n.getDerivedStateFromProps,(H=typeof f=="function"||typeof i.getSnapshotBeforeUpdate=="function")||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(d!==J||B!==T)&&gm(t,i,l,T),_t=!1,B=t.memoizedState,i.state=B,Rl(t,l,i,s),El();var q=t.memoizedState;d!==J||B!==q||_t||e!==null&&e.dependencies!==null&&qs(e.dependencies)?(typeof f=="function"&&(vc(t,n,f,l),q=t.memoizedState),(P=_t||fm(t,n,P,l,B,q,T)||e!==null&&e.dependencies!==null&&qs(e.dependencies))?(H||typeof i.UNSAFE_componentWillUpdate!="function"&&typeof i.componentWillUpdate!="function"||(typeof i.componentWillUpdate=="function"&&i.componentWillUpdate(l,q,T),typeof i.UNSAFE_componentWillUpdate=="function"&&i.UNSAFE_componentWillUpdate(l,q,T)),typeof i.componentDidUpdate=="function"&&(t.flags|=4),typeof i.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof i.componentDidUpdate!="function"||d===e.memoizedProps&&B===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||d===e.memoizedProps&&B===e.memoizedState||(t.flags|=1024),t.memoizedProps=l,t.memoizedState=q),i.props=l,i.state=q,i.context=T,l=P):(typeof i.componentDidUpdate!="function"||d===e.memoizedProps&&B===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||d===e.memoizedProps&&B===e.memoizedState||(t.flags|=1024),l=!1)}return i=l,ri(e,t),l=(t.flags&128)!==0,i||l?(i=t.stateNode,n=l&&typeof n.getDerivedStateFromError!="function"?null:i.render(),t.flags|=1,e!==null&&l?(t.child=hn(t,e.child,null,s),t.child=hn(t,null,n,s)):la(e,t,n,s),t.memoizedState=i.state,e=t.child):e=ut(e,t,s),e}function _m(e,t,n,l){return rn(),t.flags|=256,la(e,t,n,l),t.child}var kc={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Sc(e){return{baseLanes:e,cachePool:ju()}}function wc(e,t,n){return e=e!==null?e.childLanes&~n:0,t&&(e|=Aa),e}function Mm(e,t,n){var l=t.pendingProps,s=!1,i=(t.flags&128)!==0,d;if((d=i)||(d=e!==null&&e.memoizedState===null?!1:(Ie.current&2)!==0),d&&(s=!0,t.flags&=-129),d=(t.flags&32)!==0,t.flags&=-33,e===null){if(ye){if(s?Rt(t):Ut(),(e=Re)?(e=Bh(e,Oa),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Tt!==null?{id:Qa,overflow:Ya}:null,retryLane:536870912,hydrationErrors:null},n=uu(e),n.return=t,t.child=n,ta=t,Re=null)):e=null,e===null)throw Ct(t);return ro(e)?t.lanes=32:t.lanes=536870912,null}var f=l.children;return l=l.fallback,s?(Ut(),s=t.mode,f=ci({mode:"hidden",children:f},s),l=sn(l,s,n,null),f.return=t,l.return=t,f.sibling=l,t.child=f,l=t.child,l.memoizedState=Sc(n),l.childLanes=wc(e,d,n),t.memoizedState=kc,Kl(null,l)):(Rt(t),zc(t,f))}var T=e.memoizedState;if(T!==null&&(f=T.dehydrated,f!==null)){if(i)t.flags&256?(Rt(t),t.flags&=-257,t=Tc(e,t,n)):t.memoizedState!==null?(Ut(),t.child=e.child,t.flags|=128,t=null):(Ut(),f=l.fallback,s=t.mode,l=ci({mode:"visible",children:l.children},s),f=sn(f,s,n,null),f.flags|=2,l.return=t,f.return=t,l.sibling=f,t.child=l,hn(t,e.child,null,n),l=t.child,l.memoizedState=Sc(n),l.childLanes=wc(e,d,n),t.memoizedState=kc,t=Kl(null,l));else if(Rt(t),ro(f)){if(d=f.nextSibling&&f.nextSibling.dataset,d)var H=d.dgst;d=H,l=Error(o(419)),l.stack="",l.digest=d,Tl({value:l,source:null,stack:null}),t=Tc(e,t,n)}else if(Ye||Hn(e,t,n,!1),d=(n&e.childLanes)!==0,Ye||d){if(d=Me,d!==null&&(l=vd(d,n),l!==0&&l!==T.retryLane))throw T.retryLane=l,ln(e,l),xa(d,e,l),yc;io(f)||xi(),t=Tc(e,t,n)}else io(f)?(t.flags|=192,t.child=e.child,t=null):(e=T.treeContext,Re=Ka(f.nextSibling),ta=t,ye=!0,At=null,Oa=!1,e!==null&&pu(t,e),t=zc(t,l.children),t.flags|=4096);return t}return s?(Ut(),f=l.fallback,s=t.mode,T=e.child,H=T.sibling,l=st(T,{mode:"hidden",children:l.children}),l.subtreeFlags=T.subtreeFlags&65011712,H!==null?f=st(H,f):(f=sn(f,s,n,null),f.flags|=2),f.return=t,l.return=t,l.sibling=f,t.child=l,Kl(null,l),l=t.child,f=e.child.memoizedState,f===null?f=Sc(n):(s=f.cachePool,s!==null?(T=Ge._currentValue,s=s.parent!==T?{parent:T,pool:T}:s):s=ju(),f={baseLanes:f.baseLanes|n,cachePool:s}),l.memoizedState=f,l.childLanes=wc(e,d,n),t.memoizedState=kc,Kl(e.child,l)):(Rt(t),n=e.child,e=n.sibling,n=st(n,{mode:"visible",children:l.children}),n.return=t,n.sibling=null,e!==null&&(d=t.deletions,d===null?(t.deletions=[e],t.flags|=16):d.push(e)),t.child=n,t.memoizedState=null,n)}function zc(e,t){return t=ci({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function ci(e,t){return e=Sa(22,e,null,t),e.lanes=0,e}function Tc(e,t,n){return hn(t,e.child,null,n),e=zc(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function Em(e,t,n){e.lanes|=t;var l=e.alternate;l!==null&&(l.lanes|=t),qr(e.return,t,n)}function Ac(e,t,n,l,s,i){var d=e.memoizedState;d===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:l,tail:n,tailMode:s,treeForkCount:i}:(d.isBackwards=t,d.rendering=null,d.renderingStartTime=0,d.last=l,d.tail=n,d.tailMode=s,d.treeForkCount=i)}function Rm(e,t,n){var l=t.pendingProps,s=l.revealOrder,i=l.tail;l=l.children;var d=Ie.current,f=(d&2)!==0;if(f?(d=d&1|2,t.flags|=128):d&=1,ee(Ie,d),la(e,t,l,n),l=ye?zl:0,!f&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Em(e,n,t);else if(e.tag===19)Em(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(s){case"forwards":for(n=t.child,s=null;n!==null;)e=n.alternate,e!==null&&Js(e)===null&&(s=n),n=n.sibling;n=s,n===null?(s=t.child,t.child=null):(s=n.sibling,n.sibling=null),Ac(t,!1,s,n,i,l);break;case"backwards":case"unstable_legacy-backwards":for(n=null,s=t.child,t.child=null;s!==null;){if(e=s.alternate,e!==null&&Js(e)===null){t.child=s;break}e=s.sibling,s.sibling=n,n=s,s=e}Ac(t,!0,n,null,i,l);break;case"together":Ac(t,!1,null,null,void 0,l);break;default:t.memoizedState=null}return t.child}function ut(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Ht|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(Hn(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(o(153));if(t.child!==null){for(e=t.child,n=st(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=st(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function Cc(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&qs(e)))}function dx(e,t,n){switch(t.tag){case 3:ca(t,t.stateNode.containerInfo),Dt(t,Ge,e.memoizedState.cache),rn();break;case 27:case 5:ul(t);break;case 4:ca(t,t.stateNode.containerInfo);break;case 10:Dt(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,ec(t),null;break;case 13:var l=t.memoizedState;if(l!==null)return l.dehydrated!==null?(Rt(t),t.flags|=128,null):(n&t.child.childLanes)!==0?Mm(e,t,n):(Rt(t),e=ut(e,t,n),e!==null?e.sibling:null);Rt(t);break;case 19:var s=(e.flags&128)!==0;if(l=(n&t.childLanes)!==0,l||(Hn(e,t,n,!1),l=(n&t.childLanes)!==0),s){if(l)return Rm(e,t,n);t.flags|=128}if(s=t.memoizedState,s!==null&&(s.rendering=null,s.tail=null,s.lastEffect=null),ee(Ie,Ie.current),l)break;return null;case 22:return t.lanes=0,zm(e,t,n,t.pendingProps);case 24:Dt(t,Ge,e.memoizedState.cache)}return ut(e,t,n)}function Um(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps)Ye=!0;else{if(!Cc(e,n)&&(t.flags&128)===0)return Ye=!1,dx(e,t,n);Ye=(e.flags&131072)!==0}else Ye=!1,ye&&(t.flags&1048576)!==0&&hu(t,zl,t.index);switch(t.lanes=0,t.tag){case 16:e:{var l=t.pendingProps;if(e=un(t.elementType),t.type=e,typeof e=="function")Rr(e)?(l=fn(e,l),t.tag=1,t=Dm(null,t,e,l,n)):(t.tag=0,t=Nc(null,t,e,l,n));else{if(e!=null){var s=e.$$typeof;if(s===Q){t.tag=11,t=km(null,t,e,l,n);break e}else if(s===U){t.tag=14,t=Sm(null,t,e,l,n);break e}}throw t=ve(e)||e,Error(o(306,t,""))}}return t;case 0:return Nc(e,t,t.type,t.pendingProps,n);case 1:return l=t.type,s=fn(l,t.pendingProps),Dm(e,t,l,s,n);case 3:e:{if(ca(t,t.stateNode.containerInfo),e===null)throw Error(o(387));l=t.pendingProps;var i=t.memoizedState;s=i.element,Vr(e,t),Rl(t,l,null,n);var d=t.memoizedState;if(l=d.cache,Dt(t,Ge,l),l!==i.cache&&Ir(t,[Ge],n,!0),El(),l=d.element,i.isDehydrated)if(i={element:l,isDehydrated:!1,cache:d.cache},t.updateQueue.baseState=i,t.memoizedState=i,t.flags&256){t=_m(e,t,l,n);break e}else if(l!==s){s=Ra(Error(o(424)),t),Tl(s),t=_m(e,t,l,n);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,Re=Ka(e.firstChild),ta=t,ye=!0,At=null,Oa=!0,n=zu(t,null,l,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling;else{if(rn(),l===s){t=ut(e,t,n);break e}la(e,t,l,n)}t=t.child}return t;case 26:return ri(e,t),e===null?(n=Qh(t.type,null,t.pendingProps,null))?t.memoizedState=n:ye||(n=t.type,e=t.pendingProps,l=Si(pe.current).createElement(n),l[aa]=t,l[ua]=e,sa(l,n,e),Fe(l),t.stateNode=l):t.memoizedState=Qh(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return ul(t),e===null&&ye&&(l=t.stateNode=Ih(t.type,t.pendingProps,pe.current),ta=t,Oa=!0,s=Re,It(t.type)?(co=s,Re=Ka(l.firstChild)):Re=s),la(e,t,t.pendingProps.children,n),ri(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&ye&&((s=l=Re)&&(l=Bx(l,t.type,t.pendingProps,Oa),l!==null?(t.stateNode=l,ta=t,Re=Ka(l.firstChild),Oa=!1,s=!0):s=!1),s||Ct(t)),ul(t),s=t.type,i=t.pendingProps,d=e!==null?e.memoizedProps:null,l=i.children,no(s,i)?l=null:d!==null&&no(s,d)&&(t.flags|=32),t.memoizedState!==null&&(s=tc(e,t,ax,null,null,n),es._currentValue=s),ri(e,t),la(e,t,l,n),t.child;case 6:return e===null&&ye&&((e=n=Re)&&(n=$x(n,t.pendingProps,Oa),n!==null?(t.stateNode=n,ta=t,Re=null,e=!0):e=!1),e||Ct(t)),null;case 13:return Mm(e,t,n);case 4:return ca(t,t.stateNode.containerInfo),l=t.pendingProps,e===null?t.child=hn(t,null,l,n):la(e,t,l,n),t.child;case 11:return km(e,t,t.type,t.pendingProps,n);case 7:return la(e,t,t.pendingProps,n),t.child;case 8:return la(e,t,t.pendingProps.children,n),t.child;case 12:return la(e,t,t.pendingProps.children,n),t.child;case 10:return l=t.pendingProps,Dt(t,t.type,l.value),la(e,t,l.children,n),t.child;case 9:return s=t.type._context,l=t.pendingProps.children,on(t),s=na(s),l=l(s),t.flags|=1,la(e,t,l,n),t.child;case 14:return Sm(e,t,t.type,t.pendingProps,n);case 15:return wm(e,t,t.type,t.pendingProps,n);case 19:return Rm(e,t,n);case 31:return ox(e,t,n);case 22:return zm(e,t,n,t.pendingProps);case 24:return on(t),l=na(Ge),e===null?(s=Qr(),s===null&&(s=Me,i=Pr(),s.pooledCache=i,i.refCount++,i!==null&&(s.pooledCacheLanes|=n),s=i),t.memoizedState={parent:l,cache:s},Xr(t),Dt(t,Ge,s)):((e.lanes&n)!==0&&(Vr(e,t),Rl(t,null,null,n),El()),s=e.memoizedState,i=t.memoizedState,s.parent!==l?(s={parent:l,cache:l},t.memoizedState=s,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=s),Dt(t,Ge,l)):(l=i.cache,Dt(t,Ge,l),l!==s.cache&&Ir(t,[Ge],n,!0))),la(e,t,t.pendingProps.children,n),t.child;case 29:throw t.pendingProps}throw Error(o(156,t.tag))}function mt(e){e.flags|=4}function Dc(e,t,n,l,s){if((t=(e.mode&32)!==0)&&(t=!1),t){if(e.flags|=16777216,(s&335544128)===s)if(e.stateNode.complete)e.flags|=8192;else if(ch())e.flags|=8192;else throw mn=Qs,Yr}else e.flags&=-16777217}function Lm(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!Zh(t))if(ch())e.flags|=8192;else throw mn=Qs,Yr}function oi(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?fd():536870912,e.lanes|=t,Jn|=t)}function Bl(e,t){if(!ye)switch(e.tailMode){case"hidden":t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case"collapsed":n=e.tail;for(var l=null;n!==null;)n.alternate!==null&&(l=n),n=n.sibling;l===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:l.sibling=null}}function Ue(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,l=0;if(t)for(var s=e.child;s!==null;)n|=s.lanes|s.childLanes,l|=s.subtreeFlags&65011712,l|=s.flags&65011712,s.return=e,s=s.sibling;else for(s=e.child;s!==null;)n|=s.lanes|s.childLanes,l|=s.subtreeFlags,l|=s.flags,s.return=e,s=s.sibling;return e.subtreeFlags|=l,e.childLanes=n,t}function ux(e,t,n){var l=t.pendingProps;switch(Hr(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Ue(t),null;case 1:return Ue(t),null;case 3:return n=t.stateNode,l=null,e!==null&&(l=e.memoizedState.cache),t.memoizedState.cache!==l&&(t.flags|=2048),ct(Ge),qe(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(On(t)?mt(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,Br())),Ue(t),null;case 26:var s=t.type,i=t.memoizedState;return e===null?(mt(t),i!==null?(Ue(t),Lm(t,i)):(Ue(t),Dc(t,s,null,l,n))):i?i!==e.memoizedState?(mt(t),Ue(t),Lm(t,i)):(Ue(t),t.flags&=-16777217):(e=e.memoizedProps,e!==l&&mt(t),Ue(t),Dc(t,s,e,l,n)),null;case 27:if(js(t),n=pe.current,s=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==l&&mt(t);else{if(!l){if(t.stateNode===null)throw Error(o(166));return Ue(t),null}e=te.current,On(t)?fu(t):(e=Ih(s,l,n),t.stateNode=e,mt(t))}return Ue(t),null;case 5:if(js(t),s=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==l&&mt(t);else{if(!l){if(t.stateNode===null)throw Error(o(166));return Ue(t),null}if(i=te.current,On(t))fu(t);else{var d=Si(pe.current);switch(i){case 1:i=d.createElementNS("http://www.w3.org/2000/svg",s);break;case 2:i=d.createElementNS("http://www.w3.org/1998/Math/MathML",s);break;default:switch(s){case"svg":i=d.createElementNS("http://www.w3.org/2000/svg",s);break;case"math":i=d.createElementNS("http://www.w3.org/1998/Math/MathML",s);break;case"script":i=d.createElement("div"),i.innerHTML="<script><\/script>",i=i.removeChild(i.firstChild);break;case"select":i=typeof l.is=="string"?d.createElement("select",{is:l.is}):d.createElement("select"),l.multiple?i.multiple=!0:l.size&&(i.size=l.size);break;default:i=typeof l.is=="string"?d.createElement(s,{is:l.is}):d.createElement(s)}}i[aa]=t,i[ua]=l;e:for(d=t.child;d!==null;){if(d.tag===5||d.tag===6)i.appendChild(d.stateNode);else if(d.tag!==4&&d.tag!==27&&d.child!==null){d.child.return=d,d=d.child;continue}if(d===t)break e;for(;d.sibling===null;){if(d.return===null||d.return===t)break e;d=d.return}d.sibling.return=d.return,d=d.sibling}t.stateNode=i;e:switch(sa(i,s,l),s){case"button":case"input":case"select":case"textarea":l=!!l.autoFocus;break e;case"img":l=!0;break e;default:l=!1}l&&mt(t)}}return Ue(t),Dc(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==l&&mt(t);else{if(typeof l!="string"&&t.stateNode===null)throw Error(o(166));if(e=pe.current,On(t)){if(e=t.stateNode,n=t.memoizedProps,l=null,s=ta,s!==null)switch(s.tag){case 27:case 5:l=s.memoizedProps}e[aa]=t,e=!!(e.nodeValue===n||l!==null&&l.suppressHydrationWarning===!0||Mh(e.nodeValue,n)),e||Ct(t,!0)}else e=Si(e).createTextNode(l),e[aa]=t,t.stateNode=e}return Ue(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(l=On(t),n!==null){if(e===null){if(!l)throw Error(o(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(o(557));e[aa]=t}else rn(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;Ue(t),e=!1}else n=Br(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(za(t),t):(za(t),null);if((t.flags&128)!==0)throw Error(o(558))}return Ue(t),null;case 13:if(l=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(s=On(t),l!==null&&l.dehydrated!==null){if(e===null){if(!s)throw Error(o(318));if(s=t.memoizedState,s=s!==null?s.dehydrated:null,!s)throw Error(o(317));s[aa]=t}else rn(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;Ue(t),s=!1}else s=Br(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=s),s=!0;if(!s)return t.flags&256?(za(t),t):(za(t),null)}return za(t),(t.flags&128)!==0?(t.lanes=n,t):(n=l!==null,e=e!==null&&e.memoizedState!==null,n&&(l=t.child,s=null,l.alternate!==null&&l.alternate.memoizedState!==null&&l.alternate.memoizedState.cachePool!==null&&(s=l.alternate.memoizedState.cachePool.pool),i=null,l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(i=l.memoizedState.cachePool.pool),i!==s&&(l.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),oi(t,t.updateQueue),Ue(t),null);case 4:return qe(),e===null&&Wc(t.stateNode.containerInfo),Ue(t),null;case 10:return ct(t.type),Ue(t),null;case 19:if(Z(Ie),l=t.memoizedState,l===null)return Ue(t),null;if(s=(t.flags&128)!==0,i=l.rendering,i===null)if(s)Bl(l,!1);else{if($e!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(i=Js(e),i!==null){for(t.flags|=128,Bl(l,!1),e=i.updateQueue,t.updateQueue=e,oi(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)du(n,e),n=n.sibling;return ee(Ie,Ie.current&1|2),ye&&it(t,l.treeForkCount),t.child}e=e.sibling}l.tail!==null&&ja()>pi&&(t.flags|=128,s=!0,Bl(l,!1),t.lanes=4194304)}else{if(!s)if(e=Js(i),e!==null){if(t.flags|=128,s=!0,e=e.updateQueue,t.updateQueue=e,oi(t,e),Bl(l,!0),l.tail===null&&l.tailMode==="hidden"&&!i.alternate&&!ye)return Ue(t),null}else 2*ja()-l.renderingStartTime>pi&&n!==536870912&&(t.flags|=128,s=!0,Bl(l,!1),t.lanes=4194304);l.isBackwards?(i.sibling=t.child,t.child=i):(e=l.last,e!==null?e.sibling=i:t.child=i,l.last=i)}return l.tail!==null?(e=l.tail,l.rendering=e,l.tail=e.sibling,l.renderingStartTime=ja(),e.sibling=null,n=Ie.current,ee(Ie,s?n&1|2:n&1),ye&&it(t,l.treeForkCount),e):(Ue(t),null);case 22:case 23:return za(t),Fr(),l=t.memoizedState!==null,e!==null?e.memoizedState!==null!==l&&(t.flags|=8192):l&&(t.flags|=8192),l?(n&536870912)!==0&&(t.flags&128)===0&&(Ue(t),t.subtreeFlags&6&&(t.flags|=8192)):Ue(t),n=t.updateQueue,n!==null&&oi(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),l=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(l=t.memoizedState.cachePool.pool),l!==n&&(t.flags|=2048),e!==null&&Z(dn),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),ct(Ge),Ue(t),null;case 25:return null;case 30:return null}throw Error(o(156,t.tag))}function mx(e,t){switch(Hr(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return ct(Ge),qe(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return js(t),null;case 31:if(t.memoizedState!==null){if(za(t),t.alternate===null)throw Error(o(340));rn()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(za(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(o(340));rn()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return Z(Ie),null;case 4:return qe(),null;case 10:return ct(t.type),null;case 22:case 23:return za(t),Fr(),e!==null&&Z(dn),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return ct(Ge),null;case 25:return null;default:return null}}function Om(e,t){switch(Hr(t),t.tag){case 3:ct(Ge),qe();break;case 26:case 27:case 5:js(t);break;case 4:qe();break;case 31:t.memoizedState!==null&&za(t);break;case 13:za(t);break;case 19:Z(Ie);break;case 10:ct(t.type);break;case 22:case 23:za(t),Fr(),e!==null&&Z(dn);break;case 24:ct(Ge)}}function $l(e,t){try{var n=t.updateQueue,l=n!==null?n.lastEffect:null;if(l!==null){var s=l.next;n=s;do{if((n.tag&e)===e){l=void 0;var i=n.create,d=n.inst;l=i(),d.destroy=l}n=n.next}while(n!==s)}}catch(f){Ae(t,t.return,f)}}function Lt(e,t,n){try{var l=t.updateQueue,s=l!==null?l.lastEffect:null;if(s!==null){var i=s.next;l=i;do{if((l.tag&e)===e){var d=l.inst,f=d.destroy;if(f!==void 0){d.destroy=void 0,s=t;var T=n,H=f;try{H()}catch(P){Ae(s,T,P)}}}l=l.next}while(l!==i)}}catch(P){Ae(t,t.return,P)}}function Hm(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{Au(t,n)}catch(l){Ae(e,e.return,l)}}}function Km(e,t,n){n.props=fn(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(l){Ae(e,t,l)}}function ql(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var l=e.stateNode;break;case 30:l=e.stateNode;break;default:l=e.stateNode}typeof n=="function"?e.refCleanup=n(l):n.current=l}}catch(s){Ae(e,t,s)}}function Xa(e,t){var n=e.ref,l=e.refCleanup;if(n!==null)if(typeof l=="function")try{l()}catch(s){Ae(e,t,s)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n=="function")try{n(null)}catch(s){Ae(e,t,s)}else n.current=null}function Bm(e){var t=e.type,n=e.memoizedProps,l=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":n.autoFocus&&l.focus();break e;case"img":n.src?l.src=n.src:n.srcSet&&(l.srcset=n.srcSet)}}catch(s){Ae(e,e.return,s)}}function _c(e,t,n){try{var l=e.stateNode;Rx(l,e.type,n,t),l[ua]=t}catch(s){Ae(e,e.return,s)}}function $m(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&It(e.type)||e.tag===4}function Mc(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||$m(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&It(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Ec(e,t,n){var l=e.tag;if(l===5||l===6)e=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n).insertBefore(e,t):(t=n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n,t.appendChild(e),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=nt));else if(l!==4&&(l===27&&It(e.type)&&(n=e.stateNode,t=null),e=e.child,e!==null))for(Ec(e,t,n),e=e.sibling;e!==null;)Ec(e,t,n),e=e.sibling}function di(e,t,n){var l=e.tag;if(l===5||l===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(l!==4&&(l===27&&It(e.type)&&(n=e.stateNode),e=e.child,e!==null))for(di(e,t,n),e=e.sibling;e!==null;)di(e,t,n),e=e.sibling}function qm(e){var t=e.stateNode,n=e.memoizedProps;try{for(var l=e.type,s=t.attributes;s.length;)t.removeAttributeNode(s[0]);sa(t,l,n),t[aa]=e,t[ua]=n}catch(i){Ae(e,e.return,i)}}var ht=!1,Xe=!1,Rc=!1,Im=typeof WeakSet=="function"?WeakSet:Set,ea=null;function hx(e,t){if(e=e.containerInfo,ao=_i,e=au(e),Tr(e)){if("selectionStart"in e)var n={start:e.selectionStart,end:e.selectionEnd};else e:{n=(n=e.ownerDocument)&&n.defaultView||window;var l=n.getSelection&&n.getSelection();if(l&&l.rangeCount!==0){n=l.anchorNode;var s=l.anchorOffset,i=l.focusNode;l=l.focusOffset;try{n.nodeType,i.nodeType}catch{n=null;break e}var d=0,f=-1,T=-1,H=0,P=0,J=e,B=null;a:for(;;){for(var q;J!==n||s!==0&&J.nodeType!==3||(f=d+s),J!==i||l!==0&&J.nodeType!==3||(T=d+l),J.nodeType===3&&(d+=J.nodeValue.length),(q=J.firstChild)!==null;)B=J,J=q;for(;;){if(J===e)break a;if(B===n&&++H===s&&(f=d),B===i&&++P===l&&(T=d),(q=J.nextSibling)!==null)break;J=B,B=J.parentNode}J=q}n=f===-1||T===-1?null:{start:f,end:T}}else n=null}n=n||{start:0,end:0}}else n=null;for(to={focusedElem:e,selectionRange:n},_i=!1,ea=t;ea!==null;)if(t=ea,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,ea=e;else for(;ea!==null;){switch(t=ea,i=t.alternate,e=t.flags,t.tag){case 0:if((e&4)!==0&&(e=t.updateQueue,e=e!==null?e.events:null,e!==null))for(n=0;n<e.length;n++)s=e[n],s.ref.impl=s.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&i!==null){e=void 0,n=t,s=i.memoizedProps,i=i.memoizedState,l=n.stateNode;try{var ae=fn(n.type,s);e=l.getSnapshotBeforeUpdate(ae,i),l.__reactInternalSnapshotBeforeUpdate=e}catch(re){Ae(n,n.return,re)}}break;case 3:if((e&1024)!==0){if(e=t.stateNode.containerInfo,n=e.nodeType,n===9)so(e);else if(n===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":so(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(o(163))}if(e=t.sibling,e!==null){e.return=t.return,ea=e;break}ea=t.return}}function Pm(e,t,n){var l=n.flags;switch(n.tag){case 0:case 11:case 15:ft(e,n),l&4&&$l(5,n);break;case 1:if(ft(e,n),l&4)if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(d){Ae(n,n.return,d)}else{var s=fn(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(s,t,e.__reactInternalSnapshotBeforeUpdate)}catch(d){Ae(n,n.return,d)}}l&64&&Hm(n),l&512&&ql(n,n.return);break;case 3:if(ft(e,n),l&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{Au(e,t)}catch(d){Ae(n,n.return,d)}}break;case 27:t===null&&l&4&&qm(n);case 26:case 5:ft(e,n),t===null&&l&4&&Bm(n),l&512&&ql(n,n.return);break;case 12:ft(e,n);break;case 31:ft(e,n),l&4&&Ym(e,n);break;case 13:ft(e,n),l&4&&Xm(e,n),l&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=Nx.bind(null,n),qx(e,n))));break;case 22:if(l=n.memoizedState!==null||ht,!l){t=t!==null&&t.memoizedState!==null||Xe,s=ht;var i=Xe;ht=l,(Xe=t)&&!i?gt(e,n,(n.subtreeFlags&8772)!==0):ft(e,n),ht=s,Xe=i}break;case 30:break;default:ft(e,n)}}function Gm(e){var t=e.alternate;t!==null&&(e.alternate=null,Gm(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&dr(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var He=null,ha=!1;function pt(e,t,n){for(n=n.child;n!==null;)Qm(e,t,n),n=n.sibling}function Qm(e,t,n){if(ya&&typeof ya.onCommitFiberUnmount=="function")try{ya.onCommitFiberUnmount(ml,n)}catch{}switch(n.tag){case 26:Xe||Xa(n,t),pt(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:Xe||Xa(n,t);var l=He,s=ha;It(n.type)&&(He=n.stateNode,ha=!1),pt(e,t,n),Zl(n.stateNode),He=l,ha=s;break;case 5:Xe||Xa(n,t);case 6:if(l=He,s=ha,He=null,pt(e,t,n),He=l,ha=s,He!==null)if(ha)try{(He.nodeType===9?He.body:He.nodeName==="HTML"?He.ownerDocument.body:He).removeChild(n.stateNode)}catch(i){Ae(n,t,i)}else try{He.removeChild(n.stateNode)}catch(i){Ae(n,t,i)}break;case 18:He!==null&&(ha?(e=He,Hh(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,n.stateNode),ll(e)):Hh(He,n.stateNode));break;case 4:l=He,s=ha,He=n.stateNode.containerInfo,ha=!0,pt(e,t,n),He=l,ha=s;break;case 0:case 11:case 14:case 15:Lt(2,n,t),Xe||Lt(4,n,t),pt(e,t,n);break;case 1:Xe||(Xa(n,t),l=n.stateNode,typeof l.componentWillUnmount=="function"&&Km(n,t,l)),pt(e,t,n);break;case 21:pt(e,t,n);break;case 22:Xe=(l=Xe)||n.memoizedState!==null,pt(e,t,n),Xe=l;break;default:pt(e,t,n)}}function Ym(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{ll(e)}catch(n){Ae(t,t.return,n)}}}function Xm(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{ll(e)}catch(n){Ae(t,t.return,n)}}function px(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new Im),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new Im),t;default:throw Error(o(435,e.tag))}}function ui(e,t){var n=px(e);t.forEach(function(l){if(!n.has(l)){n.add(l);var s=kx.bind(null,e,l);l.then(s,s)}})}function pa(e,t){var n=t.deletions;if(n!==null)for(var l=0;l<n.length;l++){var s=n[l],i=e,d=t,f=d;e:for(;f!==null;){switch(f.tag){case 27:if(It(f.type)){He=f.stateNode,ha=!1;break e}break;case 5:He=f.stateNode,ha=!1;break e;case 3:case 4:He=f.stateNode.containerInfo,ha=!0;break e}f=f.return}if(He===null)throw Error(o(160));Qm(i,d,s),He=null,ha=!1,i=s.alternate,i!==null&&(i.return=null),s.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)Vm(t,e),t=t.sibling}var Pa=null;function Vm(e,t){var n=e.alternate,l=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:pa(t,e),fa(e),l&4&&(Lt(3,e,e.return),$l(3,e),Lt(5,e,e.return));break;case 1:pa(t,e),fa(e),l&512&&(Xe||n===null||Xa(n,n.return)),l&64&&ht&&(e=e.updateQueue,e!==null&&(l=e.callbacks,l!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?l:n.concat(l))));break;case 26:var s=Pa;if(pa(t,e),fa(e),l&512&&(Xe||n===null||Xa(n,n.return)),l&4){var i=n!==null?n.memoizedState:null;if(l=e.memoizedState,n===null)if(l===null)if(e.stateNode===null){e:{l=e.type,n=e.memoizedProps,s=s.ownerDocument||s;a:switch(l){case"title":i=s.getElementsByTagName("title")[0],(!i||i[fl]||i[aa]||i.namespaceURI==="http://www.w3.org/2000/svg"||i.hasAttribute("itemprop"))&&(i=s.createElement(l),s.head.insertBefore(i,s.querySelector("head > title"))),sa(i,l,n),i[aa]=e,Fe(i),l=i;break e;case"link":var d=Vh("link","href",s).get(l+(n.href||""));if(d){for(var f=0;f<d.length;f++)if(i=d[f],i.getAttribute("href")===(n.href==null||n.href===""?null:n.href)&&i.getAttribute("rel")===(n.rel==null?null:n.rel)&&i.getAttribute("title")===(n.title==null?null:n.title)&&i.getAttribute("crossorigin")===(n.crossOrigin==null?null:n.crossOrigin)){d.splice(f,1);break a}}i=s.createElement(l),sa(i,l,n),s.head.appendChild(i);break;case"meta":if(d=Vh("meta","content",s).get(l+(n.content||""))){for(f=0;f<d.length;f++)if(i=d[f],i.getAttribute("content")===(n.content==null?null:""+n.content)&&i.getAttribute("name")===(n.name==null?null:n.name)&&i.getAttribute("property")===(n.property==null?null:n.property)&&i.getAttribute("http-equiv")===(n.httpEquiv==null?null:n.httpEquiv)&&i.getAttribute("charset")===(n.charSet==null?null:n.charSet)){d.splice(f,1);break a}}i=s.createElement(l),sa(i,l,n),s.head.appendChild(i);break;default:throw Error(o(468,l))}i[aa]=e,Fe(i),l=i}e.stateNode=l}else Jh(s,e.type,e.stateNode);else e.stateNode=Xh(s,l,e.memoizedProps);else i!==l?(i===null?n.stateNode!==null&&(n=n.stateNode,n.parentNode.removeChild(n)):i.count--,l===null?Jh(s,e.type,e.stateNode):Xh(s,l,e.memoizedProps)):l===null&&e.stateNode!==null&&_c(e,e.memoizedProps,n.memoizedProps)}break;case 27:pa(t,e),fa(e),l&512&&(Xe||n===null||Xa(n,n.return)),n!==null&&l&4&&_c(e,e.memoizedProps,n.memoizedProps);break;case 5:if(pa(t,e),fa(e),l&512&&(Xe||n===null||Xa(n,n.return)),e.flags&32){s=e.stateNode;try{Tn(s,"")}catch(ae){Ae(e,e.return,ae)}}l&4&&e.stateNode!=null&&(s=e.memoizedProps,_c(e,s,n!==null?n.memoizedProps:s)),l&1024&&(Rc=!0);break;case 6:if(pa(t,e),fa(e),l&4){if(e.stateNode===null)throw Error(o(162));l=e.memoizedProps,n=e.stateNode;try{n.nodeValue=l}catch(ae){Ae(e,e.return,ae)}}break;case 3:if(Ti=null,s=Pa,Pa=wi(t.containerInfo),pa(t,e),Pa=s,fa(e),l&4&&n!==null&&n.memoizedState.isDehydrated)try{ll(t.containerInfo)}catch(ae){Ae(e,e.return,ae)}Rc&&(Rc=!1,Jm(e));break;case 4:l=Pa,Pa=wi(e.stateNode.containerInfo),pa(t,e),fa(e),Pa=l;break;case 12:pa(t,e),fa(e);break;case 31:pa(t,e),fa(e),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,ui(e,l)));break;case 13:pa(t,e),fa(e),e.child.flags&8192&&e.memoizedState!==null!=(n!==null&&n.memoizedState!==null)&&(hi=ja()),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,ui(e,l)));break;case 22:s=e.memoizedState!==null;var T=n!==null&&n.memoizedState!==null,H=ht,P=Xe;if(ht=H||s,Xe=P||T,pa(t,e),Xe=P,ht=H,fa(e),l&8192)e:for(t=e.stateNode,t._visibility=s?t._visibility&-2:t._visibility|1,s&&(n===null||T||ht||Xe||gn(e)),n=null,t=e;;){if(t.tag===5||t.tag===26){if(n===null){T=n=t;try{if(i=T.stateNode,s)d=i.style,typeof d.setProperty=="function"?d.setProperty("display","none","important"):d.display="none";else{f=T.stateNode;var J=T.memoizedProps.style,B=J!=null&&J.hasOwnProperty("display")?J.display:null;f.style.display=B==null||typeof B=="boolean"?"":(""+B).trim()}}catch(ae){Ae(T,T.return,ae)}}}else if(t.tag===6){if(n===null){T=t;try{T.stateNode.nodeValue=s?"":T.memoizedProps}catch(ae){Ae(T,T.return,ae)}}}else if(t.tag===18){if(n===null){T=t;try{var q=T.stateNode;s?Kh(q,!0):Kh(T.stateNode,!1)}catch(ae){Ae(T,T.return,ae)}}}else if((t.tag!==22&&t.tag!==23||t.memoizedState===null||t===e)&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;t.sibling===null;){if(t.return===null||t.return===e)break e;n===t&&(n=null),t=t.return}n===t&&(n=null),t.sibling.return=t.return,t=t.sibling}l&4&&(l=e.updateQueue,l!==null&&(n=l.retryQueue,n!==null&&(l.retryQueue=null,ui(e,n))));break;case 19:pa(t,e),fa(e),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,ui(e,l)));break;case 30:break;case 21:break;default:pa(t,e),fa(e)}}function fa(e){var t=e.flags;if(t&2){try{for(var n,l=e.return;l!==null;){if($m(l)){n=l;break}l=l.return}if(n==null)throw Error(o(160));switch(n.tag){case 27:var s=n.stateNode,i=Mc(e);di(e,i,s);break;case 5:var d=n.stateNode;n.flags&32&&(Tn(d,""),n.flags&=-33);var f=Mc(e);di(e,f,d);break;case 3:case 4:var T=n.stateNode.containerInfo,H=Mc(e);Ec(e,H,T);break;default:throw Error(o(161))}}catch(P){Ae(e,e.return,P)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Jm(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Jm(t),t.tag===5&&t.flags&1024&&t.stateNode.reset(),e=e.sibling}}function ft(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)Pm(e,t.alternate,t),t=t.sibling}function gn(e){for(e=e.child;e!==null;){var t=e;switch(t.tag){case 0:case 11:case 14:case 15:Lt(4,t,t.return),gn(t);break;case 1:Xa(t,t.return);var n=t.stateNode;typeof n.componentWillUnmount=="function"&&Km(t,t.return,n),gn(t);break;case 27:Zl(t.stateNode);case 26:case 5:Xa(t,t.return),gn(t);break;case 22:t.memoizedState===null&&gn(t);break;case 30:gn(t);break;default:gn(t)}e=e.sibling}}function gt(e,t,n){for(n=n&&(t.subtreeFlags&8772)!==0,t=t.child;t!==null;){var l=t.alternate,s=e,i=t,d=i.flags;switch(i.tag){case 0:case 11:case 15:gt(s,i,n),$l(4,i);break;case 1:if(gt(s,i,n),l=i,s=l.stateNode,typeof s.componentDidMount=="function")try{s.componentDidMount()}catch(H){Ae(l,l.return,H)}if(l=i,s=l.updateQueue,s!==null){var f=l.stateNode;try{var T=s.shared.hiddenCallbacks;if(T!==null)for(s.shared.hiddenCallbacks=null,s=0;s<T.length;s++)Tu(T[s],f)}catch(H){Ae(l,l.return,H)}}n&&d&64&&Hm(i),ql(i,i.return);break;case 27:qm(i);case 26:case 5:gt(s,i,n),n&&l===null&&d&4&&Bm(i),ql(i,i.return);break;case 12:gt(s,i,n);break;case 31:gt(s,i,n),n&&d&4&&Ym(s,i);break;case 13:gt(s,i,n),n&&d&4&&Xm(s,i);break;case 22:i.memoizedState===null&&gt(s,i,n),ql(i,i.return);break;case 30:break;default:gt(s,i,n)}t=t.sibling}}function Uc(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&Al(n))}function Lc(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Al(e))}function Ga(e,t,n,l){if(t.subtreeFlags&10256)for(t=t.child;t!==null;)Zm(e,t,n,l),t=t.sibling}function Zm(e,t,n,l){var s=t.flags;switch(t.tag){case 0:case 11:case 15:Ga(e,t,n,l),s&2048&&$l(9,t);break;case 1:Ga(e,t,n,l);break;case 3:Ga(e,t,n,l),s&2048&&(e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Al(e)));break;case 12:if(s&2048){Ga(e,t,n,l),e=t.stateNode;try{var i=t.memoizedProps,d=i.id,f=i.onPostCommit;typeof f=="function"&&f(d,t.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(T){Ae(t,t.return,T)}}else Ga(e,t,n,l);break;case 31:Ga(e,t,n,l);break;case 13:Ga(e,t,n,l);break;case 23:break;case 22:i=t.stateNode,d=t.alternate,t.memoizedState!==null?i._visibility&2?Ga(e,t,n,l):Il(e,t):i._visibility&2?Ga(e,t,n,l):(i._visibility|=2,Yn(e,t,n,l,(t.subtreeFlags&10256)!==0||!1)),s&2048&&Uc(d,t);break;case 24:Ga(e,t,n,l),s&2048&&Lc(t.alternate,t);break;default:Ga(e,t,n,l)}}function Yn(e,t,n,l,s){for(s=s&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var i=e,d=t,f=n,T=l,H=d.flags;switch(d.tag){case 0:case 11:case 15:Yn(i,d,f,T,s),$l(8,d);break;case 23:break;case 22:var P=d.stateNode;d.memoizedState!==null?P._visibility&2?Yn(i,d,f,T,s):Il(i,d):(P._visibility|=2,Yn(i,d,f,T,s)),s&&H&2048&&Uc(d.alternate,d);break;case 24:Yn(i,d,f,T,s),s&&H&2048&&Lc(d.alternate,d);break;default:Yn(i,d,f,T,s)}t=t.sibling}}function Il(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,l=t,s=l.flags;switch(l.tag){case 22:Il(n,l),s&2048&&Uc(l.alternate,l);break;case 24:Il(n,l),s&2048&&Lc(l.alternate,l);break;default:Il(n,l)}t=t.sibling}}var Pl=8192;function Xn(e,t,n){if(e.subtreeFlags&Pl)for(e=e.child;e!==null;)Wm(e,t,n),e=e.sibling}function Wm(e,t,n){switch(e.tag){case 26:Xn(e,t,n),e.flags&Pl&&e.memoizedState!==null&&e0(n,Pa,e.memoizedState,e.memoizedProps);break;case 5:Xn(e,t,n);break;case 3:case 4:var l=Pa;Pa=wi(e.stateNode.containerInfo),Xn(e,t,n),Pa=l;break;case 22:e.memoizedState===null&&(l=e.alternate,l!==null&&l.memoizedState!==null?(l=Pl,Pl=16777216,Xn(e,t,n),Pl=l):Xn(e,t,n));break;default:Xn(e,t,n)}}function Fm(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function Gl(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var l=t[n];ea=l,ah(l,e)}Fm(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)eh(e),e=e.sibling}function eh(e){switch(e.tag){case 0:case 11:case 15:Gl(e),e.flags&2048&&Lt(9,e,e.return);break;case 3:Gl(e);break;case 12:Gl(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,mi(e)):Gl(e);break;default:Gl(e)}}function mi(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var l=t[n];ea=l,ah(l,e)}Fm(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Lt(8,t,t.return),mi(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,mi(t));break;default:mi(t)}e=e.sibling}}function ah(e,t){for(;ea!==null;){var n=ea;switch(n.tag){case 0:case 11:case 15:Lt(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var l=n.memoizedState.cachePool.pool;l!=null&&l.refCount++}break;case 24:Al(n.memoizedState.cache)}if(l=n.child,l!==null)l.return=n,ea=l;else e:for(n=e;ea!==null;){l=ea;var s=l.sibling,i=l.return;if(Gm(l),l===n){ea=null;break e}if(s!==null){s.return=i,ea=s;break e}ea=i}}}var fx={getCacheForType:function(e){var t=na(Ge),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return na(Ge).controller.signal}},gx=typeof WeakMap=="function"?WeakMap:Map,we=0,Me=null,fe=null,be=0,Te=0,Ta=null,Ot=!1,Vn=!1,Oc=!1,xt=0,$e=0,Ht=0,xn=0,Hc=0,Aa=0,Jn=0,Ql=null,ga=null,Kc=!1,hi=0,th=0,pi=1/0,fi=null,Kt=null,Ze=0,Bt=null,Zn=null,vt=0,Bc=0,$c=null,nh=null,Yl=0,qc=null;function Ca(){return(we&2)!==0&&be!==0?be&-be:I.T!==null?Xc():bd()}function lh(){if(Aa===0)if((be&536870912)===0||ye){var e=ks;ks<<=1,(ks&3932160)===0&&(ks=262144),Aa=e}else Aa=536870912;return e=wa.current,e!==null&&(e.flags|=32),Aa}function xa(e,t,n){(e===Me&&(Te===2||Te===9)||e.cancelPendingCommit!==null)&&(Wn(e,0),$t(e,be,Aa,!1)),pl(e,n),((we&2)===0||e!==Me)&&(e===Me&&((we&2)===0&&(xn|=n),$e===4&&$t(e,be,Aa,!1)),Va(e))}function sh(e,t,n){if((we&6)!==0)throw Error(o(327));var l=!n&&(t&127)===0&&(t&e.expiredLanes)===0||hl(e,t),s=l?bx(e,t):Pc(e,t,!0),i=l;do{if(s===0){Vn&&!l&&$t(e,t,0,!1);break}else{if(n=e.current.alternate,i&&!xx(n)){s=Pc(e,t,!1),i=!1;continue}if(s===2){if(i=t,e.errorRecoveryDisabledLanes&i)var d=0;else d=e.pendingLanes&-536870913,d=d!==0?d:d&536870912?536870912:0;if(d!==0){t=d;e:{var f=e;s=Ql;var T=f.current.memoizedState.isDehydrated;if(T&&(Wn(f,d).flags|=256),d=Pc(f,d,!1),d!==2){if(Oc&&!T){f.errorRecoveryDisabledLanes|=i,xn|=i,s=4;break e}i=ga,ga=s,i!==null&&(ga===null?ga=i:ga.push.apply(ga,i))}s=d}if(i=!1,s!==2)continue}}if(s===1){Wn(e,0),$t(e,t,0,!0);break}e:{switch(l=e,i=s,i){case 0:case 1:throw Error(o(345));case 4:if((t&4194048)!==t)break;case 6:$t(l,t,Aa,!Ot);break e;case 2:ga=null;break;case 3:case 5:break;default:throw Error(o(329))}if((t&62914560)===t&&(s=hi+300-ja(),10<s)){if($t(l,t,Aa,!Ot),ws(l,0,!0)!==0)break e;vt=t,l.timeoutHandle=Lh(ih.bind(null,l,n,ga,fi,Kc,t,Aa,xn,Jn,Ot,i,"Throttled",-0,0),s);break e}ih(l,n,ga,fi,Kc,t,Aa,xn,Jn,Ot,i,null,-0,0)}}break}while(!0);Va(e)}function ih(e,t,n,l,s,i,d,f,T,H,P,J,B,q){if(e.timeoutHandle=-1,J=t.subtreeFlags,J&8192||(J&16785408)===16785408){J={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:nt},Wm(t,i,J);var ae=(i&62914560)===i?hi-ja():(i&4194048)===i?th-ja():0;if(ae=a0(J,ae),ae!==null){vt=i,e.cancelPendingCommit=ae(ph.bind(null,e,t,i,n,l,s,d,f,T,P,J,null,B,q)),$t(e,i,d,!H);return}}ph(e,t,i,n,l,s,d,f,T)}function xx(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var l=0;l<n.length;l++){var s=n[l],i=s.getSnapshot;s=s.value;try{if(!ka(i(),s))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function $t(e,t,n,l){t&=~Hc,t&=~xn,e.suspendedLanes|=t,e.pingedLanes&=~t,l&&(e.warmLanes|=t),l=e.expirationTimes;for(var s=t;0<s;){var i=31-Na(s),d=1<<i;l[i]=-1,s&=~d}n!==0&&gd(e,n,t)}function gi(){return(we&6)===0?(Xl(0),!1):!0}function Ic(){if(fe!==null){if(Te===0)var e=fe.return;else e=fe,rt=cn=null,sc(e),qn=null,Dl=0,e=fe;for(;e!==null;)Om(e.alternate,e),e=e.return;fe=null}}function Wn(e,t){var n=e.timeoutHandle;n!==-1&&(e.timeoutHandle=-1,Ox(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),vt=0,Ic(),Me=e,fe=n=st(e.current,null),be=t,Te=0,Ta=null,Ot=!1,Vn=hl(e,t),Oc=!1,Jn=Aa=Hc=xn=Ht=$e=0,ga=Ql=null,Kc=!1,(t&8)!==0&&(t|=t&32);var l=e.entangledLanes;if(l!==0)for(e=e.entanglements,l&=t;0<l;){var s=31-Na(l),i=1<<s;t|=e[s],l&=~i}return xt=t,Os(),n}function rh(e,t){me=null,I.H=Hl,t===$n||t===Gs?(t=ku(),Te=3):t===Yr?(t=ku(),Te=4):Te=t===yc?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,Ta=t,fe===null&&($e=1,si(e,Ra(t,e.current)))}function ch(){var e=wa.current;return e===null?!0:(be&4194048)===be?Ha===null:(be&62914560)===be||(be&536870912)!==0?e===Ha:!1}function oh(){var e=I.H;return I.H=Hl,e===null?Hl:e}function dh(){var e=I.A;return I.A=fx,e}function xi(){$e=4,Ot||(be&4194048)!==be&&wa.current!==null||(Vn=!0),(Ht&134217727)===0&&(xn&134217727)===0||Me===null||$t(Me,be,Aa,!1)}function Pc(e,t,n){var l=we;we|=2;var s=oh(),i=dh();(Me!==e||be!==t)&&(fi=null,Wn(e,t)),t=!1;var d=$e;e:do try{if(Te!==0&&fe!==null){var f=fe,T=Ta;switch(Te){case 8:Ic(),d=6;break e;case 3:case 2:case 9:case 6:wa.current===null&&(t=!0);var H=Te;if(Te=0,Ta=null,Fn(e,f,T,H),n&&Vn){d=0;break e}break;default:H=Te,Te=0,Ta=null,Fn(e,f,T,H)}}vx(),d=$e;break}catch(P){rh(e,P)}while(!0);return t&&e.shellSuspendCounter++,rt=cn=null,we=l,I.H=s,I.A=i,fe===null&&(Me=null,be=0,Os()),d}function vx(){for(;fe!==null;)uh(fe)}function bx(e,t){var n=we;we|=2;var l=oh(),s=dh();Me!==e||be!==t?(fi=null,pi=ja()+500,Wn(e,t)):Vn=hl(e,t);e:do try{if(Te!==0&&fe!==null){t=fe;var i=Ta;a:switch(Te){case 1:Te=0,Ta=null,Fn(e,t,i,1);break;case 2:case 9:if(yu(i)){Te=0,Ta=null,mh(t);break}t=function(){Te!==2&&Te!==9||Me!==e||(Te=7),Va(e)},i.then(t,t);break e;case 3:Te=7;break e;case 4:Te=5;break e;case 7:yu(i)?(Te=0,Ta=null,mh(t)):(Te=0,Ta=null,Fn(e,t,i,7));break;case 5:var d=null;switch(fe.tag){case 26:d=fe.memoizedState;case 5:case 27:var f=fe;if(d?Zh(d):f.stateNode.complete){Te=0,Ta=null;var T=f.sibling;if(T!==null)fe=T;else{var H=f.return;H!==null?(fe=H,vi(H)):fe=null}break a}}Te=0,Ta=null,Fn(e,t,i,5);break;case 6:Te=0,Ta=null,Fn(e,t,i,6);break;case 8:Ic(),$e=6;break e;default:throw Error(o(462))}}jx();break}catch(P){rh(e,P)}while(!0);return rt=cn=null,I.H=l,I.A=s,we=n,fe!==null?0:(Me=null,be=0,Os(),$e)}function jx(){for(;fe!==null&&!If();)uh(fe)}function uh(e){var t=Um(e.alternate,e,xt);e.memoizedProps=e.pendingProps,t===null?vi(e):fe=t}function mh(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Cm(n,t,t.pendingProps,t.type,void 0,be);break;case 11:t=Cm(n,t,t.pendingProps,t.type.render,t.ref,be);break;case 5:sc(t);default:Om(n,t),t=fe=du(t,xt),t=Um(n,t,xt)}e.memoizedProps=e.pendingProps,t===null?vi(e):fe=t}function Fn(e,t,n,l){rt=cn=null,sc(t),qn=null,Dl=0;var s=t.return;try{if(cx(e,s,t,n,be)){$e=1,si(e,Ra(n,e.current)),fe=null;return}}catch(i){if(s!==null)throw fe=s,i;$e=1,si(e,Ra(n,e.current)),fe=null;return}t.flags&32768?(ye||l===1?e=!0:Vn||(be&536870912)!==0?e=!1:(Ot=e=!0,(l===2||l===9||l===3||l===6)&&(l=wa.current,l!==null&&l.tag===13&&(l.flags|=16384))),hh(t,e)):vi(t)}function vi(e){var t=e;do{if((t.flags&32768)!==0){hh(t,Ot);return}e=t.return;var n=ux(t.alternate,t,xt);if(n!==null){fe=n;return}if(t=t.sibling,t!==null){fe=t;return}fe=t=e}while(t!==null);$e===0&&($e=5)}function hh(e,t){do{var n=mx(e.alternate,e);if(n!==null){n.flags&=32767,fe=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){fe=e;return}fe=e=n}while(e!==null);$e=6,fe=null}function ph(e,t,n,l,s,i,d,f,T){e.cancelPendingCommit=null;do bi();while(Ze!==0);if((we&6)!==0)throw Error(o(327));if(t!==null){if(t===e.current)throw Error(o(177));if(i=t.lanes|t.childLanes,i|=Mr,Ff(e,n,i,d,f,T),e===Me&&(fe=Me=null,be=0),Zn=t,Bt=e,vt=n,Bc=i,$c=s,nh=l,(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,Sx(ys,function(){return bh(),null})):(e.callbackNode=null,e.callbackPriority=0),l=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||l){l=I.T,I.T=null,s=G.p,G.p=2,d=we,we|=4;try{hx(e,t,n)}finally{we=d,G.p=s,I.T=l}}Ze=1,fh(),gh(),xh()}}function fh(){if(Ze===1){Ze=0;var e=Bt,t=Zn,n=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||n){n=I.T,I.T=null;var l=G.p;G.p=2;var s=we;we|=4;try{Vm(t,e);var i=to,d=au(e.containerInfo),f=i.focusedElem,T=i.selectionRange;if(d!==f&&f&&f.ownerDocument&&eu(f.ownerDocument.documentElement,f)){if(T!==null&&Tr(f)){var H=T.start,P=T.end;if(P===void 0&&(P=H),"selectionStart"in f)f.selectionStart=H,f.selectionEnd=Math.min(P,f.value.length);else{var J=f.ownerDocument||document,B=J&&J.defaultView||window;if(B.getSelection){var q=B.getSelection(),ae=f.textContent.length,re=Math.min(T.start,ae),_e=T.end===void 0?re:Math.min(T.end,ae);!q.extend&&re>_e&&(d=_e,_e=re,re=d);var E=Fd(f,re),D=Fd(f,_e);if(E&&D&&(q.rangeCount!==1||q.anchorNode!==E.node||q.anchorOffset!==E.offset||q.focusNode!==D.node||q.focusOffset!==D.offset)){var O=J.createRange();O.setStart(E.node,E.offset),q.removeAllRanges(),re>_e?(q.addRange(O),q.extend(D.node,D.offset)):(O.setEnd(D.node,D.offset),q.addRange(O))}}}}for(J=[],q=f;q=q.parentNode;)q.nodeType===1&&J.push({element:q,left:q.scrollLeft,top:q.scrollTop});for(typeof f.focus=="function"&&f.focus(),f=0;f<J.length;f++){var Y=J[f];Y.element.scrollLeft=Y.left,Y.element.scrollTop=Y.top}}_i=!!ao,to=ao=null}finally{we=s,G.p=l,I.T=n}}e.current=t,Ze=2}}function gh(){if(Ze===2){Ze=0;var e=Bt,t=Zn,n=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||n){n=I.T,I.T=null;var l=G.p;G.p=2;var s=we;we|=4;try{Pm(e,t.alternate,t)}finally{we=s,G.p=l,I.T=n}}Ze=3}}function xh(){if(Ze===4||Ze===3){Ze=0,Pf();var e=Bt,t=Zn,n=vt,l=nh;(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?Ze=5:(Ze=0,Zn=Bt=null,vh(e,e.pendingLanes));var s=e.pendingLanes;if(s===0&&(Kt=null),cr(n),t=t.stateNode,ya&&typeof ya.onCommitFiberRoot=="function")try{ya.onCommitFiberRoot(ml,t,void 0,(t.current.flags&128)===128)}catch{}if(l!==null){t=I.T,s=G.p,G.p=2,I.T=null;try{for(var i=e.onRecoverableError,d=0;d<l.length;d++){var f=l[d];i(f.value,{componentStack:f.stack})}}finally{I.T=t,G.p=s}}(vt&3)!==0&&bi(),Va(e),s=e.pendingLanes,(n&261930)!==0&&(s&42)!==0?e===qc?Yl++:(Yl=0,qc=e):Yl=0,Xl(0)}}function vh(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,Al(t)))}function bi(){return fh(),gh(),xh(),bh()}function bh(){if(Ze!==5)return!1;var e=Bt,t=Bc;Bc=0;var n=cr(vt),l=I.T,s=G.p;try{G.p=32>n?32:n,I.T=null,n=$c,$c=null;var i=Bt,d=vt;if(Ze=0,Zn=Bt=null,vt=0,(we&6)!==0)throw Error(o(331));var f=we;if(we|=4,eh(i.current),Zm(i,i.current,d,n),we=f,Xl(0,!1),ya&&typeof ya.onPostCommitFiberRoot=="function")try{ya.onPostCommitFiberRoot(ml,i)}catch{}return!0}finally{G.p=s,I.T=l,vh(e,t)}}function jh(e,t,n){t=Ra(n,t),t=jc(e.stateNode,t,2),e=Et(e,t,2),e!==null&&(pl(e,2),Va(e))}function Ae(e,t,n){if(e.tag===3)jh(e,e,n);else for(;t!==null;){if(t.tag===3){jh(t,e,n);break}else if(t.tag===1){var l=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof l.componentDidCatch=="function"&&(Kt===null||!Kt.has(l))){e=Ra(n,e),n=ym(2),l=Et(t,n,2),l!==null&&(Nm(n,l,t,e),pl(l,2),Va(l));break}}t=t.return}}function Gc(e,t,n){var l=e.pingCache;if(l===null){l=e.pingCache=new gx;var s=new Set;l.set(t,s)}else s=l.get(t),s===void 0&&(s=new Set,l.set(t,s));s.has(n)||(Oc=!0,s.add(n),e=yx.bind(null,e,t,n),t.then(e,e))}function yx(e,t,n){var l=e.pingCache;l!==null&&l.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,Me===e&&(be&n)===n&&($e===4||$e===3&&(be&62914560)===be&&300>ja()-hi?(we&2)===0&&Wn(e,0):Hc|=n,Jn===be&&(Jn=0)),Va(e)}function yh(e,t){t===0&&(t=fd()),e=ln(e,t),e!==null&&(pl(e,t),Va(e))}function Nx(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),yh(e,n)}function kx(e,t){var n=0;switch(e.tag){case 31:case 13:var l=e.stateNode,s=e.memoizedState;s!==null&&(n=s.retryLane);break;case 19:l=e.stateNode;break;case 22:l=e.stateNode._retryCache;break;default:throw Error(o(314))}l!==null&&l.delete(t),yh(e,n)}function Sx(e,t){return lr(e,t)}var ji=null,el=null,Qc=!1,yi=!1,Yc=!1,qt=0;function Va(e){e!==el&&e.next===null&&(el===null?ji=el=e:el=el.next=e),yi=!0,Qc||(Qc=!0,zx())}function Xl(e,t){if(!Yc&&yi){Yc=!0;do for(var n=!1,l=ji;l!==null;){if(e!==0){var s=l.pendingLanes;if(s===0)var i=0;else{var d=l.suspendedLanes,f=l.pingedLanes;i=(1<<31-Na(42|e)+1)-1,i&=s&~(d&~f),i=i&201326741?i&201326741|1:i?i|2:0}i!==0&&(n=!0,wh(l,i))}else i=be,i=ws(l,l===Me?i:0,l.cancelPendingCommit!==null||l.timeoutHandle!==-1),(i&3)===0||hl(l,i)||(n=!0,wh(l,i));l=l.next}while(n);Yc=!1}}function wx(){Nh()}function Nh(){yi=Qc=!1;var e=0;qt!==0&&Lx()&&(e=qt);for(var t=ja(),n=null,l=ji;l!==null;){var s=l.next,i=kh(l,t);i===0?(l.next=null,n===null?ji=s:n.next=s,s===null&&(el=n)):(n=l,(e!==0||(i&3)!==0)&&(yi=!0)),l=s}Ze!==0&&Ze!==5||Xl(e),qt!==0&&(qt=0)}function kh(e,t){for(var n=e.suspendedLanes,l=e.pingedLanes,s=e.expirationTimes,i=e.pendingLanes&-62914561;0<i;){var d=31-Na(i),f=1<<d,T=s[d];T===-1?((f&n)===0||(f&l)!==0)&&(s[d]=Wf(f,t)):T<=t&&(e.expiredLanes|=f),i&=~f}if(t=Me,n=be,n=ws(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),l=e.callbackNode,n===0||e===t&&(Te===2||Te===9)||e.cancelPendingCommit!==null)return l!==null&&l!==null&&sr(l),e.callbackNode=null,e.callbackPriority=0;if((n&3)===0||hl(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(l!==null&&sr(l),cr(n)){case 2:case 8:n=hd;break;case 32:n=ys;break;case 268435456:n=pd;break;default:n=ys}return l=Sh.bind(null,e),n=lr(n,l),e.callbackPriority=t,e.callbackNode=n,t}return l!==null&&l!==null&&sr(l),e.callbackPriority=2,e.callbackNode=null,2}function Sh(e,t){if(Ze!==0&&Ze!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(bi()&&e.callbackNode!==n)return null;var l=be;return l=ws(e,e===Me?l:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),l===0?null:(sh(e,l,t),kh(e,ja()),e.callbackNode!=null&&e.callbackNode===n?Sh.bind(null,e):null)}function wh(e,t){if(bi())return null;sh(e,t,!0)}function zx(){Hx(function(){(we&6)!==0?lr(md,wx):Nh()})}function Xc(){if(qt===0){var e=Kn;e===0&&(e=Ns,Ns<<=1,(Ns&261888)===0&&(Ns=256)),qt=e}return qt}function zh(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:Cs(""+e)}function Th(e,t){var n=t.ownerDocument.createElement("input");return n.name=t.name,n.value=t.value,e.id&&n.setAttribute("form",e.id),t.parentNode.insertBefore(n,t),e=new FormData(e),n.parentNode.removeChild(n),e}function Tx(e,t,n,l,s){if(t==="submit"&&n&&n.stateNode===s){var i=zh((s[ua]||null).action),d=l.submitter;d&&(t=(t=d[ua]||null)?zh(t.formAction):d.getAttribute("formAction"),t!==null&&(i=t,d=null));var f=new Es("action","action",null,l,s);e.push({event:f,listeners:[{instance:null,listener:function(){if(l.defaultPrevented){if(qt!==0){var T=d?Th(s,d):new FormData(s);pc(n,{pending:!0,data:T,method:s.method,action:i},null,T)}}else typeof i=="function"&&(f.preventDefault(),T=d?Th(s,d):new FormData(s),pc(n,{pending:!0,data:T,method:s.method,action:i},i,T))},currentTarget:s}]})}}for(var Vc=0;Vc<_r.length;Vc++){var Jc=_r[Vc],Ax=Jc.toLowerCase(),Cx=Jc[0].toUpperCase()+Jc.slice(1);Ia(Ax,"on"+Cx)}Ia(lu,"onAnimationEnd"),Ia(su,"onAnimationIteration"),Ia(iu,"onAnimationStart"),Ia("dblclick","onDoubleClick"),Ia("focusin","onFocus"),Ia("focusout","onBlur"),Ia(Gg,"onTransitionRun"),Ia(Qg,"onTransitionStart"),Ia(Yg,"onTransitionCancel"),Ia(ru,"onTransitionEnd"),wn("onMouseEnter",["mouseout","mouseover"]),wn("onMouseLeave",["mouseout","mouseover"]),wn("onPointerEnter",["pointerout","pointerover"]),wn("onPointerLeave",["pointerout","pointerover"]),en("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),en("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),en("onBeforeInput",["compositionend","keypress","textInput","paste"]),en("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),en("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),en("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Vl="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Dx=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Vl));function Ah(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var l=e[n],s=l.event;l=l.listeners;e:{var i=void 0;if(t)for(var d=l.length-1;0<=d;d--){var f=l[d],T=f.instance,H=f.currentTarget;if(f=f.listener,T!==i&&s.isPropagationStopped())break e;i=f,s.currentTarget=H;try{i(s)}catch(P){Ls(P)}s.currentTarget=null,i=T}else for(d=0;d<l.length;d++){if(f=l[d],T=f.instance,H=f.currentTarget,f=f.listener,T!==i&&s.isPropagationStopped())break e;i=f,s.currentTarget=H;try{i(s)}catch(P){Ls(P)}s.currentTarget=null,i=T}}}}function ge(e,t){var n=t[or];n===void 0&&(n=t[or]=new Set);var l=e+"__bubble";n.has(l)||(Ch(t,e,2,!1),n.add(l))}function Zc(e,t,n){var l=0;t&&(l|=4),Ch(n,e,l,t)}var Ni="_reactListening"+Math.random().toString(36).slice(2);function Wc(e){if(!e[Ni]){e[Ni]=!0,Nd.forEach(function(n){n!=="selectionchange"&&(Dx.has(n)||Zc(n,!1,e),Zc(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[Ni]||(t[Ni]=!0,Zc("selectionchange",!1,t))}}function Ch(e,t,n,l){switch(lp(t)){case 2:var s=l0;break;case 8:s=s0;break;default:s=po}n=s.bind(null,t,n,e),s=void 0,!vr||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(s=!0),l?s!==void 0?e.addEventListener(t,n,{capture:!0,passive:s}):e.addEventListener(t,n,!0):s!==void 0?e.addEventListener(t,n,{passive:s}):e.addEventListener(t,n,!1)}function Fc(e,t,n,l,s){var i=l;if((t&1)===0&&(t&2)===0&&l!==null)e:for(;;){if(l===null)return;var d=l.tag;if(d===3||d===4){var f=l.stateNode.containerInfo;if(f===s)break;if(d===4)for(d=l.return;d!==null;){var T=d.tag;if((T===3||T===4)&&d.stateNode.containerInfo===s)return;d=d.return}for(;f!==null;){if(d=Nn(f),d===null)return;if(T=d.tag,T===5||T===6||T===26||T===27){l=i=d;continue e}f=f.parentNode}}l=l.return}Rd(function(){var H=i,P=gr(n),J=[];e:{var B=cu.get(e);if(B!==void 0){var q=Es,ae=e;switch(e){case"keypress":if(_s(n)===0)break e;case"keydown":case"keyup":q=kg;break;case"focusin":ae="focus",q=Nr;break;case"focusout":ae="blur",q=Nr;break;case"beforeblur":case"afterblur":q=Nr;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":q=Od;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":q=ug;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":q=zg;break;case lu:case su:case iu:q=pg;break;case ru:q=Ag;break;case"scroll":case"scrollend":q=og;break;case"wheel":q=Dg;break;case"copy":case"cut":case"paste":q=gg;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":q=Kd;break;case"toggle":case"beforetoggle":q=Mg}var re=(t&4)!==0,_e=!re&&(e==="scroll"||e==="scrollend"),E=re?B!==null?B+"Capture":null:B;re=[];for(var D=H,O;D!==null;){var Y=D;if(O=Y.stateNode,Y=Y.tag,Y!==5&&Y!==26&&Y!==27||O===null||E===null||(Y=xl(D,E),Y!=null&&re.push(Jl(D,Y,O))),_e)break;D=D.return}0<re.length&&(B=new q(B,ae,null,n,P),J.push({event:B,listeners:re}))}}if((t&7)===0){e:{if(B=e==="mouseover"||e==="pointerover",q=e==="mouseout"||e==="pointerout",B&&n!==fr&&(ae=n.relatedTarget||n.fromElement)&&(Nn(ae)||ae[yn]))break e;if((q||B)&&(B=P.window===P?P:(B=P.ownerDocument)?B.defaultView||B.parentWindow:window,q?(ae=n.relatedTarget||n.toElement,q=H,ae=ae?Nn(ae):null,ae!==null&&(_e=m(ae),re=ae.tag,ae!==_e||re!==5&&re!==27&&re!==6)&&(ae=null)):(q=null,ae=H),q!==ae)){if(re=Od,Y="onMouseLeave",E="onMouseEnter",D="mouse",(e==="pointerout"||e==="pointerover")&&(re=Kd,Y="onPointerLeave",E="onPointerEnter",D="pointer"),_e=q==null?B:gl(q),O=ae==null?B:gl(ae),B=new re(Y,D+"leave",q,n,P),B.target=_e,B.relatedTarget=O,Y=null,Nn(P)===H&&(re=new re(E,D+"enter",ae,n,P),re.target=O,re.relatedTarget=_e,Y=re),_e=Y,q&&ae)a:{for(re=_x,E=q,D=ae,O=0,Y=E;Y;Y=re(Y))O++;Y=0;for(var le=D;le;le=re(le))Y++;for(;0<O-Y;)E=re(E),O--;for(;0<Y-O;)D=re(D),Y--;for(;O--;){if(E===D||D!==null&&E===D.alternate){re=E;break a}E=re(E),D=re(D)}re=null}else re=null;q!==null&&Dh(J,B,q,re,!1),ae!==null&&_e!==null&&Dh(J,_e,ae,re,!0)}}e:{if(B=H?gl(H):window,q=B.nodeName&&B.nodeName.toLowerCase(),q==="select"||q==="input"&&B.type==="file")var ke=Yd;else if(Gd(B))if(Xd)ke=qg;else{ke=Bg;var ne=Kg}else q=B.nodeName,!q||q.toLowerCase()!=="input"||B.type!=="checkbox"&&B.type!=="radio"?H&&pr(H.elementType)&&(ke=Yd):ke=$g;if(ke&&(ke=ke(e,H))){Qd(J,ke,n,P);break e}ne&&ne(e,B,H),e==="focusout"&&H&&B.type==="number"&&H.memoizedProps.value!=null&&hr(B,"number",B.value)}switch(ne=H?gl(H):window,e){case"focusin":(Gd(ne)||ne.contentEditable==="true")&&(_n=ne,Ar=H,wl=null);break;case"focusout":wl=Ar=_n=null;break;case"mousedown":Cr=!0;break;case"contextmenu":case"mouseup":case"dragend":Cr=!1,tu(J,n,P);break;case"selectionchange":if(Pg)break;case"keydown":case"keyup":tu(J,n,P)}var he;if(Sr)e:{switch(e){case"compositionstart":var je="onCompositionStart";break e;case"compositionend":je="onCompositionEnd";break e;case"compositionupdate":je="onCompositionUpdate";break e}je=void 0}else Dn?Id(e,n)&&(je="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(je="onCompositionStart");je&&(Bd&&n.locale!=="ko"&&(Dn||je!=="onCompositionStart"?je==="onCompositionEnd"&&Dn&&(he=Ud()):(zt=P,br="value"in zt?zt.value:zt.textContent,Dn=!0)),ne=ki(H,je),0<ne.length&&(je=new Hd(je,e,null,n,P),J.push({event:je,listeners:ne}),he?je.data=he:(he=Pd(n),he!==null&&(je.data=he)))),(he=Rg?Ug(e,n):Lg(e,n))&&(je=ki(H,"onBeforeInput"),0<je.length&&(ne=new Hd("onBeforeInput","beforeinput",null,n,P),J.push({event:ne,listeners:je}),ne.data=he)),Tx(J,e,H,n,P)}Ah(J,t)})}function Jl(e,t,n){return{instance:e,listener:t,currentTarget:n}}function ki(e,t){for(var n=t+"Capture",l=[];e!==null;){var s=e,i=s.stateNode;if(s=s.tag,s!==5&&s!==26&&s!==27||i===null||(s=xl(e,n),s!=null&&l.unshift(Jl(e,s,i)),s=xl(e,t),s!=null&&l.push(Jl(e,s,i))),e.tag===3)return l;e=e.return}return[]}function _x(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function Dh(e,t,n,l,s){for(var i=t._reactName,d=[];n!==null&&n!==l;){var f=n,T=f.alternate,H=f.stateNode;if(f=f.tag,T!==null&&T===l)break;f!==5&&f!==26&&f!==27||H===null||(T=H,s?(H=xl(n,i),H!=null&&d.unshift(Jl(n,H,T))):s||(H=xl(n,i),H!=null&&d.push(Jl(n,H,T)))),n=n.return}d.length!==0&&e.push({event:t,listeners:d})}var Mx=/\r\n?/g,Ex=/\u0000|\uFFFD/g;function _h(e){return(typeof e=="string"?e:""+e).replace(Mx,`
`).replace(Ex,"")}function Mh(e,t){return t=_h(t),_h(e)===t}function De(e,t,n,l,s,i){switch(n){case"children":typeof l=="string"?t==="body"||t==="textarea"&&l===""||Tn(e,l):(typeof l=="number"||typeof l=="bigint")&&t!=="body"&&Tn(e,""+l);break;case"className":Ts(e,"class",l);break;case"tabIndex":Ts(e,"tabindex",l);break;case"dir":case"role":case"viewBox":case"width":case"height":Ts(e,n,l);break;case"style":Md(e,l,i);break;case"data":if(t!=="object"){Ts(e,"data",l);break}case"src":case"href":if(l===""&&(t!=="a"||n!=="href")){e.removeAttribute(n);break}if(l==null||typeof l=="function"||typeof l=="symbol"||typeof l=="boolean"){e.removeAttribute(n);break}l=Cs(""+l),e.setAttribute(n,l);break;case"action":case"formAction":if(typeof l=="function"){e.setAttribute(n,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof i=="function"&&(n==="formAction"?(t!=="input"&&De(e,t,"name",s.name,s,null),De(e,t,"formEncType",s.formEncType,s,null),De(e,t,"formMethod",s.formMethod,s,null),De(e,t,"formTarget",s.formTarget,s,null)):(De(e,t,"encType",s.encType,s,null),De(e,t,"method",s.method,s,null),De(e,t,"target",s.target,s,null)));if(l==null||typeof l=="symbol"||typeof l=="boolean"){e.removeAttribute(n);break}l=Cs(""+l),e.setAttribute(n,l);break;case"onClick":l!=null&&(e.onclick=nt);break;case"onScroll":l!=null&&ge("scroll",e);break;case"onScrollEnd":l!=null&&ge("scrollend",e);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(o(61));if(n=l.__html,n!=null){if(s.children!=null)throw Error(o(60));e.innerHTML=n}}break;case"multiple":e.multiple=l&&typeof l!="function"&&typeof l!="symbol";break;case"muted":e.muted=l&&typeof l!="function"&&typeof l!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(l==null||typeof l=="function"||typeof l=="boolean"||typeof l=="symbol"){e.removeAttribute("xlink:href");break}n=Cs(""+l),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",n);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":l!=null&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(n,""+l):e.removeAttribute(n);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":l&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(n,""):e.removeAttribute(n);break;case"capture":case"download":l===!0?e.setAttribute(n,""):l!==!1&&l!=null&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(n,l):e.removeAttribute(n);break;case"cols":case"rows":case"size":case"span":l!=null&&typeof l!="function"&&typeof l!="symbol"&&!isNaN(l)&&1<=l?e.setAttribute(n,l):e.removeAttribute(n);break;case"rowSpan":case"start":l==null||typeof l=="function"||typeof l=="symbol"||isNaN(l)?e.removeAttribute(n):e.setAttribute(n,l);break;case"popover":ge("beforetoggle",e),ge("toggle",e),zs(e,"popover",l);break;case"xlinkActuate":tt(e,"http://www.w3.org/1999/xlink","xlink:actuate",l);break;case"xlinkArcrole":tt(e,"http://www.w3.org/1999/xlink","xlink:arcrole",l);break;case"xlinkRole":tt(e,"http://www.w3.org/1999/xlink","xlink:role",l);break;case"xlinkShow":tt(e,"http://www.w3.org/1999/xlink","xlink:show",l);break;case"xlinkTitle":tt(e,"http://www.w3.org/1999/xlink","xlink:title",l);break;case"xlinkType":tt(e,"http://www.w3.org/1999/xlink","xlink:type",l);break;case"xmlBase":tt(e,"http://www.w3.org/XML/1998/namespace","xml:base",l);break;case"xmlLang":tt(e,"http://www.w3.org/XML/1998/namespace","xml:lang",l);break;case"xmlSpace":tt(e,"http://www.w3.org/XML/1998/namespace","xml:space",l);break;case"is":zs(e,"is",l);break;case"innerText":case"textContent":break;default:(!(2<n.length)||n[0]!=="o"&&n[0]!=="O"||n[1]!=="n"&&n[1]!=="N")&&(n=rg.get(n)||n,zs(e,n,l))}}function eo(e,t,n,l,s,i){switch(n){case"style":Md(e,l,i);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(o(61));if(n=l.__html,n!=null){if(s.children!=null)throw Error(o(60));e.innerHTML=n}}break;case"children":typeof l=="string"?Tn(e,l):(typeof l=="number"||typeof l=="bigint")&&Tn(e,""+l);break;case"onScroll":l!=null&&ge("scroll",e);break;case"onScrollEnd":l!=null&&ge("scrollend",e);break;case"onClick":l!=null&&(e.onclick=nt);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!kd.hasOwnProperty(n))e:{if(n[0]==="o"&&n[1]==="n"&&(s=n.endsWith("Capture"),t=n.slice(2,s?n.length-7:void 0),i=e[ua]||null,i=i!=null?i[n]:null,typeof i=="function"&&e.removeEventListener(t,i,s),typeof l=="function")){typeof i!="function"&&i!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(t,l,s);break e}n in e?e[n]=l:l===!0?e.setAttribute(n,""):zs(e,n,l)}}}function sa(e,t,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":ge("error",e),ge("load",e);var l=!1,s=!1,i;for(i in n)if(n.hasOwnProperty(i)){var d=n[i];if(d!=null)switch(i){case"src":l=!0;break;case"srcSet":s=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(o(137,t));default:De(e,t,i,d,n,null)}}s&&De(e,t,"srcSet",n.srcSet,n,null),l&&De(e,t,"src",n.src,n,null);return;case"input":ge("invalid",e);var f=i=d=s=null,T=null,H=null;for(l in n)if(n.hasOwnProperty(l)){var P=n[l];if(P!=null)switch(l){case"name":s=P;break;case"type":d=P;break;case"checked":T=P;break;case"defaultChecked":H=P;break;case"value":i=P;break;case"defaultValue":f=P;break;case"children":case"dangerouslySetInnerHTML":if(P!=null)throw Error(o(137,t));break;default:De(e,t,l,P,n,null)}}Ad(e,i,f,T,H,d,s,!1);return;case"select":ge("invalid",e),l=d=i=null;for(s in n)if(n.hasOwnProperty(s)&&(f=n[s],f!=null))switch(s){case"value":i=f;break;case"defaultValue":d=f;break;case"multiple":l=f;default:De(e,t,s,f,n,null)}t=i,n=d,e.multiple=!!l,t!=null?zn(e,!!l,t,!1):n!=null&&zn(e,!!l,n,!0);return;case"textarea":ge("invalid",e),i=s=l=null;for(d in n)if(n.hasOwnProperty(d)&&(f=n[d],f!=null))switch(d){case"value":l=f;break;case"defaultValue":s=f;break;case"children":i=f;break;case"dangerouslySetInnerHTML":if(f!=null)throw Error(o(91));break;default:De(e,t,d,f,n,null)}Dd(e,l,s,i);return;case"option":for(T in n)n.hasOwnProperty(T)&&(l=n[T],l!=null)&&(T==="selected"?e.selected=l&&typeof l!="function"&&typeof l!="symbol":De(e,t,T,l,n,null));return;case"dialog":ge("beforetoggle",e),ge("toggle",e),ge("cancel",e),ge("close",e);break;case"iframe":case"object":ge("load",e);break;case"video":case"audio":for(l=0;l<Vl.length;l++)ge(Vl[l],e);break;case"image":ge("error",e),ge("load",e);break;case"details":ge("toggle",e);break;case"embed":case"source":case"link":ge("error",e),ge("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(H in n)if(n.hasOwnProperty(H)&&(l=n[H],l!=null))switch(H){case"children":case"dangerouslySetInnerHTML":throw Error(o(137,t));default:De(e,t,H,l,n,null)}return;default:if(pr(t)){for(P in n)n.hasOwnProperty(P)&&(l=n[P],l!==void 0&&eo(e,t,P,l,n,void 0));return}}for(f in n)n.hasOwnProperty(f)&&(l=n[f],l!=null&&De(e,t,f,l,n,null))}function Rx(e,t,n,l){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var s=null,i=null,d=null,f=null,T=null,H=null,P=null;for(q in n){var J=n[q];if(n.hasOwnProperty(q)&&J!=null)switch(q){case"checked":break;case"value":break;case"defaultValue":T=J;default:l.hasOwnProperty(q)||De(e,t,q,null,l,J)}}for(var B in l){var q=l[B];if(J=n[B],l.hasOwnProperty(B)&&(q!=null||J!=null))switch(B){case"type":i=q;break;case"name":s=q;break;case"checked":H=q;break;case"defaultChecked":P=q;break;case"value":d=q;break;case"defaultValue":f=q;break;case"children":case"dangerouslySetInnerHTML":if(q!=null)throw Error(o(137,t));break;default:q!==J&&De(e,t,B,q,l,J)}}mr(e,d,f,T,H,P,i,s);return;case"select":q=d=f=B=null;for(i in n)if(T=n[i],n.hasOwnProperty(i)&&T!=null)switch(i){case"value":break;case"multiple":q=T;default:l.hasOwnProperty(i)||De(e,t,i,null,l,T)}for(s in l)if(i=l[s],T=n[s],l.hasOwnProperty(s)&&(i!=null||T!=null))switch(s){case"value":B=i;break;case"defaultValue":f=i;break;case"multiple":d=i;default:i!==T&&De(e,t,s,i,l,T)}t=f,n=d,l=q,B!=null?zn(e,!!n,B,!1):!!l!=!!n&&(t!=null?zn(e,!!n,t,!0):zn(e,!!n,n?[]:"",!1));return;case"textarea":q=B=null;for(f in n)if(s=n[f],n.hasOwnProperty(f)&&s!=null&&!l.hasOwnProperty(f))switch(f){case"value":break;case"children":break;default:De(e,t,f,null,l,s)}for(d in l)if(s=l[d],i=n[d],l.hasOwnProperty(d)&&(s!=null||i!=null))switch(d){case"value":B=s;break;case"defaultValue":q=s;break;case"children":break;case"dangerouslySetInnerHTML":if(s!=null)throw Error(o(91));break;default:s!==i&&De(e,t,d,s,l,i)}Cd(e,B,q);return;case"option":for(var ae in n)B=n[ae],n.hasOwnProperty(ae)&&B!=null&&!l.hasOwnProperty(ae)&&(ae==="selected"?e.selected=!1:De(e,t,ae,null,l,B));for(T in l)B=l[T],q=n[T],l.hasOwnProperty(T)&&B!==q&&(B!=null||q!=null)&&(T==="selected"?e.selected=B&&typeof B!="function"&&typeof B!="symbol":De(e,t,T,B,l,q));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var re in n)B=n[re],n.hasOwnProperty(re)&&B!=null&&!l.hasOwnProperty(re)&&De(e,t,re,null,l,B);for(H in l)if(B=l[H],q=n[H],l.hasOwnProperty(H)&&B!==q&&(B!=null||q!=null))switch(H){case"children":case"dangerouslySetInnerHTML":if(B!=null)throw Error(o(137,t));break;default:De(e,t,H,B,l,q)}return;default:if(pr(t)){for(var _e in n)B=n[_e],n.hasOwnProperty(_e)&&B!==void 0&&!l.hasOwnProperty(_e)&&eo(e,t,_e,void 0,l,B);for(P in l)B=l[P],q=n[P],!l.hasOwnProperty(P)||B===q||B===void 0&&q===void 0||eo(e,t,P,B,l,q);return}}for(var E in n)B=n[E],n.hasOwnProperty(E)&&B!=null&&!l.hasOwnProperty(E)&&De(e,t,E,null,l,B);for(J in l)B=l[J],q=n[J],!l.hasOwnProperty(J)||B===q||B==null&&q==null||De(e,t,J,B,l,q)}function Eh(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function Ux(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,n=performance.getEntriesByType("resource"),l=0;l<n.length;l++){var s=n[l],i=s.transferSize,d=s.initiatorType,f=s.duration;if(i&&f&&Eh(d)){for(d=0,f=s.responseEnd,l+=1;l<n.length;l++){var T=n[l],H=T.startTime;if(H>f)break;var P=T.transferSize,J=T.initiatorType;P&&Eh(J)&&(T=T.responseEnd,d+=P*(T<f?1:(f-H)/(T-H)))}if(--l,t+=8*(i+d)/(s.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var ao=null,to=null;function Si(e){return e.nodeType===9?e:e.ownerDocument}function Rh(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Uh(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function no(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var lo=null;function Lx(){var e=window.event;return e&&e.type==="popstate"?e===lo?!1:(lo=e,!0):(lo=null,!1)}var Lh=typeof setTimeout=="function"?setTimeout:void 0,Ox=typeof clearTimeout=="function"?clearTimeout:void 0,Oh=typeof Promise=="function"?Promise:void 0,Hx=typeof queueMicrotask=="function"?queueMicrotask:typeof Oh<"u"?function(e){return Oh.resolve(null).then(e).catch(Kx)}:Lh;function Kx(e){setTimeout(function(){throw e})}function It(e){return e==="head"}function Hh(e,t){var n=t,l=0;do{var s=n.nextSibling;if(e.removeChild(n),s&&s.nodeType===8)if(n=s.data,n==="/$"||n==="/&"){if(l===0){e.removeChild(s),ll(t);return}l--}else if(n==="$"||n==="$?"||n==="$~"||n==="$!"||n==="&")l++;else if(n==="html")Zl(e.ownerDocument.documentElement);else if(n==="head"){n=e.ownerDocument.head,Zl(n);for(var i=n.firstChild;i;){var d=i.nextSibling,f=i.nodeName;i[fl]||f==="SCRIPT"||f==="STYLE"||f==="LINK"&&i.rel.toLowerCase()==="stylesheet"||n.removeChild(i),i=d}}else n==="body"&&Zl(e.ownerDocument.body);n=s}while(n);ll(t)}function Kh(e,t){var n=e;e=0;do{var l=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display="none"):(n.style.display=n._stashedDisplay||"",n.getAttribute("style")===""&&n.removeAttribute("style")):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=""):n.nodeValue=n._stashedText||""),l&&l.nodeType===8)if(n=l.data,n==="/$"){if(e===0)break;e--}else n!=="$"&&n!=="$?"&&n!=="$~"&&n!=="$!"||e++;n=l}while(n)}function so(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case"HTML":case"HEAD":case"BODY":so(n),dr(n);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(n.rel.toLowerCase()==="stylesheet")continue}e.removeChild(n)}}function Bx(e,t,n,l){for(;e.nodeType===1;){var s=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!l&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(l){if(!e[fl])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(i=e.getAttribute("rel"),i==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(i!==s.rel||e.getAttribute("href")!==(s.href==null||s.href===""?null:s.href)||e.getAttribute("crossorigin")!==(s.crossOrigin==null?null:s.crossOrigin)||e.getAttribute("title")!==(s.title==null?null:s.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(i=e.getAttribute("src"),(i!==(s.src==null?null:s.src)||e.getAttribute("type")!==(s.type==null?null:s.type)||e.getAttribute("crossorigin")!==(s.crossOrigin==null?null:s.crossOrigin))&&i&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var i=s.name==null?null:""+s.name;if(s.type==="hidden"&&e.getAttribute("name")===i)return e}else return e;if(e=Ka(e.nextSibling),e===null)break}return null}function $x(e,t,n){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!n||(e=Ka(e.nextSibling),e===null))return null;return e}function Bh(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=Ka(e.nextSibling),e===null))return null;return e}function io(e){return e.data==="$?"||e.data==="$~"}function ro(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function qx(e,t){var n=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||n.readyState!=="loading")t();else{var l=function(){t(),n.removeEventListener("DOMContentLoaded",l)};n.addEventListener("DOMContentLoaded",l),e._reactRetry=l}}function Ka(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var co=null;function $h(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"||n==="/&"){if(t===0)return Ka(e.nextSibling);t--}else n!=="$"&&n!=="$!"&&n!=="$?"&&n!=="$~"&&n!=="&"||t++}e=e.nextSibling}return null}function qh(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"){if(t===0)return e;t--}else n!=="/$"&&n!=="/&"||t++}e=e.previousSibling}return null}function Ih(e,t,n){switch(t=Si(n),e){case"html":if(e=t.documentElement,!e)throw Error(o(452));return e;case"head":if(e=t.head,!e)throw Error(o(453));return e;case"body":if(e=t.body,!e)throw Error(o(454));return e;default:throw Error(o(451))}}function Zl(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);dr(e)}var Ba=new Map,Ph=new Set;function wi(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var bt=G.d;G.d={f:Ix,r:Px,D:Gx,C:Qx,L:Yx,m:Xx,X:Jx,S:Vx,M:Zx};function Ix(){var e=bt.f(),t=gi();return e||t}function Px(e){var t=kn(e);t!==null&&t.tag===5&&t.type==="form"?rm(t):bt.r(e)}var al=typeof document>"u"?null:document;function Gh(e,t,n){var l=al;if(l&&typeof t=="string"&&t){var s=Ma(t);s='link[rel="'+e+'"][href="'+s+'"]',typeof n=="string"&&(s+='[crossorigin="'+n+'"]'),Ph.has(s)||(Ph.add(s),e={rel:e,crossOrigin:n,href:t},l.querySelector(s)===null&&(t=l.createElement("link"),sa(t,"link",e),Fe(t),l.head.appendChild(t)))}}function Gx(e){bt.D(e),Gh("dns-prefetch",e,null)}function Qx(e,t){bt.C(e,t),Gh("preconnect",e,t)}function Yx(e,t,n){bt.L(e,t,n);var l=al;if(l&&e&&t){var s='link[rel="preload"][as="'+Ma(t)+'"]';t==="image"&&n&&n.imageSrcSet?(s+='[imagesrcset="'+Ma(n.imageSrcSet)+'"]',typeof n.imageSizes=="string"&&(s+='[imagesizes="'+Ma(n.imageSizes)+'"]')):s+='[href="'+Ma(e)+'"]';var i=s;switch(t){case"style":i=tl(e);break;case"script":i=nl(e)}Ba.has(i)||(e=N({rel:"preload",href:t==="image"&&n&&n.imageSrcSet?void 0:e,as:t},n),Ba.set(i,e),l.querySelector(s)!==null||t==="style"&&l.querySelector(Wl(i))||t==="script"&&l.querySelector(Fl(i))||(t=l.createElement("link"),sa(t,"link",e),Fe(t),l.head.appendChild(t)))}}function Xx(e,t){bt.m(e,t);var n=al;if(n&&e){var l=t&&typeof t.as=="string"?t.as:"script",s='link[rel="modulepreload"][as="'+Ma(l)+'"][href="'+Ma(e)+'"]',i=s;switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":i=nl(e)}if(!Ba.has(i)&&(e=N({rel:"modulepreload",href:e},t),Ba.set(i,e),n.querySelector(s)===null)){switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(n.querySelector(Fl(i)))return}l=n.createElement("link"),sa(l,"link",e),Fe(l),n.head.appendChild(l)}}}function Vx(e,t,n){bt.S(e,t,n);var l=al;if(l&&e){var s=Sn(l).hoistableStyles,i=tl(e);t=t||"default";var d=s.get(i);if(!d){var f={loading:0,preload:null};if(d=l.querySelector(Wl(i)))f.loading=5;else{e=N({rel:"stylesheet",href:e,"data-precedence":t},n),(n=Ba.get(i))&&oo(e,n);var T=d=l.createElement("link");Fe(T),sa(T,"link",e),T._p=new Promise(function(H,P){T.onload=H,T.onerror=P}),T.addEventListener("load",function(){f.loading|=1}),T.addEventListener("error",function(){f.loading|=2}),f.loading|=4,zi(d,t,l)}d={type:"stylesheet",instance:d,count:1,state:f},s.set(i,d)}}}function Jx(e,t){bt.X(e,t);var n=al;if(n&&e){var l=Sn(n).hoistableScripts,s=nl(e),i=l.get(s);i||(i=n.querySelector(Fl(s)),i||(e=N({src:e,async:!0},t),(t=Ba.get(s))&&uo(e,t),i=n.createElement("script"),Fe(i),sa(i,"link",e),n.head.appendChild(i)),i={type:"script",instance:i,count:1,state:null},l.set(s,i))}}function Zx(e,t){bt.M(e,t);var n=al;if(n&&e){var l=Sn(n).hoistableScripts,s=nl(e),i=l.get(s);i||(i=n.querySelector(Fl(s)),i||(e=N({src:e,async:!0,type:"module"},t),(t=Ba.get(s))&&uo(e,t),i=n.createElement("script"),Fe(i),sa(i,"link",e),n.head.appendChild(i)),i={type:"script",instance:i,count:1,state:null},l.set(s,i))}}function Qh(e,t,n,l){var s=(s=pe.current)?wi(s):null;if(!s)throw Error(o(446));switch(e){case"meta":case"title":return null;case"style":return typeof n.precedence=="string"&&typeof n.href=="string"?(t=tl(n.href),n=Sn(s).hoistableStyles,l=n.get(t),l||(l={type:"style",instance:null,count:0,state:null},n.set(t,l)),l):{type:"void",instance:null,count:0,state:null};case"link":if(n.rel==="stylesheet"&&typeof n.href=="string"&&typeof n.precedence=="string"){e=tl(n.href);var i=Sn(s).hoistableStyles,d=i.get(e);if(d||(s=s.ownerDocument||s,d={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},i.set(e,d),(i=s.querySelector(Wl(e)))&&!i._p&&(d.instance=i,d.state.loading=5),Ba.has(e)||(n={rel:"preload",as:"style",href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},Ba.set(e,n),i||Wx(s,e,n,d.state))),t&&l===null)throw Error(o(528,""));return d}if(t&&l!==null)throw Error(o(529,""));return null;case"script":return t=n.async,n=n.src,typeof n=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(t=nl(n),n=Sn(s).hoistableScripts,l=n.get(t),l||(l={type:"script",instance:null,count:0,state:null},n.set(t,l)),l):{type:"void",instance:null,count:0,state:null};default:throw Error(o(444,e))}}function tl(e){return'href="'+Ma(e)+'"'}function Wl(e){return'link[rel="stylesheet"]['+e+"]"}function Yh(e){return N({},e,{"data-precedence":e.precedence,precedence:null})}function Wx(e,t,n,l){e.querySelector('link[rel="preload"][as="style"]['+t+"]")?l.loading=1:(t=e.createElement("link"),l.preload=t,t.addEventListener("load",function(){return l.loading|=1}),t.addEventListener("error",function(){return l.loading|=2}),sa(t,"link",n),Fe(t),e.head.appendChild(t))}function nl(e){return'[src="'+Ma(e)+'"]'}function Fl(e){return"script[async]"+e}function Xh(e,t,n){if(t.count++,t.instance===null)switch(t.type){case"style":var l=e.querySelector('style[data-href~="'+Ma(n.href)+'"]');if(l)return t.instance=l,Fe(l),l;var s=N({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return l=(e.ownerDocument||e).createElement("style"),Fe(l),sa(l,"style",s),zi(l,n.precedence,e),t.instance=l;case"stylesheet":s=tl(n.href);var i=e.querySelector(Wl(s));if(i)return t.state.loading|=4,t.instance=i,Fe(i),i;l=Yh(n),(s=Ba.get(s))&&oo(l,s),i=(e.ownerDocument||e).createElement("link"),Fe(i);var d=i;return d._p=new Promise(function(f,T){d.onload=f,d.onerror=T}),sa(i,"link",l),t.state.loading|=4,zi(i,n.precedence,e),t.instance=i;case"script":return i=nl(n.src),(s=e.querySelector(Fl(i)))?(t.instance=s,Fe(s),s):(l=n,(s=Ba.get(i))&&(l=N({},n),uo(l,s)),e=e.ownerDocument||e,s=e.createElement("script"),Fe(s),sa(s,"link",l),e.head.appendChild(s),t.instance=s);case"void":return null;default:throw Error(o(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(l=t.instance,t.state.loading|=4,zi(l,n.precedence,e));return t.instance}function zi(e,t,n){for(var l=n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),s=l.length?l[l.length-1]:null,i=s,d=0;d<l.length;d++){var f=l[d];if(f.dataset.precedence===t)i=f;else if(i!==s)break}i?i.parentNode.insertBefore(e,i.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function oo(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function uo(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var Ti=null;function Vh(e,t,n){if(Ti===null){var l=new Map,s=Ti=new Map;s.set(n,l)}else s=Ti,l=s.get(n),l||(l=new Map,s.set(n,l));if(l.has(e))return l;for(l.set(e,null),n=n.getElementsByTagName(e),s=0;s<n.length;s++){var i=n[s];if(!(i[fl]||i[aa]||e==="link"&&i.getAttribute("rel")==="stylesheet")&&i.namespaceURI!=="http://www.w3.org/2000/svg"){var d=i.getAttribute(t)||"";d=e+d;var f=l.get(d);f?f.push(i):l.set(d,[i])}}return l}function Jh(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t==="title"?e.querySelector("head > title"):null)}function Fx(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function Zh(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function e0(e,t,n,l){if(n.type==="stylesheet"&&(typeof l.media!="string"||matchMedia(l.media).matches!==!1)&&(n.state.loading&4)===0){if(n.instance===null){var s=tl(l.href),i=t.querySelector(Wl(s));if(i){t=i._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=Ai.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=i,Fe(i);return}i=t.ownerDocument||t,l=Yh(l),(s=Ba.get(s))&&oo(l,s),i=i.createElement("link"),Fe(i);var d=i;d._p=new Promise(function(f,T){d.onload=f,d.onerror=T}),sa(i,"link",l),n.instance=i}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&(n.state.loading&3)===0&&(e.count++,n=Ai.bind(e),t.addEventListener("load",n),t.addEventListener("error",n))}}var mo=0;function a0(e,t){return e.stylesheets&&e.count===0&&Di(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var l=setTimeout(function(){if(e.stylesheets&&Di(e,e.stylesheets),e.unsuspend){var i=e.unsuspend;e.unsuspend=null,i()}},6e4+t);0<e.imgBytes&&mo===0&&(mo=62500*Ux());var s=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&Di(e,e.stylesheets),e.unsuspend)){var i=e.unsuspend;e.unsuspend=null,i()}},(e.imgBytes>mo?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(l),clearTimeout(s)}}:null}function Ai(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)Di(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var Ci=null;function Di(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,Ci=new Map,t.forEach(t0,e),Ci=null,Ai.call(e))}function t0(e,t){if(!(t.state.loading&4)){var n=Ci.get(e);if(n)var l=n.get(null);else{n=new Map,Ci.set(e,n);for(var s=e.querySelectorAll("link[data-precedence],style[data-precedence]"),i=0;i<s.length;i++){var d=s[i];(d.nodeName==="LINK"||d.getAttribute("media")!=="not all")&&(n.set(d.dataset.precedence,d),l=d)}l&&n.set(null,l)}s=t.instance,d=s.getAttribute("data-precedence"),i=n.get(d)||l,i===l&&n.set(null,s),n.set(d,s),this.count++,l=Ai.bind(this),s.addEventListener("load",l),s.addEventListener("error",l),i?i.parentNode.insertBefore(s,i.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(s,e.firstChild)),t.state.loading|=4}}var es={$$typeof:k,Provider:null,Consumer:null,_currentValue:W,_currentValue2:W,_threadCount:0};function n0(e,t,n,l,s,i,d,f,T){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=ir(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=ir(0),this.hiddenUpdates=ir(null),this.identifierPrefix=l,this.onUncaughtError=s,this.onCaughtError=i,this.onRecoverableError=d,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=T,this.incompleteTransitions=new Map}function Wh(e,t,n,l,s,i,d,f,T,H,P,J){return e=new n0(e,t,n,d,T,H,P,J,f),t=1,i===!0&&(t|=24),i=Sa(3,null,null,t),e.current=i,i.stateNode=e,t=Pr(),t.refCount++,e.pooledCache=t,t.refCount++,i.memoizedState={element:l,isDehydrated:n,cache:t},Xr(i),e}function Fh(e){return e?(e=Rn,e):Rn}function ep(e,t,n,l,s,i){s=Fh(s),l.context===null?l.context=s:l.pendingContext=s,l=Mt(t),l.payload={element:n},i=i===void 0?null:i,i!==null&&(l.callback=i),n=Et(e,l,t),n!==null&&(xa(n,e,t),Ml(n,e,t))}function ap(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function ho(e,t){ap(e,t),(e=e.alternate)&&ap(e,t)}function tp(e){if(e.tag===13||e.tag===31){var t=ln(e,67108864);t!==null&&xa(t,e,67108864),ho(e,67108864)}}function np(e){if(e.tag===13||e.tag===31){var t=Ca();t=rr(t);var n=ln(e,t);n!==null&&xa(n,e,t),ho(e,t)}}var _i=!0;function l0(e,t,n,l){var s=I.T;I.T=null;var i=G.p;try{G.p=2,po(e,t,n,l)}finally{G.p=i,I.T=s}}function s0(e,t,n,l){var s=I.T;I.T=null;var i=G.p;try{G.p=8,po(e,t,n,l)}finally{G.p=i,I.T=s}}function po(e,t,n,l){if(_i){var s=fo(l);if(s===null)Fc(e,t,l,Mi,n),sp(e,l);else if(r0(s,e,t,n,l))l.stopPropagation();else if(sp(e,l),t&4&&-1<i0.indexOf(e)){for(;s!==null;){var i=kn(s);if(i!==null)switch(i.tag){case 3:if(i=i.stateNode,i.current.memoizedState.isDehydrated){var d=Ft(i.pendingLanes);if(d!==0){var f=i;for(f.pendingLanes|=2,f.entangledLanes|=2;d;){var T=1<<31-Na(d);f.entanglements[1]|=T,d&=~T}Va(i),(we&6)===0&&(pi=ja()+500,Xl(0))}}break;case 31:case 13:f=ln(i,2),f!==null&&xa(f,i,2),gi(),ho(i,2)}if(i=fo(l),i===null&&Fc(e,t,l,Mi,n),i===s)break;s=i}s!==null&&l.stopPropagation()}else Fc(e,t,l,null,n)}}function fo(e){return e=gr(e),go(e)}var Mi=null;function go(e){if(Mi=null,e=Nn(e),e!==null){var t=m(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=x(t),e!==null)return e;e=null}else if(n===31){if(e=g(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return Mi=e,null}function lp(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Gf()){case md:return 2;case hd:return 8;case ys:case Qf:return 32;case pd:return 268435456;default:return 32}default:return 32}}var xo=!1,Pt=null,Gt=null,Qt=null,as=new Map,ts=new Map,Yt=[],i0="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function sp(e,t){switch(e){case"focusin":case"focusout":Pt=null;break;case"dragenter":case"dragleave":Gt=null;break;case"mouseover":case"mouseout":Qt=null;break;case"pointerover":case"pointerout":as.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":ts.delete(t.pointerId)}}function ns(e,t,n,l,s,i){return e===null||e.nativeEvent!==i?(e={blockedOn:t,domEventName:n,eventSystemFlags:l,nativeEvent:i,targetContainers:[s]},t!==null&&(t=kn(t),t!==null&&tp(t)),e):(e.eventSystemFlags|=l,t=e.targetContainers,s!==null&&t.indexOf(s)===-1&&t.push(s),e)}function r0(e,t,n,l,s){switch(t){case"focusin":return Pt=ns(Pt,e,t,n,l,s),!0;case"dragenter":return Gt=ns(Gt,e,t,n,l,s),!0;case"mouseover":return Qt=ns(Qt,e,t,n,l,s),!0;case"pointerover":var i=s.pointerId;return as.set(i,ns(as.get(i)||null,e,t,n,l,s)),!0;case"gotpointercapture":return i=s.pointerId,ts.set(i,ns(ts.get(i)||null,e,t,n,l,s)),!0}return!1}function ip(e){var t=Nn(e.target);if(t!==null){var n=m(t);if(n!==null){if(t=n.tag,t===13){if(t=x(n),t!==null){e.blockedOn=t,jd(e.priority,function(){np(n)});return}}else if(t===31){if(t=g(n),t!==null){e.blockedOn=t,jd(e.priority,function(){np(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Ei(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=fo(e.nativeEvent);if(n===null){n=e.nativeEvent;var l=new n.constructor(n.type,n);fr=l,n.target.dispatchEvent(l),fr=null}else return t=kn(n),t!==null&&tp(t),e.blockedOn=n,!1;t.shift()}return!0}function rp(e,t,n){Ei(e)&&n.delete(t)}function c0(){xo=!1,Pt!==null&&Ei(Pt)&&(Pt=null),Gt!==null&&Ei(Gt)&&(Gt=null),Qt!==null&&Ei(Qt)&&(Qt=null),as.forEach(rp),ts.forEach(rp)}function Ri(e,t){e.blockedOn===t&&(e.blockedOn=null,xo||(xo=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,c0)))}var Ui=null;function cp(e){Ui!==e&&(Ui=e,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){Ui===e&&(Ui=null);for(var t=0;t<e.length;t+=3){var n=e[t],l=e[t+1],s=e[t+2];if(typeof l!="function"){if(go(l||n)===null)continue;break}var i=kn(n);i!==null&&(e.splice(t,3),t-=3,pc(i,{pending:!0,data:s,method:n.method,action:l},l,s))}}))}function ll(e){function t(T){return Ri(T,e)}Pt!==null&&Ri(Pt,e),Gt!==null&&Ri(Gt,e),Qt!==null&&Ri(Qt,e),as.forEach(t),ts.forEach(t);for(var n=0;n<Yt.length;n++){var l=Yt[n];l.blockedOn===e&&(l.blockedOn=null)}for(;0<Yt.length&&(n=Yt[0],n.blockedOn===null);)ip(n),n.blockedOn===null&&Yt.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(l=0;l<n.length;l+=3){var s=n[l],i=n[l+1],d=s[ua]||null;if(typeof i=="function")d||cp(n);else if(d){var f=null;if(i&&i.hasAttribute("formAction")){if(s=i,d=i[ua]||null)f=d.formAction;else if(go(s)!==null)continue}else f=d.action;typeof f=="function"?n[l+1]=f:(n.splice(l,3),l-=3),cp(n)}}}function op(){function e(i){i.canIntercept&&i.info==="react-transition"&&i.intercept({handler:function(){return new Promise(function(d){return s=d})},focusReset:"manual",scroll:"manual"})}function t(){s!==null&&(s(),s=null),l||setTimeout(n,20)}function n(){if(!l&&!navigation.transition){var i=navigation.currentEntry;i&&i.url!=null&&navigation.navigate(i.url,{state:i.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var l=!1,s=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(n,100),function(){l=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),s!==null&&(s(),s=null)}}}function vo(e){this._internalRoot=e}Li.prototype.render=vo.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(o(409));var n=t.current,l=Ca();ep(n,l,e,t,null,null)},Li.prototype.unmount=vo.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;ep(e.current,2,null,e,null,null),gi(),t[yn]=null}};function Li(e){this._internalRoot=e}Li.prototype.unstable_scheduleHydration=function(e){if(e){var t=bd();e={blockedOn:null,target:e,priority:t};for(var n=0;n<Yt.length&&t!==0&&t<Yt[n].priority;n++);Yt.splice(n,0,e),n===0&&ip(e)}};var dp=c.version;if(dp!=="19.2.3")throw Error(o(527,dp,"19.2.3"));G.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(o(188)):(e=Object.keys(e).join(","),Error(o(268,e)));return e=p(t),e=e!==null?z(e):null,e=e===null?null:e.stateNode,e};var o0={bundleType:0,version:"19.2.3",rendererPackageName:"react-dom",currentDispatcherRef:I,reconcilerVersion:"19.2.3"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Oi=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Oi.isDisabled&&Oi.supportsFiber)try{ml=Oi.inject(o0),ya=Oi}catch{}}return ss.createRoot=function(e,t){if(!h(e))throw Error(o(299));var n=!1,l="",s=xm,i=vm,d=bm;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(l=t.identifierPrefix),t.onUncaughtError!==void 0&&(s=t.onUncaughtError),t.onCaughtError!==void 0&&(i=t.onCaughtError),t.onRecoverableError!==void 0&&(d=t.onRecoverableError)),t=Wh(e,1,!1,null,null,n,l,null,s,i,d,op),e[yn]=t.current,Wc(e),new vo(t)},ss.hydrateRoot=function(e,t,n){if(!h(e))throw Error(o(299));var l=!1,s="",i=xm,d=vm,f=bm,T=null;return n!=null&&(n.unstable_strictMode===!0&&(l=!0),n.identifierPrefix!==void 0&&(s=n.identifierPrefix),n.onUncaughtError!==void 0&&(i=n.onUncaughtError),n.onCaughtError!==void 0&&(d=n.onCaughtError),n.onRecoverableError!==void 0&&(f=n.onRecoverableError),n.formState!==void 0&&(T=n.formState)),t=Wh(e,1,!0,t,n??null,l,s,T,i,d,f,op),t.context=Fh(null),n=t.current,l=Ca(),l=rr(l),s=Mt(l),s.callback=null,Et(n,s,l),n=l,t.current.lanes=n,pl(t,n),Va(t),e[yn]=t.current,Wc(e),new Li(t)},ss.version="19.2.3",ss}var jp;function b0(){if(jp)return yo.exports;jp=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(c){console.error(c)}}return r(),yo.exports=v0(),yo.exports}var j0=b0();var yp="popstate";function y0(r={}){function c(o,h){let{pathname:m,search:x,hash:g}=o.location;return Go("",{pathname:m,search:x,hash:g},h.state&&h.state.usr||null,h.state&&h.state.key||"default")}function u(o,h){return typeof h=="string"?h:hs(h)}return k0(c,u,null,r)}function Ke(r,c){if(r===!1||r===null||typeof r>"u")throw new Error(c)}function $a(r,c){if(!r){typeof console<"u"&&console.warn(c);try{throw new Error(c)}catch{}}}function N0(){return Math.random().toString(36).substring(2,10)}function Np(r,c){return{usr:r.state,key:r.key,idx:c}}function Go(r,c,u=null,o){return{pathname:typeof r=="string"?r:r.pathname,search:"",hash:"",...typeof c=="string"?rl(c):c,state:u,key:c&&c.key||o||N0()}}function hs({pathname:r="/",search:c="",hash:u=""}){return c&&c!=="?"&&(r+=c.charAt(0)==="?"?c:"?"+c),u&&u!=="#"&&(r+=u.charAt(0)==="#"?u:"#"+u),r}function rl(r){let c={};if(r){let u=r.indexOf("#");u>=0&&(c.hash=r.substring(u),r=r.substring(0,u));let o=r.indexOf("?");o>=0&&(c.search=r.substring(o),r=r.substring(0,o)),r&&(c.pathname=r)}return c}function k0(r,c,u,o={}){let{window:h=document.defaultView,v5Compat:m=!1}=o,x=h.history,g="POP",b=null,p=z();p==null&&(p=0,x.replaceState({...x.state,idx:p},""));function z(){return(x.state||{idx:null}).idx}function N(){g="POP";let j=z(),w=j==null?null:j-p;p=j,b&&b({action:g,location:R.location,delta:w})}function S(j,w){g="PUSH";let C=Go(R.location,j,w);p=z()+1;let k=Np(C,p),Q=R.createHref(C);try{x.pushState(k,"",Q)}catch($){if($ instanceof DOMException&&$.name==="DataCloneError")throw $;h.location.assign(Q)}m&&b&&b({action:g,location:R.location,delta:1})}function A(j,w){g="REPLACE";let C=Go(R.location,j,w);p=z();let k=Np(C,p),Q=R.createHref(C);x.replaceState(k,"",Q),m&&b&&b({action:g,location:R.location,delta:0})}function v(j){return S0(j)}let R={get action(){return g},get location(){return r(h,x)},listen(j){if(b)throw new Error("A history only accepts one active listener");return h.addEventListener(yp,N),b=j,()=>{h.removeEventListener(yp,N),b=null}},createHref(j){return c(h,j)},createURL:v,encodeLocation(j){let w=v(j);return{pathname:w.pathname,search:w.search,hash:w.hash}},push:S,replace:A,go(j){return x.go(j)}};return R}function S0(r,c=!1){let u="http://localhost";typeof window<"u"&&(u=window.location.origin!=="null"?window.location.origin:window.location.href),Ke(u,"No window.location.(origin|href) available to create URL");let o=typeof r=="string"?r:hs(r);return o=o.replace(/ $/,"%20"),!c&&o.startsWith("//")&&(o=u+o),new URL(o,u)}function uf(r,c,u="/"){return w0(r,c,u,!1)}function w0(r,c,u,o){let h=typeof c=="string"?rl(c):c,m=Nt(h.pathname||"/",u);if(m==null)return null;let x=mf(r);z0(x);let g=null;for(let b=0;g==null&&b<x.length;++b){let p=O0(m);g=U0(x[b],p,o)}return g}function mf(r,c=[],u=[],o="",h=!1){let m=(x,g,b=h,p)=>{let z={relativePath:p===void 0?x.path||"":p,caseSensitive:x.caseSensitive===!0,childrenIndex:g,route:x};if(z.relativePath.startsWith("/")){if(!z.relativePath.startsWith(o)&&b)return;Ke(z.relativePath.startsWith(o),`Absolute route path "${z.relativePath}" nested under path "${o}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),z.relativePath=z.relativePath.slice(o.length)}let N=yt([o,z.relativePath]),S=u.concat(z);x.children&&x.children.length>0&&(Ke(x.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${N}".`),mf(x.children,c,S,N,b)),!(x.path==null&&!x.index)&&c.push({path:N,score:E0(N,x.index),routesMeta:S})};return r.forEach((x,g)=>{if(x.path===""||!x.path?.includes("?"))m(x,g);else for(let b of hf(x.path))m(x,g,!0,b)}),c}function hf(r){let c=r.split("/");if(c.length===0)return[];let[u,...o]=c,h=u.endsWith("?"),m=u.replace(/\?$/,"");if(o.length===0)return h?[m,""]:[m];let x=hf(o.join("/")),g=[];return g.push(...x.map(b=>b===""?m:[m,b].join("/"))),h&&g.push(...x),g.map(b=>r.startsWith("/")&&b===""?"/":b)}function z0(r){r.sort((c,u)=>c.score!==u.score?u.score-c.score:R0(c.routesMeta.map(o=>o.childrenIndex),u.routesMeta.map(o=>o.childrenIndex)))}var T0=/^:[\w-]+$/,A0=3,C0=2,D0=1,_0=10,M0=-2,kp=r=>r==="*";function E0(r,c){let u=r.split("/"),o=u.length;return u.some(kp)&&(o+=M0),c&&(o+=C0),u.filter(h=>!kp(h)).reduce((h,m)=>h+(T0.test(m)?A0:m===""?D0:_0),o)}function R0(r,c){return r.length===c.length&&r.slice(0,-1).every((o,h)=>o===c[h])?r[r.length-1]-c[c.length-1]:0}function U0(r,c,u=!1){let{routesMeta:o}=r,h={},m="/",x=[];for(let g=0;g<o.length;++g){let b=o[g],p=g===o.length-1,z=m==="/"?c:c.slice(m.length)||"/",N=Qi({path:b.relativePath,caseSensitive:b.caseSensitive,end:p},z),S=b.route;if(!N&&p&&u&&!o[o.length-1].route.index&&(N=Qi({path:b.relativePath,caseSensitive:b.caseSensitive,end:!1},z)),!N)return null;Object.assign(h,N.params),x.push({params:h,pathname:yt([m,N.pathname]),pathnameBase:$0(yt([m,N.pathnameBase])),route:S}),N.pathnameBase!=="/"&&(m=yt([m,N.pathnameBase]))}return x}function Qi(r,c){typeof r=="string"&&(r={path:r,caseSensitive:!1,end:!0});let[u,o]=L0(r.path,r.caseSensitive,r.end),h=c.match(u);if(!h)return null;let m=h[0],x=m.replace(/(.)\/+$/,"$1"),g=h.slice(1);return{params:o.reduce((p,{paramName:z,isOptional:N},S)=>{if(z==="*"){let v=g[S]||"";x=m.slice(0,m.length-v.length).replace(/(.)\/+$/,"$1")}const A=g[S];return N&&!A?p[z]=void 0:p[z]=(A||"").replace(/%2F/g,"/"),p},{}),pathname:m,pathnameBase:x,pattern:r}}function L0(r,c=!1,u=!0){$a(r==="*"||!r.endsWith("*")||r.endsWith("/*"),`Route path "${r}" will be treated as if it were "${r.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${r.replace(/\*$/,"/*")}".`);let o=[],h="^"+r.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(x,g,b)=>(o.push({paramName:g,isOptional:b!=null}),b?"/?([^\\/]+)?":"/([^\\/]+)")).replace(/\/([\w-]+)\?(\/|$)/g,"(/$1)?$2");return r.endsWith("*")?(o.push({paramName:"*"}),h+=r==="*"||r==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):u?h+="\\/*$":r!==""&&r!=="/"&&(h+="(?:(?=\\/|$))"),[new RegExp(h,c?void 0:"i"),o]}function O0(r){try{return r.split("/").map(c=>decodeURIComponent(c).replace(/\//g,"%2F")).join("/")}catch(c){return $a(!1,`The URL path "${r}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${c}).`),r}}function Nt(r,c){if(c==="/")return r;if(!r.toLowerCase().startsWith(c.toLowerCase()))return null;let u=c.endsWith("/")?c.length-1:c.length,o=r.charAt(u);return o&&o!=="/"?null:r.slice(u)||"/"}var pf=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,H0=r=>pf.test(r);function K0(r,c="/"){let{pathname:u,search:o="",hash:h=""}=typeof r=="string"?rl(r):r,m;if(u)if(H0(u))m=u;else{if(u.includes("//")){let x=u;u=u.replace(/\/\/+/g,"/"),$a(!1,`Pathnames cannot have embedded double slashes - normalizing ${x} -> ${u}`)}u.startsWith("/")?m=Sp(u.substring(1),"/"):m=Sp(u,c)}else m=c;return{pathname:m,search:q0(o),hash:I0(h)}}function Sp(r,c){let u=c.replace(/\/+$/,"").split("/");return r.split("/").forEach(h=>{h===".."?u.length>1&&u.pop():h!=="."&&u.push(h)}),u.length>1?u.join("/"):"/"}function wo(r,c,u,o){return`Cannot include a '${r}' character in a manually specified \`to.${c}\` field [${JSON.stringify(o)}].  Please separate it out to the \`to.${u}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function B0(r){return r.filter((c,u)=>u===0||c.route.path&&c.route.path.length>0)}function Wo(r){let c=B0(r);return c.map((u,o)=>o===c.length-1?u.pathname:u.pathnameBase)}function Fo(r,c,u,o=!1){let h;typeof r=="string"?h=rl(r):(h={...r},Ke(!h.pathname||!h.pathname.includes("?"),wo("?","pathname","search",h)),Ke(!h.pathname||!h.pathname.includes("#"),wo("#","pathname","hash",h)),Ke(!h.search||!h.search.includes("#"),wo("#","search","hash",h)));let m=r===""||h.pathname==="",x=m?"/":h.pathname,g;if(x==null)g=u;else{let N=c.length-1;if(!o&&x.startsWith("..")){let S=x.split("/");for(;S[0]==="..";)S.shift(),N-=1;h.pathname=S.join("/")}g=N>=0?c[N]:"/"}let b=K0(h,g),p=x&&x!=="/"&&x.endsWith("/"),z=(m||x===".")&&u.endsWith("/");return!b.pathname.endsWith("/")&&(p||z)&&(b.pathname+="/"),b}var yt=r=>r.join("/").replace(/\/\/+/g,"/"),$0=r=>r.replace(/\/+$/,"").replace(/^\/*/,"/"),q0=r=>!r||r==="?"?"":r.startsWith("?")?r:"?"+r,I0=r=>!r||r==="#"?"":r.startsWith("#")?r:"#"+r,P0=class{constructor(r,c,u,o=!1){this.status=r,this.statusText=c||"",this.internal=o,u instanceof Error?(this.data=u.toString(),this.error=u):this.data=u}};function G0(r){return r!=null&&typeof r.status=="number"&&typeof r.statusText=="string"&&typeof r.internal=="boolean"&&"data"in r}function Q0(r){return r.map(c=>c.route.path).filter(Boolean).join("/").replace(/\/\/*/g,"/")||"/"}var ff=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";function gf(r,c){let u=r;if(typeof u!="string"||!pf.test(u))return{absoluteURL:void 0,isExternal:!1,to:u};let o=u,h=!1;if(ff)try{let m=new URL(window.location.href),x=u.startsWith("//")?new URL(m.protocol+u):new URL(u),g=Nt(x.pathname,c);x.origin===m.origin&&g!=null?u=g+x.search+x.hash:h=!0}catch{$a(!1,`<Link to="${u}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}return{absoluteURL:o,isExternal:h,to:u}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");var xf=["POST","PUT","PATCH","DELETE"];new Set(xf);var Y0=["GET",...xf];new Set(Y0);var cl=y.createContext(null);cl.displayName="DataRouter";var Wi=y.createContext(null);Wi.displayName="DataRouterState";var X0=y.createContext(!1),vf=y.createContext({isTransitioning:!1});vf.displayName="ViewTransition";var V0=y.createContext(new Map);V0.displayName="Fetchers";var J0=y.createContext(null);J0.displayName="Await";var Da=y.createContext(null);Da.displayName="Navigation";var fs=y.createContext(null);fs.displayName="Location";var Za=y.createContext({outlet:null,matches:[],isDataRoute:!1});Za.displayName="Route";var ed=y.createContext(null);ed.displayName="RouteError";var bf="REACT_ROUTER_ERROR",Z0="REDIRECT",W0="ROUTE_ERROR_RESPONSE";function F0(r){if(r.startsWith(`${bf}:${Z0}:{`))try{let c=JSON.parse(r.slice(28));if(typeof c=="object"&&c&&typeof c.status=="number"&&typeof c.statusText=="string"&&typeof c.location=="string"&&typeof c.reloadDocument=="boolean"&&typeof c.replace=="boolean")return c}catch{}}function ev(r){if(r.startsWith(`${bf}:${W0}:{`))try{let c=JSON.parse(r.slice(40));if(typeof c=="object"&&c&&typeof c.status=="number"&&typeof c.statusText=="string")return new P0(c.status,c.statusText,c.data)}catch{}}function av(r,{relative:c}={}){Ke(ol(),"useHref() may be used only in the context of a <Router> component.");let{basename:u,navigator:o}=y.useContext(Da),{hash:h,pathname:m,search:x}=gs(r,{relative:c}),g=m;return u!=="/"&&(g=m==="/"?u:yt([u,m])),o.createHref({pathname:g,search:x,hash:h})}function ol(){return y.useContext(fs)!=null}function Zt(){return Ke(ol(),"useLocation() may be used only in the context of a <Router> component."),y.useContext(fs).location}var jf="You should call navigate() in a React.useEffect(), not when your component is first rendered.";function yf(r){y.useContext(Da).static||y.useLayoutEffect(r)}function jn(){let{isDataRoute:r}=y.useContext(Za);return r?pv():tv()}function tv(){Ke(ol(),"useNavigate() may be used only in the context of a <Router> component.");let r=y.useContext(cl),{basename:c,navigator:u}=y.useContext(Da),{matches:o}=y.useContext(Za),{pathname:h}=Zt(),m=JSON.stringify(Wo(o)),x=y.useRef(!1);return yf(()=>{x.current=!0}),y.useCallback((b,p={})=>{if($a(x.current,jf),!x.current)return;if(typeof b=="number"){u.go(b);return}let z=Fo(b,JSON.parse(m),h,p.relative==="path");r==null&&c!=="/"&&(z.pathname=z.pathname==="/"?c:yt([c,z.pathname])),(p.replace?u.replace:u.push)(z,p.state,p)},[c,u,m,h,r])}y.createContext(null);function gs(r,{relative:c}={}){let{matches:u}=y.useContext(Za),{pathname:o}=Zt(),h=JSON.stringify(Wo(u));return y.useMemo(()=>Fo(r,JSON.parse(h),o,c==="path"),[r,h,o,c])}function nv(r,c){return Nf(r,c)}function Nf(r,c,u,o,h){Ke(ol(),"useRoutes() may be used only in the context of a <Router> component.");let{navigator:m}=y.useContext(Da),{matches:x}=y.useContext(Za),g=x[x.length-1],b=g?g.params:{},p=g?g.pathname:"/",z=g?g.pathnameBase:"/",N=g&&g.route;{let C=N&&N.path||"";Sf(p,!N||C.endsWith("*")||C.endsWith("*?"),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${p}" (under <Route path="${C}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${C}"> to <Route path="${C==="/"?"*":`${C}/*`}">.`)}let S=Zt(),A;if(c){let C=typeof c=="string"?rl(c):c;Ke(z==="/"||C.pathname?.startsWith(z),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${z}" but pathname "${C.pathname}" was given in the \`location\` prop.`),A=C}else A=S;let v=A.pathname||"/",R=v;if(z!=="/"){let C=z.replace(/^\//,"").split("/");R="/"+v.replace(/^\//,"").split("/").slice(C.length).join("/")}let j=uf(r,{pathname:R});$a(N||j!=null,`No routes matched location "${A.pathname}${A.search}${A.hash}" `),$a(j==null||j[j.length-1].route.element!==void 0||j[j.length-1].route.Component!==void 0||j[j.length-1].route.lazy!==void 0,`Matched leaf route at location "${A.pathname}${A.search}${A.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let w=cv(j&&j.map(C=>Object.assign({},C,{params:Object.assign({},b,C.params),pathname:yt([z,m.encodeLocation?m.encodeLocation(C.pathname.replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:C.pathname]),pathnameBase:C.pathnameBase==="/"?z:yt([z,m.encodeLocation?m.encodeLocation(C.pathnameBase.replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:C.pathnameBase])})),x,u,o,h);return c&&w?y.createElement(fs.Provider,{value:{location:{pathname:"/",search:"",hash:"",state:null,key:"default",...A},navigationType:"POP"}},w):w}function lv(){let r=hv(),c=G0(r)?`${r.status} ${r.statusText}`:r instanceof Error?r.message:JSON.stringify(r),u=r instanceof Error?r.stack:null,o="rgba(200,200,200, 0.5)",h={padding:"0.5rem",backgroundColor:o},m={padding:"2px 4px",backgroundColor:o},x=null;return console.error("Error handled by React Router default ErrorBoundary:",r),x=y.createElement(y.Fragment,null,y.createElement("p",null,"💿 Hey developer 👋"),y.createElement("p",null,"You can provide a way better UX than this when your app throws errors by providing your own ",y.createElement("code",{style:m},"ErrorBoundary")," or"," ",y.createElement("code",{style:m},"errorElement")," prop on your route.")),y.createElement(y.Fragment,null,y.createElement("h2",null,"Unexpected Application Error!"),y.createElement("h3",{style:{fontStyle:"italic"}},c),u?y.createElement("pre",{style:h},u):null,x)}var sv=y.createElement(lv,null),kf=class extends y.Component{constructor(r){super(r),this.state={location:r.location,revalidation:r.revalidation,error:r.error}}static getDerivedStateFromError(r){return{error:r}}static getDerivedStateFromProps(r,c){return c.location!==r.location||c.revalidation!=="idle"&&r.revalidation==="idle"?{error:r.error,location:r.location,revalidation:r.revalidation}:{error:r.error!==void 0?r.error:c.error,location:c.location,revalidation:r.revalidation||c.revalidation}}componentDidCatch(r,c){this.props.onError?this.props.onError(r,c):console.error("React Router caught the following error during render",r)}render(){let r=this.state.error;if(this.context&&typeof r=="object"&&r&&"digest"in r&&typeof r.digest=="string"){const u=ev(r.digest);u&&(r=u)}let c=r!==void 0?y.createElement(Za.Provider,{value:this.props.routeContext},y.createElement(ed.Provider,{value:r,children:this.props.component})):this.props.children;return this.context?y.createElement(iv,{error:r},c):c}};kf.contextType=X0;var zo=new WeakMap;function iv({children:r,error:c}){let{basename:u}=y.useContext(Da);if(typeof c=="object"&&c&&"digest"in c&&typeof c.digest=="string"){let o=F0(c.digest);if(o){let h=zo.get(c);if(h)throw h;let m=gf(o.location,u);if(ff&&!zo.get(c))if(m.isExternal||o.reloadDocument)window.location.href=m.absoluteURL||m.to;else{const x=Promise.resolve().then(()=>window.__reactRouterDataRouter.navigate(m.to,{replace:o.replace}));throw zo.set(c,x),x}return y.createElement("meta",{httpEquiv:"refresh",content:`0;url=${m.absoluteURL||m.to}`})}}return r}function rv({routeContext:r,match:c,children:u}){let o=y.useContext(cl);return o&&o.static&&o.staticContext&&(c.route.errorElement||c.route.ErrorBoundary)&&(o.staticContext._deepestRenderedBoundaryId=c.route.id),y.createElement(Za.Provider,{value:r},u)}function cv(r,c=[],u=null,o=null,h=null){if(r==null){if(!u)return null;if(u.errors)r=u.matches;else if(c.length===0&&!u.initialized&&u.matches.length>0)r=u.matches;else return null}let m=r,x=u?.errors;if(x!=null){let z=m.findIndex(N=>N.route.id&&x?.[N.route.id]!==void 0);Ke(z>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(x).join(",")}`),m=m.slice(0,Math.min(m.length,z+1))}let g=!1,b=-1;if(u)for(let z=0;z<m.length;z++){let N=m[z];if((N.route.HydrateFallback||N.route.hydrateFallbackElement)&&(b=z),N.route.id){let{loaderData:S,errors:A}=u,v=N.route.loader&&!S.hasOwnProperty(N.route.id)&&(!A||A[N.route.id]===void 0);if(N.route.lazy||v){g=!0,b>=0?m=m.slice(0,b+1):m=[m[0]];break}}}let p=u&&o?(z,N)=>{o(z,{location:u.location,params:u.matches?.[0]?.params??{},unstable_pattern:Q0(u.matches),errorInfo:N})}:void 0;return m.reduceRight((z,N,S)=>{let A,v=!1,R=null,j=null;u&&(A=x&&N.route.id?x[N.route.id]:void 0,R=N.route.errorElement||sv,g&&(b<0&&S===0?(Sf("route-fallback",!1,"No `HydrateFallback` element provided to render during initial hydration"),v=!0,j=null):b===S&&(v=!0,j=N.route.hydrateFallbackElement||null)));let w=c.concat(m.slice(0,S+1)),C=()=>{let k;return A?k=R:v?k=j:N.route.Component?k=y.createElement(N.route.Component,null):N.route.element?k=N.route.element:k=z,y.createElement(rv,{match:N,routeContext:{outlet:z,matches:w,isDataRoute:u!=null},children:k})};return u&&(N.route.ErrorBoundary||N.route.errorElement||S===0)?y.createElement(kf,{location:u.location,revalidation:u.revalidation,component:R,error:A,children:C(),routeContext:{outlet:null,matches:w,isDataRoute:!0},onError:p}):C()},null)}function ad(r){return`${r} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function ov(r){let c=y.useContext(cl);return Ke(c,ad(r)),c}function dv(r){let c=y.useContext(Wi);return Ke(c,ad(r)),c}function uv(r){let c=y.useContext(Za);return Ke(c,ad(r)),c}function td(r){let c=uv(r),u=c.matches[c.matches.length-1];return Ke(u.route.id,`${r} can only be used on routes that contain a unique "id"`),u.route.id}function mv(){return td("useRouteId")}function hv(){let r=y.useContext(ed),c=dv("useRouteError"),u=td("useRouteError");return r!==void 0?r:c.errors?.[u]}function pv(){let{router:r}=ov("useNavigate"),c=td("useNavigate"),u=y.useRef(!1);return yf(()=>{u.current=!0}),y.useCallback(async(h,m={})=>{$a(u.current,jf),u.current&&(typeof h=="number"?await r.navigate(h):await r.navigate(h,{fromRouteId:c,...m}))},[r,c])}var wp={};function Sf(r,c,u){!c&&!wp[r]&&(wp[r]=!0,$a(!1,u))}y.memo(fv);function fv({routes:r,future:c,state:u,onError:o}){return Nf(r,void 0,u,o,c)}function ds({to:r,replace:c,state:u,relative:o}){Ke(ol(),"<Navigate> may be used only in the context of a <Router> component.");let{static:h}=y.useContext(Da);$a(!h,"<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.");let{matches:m}=y.useContext(Za),{pathname:x}=Zt(),g=jn(),b=Fo(r,Wo(m),x,o==="path"),p=JSON.stringify(b);return y.useEffect(()=>{g(JSON.parse(p),{replace:c,state:u,relative:o})},[g,p,o,c,u]),null}function ie(r){Ke(!1,"A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.")}function gv({basename:r="/",children:c=null,location:u,navigationType:o="POP",navigator:h,static:m=!1,unstable_useTransitions:x}){Ke(!ol(),"You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");let g=r.replace(/^\/*/,"/"),b=y.useMemo(()=>({basename:g,navigator:h,static:m,unstable_useTransitions:x,future:{}}),[g,h,m,x]);typeof u=="string"&&(u=rl(u));let{pathname:p="/",search:z="",hash:N="",state:S=null,key:A="default"}=u,v=y.useMemo(()=>{let R=Nt(p,g);return R==null?null:{location:{pathname:R,search:z,hash:N,state:S,key:A},navigationType:o}},[g,p,z,N,S,A,o]);return $a(v!=null,`<Router basename="${g}"> is not able to match the URL "${p}${z}${N}" because it does not start with the basename, so the <Router> won't render anything.`),v==null?null:y.createElement(Da.Provider,{value:b},y.createElement(fs.Provider,{children:c,value:v}))}function xv({children:r,location:c}){return nv(Qo(r),c)}function Qo(r,c=[]){let u=[];return y.Children.forEach(r,(o,h)=>{if(!y.isValidElement(o))return;let m=[...c,h];if(o.type===y.Fragment){u.push.apply(u,Qo(o.props.children,m));return}Ke(o.type===ie,`[${typeof o.type=="string"?o.type:o.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),Ke(!o.props.index||!o.props.children,"An index route cannot have child routes.");let x={id:o.props.id||m.join("-"),caseSensitive:o.props.caseSensitive,element:o.props.element,Component:o.props.Component,index:o.props.index,path:o.props.path,middleware:o.props.middleware,loader:o.props.loader,action:o.props.action,hydrateFallbackElement:o.props.hydrateFallbackElement,HydrateFallback:o.props.HydrateFallback,errorElement:o.props.errorElement,ErrorBoundary:o.props.ErrorBoundary,hasErrorBoundary:o.props.hasErrorBoundary===!0||o.props.ErrorBoundary!=null||o.props.errorElement!=null,shouldRevalidate:o.props.shouldRevalidate,handle:o.props.handle,lazy:o.props.lazy};o.props.children&&(x.children=Qo(o.props.children,m)),u.push(x)}),u}var Ii="get",Pi="application/x-www-form-urlencoded";function Fi(r){return typeof HTMLElement<"u"&&r instanceof HTMLElement}function vv(r){return Fi(r)&&r.tagName.toLowerCase()==="button"}function bv(r){return Fi(r)&&r.tagName.toLowerCase()==="form"}function jv(r){return Fi(r)&&r.tagName.toLowerCase()==="input"}function yv(r){return!!(r.metaKey||r.altKey||r.ctrlKey||r.shiftKey)}function Nv(r,c){return r.button===0&&(!c||c==="_self")&&!yv(r)}var Hi=null;function kv(){if(Hi===null)try{new FormData(document.createElement("form"),0),Hi=!1}catch{Hi=!0}return Hi}var Sv=new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);function To(r){return r!=null&&!Sv.has(r)?($a(!1,`"${r}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${Pi}"`),null):r}function wv(r,c){let u,o,h,m,x;if(bv(r)){let g=r.getAttribute("action");o=g?Nt(g,c):null,u=r.getAttribute("method")||Ii,h=To(r.getAttribute("enctype"))||Pi,m=new FormData(r)}else if(vv(r)||jv(r)&&(r.type==="submit"||r.type==="image")){let g=r.form;if(g==null)throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');let b=r.getAttribute("formaction")||g.getAttribute("action");if(o=b?Nt(b,c):null,u=r.getAttribute("formmethod")||g.getAttribute("method")||Ii,h=To(r.getAttribute("formenctype"))||To(g.getAttribute("enctype"))||Pi,m=new FormData(g,r),!kv()){let{name:p,type:z,value:N}=r;if(z==="image"){let S=p?`${p}.`:"";m.append(`${S}x`,"0"),m.append(`${S}y`,"0")}else p&&m.append(p,N)}}else{if(Fi(r))throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');u=Ii,o=null,h=Pi,x=r}return m&&h==="text/plain"&&(x=m,m=void 0),{action:o,method:u.toLowerCase(),encType:h,formData:m,body:x}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");function nd(r,c){if(r===!1||r===null||typeof r>"u")throw new Error(c)}function zv(r,c,u){let o=typeof r=="string"?new URL(r,typeof window>"u"?"server://singlefetch/":window.location.origin):r;return o.pathname==="/"?o.pathname=`_root.${u}`:c&&Nt(o.pathname,c)==="/"?o.pathname=`${c.replace(/\/$/,"")}/_root.${u}`:o.pathname=`${o.pathname.replace(/\/$/,"")}.${u}`,o}async function Tv(r,c){if(r.id in c)return c[r.id];try{let u=await import(r.module);return c[r.id]=u,u}catch(u){return console.error(`Error loading route module \`${r.module}\`, reloading page...`),console.error(u),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function Av(r){return r==null?!1:r.href==null?r.rel==="preload"&&typeof r.imageSrcSet=="string"&&typeof r.imageSizes=="string":typeof r.rel=="string"&&typeof r.href=="string"}async function Cv(r,c,u){let o=await Promise.all(r.map(async h=>{let m=c.routes[h.route.id];if(m){let x=await Tv(m,u);return x.links?x.links():[]}return[]}));return Ev(o.flat(1).filter(Av).filter(h=>h.rel==="stylesheet"||h.rel==="preload").map(h=>h.rel==="stylesheet"?{...h,rel:"prefetch",as:"style"}:{...h,rel:"prefetch"}))}function zp(r,c,u,o,h,m){let x=(b,p)=>u[p]?b.route.id!==u[p].route.id:!0,g=(b,p)=>u[p].pathname!==b.pathname||u[p].route.path?.endsWith("*")&&u[p].params["*"]!==b.params["*"];return m==="assets"?c.filter((b,p)=>x(b,p)||g(b,p)):m==="data"?c.filter((b,p)=>{let z=o.routes[b.route.id];if(!z||!z.hasLoader)return!1;if(x(b,p)||g(b,p))return!0;if(b.route.shouldRevalidate){let N=b.route.shouldRevalidate({currentUrl:new URL(h.pathname+h.search+h.hash,window.origin),currentParams:u[0]?.params||{},nextUrl:new URL(r,window.origin),nextParams:b.params,defaultShouldRevalidate:!0});if(typeof N=="boolean")return N}return!0}):[]}function Dv(r,c,{includeHydrateFallback:u}={}){return _v(r.map(o=>{let h=c.routes[o.route.id];if(!h)return[];let m=[h.module];return h.clientActionModule&&(m=m.concat(h.clientActionModule)),h.clientLoaderModule&&(m=m.concat(h.clientLoaderModule)),u&&h.hydrateFallbackModule&&(m=m.concat(h.hydrateFallbackModule)),h.imports&&(m=m.concat(h.imports)),m}).flat(1))}function _v(r){return[...new Set(r)]}function Mv(r){let c={},u=Object.keys(r).sort();for(let o of u)c[o]=r[o];return c}function Ev(r,c){let u=new Set;return new Set(c),r.reduce((o,h)=>{let m=JSON.stringify(Mv(h));return u.has(m)||(u.add(m),o.push({key:m,link:h})),o},[])}function wf(){let r=y.useContext(cl);return nd(r,"You must render this element inside a <DataRouterContext.Provider> element"),r}function Rv(){let r=y.useContext(Wi);return nd(r,"You must render this element inside a <DataRouterStateContext.Provider> element"),r}var ld=y.createContext(void 0);ld.displayName="FrameworkContext";function zf(){let r=y.useContext(ld);return nd(r,"You must render this element inside a <HydratedRouter> element"),r}function Uv(r,c){let u=y.useContext(ld),[o,h]=y.useState(!1),[m,x]=y.useState(!1),{onFocus:g,onBlur:b,onMouseEnter:p,onMouseLeave:z,onTouchStart:N}=c,S=y.useRef(null);y.useEffect(()=>{if(r==="render"&&x(!0),r==="viewport"){let R=w=>{w.forEach(C=>{x(C.isIntersecting)})},j=new IntersectionObserver(R,{threshold:.5});return S.current&&j.observe(S.current),()=>{j.disconnect()}}},[r]),y.useEffect(()=>{if(o){let R=setTimeout(()=>{x(!0)},100);return()=>{clearTimeout(R)}}},[o]);let A=()=>{h(!0)},v=()=>{h(!1),x(!1)};return u?r!=="intent"?[m,S,{}]:[m,S,{onFocus:is(g,A),onBlur:is(b,v),onMouseEnter:is(p,A),onMouseLeave:is(z,v),onTouchStart:is(N,A)}]:[!1,S,{}]}function is(r,c){return u=>{r&&r(u),u.defaultPrevented||c(u)}}function Lv({page:r,...c}){let{router:u}=wf(),o=y.useMemo(()=>uf(u.routes,r,u.basename),[u.routes,r,u.basename]);return o?y.createElement(Hv,{page:r,matches:o,...c}):null}function Ov(r){let{manifest:c,routeModules:u}=zf(),[o,h]=y.useState([]);return y.useEffect(()=>{let m=!1;return Cv(r,c,u).then(x=>{m||h(x)}),()=>{m=!0}},[r,c,u]),o}function Hv({page:r,matches:c,...u}){let o=Zt(),{manifest:h,routeModules:m}=zf(),{basename:x}=wf(),{loaderData:g,matches:b}=Rv(),p=y.useMemo(()=>zp(r,c,b,h,o,"data"),[r,c,b,h,o]),z=y.useMemo(()=>zp(r,c,b,h,o,"assets"),[r,c,b,h,o]),N=y.useMemo(()=>{if(r===o.pathname+o.search+o.hash)return[];let v=new Set,R=!1;if(c.forEach(w=>{let C=h.routes[w.route.id];!C||!C.hasLoader||(!p.some(k=>k.route.id===w.route.id)&&w.route.id in g&&m[w.route.id]?.shouldRevalidate||C.hasClientLoader?R=!0:v.add(w.route.id))}),v.size===0)return[];let j=zv(r,x,"data");return R&&v.size>0&&j.searchParams.set("_routes",c.filter(w=>v.has(w.route.id)).map(w=>w.route.id).join(",")),[j.pathname+j.search]},[x,g,o,h,p,c,r,m]),S=y.useMemo(()=>Dv(z,h),[z,h]),A=Ov(z);return y.createElement(y.Fragment,null,N.map(v=>y.createElement("link",{key:v,rel:"prefetch",as:"fetch",href:v,...u})),S.map(v=>y.createElement("link",{key:v,rel:"modulepreload",href:v,...u})),A.map(({key:v,link:R})=>y.createElement("link",{key:v,nonce:u.nonce,...R})))}function Kv(...r){return c=>{r.forEach(u=>{typeof u=="function"?u(c):u!=null&&(u.current=c)})}}var Bv=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";try{Bv&&(window.__reactRouterVersion="7.11.0")}catch{}function $v({basename:r,children:c,unstable_useTransitions:u,window:o}){let h=y.useRef();h.current==null&&(h.current=y0({window:o,v5Compat:!0}));let m=h.current,[x,g]=y.useState({action:m.action,location:m.location}),b=y.useCallback(p=>{u===!1?g(p):y.startTransition(()=>g(p))},[u]);return y.useLayoutEffect(()=>m.listen(b),[m,b]),y.createElement(gv,{basename:r,children:c,location:x.location,navigationType:x.action,navigator:m,unstable_useTransitions:u})}var Tf=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,Af=y.forwardRef(function({onClick:c,discover:u="render",prefetch:o="none",relative:h,reloadDocument:m,replace:x,state:g,target:b,to:p,preventScrollReset:z,viewTransition:N,unstable_defaultShouldRevalidate:S,...A},v){let{basename:R,unstable_useTransitions:j}=y.useContext(Da),w=typeof p=="string"&&Tf.test(p),C=gf(p,R);p=C.to;let k=av(p,{relative:h}),[Q,$,_]=Uv(o,A),U=Pv(p,{replace:x,state:g,target:b,preventScrollReset:z,relative:h,viewTransition:N,unstable_defaultShouldRevalidate:S,unstable_useTransitions:j});function L(V){c&&c(V),V.defaultPrevented||U(V)}let K=y.createElement("a",{...A,..._,href:C.absoluteURL||k,onClick:C.isExternal||m?c:L,ref:Kv(v,$),target:b,"data-discover":!w&&u==="render"?"true":void 0});return Q&&!w?y.createElement(y.Fragment,null,K,y.createElement(Lv,{page:k})):K});Af.displayName="Link";var Cf=y.forwardRef(function({"aria-current":c="page",caseSensitive:u=!1,className:o="",end:h=!1,style:m,to:x,viewTransition:g,children:b,...p},z){let N=gs(x,{relative:p.relative}),S=Zt(),A=y.useContext(Wi),{navigator:v,basename:R}=y.useContext(Da),j=A!=null&&Vv(N)&&g===!0,w=v.encodeLocation?v.encodeLocation(N).pathname:N.pathname,C=S.pathname,k=A&&A.navigation&&A.navigation.location?A.navigation.location.pathname:null;u||(C=C.toLowerCase(),k=k?k.toLowerCase():null,w=w.toLowerCase()),k&&R&&(k=Nt(k,R)||k);const Q=w!=="/"&&w.endsWith("/")?w.length-1:w.length;let $=C===w||!h&&C.startsWith(w)&&C.charAt(Q)==="/",_=k!=null&&(k===w||!h&&k.startsWith(w)&&k.charAt(w.length)==="/"),U={isActive:$,isPending:_,isTransitioning:j},L=$?c:void 0,K;typeof o=="function"?K=o(U):K=[o,$?"active":null,_?"pending":null,j?"transitioning":null].filter(Boolean).join(" ");let V=typeof m=="function"?m(U):m;return y.createElement(Af,{...p,"aria-current":L,className:K,ref:z,style:V,to:x,viewTransition:g},typeof b=="function"?b(U):b)});Cf.displayName="NavLink";var qv=y.forwardRef(({discover:r="render",fetcherKey:c,navigate:u,reloadDocument:o,replace:h,state:m,method:x=Ii,action:g,onSubmit:b,relative:p,preventScrollReset:z,viewTransition:N,unstable_defaultShouldRevalidate:S,...A},v)=>{let{unstable_useTransitions:R}=y.useContext(Da),j=Yv(),w=Xv(g,{relative:p}),C=x.toLowerCase()==="get"?"get":"post",k=typeof g=="string"&&Tf.test(g),Q=$=>{if(b&&b($),$.defaultPrevented)return;$.preventDefault();let _=$.nativeEvent.submitter,U=_?.getAttribute("formmethod")||x,L=()=>j(_||$.currentTarget,{fetcherKey:c,method:U,navigate:u,replace:h,state:m,relative:p,preventScrollReset:z,viewTransition:N,unstable_defaultShouldRevalidate:S});R&&u!==!1?y.startTransition(()=>L()):L()};return y.createElement("form",{ref:v,method:C,action:w,onSubmit:o?b:Q,...A,"data-discover":!k&&r==="render"?"true":void 0})});qv.displayName="Form";function Iv(r){return`${r} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function Df(r){let c=y.useContext(cl);return Ke(c,Iv(r)),c}function Pv(r,{target:c,replace:u,state:o,preventScrollReset:h,relative:m,viewTransition:x,unstable_defaultShouldRevalidate:g,unstable_useTransitions:b}={}){let p=jn(),z=Zt(),N=gs(r,{relative:m});return y.useCallback(S=>{if(Nv(S,c)){S.preventDefault();let A=u!==void 0?u:hs(z)===hs(N),v=()=>p(r,{replace:A,state:o,preventScrollReset:h,relative:m,viewTransition:x,unstable_defaultShouldRevalidate:g});b?y.startTransition(()=>v()):v()}},[z,p,N,u,o,c,r,h,m,x,g,b])}var Gv=0,Qv=()=>`__${String(++Gv)}__`;function Yv(){let{router:r}=Df("useSubmit"),{basename:c}=y.useContext(Da),u=mv(),o=r.fetch,h=r.navigate;return y.useCallback(async(m,x={})=>{let{action:g,method:b,encType:p,formData:z,body:N}=wv(m,c);if(x.navigate===!1){let S=x.fetcherKey||Qv();await o(S,u,x.action||g,{unstable_defaultShouldRevalidate:x.unstable_defaultShouldRevalidate,preventScrollReset:x.preventScrollReset,formData:z,body:N,formMethod:x.method||b,formEncType:x.encType||p,flushSync:x.flushSync})}else await h(x.action||g,{unstable_defaultShouldRevalidate:x.unstable_defaultShouldRevalidate,preventScrollReset:x.preventScrollReset,formData:z,body:N,formMethod:x.method||b,formEncType:x.encType||p,replace:x.replace,state:x.state,fromRouteId:u,flushSync:x.flushSync,viewTransition:x.viewTransition})},[o,h,c,u])}function Xv(r,{relative:c}={}){let{basename:u}=y.useContext(Da),o=y.useContext(Za);Ke(o,"useFormAction must be used inside a RouteContext");let[h]=o.matches.slice(-1),m={...gs(r||".",{relative:c})},x=Zt();if(r==null){m.search=x.search;let g=new URLSearchParams(m.search),b=g.getAll("index");if(b.some(z=>z==="")){g.delete("index"),b.filter(N=>N).forEach(N=>g.append("index",N));let z=g.toString();m.search=z?`?${z}`:""}}return(!r||r===".")&&h.route.index&&(m.search=m.search?m.search.replace(/^\?/,"?index&"):"?index"),u!=="/"&&(m.pathname=m.pathname==="/"?u:yt([u,m.pathname])),hs(m)}function Vv(r,{relative:c}={}){let u=y.useContext(vf);Ke(u!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:o}=Df("useViewTransitionState"),h=gs(r,{relative:c});if(!u.isTransitioning)return!1;let m=Nt(u.currentLocation.pathname,o)||u.currentLocation.pathname,x=Nt(u.nextLocation.pathname,o)||u.nextLocation.pathname;return Qi(h.pathname,x)!=null||Qi(h.pathname,m)!=null}const Ao={appName:"CAT POLTEKTRANS",appSubtitle:"Sistem Ujian Online",logoUrl:null,primaryColor:"#0891b2",secondaryColor:"#ca8a04",institution:"Politeknik Transportasi SDP Palembang",address:"Jl. Residen Abdul Rozak, Palembang",phone:"(0711) 712345",email:"info@poltektrans.ac.id"},Jv=[{name:"Cyan (Default)",primary:"#0891b2",secondary:"#ca8a04"},{name:"Blue",primary:"#2563eb",secondary:"#dc2626"},{name:"Indigo",primary:"#4f46e5",secondary:"#ea580c"},{name:"Purple",primary:"#7c3aed",secondary:"#059669"},{name:"Emerald",primary:"#059669",secondary:"#7c3aed"},{name:"Teal",primary:"#0d9488",secondary:"#b45309"},{name:"Navy",primary:"#1e3a5f",secondary:"#d4af37"},{name:"Maroon",primary:"#7f1d1d",secondary:"#1e3a5f"}],_f=y.createContext(null);function Wa(){return y.useContext(_f)}function Zv({children:r}){const[c,u]=y.useState(Ao),[o,h]=y.useState(!1);y.useEffect(()=>{const b=localStorage.getItem("cat_app_settings");if(b)try{const p=JSON.parse(b);u({...Ao,...p})}catch(p){console.error("Failed to parse settings:",p)}h(!0)},[]),y.useEffect(()=>{if(o){document.documentElement.style.setProperty("--color-primary",c.primaryColor),document.documentElement.style.setProperty("--color-secondary",c.secondaryColor);const b=Wv(c.primaryColor);b&&(document.documentElement.style.setProperty("--color-primary-light",`hsl(${b.h}, ${b.s}%, ${Math.min(b.l+15,95)}%)`),document.documentElement.style.setProperty("--color-primary-dark",`hsl(${b.h}, ${b.s}%, ${Math.max(b.l-15,5)}%)`))}},[c,o]);const g={settings:c,updateSettings:b=>{const p={...c,...b};u(p),localStorage.setItem("cat_app_settings",JSON.stringify(p))},resetSettings:()=>{u(Ao),localStorage.removeItem("cat_app_settings")},isLoaded:o};return a.jsx(_f.Provider,{value:g,children:r})}function Wv(r){const c=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(r);if(!c)return null;let u=parseInt(c[1],16)/255,o=parseInt(c[2],16)/255,h=parseInt(c[3],16)/255;const m=Math.max(u,o,h),x=Math.min(u,o,h);let g,b,p=(m+x)/2;if(m===x)g=b=0;else{const z=m-x;switch(b=p>.5?z/(2-m-x):z/(m+x),m){case u:g=((o-h)/z+(o<h?6:0))/6;break;case o:g=((h-u)/z+2)/6;break;case h:g=((u-o)/z+4)/6;break}}return{h:Math.round(g*360),s:Math.round(b*100),l:Math.round(p*100)}}const Fv=r=>r.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),eb=r=>r.replace(/^([A-Z])|[\s-_]+(\w)/g,(c,u,o)=>o?o.toUpperCase():u.toLowerCase()),Tp=r=>{const c=eb(r);return c.charAt(0).toUpperCase()+c.slice(1)},Mf=(...r)=>r.filter((c,u,o)=>!!c&&c.trim()!==""&&o.indexOf(c)===u).join(" ").trim(),ab=r=>{for(const c in r)if(c.startsWith("aria-")||c==="role"||c==="title")return!0};var tb={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};const nb=y.forwardRef(({color:r="currentColor",size:c=24,strokeWidth:u=2,absoluteStrokeWidth:o,className:h="",children:m,iconNode:x,...g},b)=>y.createElement("svg",{ref:b,...tb,width:c,height:c,stroke:r,strokeWidth:o?Number(u)*24/Number(c):u,className:Mf("lucide",h),...!m&&!ab(g)&&{"aria-hidden":"true"},...g},[...x.map(([p,z])=>y.createElement(p,z)),...Array.isArray(m)?m:[m]]));const F=(r,c)=>{const u=y.forwardRef(({className:o,...h},m)=>y.createElement(nb,{ref:m,iconNode:c,className:Mf(`lucide-${Fv(Tp(r))}`,`lucide-${r}`,o),...h}));return u.displayName=Tp(r),u};const lb=[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]],Yo=F("activity",lb);const sb=[["path",{d:"M12 6v16",key:"nqf5sj"}],["path",{d:"m19 13 2-1a9 9 0 0 1-18 0l2 1",key:"y7qv08"}],["path",{d:"M9 11h6",key:"1fldmi"}],["circle",{cx:"12",cy:"4",r:"2",key:"muu5ef"}]],ib=F("anchor",sb);const rb=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],sd=F("arrow-right",rb);const cb=[["path",{d:"m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",key:"1yiouv"}],["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}]],Vt=F("award",cb);const ob=[["path",{d:"M4.929 4.929 19.07 19.071",key:"196cmz"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],db=F("ban",ob);const ub=[["path",{d:"M10 2v8l3-3 3 3V2",key:"sqw3rj"}],["path",{d:"M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",key:"k3hazp"}]],Co=F("book-marked",ub);const mb=[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]],xs=F("book-open",mb);const hb=[["path",{d:"M10 12h4",key:"a56b0p"}],["path",{d:"M10 8h4",key:"1sr2af"}],["path",{d:"M14 21v-3a2 2 0 0 0-4 0v3",key:"1rgiei"}],["path",{d:"M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2",key:"secmi2"}],["path",{d:"M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16",key:"16ra0t"}]],Yi=F("building-2",hb);const pb=[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]],va=F("calendar",pb);const fb=[["path",{d:"M13.997 4a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 1.759-1.048l.489-.904A2 2 0 0 1 10.004 4z",key:"18u6gg"}],["circle",{cx:"12",cy:"13",r:"3",key:"1vg3eu"}]],Ap=F("camera",fb);const gb=[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]],Do=F("chart-column",gb);const xb=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],il=F("check",xb);const vb=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],id=F("chevron-down",vb);const bb=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],Ef=F("chevron-left",bb);const jb=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],vs=F("chevron-right",jb);const yb=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],Rf=F("chevron-up",yb);const Nb=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]],us=F("circle-alert",Nb);const kb=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335",key:"yps3ct"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]],We=F("circle-check-big",kb);const Sb=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 12h8",key:"1wcyev"}],["path",{d:"M12 8v8",key:"napkw2"}]],Cp=F("circle-plus",Sb);const wb=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]],zb=F("circle-x",wb);const Tb=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],Uf=F("circle",Tb);const Ab=[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"m9 14 2 2 4-4",key:"df797q"}]],ms=F("clipboard-check",Ab);const Cb=[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"M12 11h4",key:"1jrz19"}],["path",{d:"M12 16h4",key:"n85exb"}],["path",{d:"M8 11h.01",key:"1dfujw"}],["path",{d:"M8 16h.01",key:"18s6g9"}]],Xi=F("clipboard-list",Cb);const Db=[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],Ve=F("clock",Db);const _b=[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]],Dp=F("credit-card",_b);const Mb=[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]],Eb=F("database",Mb);const Rb=[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]],rd=F("download",Rb);const Ub=[["path",{d:"M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",key:"ct8e1f"}],["path",{d:"M14.084 14.158a3 3 0 0 1-4.242-4.242",key:"151rxh"}],["path",{d:"M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",key:"13bj9a"}],["path",{d:"m2 2 20 20",key:"1ooewy"}]],Lb=F("eye-off",Ub);const Ob=[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],Fa=F("eye",Ob);const Hb=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M8 13h2",key:"yr2amv"}],["path",{d:"M14 13h2",key:"un5t4a"}],["path",{d:"M8 17h2",key:"2yhykz"}],["path",{d:"M14 17h2",key:"10kma7"}]],bs=F("file-spreadsheet",Hb);const Kb=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]],Ja=F("file-text",Kb);const Bb=[["path",{d:"M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528",key:"1jaruq"}]],_p=F("flag",Bb);const $b=[["path",{d:"M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",key:"sc7q7i"}]],et=F("funnel",$b);const qb=[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",key:"j76jl0"}],["path",{d:"M22 10v6",key:"1lu8f3"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5",key:"1r8lef"}]],Lf=F("graduation-cap",qb);const Ib=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M3 15h18",key:"5xshup"}],["path",{d:"M9 3v18",key:"fh3hqa"}],["path",{d:"M15 3v18",key:"14nvp0"}]],Pb=F("grid-3x3",Ib);const Gb=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"r6nss1"}]],sl=F("house",Gb);const Qb=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]],Xo=F("image",Qb);const Yb=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]],Of=F("info",Yb);const Xb=[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]],_o=F("layers",Xb);const Vb=[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]],Hf=F("lock",Vb);const Jb=[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]],Zb=F("log-out",Jb);const Wb=[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]],cd=F("map-pin",Wb);const Fb=[["path",{d:"M8 3H5a2 2 0 0 0-2 2v3",key:"1dcmit"}],["path",{d:"M21 8V5a2 2 0 0 0-2-2h-3",key:"1e4gt3"}],["path",{d:"M3 16v3a2 2 0 0 0 2 2h3",key:"wsl5sc"}],["path",{d:"M16 21h3a2 2 0 0 0 2-2v-3",key:"18trek"}]],ej=F("maximize",Fb);const aj=[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]],tj=F("menu",aj);const nj=[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",key:"18887p"}]],lj=F("message-square",nj);const sj=[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]],od=F("monitor",sj);const ij=[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",key:"kfwtm"}]],rj=F("moon",ij);const cj=[["path",{d:"M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z",key:"e79jfc"}],["circle",{cx:"13.5",cy:"6.5",r:".5",fill:"currentColor",key:"1okk4w"}],["circle",{cx:"17.5",cy:"10.5",r:".5",fill:"currentColor",key:"f64h9f"}],["circle",{cx:"6.5",cy:"12.5",r:".5",fill:"currentColor",key:"qy21gx"}],["circle",{cx:"8.5",cy:"7.5",r:".5",fill:"currentColor",key:"fotxhn"}]],oj=F("palette",cj);const dj=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M9 21V9",key:"1oto5p"}]],Vi=F("panels-top-left",dj);const uj=[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}]],kt=F("pen",uj);const mj=[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]],Ji=F("play",mj);const hj=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],Jt=F("plus",hj);const pj=[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]],da=F("printer",pj);const fj=[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]],gj=F("refresh-cw",fj);const xj=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]],vj=F("rotate-ccw",xj);const bj=[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]],at=F("save",bj);const jj=[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]],ba=F("search",jj);const yj=[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]],Mp=F("send",yj);const Nj=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",key:"1i5ecw"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],Mo=F("settings",Nj);const kj=[["path",{d:"M14 17H5",key:"gfn3mx"}],["path",{d:"M19 7h-9",key:"6i9tg"}],["circle",{cx:"17",cy:"17",r:"3",key:"18b49y"}],["circle",{cx:"7",cy:"7",r:"3",key:"dfmy0x"}]],Sj=F("settings-2",kj);const wj=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],Kf=F("shield",wj);const zj=[["path",{d:"M12 10.189V14",key:"1p8cqu"}],["path",{d:"M12 2v3",key:"qbqxhf"}],["path",{d:"M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6",key:"qpkstq"}],["path",{d:"M19.38 20A11.6 11.6 0 0 0 21 14l-8.188-3.639a2 2 0 0 0-1.624 0L3 14a11.6 11.6 0 0 0 2.81 7.76",key:"7tigtc"}],["path",{d:"M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1s1.2 1 2.5 1c2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"1924j5"}]],Ep=F("ship",zj);const Tj=[["path",{d:"m18 14 4 4-4 4",key:"10pe0f"}],["path",{d:"m18 2 4 4-4 4",key:"pucp1d"}],["path",{d:"M2 18h1.973a4 4 0 0 0 3.3-1.7l5.454-8.6a4 4 0 0 1 3.3-1.7H22",key:"1ailkh"}],["path",{d:"M2 6h1.972a4 4 0 0 1 3.6 2.2",key:"km57vx"}],["path",{d:"M22 18h-6.041a4 4 0 0 1-3.3-1.8l-.359-.45",key:"os18l9"}]],Aj=F("shuffle",Tj);const Cj=[["path",{d:"M21 10.656V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12.344",key:"2acyp4"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]],Zi=F("square-check-big",Cj);const Dj=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}]],Rp=F("square",Dj);const _j=[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]],Mj=F("sun",_j);const Ej=[["line",{x1:"10",x2:"14",y1:"2",y2:"2",key:"14vaq8"}],["line",{x1:"12",x2:"15",y1:"14",y2:"11",key:"17fdiu"}],["circle",{cx:"12",cy:"14",r:"8",key:"1e1u0o"}]],Up=F("timer",Ej);const Rj=[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]],dl=F("trash-2",Rj);const Uj=[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]],Bf=F("trending-up",Uj);const Lj=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],qa=F("triangle-alert",Lj);const Oj=[["path",{d:"M12 4v16",key:"1654pz"}],["path",{d:"M4 7V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2",key:"e0r10z"}],["path",{d:"M9 20h6",key:"s66wpe"}]],Hj=F("type",Oj);const Kj=[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]],Lp=F("upload",Kj);const Bj=[["path",{d:"m16 11 2 2 4-4",key:"9rsbq5"}],["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]],$j=F("user-check",Bj);const qj=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["line",{x1:"17",x2:"22",y1:"8",y2:"13",key:"3nzzx3"}],["line",{x1:"22",x2:"17",y1:"8",y2:"13",key:"1swrse"}]],Ij=F("user-x",qj);const Pj=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]],ps=F("user",Pj);const Gj=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]],ra=F("users",Gj);const Qj=[["path",{d:"M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"knzxuh"}],["path",{d:"M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"2jd2cc"}],["path",{d:"M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"rd2r6e"}]],Yj=F("waves",Qj);const Xj=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Je=F("x",Xj),Op={superadmin:{id:0,username:"superadmin",name:"Super Administrator",role:"superadmin",email:"superadmin@poltektrans.ac.id"},admin:{id:1,username:"admin",name:"Admin Prodi DPS",role:"admin_prodi",email:"admin.dps@poltektrans.ac.id",prodiId:1},dosen:{id:2,username:"dosen",name:"Dr. Ahmad Fauzi, M.T.",role:"dosen",email:"ahmad.fauzi@poltektrans.ac.id",nip:"197203151998031002"},mahasiswa:{id:3,username:"mahasiswa",name:"Budi Santoso",role:"mahasiswa",nim:"2024010001",email:"budi.santoso@student.poltektrans.ac.id"},pengawas:{id:4,username:"pengawas",name:"Ir. Siti Rahayu",role:"pengawas",email:"siti.rahayu@poltektrans.ac.id",nip:"198501012010011001"}};function Vj(){const{login:r}=Le(),{settings:c}=Wa(),[u,o]=y.useState({username:"",password:""}),[h,m]=y.useState(!1),[x,g]=y.useState(""),[b,p]=y.useState(!1),z=A=>{const{name:v,value:R}=A.target;o(j=>({...j,[v]:R})),g("")},N=async A=>{A.preventDefault(),g(""),p(!0),await new Promise(j=>setTimeout(j,800));const{username:v,password:R}=u;if(Op[v]&&R==="123456"){const j={...Op[v]};r(j)}else g("Username atau password salah. Gunakan: admin/dosen/mahasiswa/pengawas dengan password: 123456");p(!1)},S=A=>{o({username:A,password:"123456"})};return a.jsxs("div",{className:"login-page",children:[a.jsxs("div",{className:"login-bg",children:[a.jsx("div",{className:"wave wave-1"}),a.jsx("div",{className:"wave wave-2"}),a.jsx("div",{className:"wave wave-3"}),a.jsx(Ep,{className:"floating-icon ship-1",size:48}),a.jsx(Ep,{className:"floating-icon ship-2",size:32}),a.jsx(ib,{className:"floating-icon anchor-1",size:40}),a.jsx(Yj,{className:"floating-icon waves-1",size:36})]}),a.jsxs("div",{className:"login-container animate-scaleIn",children:[a.jsx("div",{className:"login-branding",children:a.jsxs("div",{className:"branding-content",children:[a.jsx("div",{className:"logo-container",children:c?.logoUrl?a.jsx("img",{src:c.logoUrl,alt:"Logo",className:"logo-image-lg"}):a.jsx("div",{className:"logo-icon",children:a.jsx(Lf,{size:48})})}),a.jsx("h1",{className:"branding-title",children:c?.appName||"CAT POLTEKTRANS"}),a.jsx("p",{className:"branding-subtitle",children:c?.institution||"Politeknik Transportasi Sungai Danau dan Penyeberangan Palembang"}),a.jsx("div",{className:"branding-divider"}),a.jsx("p",{className:"branding-tagline",children:c?.appSubtitle||"Sistem Ujian Online Berbasis Komputer"}),a.jsxs("div",{className:"branding-features",children:[a.jsxs("div",{className:"feature-item",children:[a.jsx("span",{className:"feature-icon",children:"🔒"}),a.jsx("span",{children:"Keamanan Terjamin"})]}),a.jsxs("div",{className:"feature-item",children:[a.jsx("span",{className:"feature-icon",children:"⚡"}),a.jsx("span",{children:"Cepat & Responsif"})]}),a.jsxs("div",{className:"feature-item",children:[a.jsx("span",{className:"feature-icon",children:"📊"}),a.jsx("span",{children:"Hasil Real-time"})]})]})]})}),a.jsx("div",{className:"login-form-panel",children:a.jsxs("div",{className:"login-form-content",children:[a.jsxs("div",{className:"form-header",children:[a.jsx("h2",{children:"Selamat Datang"}),a.jsx("p",{children:"Silakan masuk ke akun Anda"})]}),a.jsxs("form",{onSubmit:N,className:"login-form",children:[x&&a.jsx("div",{className:"alert alert-error animate-shake",children:a.jsx("span",{children:x})}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",htmlFor:"username",children:"Username / NIM"}),a.jsxs("div",{className:"form-input-icon",children:[a.jsx(ps,{className:"icon",size:20}),a.jsx("input",{type:"text",id:"username",name:"username",className:"form-input",placeholder:"Masukkan username atau NIM",value:u.username,onChange:z,required:!0,autoComplete:"username"})]})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",htmlFor:"password",children:"Password"}),a.jsxs("div",{className:"form-input-icon",children:[a.jsx(Hf,{className:"icon",size:20}),a.jsx("input",{type:h?"text":"password",id:"password",name:"password",className:"form-input",placeholder:"Masukkan password",value:u.password,onChange:z,required:!0,autoComplete:"current-password",style:{paddingRight:"48px"}}),a.jsx("button",{type:"button",className:"password-toggle",onClick:()=>m(!h),tabIndex:-1,children:h?a.jsx(Lb,{size:20}):a.jsx(Fa,{size:20})})]})]}),a.jsx("button",{type:"submit",className:"btn btn-primary btn-lg login-btn",disabled:b,children:b?a.jsxs(a.Fragment,{children:[a.jsx("span",{className:"spinner"}),a.jsx("span",{children:"Memproses..."})]}):"Masuk"})]}),a.jsxs("div",{className:"demo-section",children:[a.jsx("p",{className:"demo-label",children:"Login Demo:"}),a.jsxs("div",{className:"demo-buttons",children:[a.jsx("button",{type:"button",className:"btn btn-ghost btn-sm",onClick:()=>S("superadmin"),children:"Super Admin"}),a.jsx("button",{type:"button",className:"btn btn-ghost btn-sm",onClick:()=>S("admin"),children:"Admin Prodi"}),a.jsx("button",{type:"button",className:"btn btn-ghost btn-sm",onClick:()=>S("dosen"),children:"Dosen"}),a.jsx("button",{type:"button",className:"btn btn-ghost btn-sm",onClick:()=>S("mahasiswa"),children:"Mahasiswa"}),a.jsx("button",{type:"button",className:"btn btn-ghost btn-sm",onClick:()=>S("pengawas"),children:"Pengawas"})]}),a.jsx("p",{className:"demo-hint",children:"Password demo: 123456"})]}),a.jsx("div",{className:"login-footer",children:a.jsx("p",{children:"© 2026 Politeknik Transportasi SDP Palembang"})})]})})]})]})}const Jj={superadmin:[{path:"/superadmin",icon:sl,label:"Dashboard",end:!0},{path:"/superadmin/users",icon:ra,label:"Manajemen User"},{path:"/superadmin/prodi",icon:Yi,label:"Program Studi"},{path:"/superadmin/kelas",icon:_o,label:"Kelas"},{path:"/superadmin/matkul",icon:Co,label:"Mata Kuliah"},{path:"/superadmin/jadwal-ujian",icon:va,label:"Jadwal Ujian"},{path:"/superadmin/student-card",icon:Dp,label:"Cetak Kartu"},{path:"/superadmin/exam-room",icon:Vi,label:"Ruang Ujian"},{path:"/superadmin/rekap-nilai",icon:Vt,label:"Rekap Nilai"},{path:"/superadmin/rekap-kehadiran",icon:ms,label:"Rekap Kehadiran"},{path:"/superadmin/rekap-nilai-mahasiswa",icon:Do,label:"Rekap Nilai Mahasiswa"},{path:"/superadmin/settings",icon:Mo,label:"Pengaturan"}],admin_prodi:[{path:"/admin-prodi",icon:sl,label:"Dashboard",end:!0},{path:"/admin-prodi/users",icon:ra,label:"Manajemen User"},{path:"/admin-prodi/kelas",icon:_o,label:"Kelas"},{path:"/admin-prodi/matkul",icon:Co,label:"Mata Kuliah"},{path:"/admin-prodi/jadwal-ujian",icon:va,label:"Jadwal Ujian"},{path:"/admin-prodi/rekap-nilai",icon:Vt,label:"Rekap Nilai"},{path:"/admin-prodi/rekap-kehadiran",icon:ms,label:"Rekap Kehadiran"},{path:"/admin-prodi/rekap-berita-acara",icon:Ja,label:"Rekap Berita Acara"},{path:"/admin-prodi/rekap-nilai-mahasiswa",icon:Do,label:"Rekap Nilai Mahasiswa"},{path:"/admin-prodi/settings",icon:Mo,label:"Pengaturan"}],admin:[{path:"/admin",icon:sl,label:"Dashboard",end:!0},{path:"/admin/users",icon:ra,label:"Manajemen User"},{path:"/admin/prodi",icon:Yi,label:"Program Studi"},{path:"/admin/kelas",icon:_o,label:"Kelas"},{path:"/admin/matkul",icon:Co,label:"Mata Kuliah"},{path:"/admin/student-card",icon:Dp,label:"Cetak Kartu"},{path:"/admin/exam-room",icon:Vi,label:"Ruang Ujian"},{path:"/admin/reports",icon:Do,label:"Laporan"},{path:"/admin/settings",icon:Mo,label:"Pengaturan"}],dosen:[{path:"/dosen",icon:sl,label:"Dashboard",end:!0},{path:"/dosen/buat-soal",icon:xs,label:"Buat Soal"},{path:"/dosen/koreksi",icon:Zi,label:"Koreksi Ujian"},{path:"/dosen/nilai-ujian",icon:Ja,label:"Nilai Ujian"},{path:"/dosen/nilai-akhir",icon:Vt,label:"Nilai Akhir"}],mahasiswa:[{path:"/mahasiswa",icon:sl,label:"Dashboard",end:!0},{path:"/mahasiswa/ujian",icon:Xi,label:"Ujian"},{path:"/mahasiswa/hasil",icon:Vt,label:"Hasil Ujian"}],pengawas:[{path:"/pengawas",icon:sl,label:"Dashboard",end:!0},{path:"/pengawas/monitor",icon:Fa,label:"Monitor Ujian"},{path:"/pengawas/attendance",icon:ms,label:"Kehadiran"},{path:"/pengawas/berita-acara",icon:Ja,label:"Berita Acara"}]},Zj={superadmin:"Super Administrator",admin_prodi:"Admin Prodi",admin:"Administrator",dosen:"Dosen",mahasiswa:"Mahasiswa",pengawas:"Pengawas"};function Ee({children:r}){const{user:c,logout:u,theme:o,toggleTheme:h}=Le(),{settings:m}=Wa(),x=jn(),[g,b]=y.useState(!1),p=()=>{u(),x("/login")},z=Jj[c?.role]||[];return a.jsxs("div",{className:"dashboard-layout",children:[g&&a.jsx("div",{className:"sidebar-overlay",onClick:()=>b(!1)}),a.jsxs("aside",{className:`sidebar ${g?"open":""}`,children:[a.jsxs("div",{className:"sidebar-header",children:[a.jsxs("div",{className:"logo",children:[m?.logoUrl?a.jsx("img",{src:m.logoUrl,alt:"Logo",className:"logo-image"}):a.jsx("div",{className:"logo-icon",children:a.jsx(Lf,{size:24})}),a.jsxs("div",{className:"logo-text",children:[a.jsx("span",{className:"logo-title",children:m?.appName?.split(" ")[0]||"CAT"}),a.jsx("span",{className:"logo-subtitle",children:m?.appName?.split(" ").slice(1).join(" ")||"POLTEKTRANS"})]})]}),a.jsx("button",{className:"btn btn-icon btn-ghost sidebar-close",onClick:()=>b(!1),children:a.jsx(Je,{size:20})})]}),a.jsx("nav",{className:"sidebar-nav",children:a.jsxs("div",{className:"nav-section",children:[a.jsx("span",{className:"nav-section-title",children:"Menu Utama"}),z.map(N=>a.jsxs(Cf,{to:N.path,end:N.end,className:({isActive:S})=>`sidebar-nav-item ${S?"active":""}`,onClick:()=>b(!1),children:[a.jsx(N.icon,{size:20}),a.jsx("span",{children:N.label})]},N.path))]})}),a.jsxs("div",{className:"sidebar-footer",children:[a.jsxs("div",{className:"user-info",children:[a.jsx("div",{className:"avatar",children:c?.name?.charAt(0).toUpperCase()}),a.jsxs("div",{className:"user-details",children:[a.jsx("span",{className:"user-name",children:c?.name}),a.jsx("span",{className:"user-role",children:Zj[c?.role]})]})]}),a.jsxs("button",{className:"btn btn-ghost btn-sm logout-btn",onClick:p,children:[a.jsx(Zb,{size:18}),a.jsx("span",{children:"Keluar"})]})]})]}),a.jsxs("main",{className:"main-content",children:[a.jsxs("header",{className:"main-header",children:[a.jsx("div",{className:"header-left",children:a.jsx("button",{className:"btn btn-icon btn-ghost mobile-menu-btn",onClick:()=>b(!0),children:a.jsx(tj,{size:20})})}),a.jsx("div",{className:"header-right",children:a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:h,title:o==="light"?"Mode Gelap":"Mode Terang",children:o==="light"?a.jsx(rj,{size:20}):a.jsx(Mj,{size:20})})})]}),a.jsx("div",{className:"main-body",children:r})]})]})}const Wj=[{label:"Total User",value:"1,234",icon:ra,color:"primary",trend:"+12%"},{label:"Ujian Aktif",value:"8",icon:Ja,color:"accent",trend:"+3"},{label:"Selesai Hari Ini",value:"156",icon:We,color:"success",trend:"+24"},{label:"Perlu Perhatian",value:"3",icon:qa,color:"warning",trend:"-2"}],Fj=[{id:1,name:"UTS Navigasi Sungai",date:"2026-01-05",participants:45,status:"active"},{id:2,name:"UAS Teknik Perkapalan",date:"2026-01-04",participants:38,status:"completed"},{id:3,name:"Quiz Keselamatan Pelayaran",date:"2026-01-03",participants:52,status:"completed"}],e1=[{id:1,name:"Budi Santoso",role:"mahasiswa",nim:"2024010001",status:"active"},{id:2,name:"Ani Wijaya",role:"mahasiswa",nim:"2024010002",status:"active"},{id:3,name:"Dr. Rizal Hidayat",role:"dosen",nim:"-",status:"active"}],Eo=[{id:1,name:"UTS Navigasi Sungai",room:"Lab Komputer 1",startTime:"08:00",endTime:"10:00",participants:25,online:23,pengawas:"Ir. Siti Rahayu",prodi:"DPS",status:"active"},{id:2,name:"Quiz Keselamatan Pelayaran",room:"Ruang 2",startTime:"08:00",endTime:"09:00",participants:28,online:28,pengawas:"Drs. Bambang S.",prodi:"DTL",status:"active"},{id:3,name:"UAS Teknik Kapal",room:"Lab Komputer 2",startTime:"10:00",endTime:"12:00",participants:22,online:20,pengawas:"-",prodi:"DKP",status:"active"}];function Hp(){const r=jn();return a.jsx(Ee,{children:a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsx("h1",{className:"page-title",children:"Dashboard Admin"}),a.jsx("p",{className:"page-subtitle",children:"Selamat datang! Berikut ringkasan sistem hari ini."})]}),a.jsx("div",{className:"stats-grid",children:Wj.map((c,u)=>a.jsxs("div",{className:`stat-card stat-${c.color}`,children:[a.jsx("div",{className:"stat-icon",children:a.jsx(c.icon,{size:24})}),a.jsxs("div",{className:"stat-content",children:[a.jsx("span",{className:"stat-value",children:c.value}),a.jsx("span",{className:"stat-label",children:c.label})]}),a.jsxs("div",{className:"stat-trend",children:[a.jsx(Bf,{size:14}),a.jsx("span",{children:c.trend})]})]},u))}),a.jsxs("div",{className:"dashboard-grid",children:[a.jsxs("div",{className:"card",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(Ja,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Ujian Terbaru"})]}),a.jsx("button",{className:"btn btn-ghost btn-sm",children:"Lihat Semua"})]}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"Nama Ujian"}),a.jsx("th",{children:"Tanggal"}),a.jsx("th",{children:"Peserta"}),a.jsx("th",{children:"Status"})]})}),a.jsx("tbody",{children:Fj.map(c=>a.jsxs("tr",{children:[a.jsx("td",{className:"font-medium",children:c.name}),a.jsx("td",{className:"text-muted",children:c.date}),a.jsx("td",{children:c.participants}),a.jsx("td",{children:a.jsx("span",{className:`badge badge-${c.status==="active"?"success":"primary"}`,children:c.status==="active"?"Aktif":"Selesai"})})]},c.id))})]})})})]}),a.jsxs("div",{className:"card",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(ra,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"User Terbaru"})]}),a.jsx("button",{className:"btn btn-ghost btn-sm",children:"Lihat Semua"})]}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"user-list",children:e1.map(c=>a.jsxs("div",{className:"user-item",children:[a.jsx("div",{className:"avatar",children:c.name.charAt(0)}),a.jsxs("div",{className:"user-item-info",children:[a.jsx("span",{className:"user-item-name",children:c.name}),a.jsxs("span",{className:"user-item-role",children:[c.role," ",c.nim!=="-"&&`• ${c.nim}`]})]}),a.jsx("span",{className:"badge badge-success",children:"Aktif"})]},c.id))})})]}),a.jsxs("div",{className:"card card-wide",children:[a.jsx("div",{className:"card-header",children:a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(Ji,{size:20,className:"text-success"}),a.jsx("h3",{className:"font-semibold",children:"Ujian Sedang Berlangsung"}),a.jsxs("span",{className:"badge badge-success",children:[Eo.length," Aktif"]})]})}),a.jsx("div",{className:"card-body",children:Eo.length>0?a.jsx("div",{className:"exam-ongoing-list",children:Eo.map(c=>a.jsxs("div",{className:"exam-ongoing-item",children:[a.jsx("div",{className:"exam-ongoing-indicator"}),a.jsxs("div",{className:"exam-ongoing-info",children:[a.jsx("h4",{children:c.name}),a.jsxs("div",{className:"exam-ongoing-meta",children:[a.jsxs("span",{children:[a.jsx(Ve,{size:12})," ",c.startTime," - ",c.endTime]}),a.jsxs("span",{children:["• ",c.room]})]})]}),a.jsx("div",{className:"exam-ongoing-prodi",children:a.jsx("span",{className:"badge badge-primary",children:c.prodi})}),a.jsx("div",{className:"exam-ongoing-stats",children:a.jsxs("div",{className:"stat-item",children:[a.jsxs("span",{className:"stat-number",children:[c.online,"/",c.participants]}),a.jsx("span",{className:"stat-text",children:"Online"})]})}),a.jsxs("div",{className:"exam-ongoing-pengawas",children:[a.jsx(Fa,{size:14}),a.jsx("span",{className:c.pengawas!=="-"?"":"text-muted",children:c.pengawas!=="-"?c.pengawas:"Belum ada"})]}),a.jsx("button",{className:"btn btn-primary btn-sm",onClick:()=>r("/superadmin/monitor-ujian"),children:"Monitor"})]},c.id))}):a.jsxs("div",{className:"empty-state",children:[a.jsx(Ji,{size:32,className:"text-muted"}),a.jsx("p",{children:"Tidak ada ujian yang sedang berlangsung"})]})})]})]})]})})}const jt=[{id:1,kode:"DPS",nama:"D4 Pengelolaan Pelabuhan dan Pelayaran Sungai"},{id:2,kode:"DTL",nama:"D4 Transportasi Laut"},{id:3,kode:"LLASDP",nama:"D3 LLASDP"},{id:4,kode:"DKP",nama:"D4 Kepelautan"}],Gi=[{id:1,nama:"1A",prodiId:1,angkatan:2024},{id:2,nama:"1B",prodiId:1,angkatan:2024},{id:3,nama:"2A",prodiId:1,angkatan:2023},{id:4,nama:"1A",prodiId:2,angkatan:2024},{id:5,nama:"1A",prodiId:3,angkatan:2024},{id:6,nama:"1A",prodiId:4,angkatan:2024}],Kp=[{id:1,kode:"NAV101",nama:"Navigasi Sungai",prodiId:1},{id:2,kode:"KSL101",nama:"Keselamatan Pelayaran",prodiId:1},{id:3,kode:"PPL101",nama:"Pengelolaan Pelabuhan",prodiId:1},{id:4,kode:"NAL201",nama:"Navigasi Laut",prodiId:2},{id:5,kode:"TKL201",nama:"Teknik Kapal Laut",prodiId:2},{id:6,kode:"LLA301",nama:"Lalu Lintas Angkutan",prodiId:3},{id:7,kode:"KPL401",nama:"Kepelautan Dasar",prodiId:4}],a1=[{id:1,name:"Budi Santoso",username:"budi.santoso",email:"budi@student.poltektrans.ac.id",role:"mahasiswa",nim:"2024010001",status:"active",prodiId:1,kelasId:1,photo:null},{id:2,name:"Ani Wijaya",username:"ani.wijaya",email:"ani@student.poltektrans.ac.id",role:"mahasiswa",nim:"2024010002",status:"active",prodiId:1,kelasId:2,photo:null},{id:3,name:"Rizky Pratama",username:"rizky.pratama",email:"rizky@student.poltektrans.ac.id",role:"mahasiswa",nim:"2024010003",status:"inactive",prodiId:2,kelasId:4,photo:null},{id:4,name:"Dr. Ahmad Fauzi, M.T.",username:"ahmad.fauzi",email:"ahmad.fauzi@poltektrans.ac.id",role:"dosen",nim:"-",status:"active",prodiIds:[1,2],kelasIds:[1,2,4],matkulIds:[1,2,4]},{id:5,name:"Ir. Siti Rahayu",username:"siti.rahayu",email:"siti.rahayu@poltektrans.ac.id",role:"pengawas",nim:"-",status:"active"},{id:6,name:"Dewi Sartika",username:"dewi.sartika",email:"dewi@student.poltektrans.ac.id",role:"mahasiswa",nim:"2024010004",status:"active",prodiId:1,kelasId:1,photo:null},{id:7,name:"Prof. Dr. Hendra Wijaya",username:"hendra.wijaya",email:"hendra@poltektrans.ac.id",role:"dosen",nim:"-",status:"active",prodiIds:[1,3],kelasIds:[1,3,5],matkulIds:[1,3,6]},{id:8,name:"Eko Prasetyo",username:"eko.prasetyo",email:"eko@student.poltektrans.ac.id",role:"mahasiswa",nim:"2024010005",status:"active",prodiId:3,kelasId:5,photo:null}];function Ro({options:r,selected:c,onChange:u,placeholder:o,getLabel:h}){const[m,x]=y.useState(!1),g=b=>{c.includes(b)?u(c.filter(p=>p!==b)):u([...c,b])};return a.jsxs("div",{className:"multi-select",children:[a.jsx("div",{className:"multi-select-trigger",onClick:()=>x(!m),children:c.length===0?a.jsx("span",{className:"placeholder",children:o}):a.jsxs("div",{className:"selected-tags",children:[c.slice(0,2).map(b=>{const p=r.find(z=>z.id===b);return p?a.jsx("span",{className:"selected-tag",children:h(p)},b):null}),c.length>2&&a.jsxs("span",{className:"selected-tag more",children:["+",c.length-2]})]})}),m&&a.jsx("div",{className:"multi-select-dropdown",children:r.map(b=>a.jsxs("label",{className:"multi-select-option",children:[a.jsx("input",{type:"checkbox",checked:c.includes(b.id),onChange:()=>g(b.id)}),a.jsx("span",{className:"checkmark",children:a.jsx(il,{size:12})}),h(b)]},b.id))}),m&&a.jsx("div",{className:"multi-select-backdrop",onClick:()=>x(!1)})]})}function t1({isOpen:r,onClose:c,user:u,onSave:o,currentUser:h}){const[m,x]=y.useState(u||{name:"",username:"",email:"",role:"mahasiswa",nim:"",status:"active",prodiId:jt[0]?.id||"",kelasId:"",photo:null,prodiIds:[],kelasIds:[],matkulIds:[]}),[g,b]=y.useState(null);y.useEffect(()=>{if(u)x(u),b(u.photo);else{const v=h?.role==="admin_prodi"?h.prodiId:jt[0]?.id||"";x({name:"",username:"",email:"",role:"mahasiswa",nim:"",status:"active",prodiId:v,kelasId:"",photo:null,prodiIds:[],kelasIds:[],matkulIds:[]}),b(null)}},[u,r,h]);const p=Gi.filter(v=>v.prodiId===Number(m.prodiId)),z=Gi.filter(v=>m.prodiIds?.includes(v.prodiId)),N=Kp.filter(v=>m.prodiIds?.includes(v.prodiId)),S=v=>{const R=v.target.files[0];if(R){const j=new FileReader;j.onloadend=()=>{b(j.result),x({...m,photo:j.result})},j.readAsDataURL(R)}},A=v=>{v.preventDefault(),o(m),c()};return r?a.jsx("div",{className:"modal-overlay",onClick:c,children:a.jsxs("div",{className:"modal modal-lg",onClick:v=>v.stopPropagation(),children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("h3",{children:u?"Edit User":"Tambah User Baru"}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:c,children:a.jsx(Je,{size:20})})]}),a.jsxs("form",{onSubmit:A,children:[a.jsxs("div",{className:"modal-body",children:[m.role==="mahasiswa"&&a.jsxs("div",{className:"photo-upload-section",children:[a.jsx("div",{className:"photo-preview",children:g?a.jsx("img",{src:g,alt:"Preview"}):a.jsx("div",{className:"photo-placeholder",children:a.jsx(Ap,{size:32})})}),a.jsxs("label",{className:"photo-upload-btn",children:[a.jsx("input",{type:"file",accept:"image/*",onChange:S,hidden:!0}),a.jsx(Ap,{size:16}),"Upload Foto"]})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Nama Lengkap"}),a.jsx("input",{type:"text",className:"form-input",value:m.name,onChange:v=>x({...m,name:v.target.value}),required:!0})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Username"}),a.jsx("input",{type:"text",className:"form-input",value:m.username,onChange:v=>x({...m,username:v.target.value}),required:!0})]}),a.jsxs("div",{className:"form-group",children:[a.jsxs("label",{className:"form-label",children:["NIM/NIP",m.role==="mahasiswa"&&a.jsx("span",{className:"required-label",children:" *"})]}),a.jsx("input",{type:"text",className:"form-input",value:m.nim,onChange:v=>x({...m,nim:v.target.value}),placeholder:m.role==="mahasiswa"?"Wajib diisi":"Kosongkan jika tidak ada",required:m.role==="mahasiswa"})]})]}),a.jsxs("div",{className:"form-group",children:[a.jsxs("label",{className:"form-label",children:["Email",a.jsx("span",{className:"optional-label",children:" (Opsional)"})]}),a.jsx("input",{type:"email",className:"form-input",value:m.email,onChange:v=>x({...m,email:v.target.value}),placeholder:"Kosongkan jika tidak ada"})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Role"}),a.jsxs("select",{className:"form-input",value:m.role,onChange:v=>x({...m,role:v.target.value}),children:[a.jsx("option",{value:"mahasiswa",children:"Mahasiswa"}),a.jsx("option",{value:"dosen",children:"Dosen"}),a.jsx("option",{value:"pengawas",children:"Pengawas"}),h?.role!=="admin_prodi"&&a.jsxs(a.Fragment,{children:[a.jsx("option",{value:"admin_prodi",children:"Admin Prodi"}),a.jsx("option",{value:"superadmin",children:"Super Admin"})]})]})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Status"}),a.jsxs("select",{className:"form-input",value:m.status,onChange:v=>x({...m,status:v.target.value}),children:[a.jsx("option",{value:"active",children:"Aktif"}),a.jsx("option",{value:"inactive",children:"Nonaktif"})]})]})]}),m.role==="mahasiswa"&&a.jsxs("div",{className:"role-specific-section",children:[a.jsx("h4",{className:"section-title",children:"Data Akademik Mahasiswa"}),a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsxs("label",{className:"form-label",children:["Program Studi",h?.role==="admin_prodi"&&a.jsx("span",{className:"auto-assigned-badge",children:" (Otomatis)"})]}),h?.role==="admin_prodi"?a.jsxs(a.Fragment,{children:[a.jsx("input",{type:"text",className:"form-input",value:jt.find(v=>v.id===h?.prodiId)?.nama||"Prodi Anda",disabled:!0}),a.jsx("input",{type:"hidden",value:h?.prodiId||m.prodiId})]}):a.jsx("select",{className:"form-input",value:m.prodiId,onChange:v=>x({...m,prodiId:Number(v.target.value),kelasId:""}),required:!0,children:jt.map(v=>a.jsxs("option",{value:v.id,children:[v.kode," - ",v.nama]},v.id))})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Kelas"}),a.jsxs("select",{className:"form-input",value:m.kelasId,onChange:v=>x({...m,kelasId:Number(v.target.value)}),required:!0,children:[a.jsx("option",{value:"",children:"Pilih Kelas"}),p.map(v=>a.jsxs("option",{value:v.id,children:[v.nama," (",v.angkatan,")"]},v.id))]})]})]})]}),m.role==="dosen"&&a.jsxs("div",{className:"role-specific-section",children:[a.jsx("h4",{className:"section-title",children:"Data Pengampu Dosen"}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Program Studi yang Diampu"}),a.jsx(Ro,{options:jt,selected:m.prodiIds||[],onChange:v=>x({...m,prodiIds:v,kelasIds:m.kelasIds?.filter(R=>{const j=Gi.find(w=>w.id===R);return j&&v.includes(j.prodiId)})||[],matkulIds:m.matkulIds?.filter(R=>{const j=Kp.find(w=>w.id===R);return j&&v.includes(j.prodiId)})||[]}),placeholder:"Pilih Prodi...",getLabel:v=>`${v.kode} - ${v.nama}`})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Kelas yang Diampu"}),a.jsx(Ro,{options:z,selected:m.kelasIds||[],onChange:v=>x({...m,kelasIds:v}),placeholder:"Pilih Kelas...",getLabel:v=>`${jt.find(j=>j.id===v.prodiId)?.kode||""} - ${v.nama} (${v.angkatan})`})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Mata Kuliah yang Diampu"}),a.jsx(Ro,{options:N,selected:m.matkulIds||[],onChange:v=>x({...m,matkulIds:v}),placeholder:"Pilih Mata Kuliah...",getLabel:v=>`${v.kode} - ${v.nama}`})]})]}),m.role==="admin_prodi"&&a.jsxs("div",{className:"role-specific-section",children:[a.jsx("h4",{className:"section-title",children:"Program Studi yang Dikelola"}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Pilih Program Studi"}),a.jsxs("select",{className:"form-input",value:m.prodiId||"",onChange:v=>x({...m,prodiId:Number(v.target.value)}),required:!0,children:[a.jsx("option",{value:"",children:"Pilih Prodi"}),jt.map(v=>a.jsxs("option",{value:v.id,children:[v.kode," - ",v.nama]},v.id))]})]})]})]}),a.jsxs("div",{className:"modal-footer",children:[a.jsx("button",{type:"button",className:"btn btn-ghost",onClick:c,children:"Batal"}),a.jsxs("button",{type:"submit",className:"btn btn-primary",children:[a.jsx(at,{size:16}),"Simpan"]})]})]})]})}):null}function Uo(){const{user:r}=Le(),[c,u]=y.useState(a1),[o,h]=y.useState(""),[m,x]=y.useState("all"),[g,b]=y.useState(1),[p,z]=y.useState(!1),[N,S]=y.useState(null),A=5,v=c.filter(L=>{const K=L.name.toLowerCase().includes(o.toLowerCase())||L.email.toLowerCase().includes(o.toLowerCase())||L.nim.includes(o),V=m==="all"||L.role===m;return K&&V}),R=Math.ceil(v.length/A),j=v.slice((g-1)*A,g*A),w=()=>{S(null),z(!0)},C=L=>{S(L),z(!0)},k=L=>{u(N?c.map(K=>K.id===N.id?{...L,id:N.id}:K):[...c,{...L,id:Date.now()}])},Q=L=>{confirm("Apakah Anda yakin ingin menghapus user ini?")&&u(c.filter(K=>K.id!==L))},$=L=>{u(c.map(K=>K.id===L?{...K,status:K.status==="active"?"inactive":"active"}:K))},_=L=>{if(L.role==="mahasiswa"){const K=jt.find(X=>X.id===L.prodiId),V=Gi.find(X=>X.id===L.kelasId);if(K&&V)return`${K.kode} - ${V.nama}`}else if(L.role==="dosen"&&L.prodiIds?.length>0)return L.prodiIds.map(K=>jt.find(V=>V.id===K)?.kode).filter(Boolean).join(", ");return"-"},U={total:c.length,mahasiswa:c.filter(L=>L.role==="mahasiswa").length,dosen:c.filter(L=>L.role==="dosen").length,active:c.filter(L=>L.status==="active").length};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Manajemen User"}),a.jsx("p",{className:"page-subtitle",children:"Kelola data pengguna sistem CAT"})]}),a.jsx("div",{className:"flex gap-3",children:a.jsxs("button",{className:"btn btn-primary",onClick:w,children:[a.jsx(Jt,{size:18}),"Tambah User"]})})]}),a.jsxs("div",{className:"mini-stats",children:[a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:U.total}),a.jsx("span",{className:"mini-stat-label",children:"Total User"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:U.mahasiswa}),a.jsx("span",{className:"mini-stat-label",children:"Mahasiswa"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:U.dosen}),a.jsx("span",{className:"mini-stat-label",children:"Dosen"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:U.active}),a.jsx("span",{className:"mini-stat-label",children:"Aktif"})]})]}),a.jsx("div",{className:"card",children:a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"filters-row",children:[a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:18,className:"search-icon"}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Cari nama, email, atau NIM...",value:o,onChange:L=>h(L.target.value)})]}),a.jsxs("div",{className:"filter-group",children:[a.jsx(et,{size:16}),a.jsxs("select",{className:"form-input",value:m,onChange:L=>x(L.target.value),children:[a.jsx("option",{value:"all",children:"Semua Role"}),a.jsx("option",{value:"mahasiswa",children:"Mahasiswa"}),a.jsx("option",{value:"dosen",children:"Dosen"}),a.jsx("option",{value:"pengawas",children:"Pengawas"}),a.jsx("option",{value:"admin",children:"Admin"})]})]})]}),a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"Nama"}),a.jsx("th",{children:"Email"}),a.jsx("th",{children:"NIM/NIP"}),a.jsx("th",{children:"Prodi/Kelas"}),a.jsx("th",{children:"Role"}),a.jsx("th",{children:"Status"}),a.jsx("th",{children:"Aksi"})]})}),a.jsx("tbody",{children:j.map(L=>a.jsxs("tr",{children:[a.jsx("td",{children:a.jsxs("div",{className:"user-cell",children:[L.photo?a.jsx("img",{src:L.photo,alt:"",className:"avatar avatar-sm avatar-img"}):a.jsx("div",{className:"avatar avatar-sm",children:L.name.charAt(0)}),a.jsx("span",{className:"font-medium",children:L.name})]})}),a.jsx("td",{className:"text-muted",children:L.email}),a.jsx("td",{children:L.nim||"-"}),a.jsx("td",{children:a.jsx("span",{className:"prodi-kelas-info",children:_(L)})}),a.jsx("td",{children:a.jsx("span",{className:`badge badge-${L.role==="admin"?"error":L.role==="dosen"?"primary":L.role==="pengawas"?"warning":"info"}`,children:L.role})}),a.jsx("td",{children:a.jsxs("button",{className:`status-toggle ${L.status}`,onClick:()=>$(L.id),children:[L.status==="active"?a.jsx($j,{size:14}):a.jsx(Ij,{size:14}),L.status==="active"?"Aktif":"Nonaktif"]})}),a.jsx("td",{children:a.jsxs("div",{className:"flex gap-2",children:[a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm",onClick:()=>C(L),children:a.jsx(kt,{size:16})}),a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm text-error",onClick:()=>Q(L.id),children:a.jsx(dl,{size:16})})]})})]},L.id))})]})}),a.jsxs("div",{className:"pagination",children:[a.jsxs("span",{className:"pagination-info",children:["Menampilkan ",(g-1)*A+1,"-",Math.min(g*A,v.length)," dari ",v.length]}),a.jsxs("div",{className:"pagination-buttons",children:[a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm",disabled:g===1,onClick:()=>b(L=>L-1),children:a.jsx(Ef,{size:18})}),Array.from({length:R},(L,K)=>K+1).map(L=>a.jsx("button",{className:`btn btn-sm ${g===L?"btn-primary":"btn-ghost"}`,onClick:()=>b(L),children:L},L)),a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm",disabled:g===R,onClick:()=>b(L=>L+1),children:a.jsx(vs,{size:18})})]})]})]})}),a.jsx(t1,{isOpen:p,onClose:()=>z(!1),user:N,onSave:k,currentUser:r})]}),a.jsx("style",{children:`
        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          flex-wrap: wrap;
          gap: var(--space-4);
        }
        
        .mini-stats {
          display: flex;
          gap: var(--space-4);
          margin-bottom: var(--space-6);
          flex-wrap: wrap;
        }
        
        .mini-stat {
          background: var(--bg-secondary);
          padding: var(--space-4) var(--space-6);
          border-radius: var(--radius-lg);
          border: 1px solid var(--border-color);
          text-align: center;
          min-width: 120px;
        }
        
        .mini-stat-value {
          display: block;
          font-size: var(--font-size-2xl);
          font-weight: var(--font-bold);
          color: var(--primary-600);
        }
        
        .mini-stat-label {
          font-size: var(--font-size-xs);
          color: var(--text-muted);
        }
        
        .filters-row {
          display: flex;
          gap: var(--space-4);
          margin-bottom: var(--space-5);
          flex-wrap: wrap;
        }
        
        .search-box {
          position: relative;
          flex: 1;
          min-width: 250px;
        }
        
        .search-icon {
          position: absolute;
          left: var(--space-4);
          top: 50%;
          transform: translateY(-50%);
          color: var(--text-muted);
        }
        
        .search-box .form-input {
          padding-left: calc(var(--space-4) + 24px);
        }
        
        .filter-group {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          color: var(--text-muted);
        }
        
        .filter-group .form-input {
          width: auto;
          min-width: 150px;
        }
        
        .user-cell {
          display: flex;
          align-items: center;
          gap: var(--space-3);
        }
        
        .avatar-img {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          object-fit: cover;
        }
        
        .prodi-kelas-info {
          font-size: var(--font-size-xs);
          color: var(--text-secondary);
          background: var(--bg-tertiary);
          padding: var(--space-1) var(--space-2);
          border-radius: var(--radius-md);
        }
        
        .status-toggle {
          display: inline-flex;
          align-items: center;
          gap: var(--space-1);
          padding: var(--space-1) var(--space-3);
          border-radius: var(--radius-full);
          font-size: var(--font-size-xs);
          font-weight: var(--font-medium);
          border: none;
          cursor: pointer;
          transition: all var(--transition-fast);
        }
        
        .status-toggle.active {
          background: var(--success-50);
          color: var(--success-600);
        }
        
        .status-toggle.inactive {
          background: var(--gray-100);
          color: var(--gray-500);
        }
        
        .status-toggle:hover {
          transform: scale(1.05);
        }
        
        .text-error {
          color: var(--error-500);
        }
        
        .pagination {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: var(--space-4);
          padding-top: var(--space-4);
          border-top: 1px solid var(--border-color);
          flex-wrap: wrap;
          gap: var(--space-3);
        }
        
        .pagination-info {
          font-size: var(--font-size-sm);
          color: var(--text-muted);
        }
        
        .pagination-buttons {
          display: flex;
          gap: var(--space-1);
        }
        
        /* Modal */
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(4px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: var(--z-modal);
          padding: var(--space-4);
        }
        
        .modal {
          background: var(--bg-secondary);
          border-radius: var(--radius-xl);
          width: 100%;
          max-width: 500px;
          max-height: 90vh;
          overflow-y: auto;
          animation: scaleIn var(--transition-normal) ease-out;
        }
        
        .modal-lg {
          max-width: 600px;
        }
        
        .modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: var(--space-5);
          border-bottom: 1px solid var(--border-color);
        }
        
        .modal-header h3 {
          font-size: var(--font-size-lg);
          font-weight: var(--font-semibold);
        }
        
        .modal-body {
          padding: var(--space-5);
        }
        
        .modal-footer {
          display: flex;
          justify-content: flex-end;
          gap: var(--space-3);
          padding: var(--space-4) var(--space-5);
          border-top: 1px solid var(--border-color);
          background: var(--bg-tertiary);
        }
        
        .form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: var(--space-4);
        }
        
        /* Photo Upload */
        .photo-upload-section {
          display: flex;
          align-items: center;
          gap: var(--space-4);
          margin-bottom: var(--space-5);
          padding-bottom: var(--space-5);
          border-bottom: 1px solid var(--border-color);
        }
        
        .photo-preview {
          width: 80px;
          height: 80px;
          border-radius: 50%;
          overflow: hidden;
          background: var(--bg-tertiary);
          border: 3px solid var(--border-color);
        }
        
        .photo-preview img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        
        .photo-placeholder {
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--text-muted);
        }
        
        .photo-upload-btn {
          display: inline-flex;
          align-items: center;
          gap: var(--space-2);
          padding: var(--space-2) var(--space-4);
          background: var(--primary-50);
          color: var(--primary-600);
          border-radius: var(--radius-lg);
          font-size: var(--font-size-sm);
          font-weight: var(--font-medium);
          cursor: pointer;
          transition: all var(--transition-fast);
        }
        
        .photo-upload-btn:hover {
          background: var(--primary-100);
        }
        
        /* Role Specific Section */
        .role-specific-section {
          margin-top: var(--space-5);
          padding-top: var(--space-5);
          border-top: 1px solid var(--border-color);
        }
        
        .section-title {
          font-size: var(--font-size-sm);
          font-weight: var(--font-semibold);
          color: var(--primary-600);
          margin-bottom: var(--space-4);
        }
        
        /* Multi-Select */
        .multi-select {
          position: relative;
        }
        
        .multi-select-trigger {
          padding: var(--space-3);
          background: var(--bg-primary);
          border: 1px solid var(--border-color);
          border-radius: var(--radius-lg);
          cursor: pointer;
          min-height: 44px;
          display: flex;
          align-items: center;
        }
        
        .multi-select-trigger .placeholder {
          color: var(--text-muted);
        }
        
        .selected-tags {
          display: flex;
          flex-wrap: wrap;
          gap: var(--space-1);
        }
        
        .selected-tag {
          display: inline-block;
          padding: var(--space-1) var(--space-2);
          background: var(--primary-50);
          color: var(--primary-700);
          border-radius: var(--radius-md);
          font-size: var(--font-size-xs);
        }
        
        .selected-tag.more {
          background: var(--gray-100);
          color: var(--gray-600);
        }
        
        .multi-select-dropdown {
          position: absolute;
          top: 100%;
          left: 0;
          right: 0;
          max-height: 200px;
          overflow-y: auto;
          background: var(--bg-secondary);
          border: 1px solid var(--border-color);
          border-radius: var(--radius-lg);
          box-shadow: var(--shadow-lg);
          z-index: 100;
          margin-top: var(--space-1);
        }
        
        .multi-select-option {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          padding: var(--space-3);
          cursor: pointer;
          font-size: var(--font-size-sm);
          transition: background var(--transition-fast);
        }
        
        .multi-select-option:hover {
          background: var(--bg-tertiary);
        }
        
        .multi-select-option input {
          display: none;
        }
        
        .multi-select-option .checkmark {
          width: 18px;
          height: 18px;
          border: 2px solid var(--border-color);
          border-radius: var(--radius-sm);
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          flex-shrink: 0;
        }
        
        .multi-select-option input:checked + .checkmark {
          background: var(--primary-500);
          border-color: var(--primary-500);
        }
        
        .multi-select-backdrop {
          position: fixed;
          inset: 0;
          z-index: 99;
        }
        
        @media (max-width: 640px) {
          .form-row {
            grid-template-columns: 1fr;
          }
        }
        
        [data-theme="dark"] .status-toggle.active {
          background: rgba(16, 185, 129, 0.15);
        }
        
        [data-theme="dark"] .status-toggle.inactive {
          background: rgba(148, 163, 184, 0.15);
        }
        
        [data-theme="dark"] .photo-upload-btn {
          background: rgba(59, 103, 159, 0.15);
        }
        
        [data-theme="dark"] .selected-tag {
          background: rgba(59, 103, 159, 0.2);
        }
        
        [data-theme="dark"] .selected-tag.more {
          background: rgba(148, 163, 184, 0.15);
        }
        
        .auto-assigned-badge {
          font-size: var(--font-size-xs);
          color: var(--success-600);
          font-weight: var(--font-normal);
        }
        
        .optional-label {
          font-size: var(--font-size-xs);
          color: var(--text-muted);
          font-weight: var(--font-normal);
        }
        
        .required-label {
          color: var(--error-500);
        }
      `})]})}const n1=[{id:1,kode:"DPS",nama:"D4 Pengelolaan Pelabuhan dan Pelayaran Sungai"},{id:2,kode:"DTL",nama:"D4 Transportasi Laut"},{id:3,kode:"LLASDP",nama:"D3 LLASDP"},{id:4,kode:"DKP",nama:"D4 Kepelautan"}];function l1({isOpen:r,onClose:c,prodi:u,onSave:o}){const[h,m]=y.useState(u||{kode:"",nama:""}),x=g=>{g.preventDefault(),o(h),c()};return r?a.jsx("div",{className:"modal-overlay",onClick:c,children:a.jsxs("div",{className:"modal",onClick:g=>g.stopPropagation(),children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("h3",{children:u?"Edit Program Studi":"Tambah Program Studi"}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:c,children:a.jsx(Je,{size:20})})]}),a.jsxs("form",{onSubmit:x,children:[a.jsxs("div",{className:"modal-body",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Kode Prodi"}),a.jsx("input",{type:"text",className:"form-input",value:h.kode,onChange:g=>m({...h,kode:g.target.value.toUpperCase()}),placeholder:"Contoh: DPS",maxLength:10,required:!0})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Nama Program Studi"}),a.jsx("input",{type:"text",className:"form-input",value:h.nama,onChange:g=>m({...h,nama:g.target.value}),placeholder:"Contoh: D4 Pengelolaan Pelabuhan dan Pelayaran Sungai",required:!0})]})]}),a.jsxs("div",{className:"modal-footer",children:[a.jsx("button",{type:"button",className:"btn btn-ghost",onClick:c,children:"Batal"}),a.jsxs("button",{type:"submit",className:"btn btn-primary",children:[a.jsx(at,{size:16}),"Simpan"]})]})]})]})}):null}function Bp(){const[r,c]=y.useState(n1),[u,o]=y.useState(""),[h,m]=y.useState(!1),[x,g]=y.useState(null),b=r.filter(A=>A.nama.toLowerCase().includes(u.toLowerCase())||A.kode.toLowerCase().includes(u.toLowerCase())),p=()=>{g(null),m(!0)},z=A=>{g(A),m(!0)},N=A=>{c(x?r.map(v=>v.id===x.id?{...A,id:x.id}:v):[...r,{...A,id:Date.now()}])},S=A=>{confirm("Apakah Anda yakin ingin menghapus program studi ini?")&&c(r.filter(v=>v.id!==A))};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Manajemen Program Studi"}),a.jsx("p",{className:"page-subtitle",children:"Kelola data program studi"})]}),a.jsxs("button",{className:"btn btn-primary",onClick:p,children:[a.jsx(Jt,{size:18}),"Tambah Prodi"]})]}),a.jsx("div",{className:"mini-stats",children:a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:r.length}),a.jsx("span",{className:"mini-stat-label",children:"Total Prodi"})]})}),a.jsx("div",{className:"card",children:a.jsxs("div",{className:"card-body",children:[a.jsx("div",{className:"filters-row",children:a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:18,className:"search-icon"}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Cari kode atau nama prodi...",value:u,onChange:A=>o(A.target.value)})]})}),a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{style:{width:"80px"},children:"Kode"}),a.jsx("th",{children:"Nama Program Studi"}),a.jsx("th",{style:{width:"120px"},children:"Aksi"})]})}),a.jsxs("tbody",{children:[b.map(A=>a.jsxs("tr",{children:[a.jsx("td",{children:a.jsx("span",{className:"badge badge-primary",children:A.kode})}),a.jsx("td",{children:a.jsxs("div",{className:"prodi-cell",children:[a.jsx(Yi,{size:18,className:"prodi-icon"}),a.jsx("span",{className:"font-medium",children:A.nama})]})}),a.jsx("td",{children:a.jsxs("div",{className:"flex gap-2",children:[a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm",onClick:()=>z(A),children:a.jsx(kt,{size:16})}),a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm text-error",onClick:()=>S(A.id),children:a.jsx(dl,{size:16})})]})})]},A.id)),b.length===0&&a.jsx("tr",{children:a.jsx("td",{colSpan:3,className:"text-center text-muted",style:{padding:"var(--space-8)"},children:"Tidak ada data program studi"})})]})]})})]})}),a.jsx(l1,{isOpen:h,onClose:()=>m(!1),prodi:x,onSave:N})]}),a.jsx("style",{children:`
        .prodi-cell {
          display: flex;
          align-items: center;
          gap: var(--space-3);
        }
        
        .prodi-icon {
          color: var(--primary-500);
        }
        
        .text-error {
          color: var(--error-500);
        }
      `})]})}const vn=[{id:1,kode:"DPS",nama:"D4 Pengelolaan Pelabuhan dan Pelayaran Sungai"},{id:2,kode:"DTL",nama:"D4 Transportasi Laut"},{id:3,kode:"LLASDP",nama:"D3 LLASDP"},{id:4,kode:"DKP",nama:"D4 Kepelautan"}],s1=[{id:1,nama:"1A",prodiId:1,angkatan:35},{id:2,nama:"1B",prodiId:1,angkatan:35},{id:3,nama:"2A",prodiId:1,angkatan:34},{id:4,nama:"2B",prodiId:1,angkatan:34},{id:5,nama:"1A",prodiId:2,angkatan:35},{id:6,nama:"1A",prodiId:3,angkatan:35},{id:7,nama:"2A",prodiId:3,angkatan:34},{id:8,nama:"1A",prodiId:4,angkatan:35}],i1=()=>{const r=[],o=new Date().getFullYear();for(let h=0;h<=o-2023+10;h++)r.push({value:34+h,label:`Angkatan ${34+h} (${2023+h})`});return r},r1=i1();function c1({isOpen:r,onClose:c,kelas:u,onSave:o,prodiList:h}){const[m,x]=y.useState(u||{nama:"",prodiId:h[0]?.id||"",angkatan:35}),g=b=>{b.preventDefault(),o({...m,prodiId:Number(m.prodiId),angkatan:Number(m.angkatan)}),c()};return r?a.jsx("div",{className:"modal-overlay",onClick:c,children:a.jsxs("div",{className:"modal",onClick:b=>b.stopPropagation(),children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("h3",{children:u?"Edit Kelas":"Tambah Kelas"}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:c,children:a.jsx(Je,{size:20})})]}),a.jsxs("form",{onSubmit:g,children:[a.jsxs("div",{className:"modal-body",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Program Studi"}),a.jsx("select",{className:"form-input",value:m.prodiId,onChange:b=>x({...m,prodiId:b.target.value}),required:!0,children:h.map(b=>a.jsxs("option",{value:b.id,children:[b.kode," - ",b.nama]},b.id))})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Nama Kelas"}),a.jsx("input",{type:"text",className:"form-input",value:m.nama,onChange:b=>x({...m,nama:b.target.value.toUpperCase()}),placeholder:"Contoh: 1A",maxLength:5,required:!0})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Angkatan"}),a.jsx("select",{className:"form-input",value:m.angkatan,onChange:b=>x({...m,angkatan:Number(b.target.value)}),required:!0,children:r1.map(b=>a.jsx("option",{value:b.value,children:b.label},b.value))})]})]})]}),a.jsxs("div",{className:"modal-footer",children:[a.jsx("button",{type:"button",className:"btn btn-ghost",onClick:c,children:"Batal"}),a.jsxs("button",{type:"submit",className:"btn btn-primary",children:[a.jsx(at,{size:16}),"Simpan"]})]})]})]})}):null}function Lo(){const{user:r}=Le(),[c,u]=y.useState(s1),[o,h]=y.useState(""),[m,x]=y.useState(r?.role==="admin_prodi"?r.prodiId:"all"),[g,b]=y.useState(!1),[p,z]=y.useState(null),N=r?.role==="admin_prodi"?r.prodiId:m,S=r?.role==="admin_prodi"?vn.filter(k=>k.id===r.prodiId):vn,A=c.filter(k=>{const Q=vn.find(U=>U.id===k.prodiId),$=k.nama.toLowerCase().includes(o.toLowerCase())||Q?.nama.toLowerCase().includes(o.toLowerCase()),_=N==="all"||k.prodiId===Number(N);return $&&_}),v=()=>{z(null),b(!0)},R=k=>{z(k),b(!0)},j=k=>{u(p?c.map(Q=>Q.id===p.id?{...k,id:p.id}:Q):[...c,{...k,id:Date.now()}])},w=k=>{confirm("Apakah Anda yakin ingin menghapus kelas ini?")&&u(c.filter(Q=>Q.id!==k))},C=k=>{const Q=vn.find($=>$.id===k);return Q?Q.kode:"-"};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Manajemen Kelas"}),a.jsx("p",{className:"page-subtitle",children:"Kelola data kelas per program studi"})]}),a.jsxs("button",{className:"btn btn-primary",onClick:v,children:[a.jsx(Jt,{size:18}),"Tambah Kelas"]})]}),a.jsxs("div",{className:"mini-stats",children:[a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:c.length}),a.jsx("span",{className:"mini-stat-label",children:"Total Kelas"})]}),vn.map(k=>a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:c.filter(Q=>Q.prodiId===k.id).length}),a.jsx("span",{className:"mini-stat-label",children:k.kode})]},k.id))]}),a.jsx("div",{className:"card",children:a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"filters-row",children:[a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:18,className:"search-icon"}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Cari kelas...",value:o,onChange:k=>h(k.target.value)})]}),r?.role!=="admin_prodi"&&a.jsxs("div",{className:"filter-group",children:[a.jsx(et,{size:16}),a.jsxs("select",{className:"form-input",value:m,onChange:k=>x(k.target.value),children:[a.jsx("option",{value:"all",children:"Semua Prodi"}),vn.map(k=>a.jsx("option",{value:k.id,children:k.kode},k.id))]})]})]}),a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{style:{width:"100px"},children:"Kelas"}),a.jsx("th",{children:"Program Studi"}),a.jsx("th",{style:{width:"100px"},children:"Angkatan"}),a.jsx("th",{style:{width:"100px"},children:"Aksi"})]})}),a.jsxs("tbody",{children:[A.map(k=>a.jsxs("tr",{children:[a.jsx("td",{children:a.jsxs("div",{className:"kelas-badge",children:[a.jsx(ra,{size:14}),k.nama]})}),a.jsxs("td",{children:[a.jsx("span",{className:"badge badge-primary",children:C(k.prodiId)}),a.jsx("span",{className:"prodi-full-name",children:vn.find(Q=>Q.id===k.prodiId)?.nama})]}),a.jsxs("td",{className:"font-medium",children:["Angkatan ",k.angkatan," (",1989+k.angkatan,")"]}),a.jsx("td",{children:a.jsxs("div",{className:"flex gap-2",children:[a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm",onClick:()=>R(k),children:a.jsx(kt,{size:16})}),a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm text-error",onClick:()=>w(k.id),children:a.jsx(dl,{size:16})})]})})]},k.id)),A.length===0&&a.jsx("tr",{children:a.jsx("td",{colSpan:4,className:"text-center text-muted",style:{padding:"var(--space-8)"},children:"Tidak ada data kelas"})})]})]})})]})}),a.jsx(c1,{isOpen:g,onClose:()=>b(!1),kelas:p,onSave:j,prodiList:S})]}),a.jsx("style",{children:`
        .kelas-badge {
          display: inline-flex;
          align-items: center;
          gap: var(--space-2);
          padding: var(--space-2) var(--space-3);
          background: var(--accent-50);
          color: var(--accent-700);
          border-radius: var(--radius-md);
          font-weight: var(--font-semibold);
        }
        
        .prodi-full-name {
          display: block;
          font-size: var(--font-size-xs);
          color: var(--text-muted);
          margin-top: var(--space-1);
        }
        
        .text-error {
          color: var(--error-500);
        }
        
        .form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: var(--space-4);
        }
        
        @media (max-width: 640px) {
          .form-row {
            grid-template-columns: 1fr;
          }
        }
        
        [data-theme="dark"] .kelas-badge {
          background: rgba(0, 168, 168, 0.15);
        }
      `})]})}const Ki=[{id:1,kode:"DPS",nama:"D4 Pengelolaan Pelabuhan dan Pelayaran Sungai"},{id:2,kode:"DTL",nama:"D4 Transportasi Laut"},{id:3,kode:"LLASDP",nama:"D3 LLASDP"},{id:4,kode:"DKP",nama:"D4 Kepelautan"}],o1=[{id:1,kode:"NAV101",nama:"Navigasi Sungai",sksTeori:2,sksPraktek:1,prodiId:1},{id:2,kode:"KSL101",nama:"Keselamatan Pelayaran",sksTeori:2,sksPraktek:0,prodiId:1},{id:3,kode:"PPL101",nama:"Pengelolaan Pelabuhan",sksTeori:2,sksPraktek:1,prodiId:1},{id:4,kode:"MAN101",nama:"Manajemen Transportasi",sksTeori:3,sksPraktek:0,prodiId:1},{id:5,kode:"NAL201",nama:"Navigasi Laut",sksTeori:2,sksPraktek:1,prodiId:2},{id:6,kode:"TKL201",nama:"Teknik Kapal Laut",sksTeori:2,sksPraktek:1,prodiId:2},{id:7,kode:"LLA301",nama:"Lalu Lintas Angkutan",sksTeori:3,sksPraktek:0,prodiId:3},{id:8,kode:"KPL401",nama:"Kepelautan Dasar",sksTeori:1,sksPraktek:1,prodiId:4}];function d1({isOpen:r,onClose:c,matkul:u,onSave:o,prodiList:h}){const[m,x]=y.useState(u||{kode:"",nama:"",sksTeori:2,sksPraktek:0,prodiId:h[0]?.id||""}),g=p=>{p.preventDefault(),o({...m,prodiId:Number(m.prodiId),sksTeori:Number(m.sksTeori),sksPraktek:Number(m.sksPraktek)}),c()},b=()=>m.sksPraktek>0?"NT (10%) + NUTS (20%) + NP (20%) + UAS (50%)":"NT (10%) + NUTS (30%) + UAS (60%)";return r?a.jsx("div",{className:"modal-overlay",onClick:c,children:a.jsxs("div",{className:"modal",onClick:p=>p.stopPropagation(),children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("h3",{children:u?"Edit Mata Kuliah":"Tambah Mata Kuliah"}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:c,children:a.jsx(Je,{size:20})})]}),a.jsxs("form",{onSubmit:g,children:[a.jsxs("div",{className:"modal-body",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Program Studi"}),a.jsx("select",{className:"form-input",value:m.prodiId,onChange:p=>x({...m,prodiId:p.target.value}),required:!0,children:h.map(p=>a.jsxs("option",{value:p.id,children:[p.kode," - ",p.nama]},p.id))})]}),a.jsx("div",{className:"form-row",children:a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Kode Mata Kuliah"}),a.jsx("input",{type:"text",className:"form-input",value:m.kode,onChange:p=>x({...m,kode:p.target.value.toUpperCase()}),placeholder:"Contoh: NAV101",maxLength:10,required:!0})]})}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Nama Mata Kuliah"}),a.jsx("input",{type:"text",className:"form-input",value:m.nama,onChange:p=>x({...m,nama:p.target.value}),placeholder:"Contoh: Navigasi Sungai",required:!0})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"SKS Teori"}),a.jsx("input",{type:"number",className:"form-input",value:m.sksTeori,onChange:p=>x({...m,sksTeori:p.target.value}),min:0,max:6,required:!0})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"SKS Praktek"}),a.jsx("input",{type:"number",className:"form-input",value:m.sksPraktek,onChange:p=>x({...m,sksPraktek:p.target.value}),min:0,max:6,required:!0})]})]}),a.jsxs("div",{className:"formula-info",children:[a.jsx(Of,{size:16}),a.jsxs("div",{children:[a.jsx("strong",{children:"Rumus Nilai:"}),a.jsx("span",{children:b()})]})]})]}),a.jsxs("div",{className:"modal-footer",children:[a.jsx("button",{type:"button",className:"btn btn-ghost",onClick:c,children:"Batal"}),a.jsxs("button",{type:"submit",className:"btn btn-primary",children:[a.jsx(at,{size:16}),"Simpan"]})]})]})]})}):null}function Oo(){const{user:r}=Le(),[c,u]=y.useState(o1),[o,h]=y.useState(""),[m,x]=y.useState(r?.role==="admin_prodi"?r.prodiId:"all"),[g,b]=y.useState(!1),[p,z]=y.useState(null),N=r?.role==="admin_prodi"?r.prodiId:m,S=r?.role==="admin_prodi"?Ki.filter($=>$.id===r.prodiId):Ki,A=c.filter($=>{const _=$.nama.toLowerCase().includes(o.toLowerCase())||$.kode.toLowerCase().includes(o.toLowerCase()),U=N==="all"||$.prodiId===Number(N);return _&&U}),v=()=>{z(null),b(!0)},R=$=>{z($),b(!0)},j=$=>{u(p?c.map(_=>_.id===p.id?{...$,id:p.id}:_):[...c,{...$,id:Date.now()}])},w=$=>{confirm("Apakah Anda yakin ingin menghapus mata kuliah ini?")&&u(c.filter(_=>_.id!==$))},C=$=>{const _=Ki.find(U=>U.id===$);return _?_.kode:"-"},k=c.reduce(($,_)=>$+_.sksTeori,0),Q=c.reduce(($,_)=>$+_.sksPraktek,0);return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Manajemen Mata Kuliah"}),a.jsx("p",{className:"page-subtitle",children:"Kelola data mata kuliah per program studi"})]}),a.jsxs("button",{className:"btn btn-primary",onClick:v,children:[a.jsx(Jt,{size:18}),"Tambah Mata Kuliah"]})]}),a.jsxs("div",{className:"mini-stats",children:[a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:c.length}),a.jsx("span",{className:"mini-stat-label",children:"Total Matkul"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:k}),a.jsx("span",{className:"mini-stat-label",children:"Total SKS Teori"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:Q}),a.jsx("span",{className:"mini-stat-label",children:"Total SKS Praktek"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:k+Q}),a.jsx("span",{className:"mini-stat-label",children:"Total SKS"})]})]}),a.jsx("div",{className:"card",children:a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"filters-row",children:[a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:18,className:"search-icon"}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Cari kode atau nama mata kuliah...",value:o,onChange:$=>h($.target.value)})]}),r?.role!=="admin_prodi"&&a.jsxs("div",{className:"filter-group",children:[a.jsx(et,{size:16}),a.jsxs("select",{className:"form-input",value:m,onChange:$=>x($.target.value),children:[a.jsx("option",{value:"all",children:"Semua Prodi"}),Ki.map($=>a.jsx("option",{value:$.id,children:$.kode},$.id))]})]})]}),a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{style:{width:"100px"},children:"Kode"}),a.jsx("th",{children:"Nama Mata Kuliah"}),a.jsx("th",{style:{width:"100px"},className:"text-center",children:"SKS Teori"}),a.jsx("th",{style:{width:"100px"},className:"text-center",children:"SKS Praktek"}),a.jsx("th",{style:{width:"80px"},className:"text-center",children:"Total"}),a.jsx("th",{style:{width:"100px"},children:"Prodi"}),a.jsx("th",{style:{width:"150px"},children:"Rumus Nilai"}),a.jsx("th",{style:{width:"100px"},children:"Aksi"})]})}),a.jsxs("tbody",{children:[A.map($=>a.jsxs("tr",{children:[a.jsx("td",{children:a.jsx("span",{className:"matkul-kode",children:$.kode})}),a.jsx("td",{children:a.jsxs("div",{className:"matkul-cell",children:[a.jsx(xs,{size:18,className:"matkul-icon"}),a.jsx("span",{className:"font-medium",children:$.nama})]})}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:"sks-badge teori",children:$.sksTeori})}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:`sks-badge ${$.sksPraktek>0?"praktek":"zero"}`,children:$.sksPraktek})}),a.jsx("td",{className:"text-center",children:a.jsx("strong",{children:$.sksTeori+$.sksPraktek})}),a.jsx("td",{children:a.jsx("span",{className:"badge badge-primary",children:C($.prodiId)})}),a.jsx("td",{children:a.jsx("span",{className:`formula-badge ${$.sksPraktek>0?"with-praktek":"no-praktek"}`,children:$.sksPraktek>0?"Dengan NP":"Tanpa NP"})}),a.jsx("td",{children:a.jsxs("div",{className:"flex gap-2",children:[a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm",onClick:()=>R($),children:a.jsx(kt,{size:16})}),a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm text-error",onClick:()=>w($.id),children:a.jsx(dl,{size:16})})]})})]},$.id)),A.length===0&&a.jsx("tr",{children:a.jsx("td",{colSpan:8,className:"text-center text-muted",style:{padding:"var(--space-8)"},children:"Tidak ada data mata kuliah"})})]})]})})]})}),a.jsx(d1,{isOpen:g,onClose:()=>b(!1),matkul:p,onSave:j,prodiList:S})]}),a.jsx("style",{children:`
        .matkul-cell {
          display: flex;
          align-items: center;
          gap: var(--space-3);
        }
        
        .matkul-icon {
          color: var(--accent-500);
        }
        
        .matkul-kode {
          font-family: monospace;
          font-size: var(--font-size-sm);
          font-weight: var(--font-medium);
          color: var(--text-secondary);
        }
        
        .text-center {
          text-align: center;
        }
        
        .sks-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-width: 28px;
          padding: var(--space-1) var(--space-2);
          border-radius: var(--radius-md);
          font-size: var(--font-size-sm);
          font-weight: var(--font-semibold);
        }
        
        .sks-badge.teori {
          background: var(--info-100);
          color: var(--info-700);
        }
        
        .sks-badge.praktek {
          background: var(--success-100);
          color: var(--success-700);
        }
        
        .sks-badge.zero {
          background: var(--gray-100);
          color: var(--gray-500);
        }
        
        .formula-badge {
          display: inline-block;
          padding: var(--space-1) var(--space-2);
          border-radius: var(--radius-md);
          font-size: var(--font-size-xs);
          font-weight: var(--font-medium);
        }
        
        .formula-badge.with-praktek {
          background: var(--success-100);
          color: var(--success-700);
        }
        
        .formula-badge.no-praktek {
          background: var(--warning-100);
          color: var(--warning-700);
        }
        
        .formula-info {
          display: flex;
          align-items: flex-start;
          gap: var(--space-3);
          padding: var(--space-3);
          background: var(--info-50);
          border: 1px solid var(--info-200);
          border-radius: var(--radius-lg);
          margin-top: var(--space-4);
          color: var(--info-700);
        }
        
        .formula-info > div {
          display: flex;
          flex-direction: column;
          gap: var(--space-1);
        }
        
        .formula-info strong {
          font-size: var(--font-size-sm);
        }
        
        .formula-info span {
          font-size: var(--font-size-sm);
        }
        
        .text-error {
          color: var(--error-500);
        }
        
        .form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: var(--space-4);
        }
        
        @media (max-width: 640px) {
          .form-row {
            grid-template-columns: 1fr;
          }
        }
        
        [data-theme="dark"] .sks-badge.teori {
          background: rgba(59, 130, 246, 0.15);
        }
        
        [data-theme="dark"] .sks-badge.praktek {
          background: rgba(34, 197, 94, 0.15);
        }
        
        [data-theme="dark"] .formula-badge.with-praktek {
          background: rgba(34, 197, 94, 0.15);
        }
        
        [data-theme="dark"] .formula-badge.no-praktek {
          background: rgba(245, 158, 11, 0.15);
        }
        
        [data-theme="dark"] .formula-info {
          background: rgba(59, 130, 246, 0.1);
          border-color: rgba(59, 130, 246, 0.2);
        }
      `})]})}const u1=[{id:1,nim:"2024010001",nama:"Budi Santoso",prodi:"D4 Pengelolaan Pelabuhan",kelas:"1A",matkul:"Navigasi Sungai",dosen:"Dr. Ahmad Fauzi",nilai:85,tanggal:"2026-01-03"},{id:2,nim:"2024010001",nama:"Budi Santoso",prodi:"D4 Pengelolaan Pelabuhan",kelas:"1A",matkul:"Keselamatan Pelayaran",dosen:"Dr. Rizal Hidayat",nilai:78,tanggal:"2026-01-04"},{id:3,nim:"2024010002",nama:"Ani Wijaya",prodi:"D4 Pengelolaan Pelabuhan",kelas:"1A",matkul:"Navigasi Sungai",dosen:"Dr. Ahmad Fauzi",nilai:92,tanggal:"2026-01-03"},{id:4,nim:"2024010002",nama:"Ani Wijaya",prodi:"D4 Pengelolaan Pelabuhan",kelas:"1A",matkul:"Keselamatan Pelayaran",dosen:"Dr. Rizal Hidayat",nilai:88,tanggal:"2026-01-04"},{id:5,nim:"2024010003",nama:"Citra Dewi",prodi:"D4 Transportasi Laut",kelas:"1A",matkul:"Teknik Perkapalan",dosen:"Dr. Bambang Sutrisno",nilai:75,tanggal:"2026-01-02"},{id:6,nim:"2024010004",nama:"Dedi Kurniawan",prodi:"D4 Transportasi Laut",kelas:"1B",matkul:"Teknik Perkapalan",dosen:"Dr. Bambang Sutrisno",nilai:82,tanggal:"2026-01-02"},{id:7,nim:"2024010005",nama:"Eka Putri",prodi:"D3 LLASDP",kelas:"1A",matkul:"Manajemen Pelabuhan",dosen:"Dr. Siti Aminah",nilai:90,tanggal:"2026-01-05"},{id:8,nim:"2024010006",nama:"Fajar Rahman",prodi:"D4 Kepelautan",kelas:"2A",matkul:"Hukum Maritim",dosen:"Dr. Hendra Wijaya",nilai:87,tanggal:"2026-01-04"}],m1=["Semua Dosen","Dr. Ahmad Fauzi","Dr. Rizal Hidayat","Dr. Bambang Sutrisno","Dr. Siti Aminah","Dr. Hendra Wijaya"],h1=["Semua Mata Kuliah","Navigasi Sungai","Keselamatan Pelayaran","Teknik Perkapalan","Manajemen Pelabuhan","Hukum Maritim"],p1=["Semua Prodi","D4 Pengelolaan Pelabuhan","D4 Transportasi Laut","D3 LLASDP","D4 Kepelautan"],f1=["Semua Kelas","1A","1B","2A","2B"];function $p(r){return r>=85?{label:"A",color:"success"}:r>=75?{label:"B",color:"primary"}:r>=65?{label:"C",color:"warning"}:r>=55?{label:"D",color:"accent"}:{label:"E",color:"danger"}}function qp(){const{settings:r}=Wa(),[c,u]=y.useState(""),[o,h]=y.useState("Semua Dosen"),[m,x]=y.useState("Semua Mata Kuliah"),[g,b]=y.useState("Semua Prodi"),[p,z]=y.useState("Semua Kelas"),[N,S]=y.useState(!1),A=y.useRef(null),v=u1.filter(k=>{const Q=k.nama.toLowerCase().includes(c.toLowerCase())||k.nim.includes(c),$=o==="Semua Dosen"||k.dosen===o,_=m==="Semua Mata Kuliah"||k.matkul===m,U=g==="Semua Prodi"||k.prodi===g,L=p==="Semua Kelas"||k.kelas===p;return Q&&$&&_&&U&&L}),R={totalRecords:v.length,avgNilai:v.length>0?Math.round(v.reduce((k,Q)=>k+Q.nilai,0)/v.length):0,gradeA:v.filter(k=>k.nilai>=85).length,gradeB:v.filter(k=>k.nilai>=75&&k.nilai<85).length,gradeC:v.filter(k=>k.nilai>=65&&k.nilai<75).length,gradeD:v.filter(k=>k.nilai<65).length},j=()=>{const k=A.current,Q=document.body.innerHTML;document.body.innerHTML=k.innerHTML,window.print(),document.body.innerHTML=Q,window.location.reload()},w=()=>{j()},C=new Date().toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"});return a.jsxs(Ee,{children:[a.jsxs("div",{className:"reports-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Laporan Nilai"}),a.jsx("p",{className:"page-subtitle",children:"Rekap nilai akumulatif dari ujian yang telah dinilai"})]}),a.jsxs("div",{className:"page-actions",children:[a.jsxs("button",{className:"btn btn-outline",onClick:()=>S(!N),children:[a.jsx(et,{size:18}),"Filter",a.jsx(id,{size:16,className:N?"rotate":""})]}),a.jsxs("button",{className:"btn btn-secondary",onClick:w,children:[a.jsx(rd,{size:18}),"Export PDF"]}),a.jsxs("button",{className:"btn btn-primary",onClick:j,children:[a.jsx(da,{size:18}),"Cetak"]})]})]}),N&&a.jsx("div",{className:"filters-panel card animate-fadeIn",children:a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"filters-grid",children:[a.jsxs("div",{className:"filter-group",children:[a.jsx("label",{className:"form-label",children:"Dosen"}),a.jsx("select",{className:"form-input",value:o,onChange:k=>h(k.target.value),children:m1.map(k=>a.jsx("option",{value:k,children:k},k))})]}),a.jsxs("div",{className:"filter-group",children:[a.jsx("label",{className:"form-label",children:"Mata Kuliah"}),a.jsx("select",{className:"form-input",value:m,onChange:k=>x(k.target.value),children:h1.map(k=>a.jsx("option",{value:k,children:k},k))})]}),a.jsxs("div",{className:"filter-group",children:[a.jsx("label",{className:"form-label",children:"Program Studi"}),a.jsx("select",{className:"form-input",value:g,onChange:k=>b(k.target.value),children:p1.map(k=>a.jsx("option",{value:k,children:k},k))})]}),a.jsxs("div",{className:"filter-group",children:[a.jsx("label",{className:"form-label",children:"Kelas"}),a.jsx("select",{className:"form-input",value:p,onChange:k=>z(k.target.value),children:f1.map(k=>a.jsx("option",{value:k,children:k},k))})]})]})})}),a.jsxs("div",{className:"summary-cards",children:[a.jsxs("div",{className:"summary-card",children:[a.jsx("span",{className:"summary-value",children:R.totalRecords}),a.jsx("span",{className:"summary-label",children:"Total Data"})]}),a.jsxs("div",{className:"summary-card",children:[a.jsx("span",{className:"summary-value",children:R.avgNilai}),a.jsx("span",{className:"summary-label",children:"Rata-rata Nilai"})]}),a.jsxs("div",{className:"summary-card success",children:[a.jsx("span",{className:"summary-value",children:R.gradeA}),a.jsx("span",{className:"summary-label",children:"Grade A"})]}),a.jsxs("div",{className:"summary-card primary",children:[a.jsx("span",{className:"summary-value",children:R.gradeB}),a.jsx("span",{className:"summary-label",children:"Grade B"})]})]}),a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:20,className:"search-icon"}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Cari nama atau NIM mahasiswa...",value:c,onChange:k=>u(k.target.value)})]}),a.jsx("div",{className:"card",children:a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"No"}),a.jsx("th",{children:"NIM"}),a.jsx("th",{children:"Nama Mahasiswa"}),a.jsx("th",{children:"Prodi"}),a.jsx("th",{children:"Kelas"}),a.jsx("th",{children:"Mata Kuliah"}),a.jsx("th",{children:"Dosen Pengampu"}),a.jsx("th",{children:"Nilai"}),a.jsx("th",{children:"Grade"}),a.jsx("th",{children:"Tanggal"})]})}),a.jsxs("tbody",{children:[v.map((k,Q)=>{const $=$p(k.nilai);return a.jsxs("tr",{children:[a.jsx("td",{children:Q+1}),a.jsx("td",{className:"font-medium",children:k.nim}),a.jsx("td",{children:k.nama}),a.jsx("td",{className:"text-muted",children:k.prodi}),a.jsx("td",{children:a.jsx("span",{className:"badge badge-outline",children:k.kelas})}),a.jsx("td",{children:k.matkul}),a.jsx("td",{className:"text-muted",children:k.dosen}),a.jsx("td",{className:"font-semibold",children:k.nilai}),a.jsx("td",{children:a.jsx("span",{className:`badge badge-${$.color}`,children:$.label})}),a.jsx("td",{className:"text-muted",children:k.tanggal})]},k.id)}),v.length===0&&a.jsx("tr",{children:a.jsx("td",{colSpan:"10",className:"text-center text-muted py-4",children:"Tidak ada data yang ditemukan"})})]})]})})})})]}),a.jsx("div",{style:{display:"none"},children:a.jsxs("div",{ref:A,children:[a.jsx("style",{children:`
                        @page { size: A4; margin: 1.5cm; }
                        body { font-family: 'Times New Roman', serif; font-size: 12pt; }
                        .print-header { text-align: center; border-bottom: 3px double #000; padding-bottom: 15px; margin-bottom: 20px; }
                        .print-logo { max-height: 80px; margin-bottom: 10px; }
                        .print-institution { font-size: 16pt; font-weight: bold; text-transform: uppercase; margin: 0; }
                        .print-address { font-size: 10pt; margin: 5px 0; }
                        .print-title { text-align: center; font-size: 14pt; font-weight: bold; margin: 20px 0; text-decoration: underline; }
                        .print-table { width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 10pt; }
                        .print-table th, .print-table td { border: 1px solid #000; padding: 6px 8px; text-align: left; }
                        .print-table th { background: #f0f0f0; font-weight: bold; }
                        .print-table td.center { text-align: center; }
                        .print-footer { margin-top: 40px; }
                        .print-signature { float: right; width: 200px; text-align: center; }
                        .print-signature-space { height: 80px; }
                        .print-signature-name { font-weight: bold; text-decoration: underline; }
                        .print-signature-title { font-size: 10pt; }
                        .print-date { margin-bottom: 10px; }
                    `}),a.jsxs("div",{className:"print-header",children:[r.logoUrl&&a.jsx("img",{src:r.logoUrl,alt:"Logo",className:"print-logo"}),a.jsx("p",{className:"print-institution",children:r.institution}),a.jsx("p",{className:"print-address",children:r.address}),a.jsxs("p",{className:"print-address",children:["Telp: ",r.phone," | Email: ",r.email]})]}),a.jsx("h2",{className:"print-title",children:"LAPORAN NILAI UJIAN"}),a.jsxs("p",{children:[a.jsx("strong",{children:"Program Studi:"})," ",g,a.jsx("br",{}),a.jsx("strong",{children:"Kelas:"})," ",p,a.jsx("br",{}),a.jsx("strong",{children:"Mata Kuliah:"})," ",m,a.jsx("br",{}),a.jsx("strong",{children:"Dosen:"})," ",o]}),a.jsxs("table",{className:"print-table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{style:{width:"30px"},children:"No"}),a.jsx("th",{children:"NIM"}),a.jsx("th",{children:"Nama Mahasiswa"}),a.jsx("th",{children:"Mata Kuliah"}),a.jsx("th",{style:{width:"50px"},children:"Nilai"}),a.jsx("th",{style:{width:"50px"},children:"Grade"})]})}),a.jsx("tbody",{children:v.map((k,Q)=>a.jsxs("tr",{children:[a.jsx("td",{className:"center",children:Q+1}),a.jsx("td",{children:k.nim}),a.jsx("td",{children:k.nama}),a.jsx("td",{children:k.matkul}),a.jsx("td",{className:"center",children:k.nilai}),a.jsx("td",{className:"center",children:$p(k.nilai).label})]},k.id))})]}),a.jsx("div",{className:"print-footer",children:a.jsxs("div",{className:"print-signature",children:[a.jsxs("p",{className:"print-date",children:["Palembang, ",C]}),a.jsx("p",{children:"Mengetahui,"}),a.jsx("div",{className:"print-signature-space"}),a.jsx("p",{className:"print-signature-name",children:"________________________"}),a.jsx("p",{className:"print-signature-title",children:"Kepala Program Studi"})]})})]})}),a.jsx("style",{children:`
                .reports-page {
                    padding: 0;
                }
                .page-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    flex-wrap: wrap;
                    gap: 1rem;
                    margin-bottom: 1.5rem;
                }
                .page-actions {
                    display: flex;
                    gap: 0.75rem;
                    flex-wrap: wrap;
                }
                .rotate {
                    transform: rotate(180deg);
                    transition: transform 0.2s ease;
                }
                .filters-panel {
                    margin-bottom: 1.5rem;
                }
                .filters-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 1rem;
                }
                .summary-cards {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                    gap: 1rem;
                    margin-bottom: 1.5rem;
                }
                .summary-card {
                    background: var(--color-surface);
                    border: 1px solid var(--color-border);
                    border-radius: 0.75rem;
                    padding: 1.25rem;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    gap: 0.25rem;
                }
                .summary-card.success {
                    background: rgba(16, 185, 129, 0.1);
                    border-color: rgba(16, 185, 129, 0.3);
                }
                .summary-card.primary {
                    background: var(--color-primary-alpha);
                    border-color: var(--color-primary);
                }
                .summary-value {
                    font-size: 1.75rem;
                    font-weight: 700;
                    color: var(--color-text);
                }
                .summary-label {
                    font-size: 0.875rem;
                    color: var(--color-text-muted);
                }
                .search-box {
                    position: relative;
                    margin-bottom: 1.5rem;
                }
                .search-box .search-icon {
                    position: absolute;
                    left: 1rem;
                    top: 50%;
                    transform: translateY(-50%);
                    color: var(--color-text-muted);
                }
                .search-box .form-input {
                    padding-left: 3rem;
                }
                .badge-outline {
                    background: transparent;
                    border: 1px solid var(--color-border);
                    color: var(--color-text-muted);
                }
                @media (max-width: 768px) {
                    .page-header {
                        flex-direction: column;
                    }
                    .page-actions {
                        width: 100%;
                    }
                    .page-actions button {
                        flex: 1;
                    }
                }
            `})]})}function Ip(){const{settings:r,updateSettings:c,resetSettings:u}=Wa(),[o,h]=y.useState(r),[m,x]=y.useState(r.logoUrl),[g,b]=y.useState(null),p=y.useRef(null),z=(j,w)=>{h(C=>({...C,[j]:w}))},N=j=>{const w=j.target.files[0];if(w){if(w.size>2*1024*1024){alert("Ukuran file maksimal 2MB");return}const C=new FileReader;C.onloadend=()=>{x(C.result),h(k=>({...k,logoUrl:C.result}))},C.readAsDataURL(w)}},S=()=>{x(null),h(j=>({...j,logoUrl:null})),p.current&&(p.current.value="")},A=j=>{h(w=>({...w,primaryColor:j.primary,secondaryColor:j.secondary}))},v=()=>{c(o),b("success"),setTimeout(()=>b(null),3e3)},R=()=>{confirm("Yakin ingin mengembalikan semua pengaturan ke default?")&&(u(),h({appName:"CAT POLTEKTRANS",appSubtitle:"Sistem Ujian Online",logoUrl:null,primaryColor:"#0891b2",secondaryColor:"#ca8a04",institution:"Politeknik Transportasi SDP Palembang",address:"Jl. Residen Abdul Rozak, Palembang",phone:"(0711) 712345",email:"info@poltektrans.ac.id"}),x(null),b("reset"),setTimeout(()=>b(null),3e3))};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"settings-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsx("h1",{className:"page-title",children:"Pengaturan Aplikasi"}),a.jsx("p",{className:"page-subtitle",children:"Kustomisasi tampilan dan informasi aplikasi"})]}),a.jsxs("div",{className:"settings-grid",children:[a.jsxs("div",{className:"card",children:[a.jsx("div",{className:"card-header",children:a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(Xo,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Logo Aplikasi"})]})}),a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"logo-upload-area",children:[m?a.jsxs("div",{className:"logo-preview-container",children:[a.jsx("img",{src:m,alt:"Logo Preview",className:"logo-preview"}),a.jsx("button",{className:"btn btn-icon btn-ghost remove-logo-btn",onClick:S,children:a.jsx(Je,{size:18})})]}):a.jsxs("div",{className:"upload-placeholder",onClick:()=>p.current?.click(),children:[a.jsx(Lp,{size:48,className:"upload-icon"}),a.jsx("span",{children:"Klik untuk upload logo"}),a.jsx("span",{className:"text-muted text-sm",children:"PNG, JPG (Max 2MB)"})]}),a.jsx("input",{ref:p,type:"file",accept:"image/png,image/jpeg,image/jpg",onChange:N,style:{display:"none"}})]}),m&&a.jsxs("button",{className:"btn btn-outline btn-sm mt-3",onClick:()=>p.current?.click(),children:[a.jsx(Lp,{size:16}),"Ganti Logo"]})]})]}),a.jsxs("div",{className:"card",children:[a.jsx("div",{className:"card-header",children:a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(oj,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Tema Warna"})]})}),a.jsxs("div",{className:"card-body",children:[a.jsx("div",{className:"color-presets",children:Jv.map((j,w)=>a.jsxs("button",{className:`color-preset-btn ${o.primaryColor===j.primary?"active":""}`,onClick:()=>A(j),title:j.name,children:[a.jsx("div",{className:"color-swatch",style:{background:`linear-gradient(135deg, ${j.primary} 50%, ${j.secondary} 50%)`}}),a.jsx("span",{className:"color-name",children:j.name}),o.primaryColor===j.primary&&a.jsx(il,{size:14,className:"color-check"})]},w))}),a.jsxs("div",{className:"color-custom mt-4",children:[a.jsx("label",{className:"form-label",children:"Warna Kustom"}),a.jsxs("div",{className:"flex gap-3",children:[a.jsxs("div",{className:"color-input-group",children:[a.jsx("label",{className:"text-sm text-muted",children:"Primary"}),a.jsx("input",{type:"color",value:o.primaryColor,onChange:j=>z("primaryColor",j.target.value),className:"color-input"})]}),a.jsxs("div",{className:"color-input-group",children:[a.jsx("label",{className:"text-sm text-muted",children:"Secondary"}),a.jsx("input",{type:"color",value:o.secondaryColor,onChange:j=>z("secondaryColor",j.target.value),className:"color-input"})]})]})]})]})]}),a.jsxs("div",{className:"card",children:[a.jsx("div",{className:"card-header",children:a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(Hj,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Nama Aplikasi"})]})}),a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Nama Utama"}),a.jsx("input",{type:"text",className:"form-input",value:o.appName,onChange:j=>z("appName",j.target.value),placeholder:"CAT POLTEKTRANS"})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Sub Judul"}),a.jsx("input",{type:"text",className:"form-input",value:o.appSubtitle,onChange:j=>z("appSubtitle",j.target.value),placeholder:"Sistem Ujian Online"})]})]})]}),a.jsxs("div",{className:"card",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(Yi,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Informasi Institusi"})]}),a.jsx("span",{className:"text-muted text-sm",children:"Untuk Kop Surat"})]}),a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Nama Institusi"}),a.jsx("input",{type:"text",className:"form-input",value:o.institution,onChange:j=>z("institution",j.target.value)})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Alamat"}),a.jsx("input",{type:"text",className:"form-input",value:o.address,onChange:j=>z("address",j.target.value)})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Telepon"}),a.jsx("input",{type:"text",className:"form-input",value:o.phone,onChange:j=>z("phone",j.target.value)})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Email"}),a.jsx("input",{type:"email",className:"form-input",value:o.email,onChange:j=>z("email",j.target.value)})]})]})]})]})]}),a.jsxs("div",{className:"settings-actions",children:[a.jsxs("button",{className:"btn btn-outline",onClick:R,children:[a.jsx(vj,{size:18}),"Reset Default"]}),a.jsxs("button",{className:"btn btn-primary",onClick:v,children:[a.jsx(at,{size:18}),"Simpan Pengaturan"]})]}),g&&a.jsxs("div",{className:`toast toast-${g==="success"?"success":"info"}`,children:[a.jsx(il,{size:18}),g==="success"?"Pengaturan berhasil disimpan!":"Pengaturan dikembalikan ke default"]})]}),a.jsx("style",{children:`
                .settings-page {
                    padding: 0;
                }
                .settings-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                    gap: 1.5rem;
                    margin-bottom: 2rem;
                }
                @media (max-width: 768px) {
                    .settings-grid {
                        grid-template-columns: 1fr;
                    }
                }
                .logo-upload-area {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                }
                .upload-placeholder {
                    width: 200px;
                    height: 200px;
                    border: 2px dashed var(--color-border);
                    border-radius: 1rem;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    gap: 0.5rem;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    background: var(--color-surface);
                }
                .upload-placeholder:hover {
                    border-color: var(--color-primary);
                    background: var(--color-primary-alpha);
                }
                .upload-icon {
                    color: var(--color-text-muted);
                }
                .logo-preview-container {
                    position: relative;
                    width: 200px;
                    height: 200px;
                }
                .logo-preview {
                    width: 100%;
                    height: 100%;
                    object-fit: contain;
                    border-radius: 1rem;
                    border: 2px solid var(--color-border);
                    background: white;
                }
                .remove-logo-btn {
                    position: absolute;
                    top: -8px;
                    right: -8px;
                    background: var(--color-danger) !important;
                    color: white !important;
                    border-radius: 50%;
                    width: 28px;
                    height: 28px;
                }
                .color-presets {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
                    gap: 0.75rem;
                }
                .color-preset-btn {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    gap: 0.5rem;
                    padding: 0.75rem;
                    border: 2px solid var(--color-border);
                    border-radius: 0.75rem;
                    background: var(--color-surface);
                    cursor: pointer;
                    transition: all 0.2s ease;
                    position: relative;
                }
                .color-preset-btn:hover {
                    border-color: var(--color-primary);
                }
                .color-preset-btn.active {
                    border-color: var(--color-primary);
                    background: var(--color-primary-alpha);
                }
                .color-swatch {
                    width: 48px;
                    height: 48px;
                    border-radius: 50%;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
                }
                .color-name {
                    font-size: 0.75rem;
                    color: var(--color-text-muted);
                    text-align: center;
                }
                .color-check {
                    position: absolute;
                    top: 0.5rem;
                    right: 0.5rem;
                    color: var(--color-primary);
                }
                .color-input-group {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }
                .color-input {
                    width: 60px;
                    height: 40px;
                    border: 2px solid var(--color-border);
                    border-radius: 0.5rem;
                    cursor: pointer;
                    padding: 0;
                    overflow: hidden;
                }
                .color-input::-webkit-color-swatch {
                    border: none;
                }
                .form-row {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 1rem;
                }
                @media (max-width: 480px) {
                    .form-row {
                        grid-template-columns: 1fr;
                    }
                }
                .settings-actions {
                    display: flex;
                    justify-content: flex-end;
                    gap: 1rem;
                    padding-top: 1rem;
                    border-top: 1px solid var(--color-border);
                }
                .toast {
                    position: fixed;
                    bottom: 2rem;
                    right: 2rem;
                    padding: 1rem 1.5rem;
                    border-radius: 0.75rem;
                    display: flex;
                    align-items: center;
                    gap: 0.75rem;
                    color: white;
                    font-weight: 500;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
                    animation: slideIn 0.3s ease;
                    z-index: 1000;
                }
                .toast-success {
                    background: var(--color-success);
                }
                .toast-info {
                    background: var(--color-primary);
                }
                @keyframes slideIn {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
            `})]})}const Bi=[{id:1,kode:"DPS",nama:"D4 Pengelolaan Pelabuhan dan Pelayaran Sungai"},{id:2,kode:"DTL",nama:"D4 Transportasi Laut"},{id:3,kode:"LLASDP",nama:"D3 LLASDP"},{id:4,kode:"DKP",nama:"D4 Kepelautan"}],$i=[{id:1,nama:"1A",prodiId:1,angkatan:2024},{id:2,nama:"1B",prodiId:1,angkatan:2024},{id:3,nama:"2A",prodiId:1,angkatan:2023},{id:4,nama:"1A",prodiId:2,angkatan:2024},{id:5,nama:"1A",prodiId:3,angkatan:2024},{id:6,nama:"1A",prodiId:4,angkatan:2024}],Pp=[{id:1,name:"Budi Santoso",username:"budi.santoso",nim:"2024010001",prodiId:1,kelasId:1,photo:null,password:"123456"},{id:2,name:"Ani Wijaya",username:"ani.wijaya",nim:"2024010002",prodiId:1,kelasId:2,photo:null,password:"123456"},{id:3,name:"Rizky Pratama",username:"rizky.pratama",nim:"2024010003",prodiId:2,kelasId:4,photo:null,password:"123456"},{id:4,name:"Dewi Sartika",username:"dewi.sartika",nim:"2024010004",prodiId:1,kelasId:1,photo:null,password:"123456"},{id:5,name:"Eko Prasetyo",username:"eko.prasetyo",nim:"2024010005",prodiId:3,kelasId:5,photo:null,password:"123456"},{id:6,name:"Fitri Handayani",username:"fitri.handayani",nim:"2024010006",prodiId:4,kelasId:6,photo:null,password:"123456"},{id:7,name:"Gilang Ramadhan",username:"gilang.ramadhan",nim:"2024010007",prodiId:1,kelasId:3,photo:null,password:"123456"},{id:8,name:"Hana Permata",username:"hana.permata",nim:"2024010008",prodiId:2,kelasId:4,photo:null,password:"123456"}];function Gp(){const{settings:r}=Wa(),[c,u]=y.useState(""),[o,h]=y.useState("all"),[m,x]=y.useState("all"),[g,b]=y.useState([]),p=y.useRef(null),z=o==="all"?$i:$i.filter(w=>w.prodiId===Number(o)),N=Pp.filter(w=>{const C=w.name.toLowerCase().includes(c.toLowerCase())||w.nim.includes(c),k=o==="all"||w.prodiId===Number(o),Q=m==="all"||w.kelasId===Number(m);return C&&k&&Q}),S=()=>{g.length===N.length?b([]):b(N.map(w=>w.id))},A=w=>{g.includes(w)?b(g.filter(C=>C!==w)):b([...g,w])},v=w=>{const C=$i.find(k=>k.id===w);return C?`${Bi.find(Q=>Q.id===C.prodiId)?.kode||""} - Kelas ${C.nama}`:"-"},R=()=>{const w=p.current,C=document.body.innerHTML;document.body.innerHTML=w.innerHTML,window.print(),document.body.innerHTML=C,window.location.reload()},j=Pp.filter(w=>g.includes(w.id));return a.jsxs(Ee,{children:[a.jsxs("div",{className:"student-card-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Cetak Kartu Mahasiswa"}),a.jsx("p",{className:"page-subtitle",children:"Cetak kartu identitas mahasiswa dengan kredensial login"})]}),a.jsx("div",{className:"page-actions",children:a.jsxs("button",{className:"btn btn-primary",disabled:g.length===0,onClick:R,children:[a.jsx(da,{size:18}),"Cetak ",g.length>0?`(${g.length})`:""]})})]}),a.jsx("div",{className:"card mb-4",children:a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"filters-row",children:[a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:18,className:"search-icon"}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Cari nama atau NIM...",value:c,onChange:w=>u(w.target.value)})]}),a.jsxs("div",{className:"filter-group",children:[a.jsx(et,{size:16}),a.jsxs("select",{className:"form-input",value:o,onChange:w=>{h(w.target.value),x("all")},children:[a.jsx("option",{value:"all",children:"Semua Prodi"}),Bi.map(w=>a.jsxs("option",{value:w.id,children:[w.kode," - ",w.nama]},w.id))]})]}),a.jsx("div",{className:"filter-group",children:a.jsxs("select",{className:"form-input",value:m,onChange:w=>x(w.target.value),children:[a.jsx("option",{value:"all",children:"Semua Kelas"}),z.map(w=>{const C=Bi.find(k=>k.id===w.prodiId);return a.jsxs("option",{value:w.id,children:[C?.kode," - ",w.nama," (",w.angkatan,")"]},w.id)})]})})]})})}),a.jsxs("div",{className:"selection-info",children:[a.jsx("button",{className:"btn btn-ghost btn-sm",onClick:S,children:g.length===N.length?a.jsxs(a.Fragment,{children:[a.jsx(Zi,{size:16})," Batal Pilih Semua"]}):a.jsxs(a.Fragment,{children:[a.jsx(Rp,{size:16})," Pilih Semua (",N.length,")"]})}),g.length>0&&a.jsxs("span",{className:"selected-count",children:[g.length," mahasiswa dipilih"]})]}),a.jsxs("div",{className:"student-grid",children:[N.map(w=>{const C=g.includes(w.id);return a.jsxs("div",{className:`student-card-item ${C?"selected":""}`,onClick:()=>A(w.id),children:[a.jsx("div",{className:"student-checkbox",children:C?a.jsx(Zi,{size:20}):a.jsx(Rp,{size:20})}),a.jsx("div",{className:"student-photo",children:w.photo?a.jsx("img",{src:w.photo,alt:w.name}):a.jsx("div",{className:"photo-placeholder",children:a.jsx(ps,{size:32})})}),a.jsxs("div",{className:"student-info",children:[a.jsx("h4",{className:"student-name",children:w.name}),a.jsx("p",{className:"student-nim",children:w.nim}),a.jsx("p",{className:"student-prodi",children:v(w.kelasId)})]})]},w.id)}),N.length===0&&a.jsxs("div",{className:"empty-state",children:[a.jsx(ps,{size:48}),a.jsx("p",{children:"Tidak ada mahasiswa yang ditemukan"})]})]})]}),a.jsx("div",{style:{display:"none"},children:a.jsxs("div",{ref:p,children:[a.jsx("style",{children:`
                        @page { 
                            size: A4; 
                            margin: 15mm; 
                        }
                        * {
                            margin: 0;
                            padding: 0;
                            box-sizing: border-box;
                        }
                        body { 
                            font-family: Arial, sans-serif; 
                            font-size: 11pt; 
                            background: white;
                        }
                        .cards-container { 
                            display: grid;
                            grid-template-columns: repeat(2, 1fr);
                            gap: 8mm;
                            padding: 0;
                            width: 100%;
                        }
                        .id-card { 
                            width: 100%;
                            min-height: 60mm;
                            border: 2px solid #0891b2;
                            border-radius: 10px;
                            padding: 5mm;
                            box-sizing: border-box;
                            background: linear-gradient(180deg, #ffffff 0%, #f0f9ff 100%);
                            page-break-inside: avoid;
                            break-inside: avoid;
                        }
                        .card-header {
                            display: flex;
                            align-items: center;
                            gap: 4mm;
                            border-bottom: 2px solid #0891b2;
                            padding-bottom: 3mm;
                            margin-bottom: 3mm;
                        }
                        .card-logo {
                            width: 15mm;
                            height: 15mm;
                            object-fit: contain;
                        }
                        .card-logo-placeholder {
                            width: 15mm;
                            height: 15mm;
                            background: linear-gradient(135deg, #0891b2, #0e7490);
                            border-radius: 6px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            color: white;
                            font-weight: bold;
                            font-size: 9pt;
                        }
                        .card-institution {
                            flex: 1;
                        }
                        .card-institution h3 {
                            font-size: 9pt;
                            margin: 0 0 1mm 0;
                            color: #0891b2;
                            font-weight: bold;
                            text-transform: uppercase;
                        }
                        .card-institution p {
                            font-size: 7pt;
                            margin: 0;
                            color: #666;
                        }
                        .card-title {
                            text-align: center;
                            font-size: 9pt;
                            font-weight: bold;
                            color: white;
                            background: linear-gradient(135deg, #0891b2, #0e7490);
                            padding: 2mm;
                            border-radius: 4px;
                            margin-bottom: 3mm;
                            letter-spacing: 1px;
                        }
                        .card-body {
                            display: flex;
                            gap: 4mm;
                        }
                        .card-photo {
                            width: 22mm;
                            height: 28mm;
                            border: 2px solid #0891b2;
                            border-radius: 4px;
                            overflow: hidden;
                            background: #f0f0f0;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            flex-shrink: 0;
                        }
                        .card-photo img {
                            width: 100%;
                            height: 100%;
                            object-fit: cover;
                        }
                        .card-photo-placeholder {
                            color: #999;
                            font-size: 24pt;
                        }
                        .card-details {
                            flex: 1;
                            font-size: 8pt;
                        }
                        .card-details table {
                            width: 100%;
                            border-collapse: collapse;
                        }
                        .card-details td {
                            padding: 1mm 0;
                            vertical-align: top;
                        }
                        .card-details td:first-child {
                            width: 16mm;
                            color: #666;
                            font-weight: 500;
                        }
                        .card-details td:last-child {
                            font-weight: 600;
                            color: #333;
                        }
                        .credentials-box {
                            margin-top: 3mm;
                            padding: 2mm 3mm;
                            background: linear-gradient(135deg, #fef3c7, #fef9c3);
                            border: 1.5px solid #f59e0b;
                            border-radius: 4px;
                            font-size: 7.5pt;
                        }
                        .credentials-box strong {
                            color: #b45309;
                        }
                        .credentials-box span {
                            color: #1f2937;
                            font-weight: 600;
                        }
                    `}),a.jsx("div",{className:"cards-container",children:j.map(w=>{const C=Bi.find(Q=>Q.id===w.prodiId),k=$i.find(Q=>Q.id===w.kelasId);return a.jsxs("div",{className:"id-card",children:[a.jsxs("div",{className:"card-header",children:[r?.logoUrl?a.jsx("img",{src:r.logoUrl,alt:"Logo",className:"card-logo"}):a.jsx("div",{className:"card-logo-placeholder",children:"CAT"}),a.jsxs("div",{className:"card-institution",children:[a.jsx("h3",{children:r?.institution||"Politeknik Transportasi SDP Palembang"}),a.jsx("p",{children:r?.address||"Jl. Residen Abdul Rozak, Palembang"})]})]}),a.jsx("div",{className:"card-title",children:"KARTU PESERTA UJIAN"}),a.jsxs("div",{className:"card-body",children:[a.jsx("div",{className:"card-photo",children:w.photo?a.jsx("img",{src:w.photo,alt:w.name}):a.jsx("span",{className:"card-photo-placeholder",children:"👤"})}),a.jsxs("div",{className:"card-details",children:[a.jsx("table",{children:a.jsxs("tbody",{children:[a.jsxs("tr",{children:[a.jsx("td",{children:"Nama"}),a.jsxs("td",{children:[": ",w.name]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"NIM"}),a.jsxs("td",{children:[": ",w.nim]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Prodi"}),a.jsxs("td",{children:[": ",C?.kode||"-"]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Kelas"}),a.jsxs("td",{children:[": ",k?.nama||"-"," (",k?.angkatan||"-",")"]})]})]})}),a.jsxs("div",{className:"credentials-box",children:[a.jsx("strong",{children:"Username:"})," ",w.username,a.jsx("br",{}),a.jsx("strong",{children:"Password:"})," ",w.password]})]})]})]},w.id)})})]})}),a.jsx("style",{children:`
                .student-card-page {
                    padding: 0;
                }
                .page-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    flex-wrap: wrap;
                    gap: 1rem;
                    margin-bottom: 1.5rem;
                }
                .page-actions {
                    display: flex;
                    gap: 0.75rem;
                }
                .filters-row {
                    display: flex;
                    gap: 1rem;
                    flex-wrap: wrap;
                }
                .search-box {
                    position: relative;
                    flex: 1;
                    min-width: 200px;
                }
                .search-box .search-icon {
                    position: absolute;
                    left: 1rem;
                    top: 50%;
                    transform: translateY(-50%);
                    color: var(--color-text-muted);
                }
                .search-box .form-input {
                    padding-left: 2.75rem;
                }
                .filter-group {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    color: var(--color-text-muted);
                }
                .filter-group .form-input {
                    min-width: 180px;
                }
                .mb-4 {
                    margin-bottom: 1.5rem;
                }
                .selection-info {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    margin-bottom: 1rem;
                }
                .selected-count {
                    font-size: 0.875rem;
                    color: var(--color-primary);
                    font-weight: 500;
                }
                .student-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
                    gap: 1rem;
                }
                .student-card-item {
                    background: var(--color-surface);
                    border: 2px solid var(--color-border);
                    border-radius: 0.75rem;
                    padding: 1rem;
                    display: flex;
                    gap: 1rem;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    position: relative;
                }
                .student-card-item:hover {
                    border-color: var(--color-primary);
                    background: var(--color-primary-alpha);
                }
                .student-card-item.selected {
                    border-color: var(--color-primary);
                    background: var(--color-primary-alpha);
                }
                .student-checkbox {
                    position: absolute;
                    top: 0.75rem;
                    right: 0.75rem;
                    color: var(--color-text-muted);
                }
                .student-card-item.selected .student-checkbox {
                    color: var(--color-primary);
                }
                .student-photo {
                    width: 70px;
                    height: 90px;
                    border-radius: 0.5rem;
                    overflow: hidden;
                    flex-shrink: 0;
                }
                .student-photo img {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                }
                .photo-placeholder {
                    width: 100%;
                    height: 100%;
                    background: var(--color-bg-tertiary);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: var(--color-text-muted);
                }
                .student-info {
                    flex: 1;
                    min-width: 0;
                }
                .student-name {
                    font-weight: 600;
                    margin: 0 0 0.25rem 0;
                    color: var(--color-text);
                }
                .student-nim {
                    font-size: 0.875rem;
                    color: var(--color-primary);
                    font-weight: 500;
                    margin: 0 0 0.5rem 0;
                }
                .student-prodi {
                    font-size: 0.75rem;
                    color: var(--color-text-muted);
                    margin: 0;
                }
                .empty-state {
                    grid-column: 1 / -1;
                    text-align: center;
                    padding: 3rem;
                    color: var(--color-text-muted);
                }
                .empty-state p {
                    margin-top: 1rem;
                }
                @media (max-width: 768px) {
                    .page-header {
                        flex-direction: column;
                    }
                    .page-actions {
                        width: 100%;
                    }
                    .page-actions button {
                        flex: 1;
                    }
                }
            `})]})}const rs=[{id:1,kode:"DPS",nama:"D4 Pengelolaan Pelabuhan dan Pelayaran Sungai",color:"#ef4444"},{id:2,kode:"DTL",nama:"D4 Transportasi Laut",color:"#3b82f6"},{id:3,kode:"LLASDP",nama:"D3 LLASDP",color:"#22c55e"},{id:4,kode:"DKP",nama:"D4 Kepelautan",color:"#a855f7"}],Ho=[{id:1,name:"Budi Santoso",nim:"2024010001",prodiId:1,kelasId:1,photo:null},{id:2,name:"Ani Wijaya",nim:"2024010002",prodiId:1,kelasId:2,photo:null},{id:3,name:"Rizky Pratama",nim:"2024020001",prodiId:2,kelasId:4,photo:null},{id:4,name:"Dewi Sartika",nim:"2024010003",prodiId:1,kelasId:1,photo:null},{id:5,name:"Eko Prasetyo",nim:"2024030001",prodiId:3,kelasId:5,photo:null},{id:6,name:"Fitri Handayani",nim:"2024040001",prodiId:4,kelasId:6,photo:null},{id:7,name:"Gilang Ramadhan",nim:"2024010004",prodiId:1,kelasId:3,photo:null},{id:8,name:"Hana Permata",nim:"2024020002",prodiId:2,kelasId:4,photo:null},{id:9,name:"Irfan Hakim",nim:"2024030002",prodiId:3,kelasId:5,photo:null},{id:10,name:"Joko Widodo",nim:"2024040002",prodiId:4,kelasId:6,photo:null},{id:11,name:"Kartini Dewi",nim:"2024010005",prodiId:1,kelasId:1,photo:null},{id:12,name:"Lukman Hakim",nim:"2024020003",prodiId:2,kelasId:4,photo:null},{id:13,name:"Mega Sari",nim:"2024030003",prodiId:3,kelasId:5,photo:null},{id:14,name:"Nanda Putra",nim:"2024040003",prodiId:4,kelasId:6,photo:null},{id:15,name:"Oscar Pratama",nim:"2024010006",prodiId:1,kelasId:2,photo:null},{id:16,name:"Putri Ayu",nim:"2024020004",prodiId:2,kelasId:4,photo:null},{id:17,name:"Qori Alam",nim:"2024030004",prodiId:3,kelasId:5,photo:null},{id:18,name:"Rina Marlina",nim:"2024040004",prodiId:4,kelasId:6,photo:null},{id:19,name:"Surya Darma",nim:"2024010007",prodiId:1,kelasId:3,photo:null},{id:20,name:"Tina Sari",nim:"2024020005",prodiId:2,kelasId:4,photo:null},{id:21,name:"Umar Said",nim:"2024030005",prodiId:3,kelasId:5,photo:null},{id:22,name:"Vina Aulia",nim:"2024040005",prodiId:4,kelasId:6,photo:null},{id:23,name:"Wawan Setiawan",nim:"2024010008",prodiId:1,kelasId:1,photo:null},{id:24,name:"Xena Putri",nim:"2024020006",prodiId:2,kelasId:4,photo:null},{id:25,name:"Yanto Sugiarto",nim:"2024030006",prodiId:3,kelasId:5,photo:null},{id:26,name:"Zara Amelia",nim:"2024040006",prodiId:4,kelasId:6,photo:null},{id:27,name:"Ahmad Fauzi",nim:"2024010009",prodiId:1,kelasId:2,photo:null},{id:28,name:"Bella Cantika",nim:"2024020007",prodiId:2,kelasId:4,photo:null},{id:29,name:"Candra Wijaya",nim:"2024030007",prodiId:3,kelasId:5,photo:null},{id:30,name:"Diana Sari",nim:"2024040007",prodiId:4,kelasId:6,photo:null}];function g1(r){const c=[...r];for(let u=c.length-1;u>0;u--){const o=Math.floor(Math.random()*(u+1));[c[u],c[o]]=[c[o],c[u]]}return c}function Qp(){const{settings:r}=Wa(),[c,u]=y.useState(25),[o,h]=y.useState([]),[m,x]=y.useState(0),[g,b]=y.useState(!1),p=y.useRef(null),z=()=>{const j={};rs.forEach(U=>{j[U.id]=g1(Ho.filter(L=>L.prodiId===U.id))});const w=Object.keys(j).filter(U=>j[U].length>0).map(Number),C=[];let k=!0,Q=0;for(;k;){k=!1;const U=Q;do{const L=w[Q%w.length];j[L].length>0&&(C.push(j[L].shift()),k=!0),Q++}while(Q%w.length!==U%w.length)}const $=[];let _=1;for(let U=0;U<C.length;U+=c){const L=C.slice(U,U+c).map(K=>({...K,examNumber:`UJIAN-${String(_++).padStart(3,"0")}`}));$.push({id:$.length+1,name:`Ruang ${$.length+1}`,students:L,rows:Math.ceil(L.length/5),cols:5})}h($),x(0),b(!0)},N=()=>{const j=p.current,w=document.body.innerHTML;document.body.innerHTML=j.innerHTML,window.print(),document.body.innerHTML=w,window.location.reload()},S=j=>rs.find(C=>C.id===j)?.color||"#6b7280",A=j=>rs.find(C=>C.id===j)?.kode||"-",v=o[m],R=j=>{if(!j)return[];const w=[];for(let C=0;C<j.rows;C++){const k=[];for(let Q=0;Q<j.cols;Q++){const $=C*j.cols+Q,_=j.students[$];k.push({seatNumber:$+1,student:_})}w.push(k)}return w};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"exam-room-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Ruang Ujian"}),a.jsx("p",{className:"page-subtitle",children:"Alokasi peserta dan denah tempat duduk ujian"})]}),a.jsxs("div",{className:"page-actions",children:[g&&a.jsxs("button",{className:"btn btn-outline",onClick:N,children:[a.jsx(da,{size:18}),"Print Denah"]}),a.jsxs("button",{className:"btn btn-primary",onClick:z,children:[a.jsx(Aj,{size:18}),g?"Acak Ulang":"Acak & Alokasikan"]})]})]}),a.jsx("div",{className:"config-section card mb-4",children:a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"config-row",children:[a.jsxs("div",{className:"config-item",children:[a.jsx(Sj,{size:18}),a.jsx("label",{children:"Kapasitas Ruangan:"}),a.jsxs("select",{className:"form-input",value:c,onChange:j=>u(Number(j.target.value)),children:[a.jsx("option",{value:20,children:"20 Peserta"}),a.jsx("option",{value:25,children:"25 Peserta"})]})]}),a.jsxs("div",{className:"config-item",children:[a.jsx(ra,{size:18}),a.jsxs("span",{children:["Total Peserta: ",a.jsx("strong",{children:Ho.length})]})]}),a.jsxs("div",{className:"config-item",children:[a.jsx(Vi,{size:18}),a.jsxs("span",{children:["Estimasi Ruangan: ",a.jsx("strong",{children:Math.ceil(Ho.length/c)})]})]})]}),a.jsx("div",{className:"prodi-legend",children:rs.map(j=>a.jsxs("div",{className:"legend-item",children:[a.jsx("span",{className:"legend-color",style:{background:j.color}}),a.jsx("span",{className:"legend-text",children:j.kode})]},j.id))})]})}),g?a.jsxs(a.Fragment,{children:[a.jsx("div",{className:"room-tabs",children:o.map((j,w)=>a.jsxs("button",{className:`room-tab ${m===w?"active":""}`,onClick:()=>x(w),children:[a.jsx(Vi,{size:16}),j.name,a.jsx("span",{className:"badge",children:j.students.length})]},j.id))}),v&&a.jsxs("div",{className:"seating-section card",children:[a.jsxs("div",{className:"card-header",children:[a.jsx("h3",{children:v.name}),a.jsxs("span",{className:"room-info",children:[v.students.length," Peserta"]})]}),a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"seating-chart",children:[a.jsx("div",{className:"board-indicator",children:a.jsx("span",{children:"📋 PAPAN TULIS / LAYAR"})}),a.jsx("div",{className:"seats-grid",style:{gridTemplateColumns:`repeat(${v.cols}, 1fr)`},children:R(v).flat().map((j,w)=>a.jsx("div",{className:`seat ${j.student?"occupied":"empty"}`,style:{borderColor:j.student?S(j.student.prodiId):void 0},children:j.student?a.jsxs(a.Fragment,{children:[a.jsx("div",{className:"seat-prodi",style:{background:S(j.student.prodiId)},children:A(j.student.prodiId)}),a.jsx("div",{className:"seat-number",children:j.student.examNumber}),a.jsx("div",{className:"seat-name",title:j.student.name,children:j.student.name}),a.jsx("div",{className:"seat-nim",children:j.student.nim})]}):a.jsx("span",{className:"seat-empty",children:"-"})},w))})]})})]}),a.jsxs("div",{className:"student-list card",children:[a.jsx("div",{className:"card-header",children:a.jsxs("h3",{children:["Daftar Peserta - ",v?.name]})}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"No. Kursi"}),a.jsx("th",{children:"No. Peserta"}),a.jsx("th",{children:"Nama"}),a.jsx("th",{children:"NIM"}),a.jsx("th",{children:"Prodi"})]})}),a.jsx("tbody",{children:v?.students.map((j,w)=>a.jsxs("tr",{children:[a.jsx("td",{children:w+1}),a.jsx("td",{children:a.jsx("span",{className:"badge badge-primary",children:j.examNumber})}),a.jsx("td",{children:j.name}),a.jsx("td",{children:j.nim}),a.jsx("td",{children:a.jsx("span",{className:"prodi-badge",style:{background:`${S(j.prodiId)}20`,color:S(j.prodiId)},children:A(j.prodiId)})})]},j.id))})]})})})]})]}):a.jsx("div",{className:"empty-state card",children:a.jsxs("div",{className:"card-body",children:[a.jsx(Pb,{size:64}),a.jsx("h3",{children:"Belum Ada Alokasi"}),a.jsx("p",{children:'Klik tombol "Acak & Alokasikan" untuk mengacak peserta ke ruangan ujian'})]})})]}),a.jsx("div",{style:{display:"none"},children:a.jsxs("div",{ref:p,children:[a.jsx("style",{children:`
                        @page { size: A4 landscape; margin: 10mm; }
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        body { font-family: Arial, sans-serif; font-size: 9pt; }
                        .print-header {
                            display: flex;
                            align-items: center;
                            gap: 15px;
                            border-bottom: 3px solid #0891b2;
                            padding-bottom: 10px;
                            margin-bottom: 15px;
                        }
                        .print-logo {
                            width: 50px;
                            height: 50px;
                            object-fit: contain;
                        }
                        .print-logo-placeholder {
                            width: 50px;
                            height: 50px;
                            background: linear-gradient(135deg, #0891b2, #0e7490);
                            border-radius: 8px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            color: white;
                            font-weight: bold;
                            font-size: 14pt;
                        }
                        .print-institution h2 {
                            font-size: 14pt;
                            color: #0891b2;
                            margin: 0;
                        }
                        .print-institution p {
                            font-size: 9pt;
                            color: #666;
                            margin: 2px 0 0;
                        }
                        .print-title {
                            text-align: center;
                            font-size: 16pt;
                            font-weight: bold;
                            margin: 10px 0;
                            color: #1f2937;
                        }
                        .print-room-name {
                            text-align: center;
                            font-size: 13pt;
                            color: #0891b2;
                            margin-bottom: 15px;
                        }
                        .print-board {
                            background: #e5e7eb;
                            padding: 8px;
                            text-align: center;
                            font-weight: bold;
                            margin-bottom: 15px;
                            border-radius: 4px;
                        }
                        .print-seats {
                            display: grid;
                            grid-template-columns: repeat(5, 1fr);
                            gap: 8px;
                            margin-bottom: 20px;
                        }
                        .print-seat {
                            border: 2px solid #ddd;
                            border-radius: 6px;
                            padding: 8px;
                            text-align: center;
                            min-height: 80px;
                        }
                        .print-seat-prodi {
                            display: inline-block;
                            padding: 2px 8px;
                            border-radius: 3px;
                            color: white;
                            font-size: 8pt;
                            font-weight: bold;
                            margin-bottom: 4px;
                        }
                        .print-seat-number {
                            font-size: 11pt;
                            font-weight: bold;
                            color: #0891b2;
                            margin-bottom: 2px;
                        }
                        .print-seat-name {
                            font-size: 8pt;
                            font-weight: 600;
                            color: #1f2937;
                            white-space: nowrap;
                            overflow: hidden;
                            text-overflow: ellipsis;
                        }
                        .print-seat-nim {
                            font-size: 7pt;
                            color: #666;
                        }
                        .print-legend {
                            display: flex;
                            gap: 20px;
                            justify-content: center;
                            margin-top: 10px;
                            padding-top: 10px;
                            border-top: 1px solid #ddd;
                        }
                        .print-legend-item {
                            display: flex;
                            align-items: center;
                            gap: 5px;
                            font-size: 8pt;
                        }
                        .print-legend-color {
                            width: 15px;
                            height: 15px;
                            border-radius: 3px;
                        }
                        .page-break { page-break-after: always; }
                    `}),o.map((j,w)=>a.jsxs("div",{className:w<o.length-1?"page-break":"",children:[a.jsxs("div",{className:"print-header",children:[r?.logoUrl?a.jsx("img",{src:r.logoUrl,alt:"Logo",className:"print-logo"}):a.jsx("div",{className:"print-logo-placeholder",children:"CAT"}),a.jsxs("div",{className:"print-institution",children:[a.jsx("h2",{children:r?.institution||"Politeknik Transportasi SDP Palembang"}),a.jsx("p",{children:r?.address||"Jl. Residen Abdul Rozak, Palembang"})]})]}),a.jsx("div",{className:"print-title",children:"DENAH TEMPAT DUDUK UJIAN"}),a.jsxs("div",{className:"print-room-name",children:[j.name," - ",j.students.length," Peserta"]}),a.jsx("div",{className:"print-board",children:"📋 PAPAN TULIS / LAYAR"}),a.jsx("div",{className:"print-seats",children:j.students.map((C,k)=>a.jsxs("div",{className:"print-seat",style:{borderColor:S(C.prodiId)},children:[a.jsx("div",{className:"print-seat-prodi",style:{background:S(C.prodiId)},children:A(C.prodiId)}),a.jsx("div",{className:"print-seat-number",children:C.examNumber}),a.jsx("div",{className:"print-seat-name",children:C.name}),a.jsx("div",{className:"print-seat-nim",children:C.nim})]},C.id))}),a.jsx("div",{className:"print-legend",children:rs.map(C=>a.jsxs("div",{className:"print-legend-item",children:[a.jsx("span",{className:"print-legend-color",style:{background:C.color}}),a.jsxs("span",{children:[C.kode," - ",C.nama]})]},C.id))})]},j.id))]})}),a.jsx("style",{children:`
                .exam-room-page {
                    padding: 0;
                }
                .page-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    flex-wrap: wrap;
                    gap: 1rem;
                    margin-bottom: 1.5rem;
                }
                .page-actions {
                    display: flex;
                    gap: 0.75rem;
                }
                .mb-4 {
                    margin-bottom: 1.5rem;
                }
                .config-row {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 2rem;
                    align-items: center;
                    margin-bottom: 1rem;
                }
                .config-item {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    color: var(--color-text-secondary);
                }
                .config-item label {
                    font-weight: 500;
                }
                .config-item strong {
                    color: var(--color-primary);
                    font-weight: 700;
                }
                .config-item .form-input {
                    width: auto;
                    min-width: 150px;
                }
                .prodi-legend {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 1rem;
                    padding-top: 1rem;
                    border-top: 1px solid var(--color-border);
                }
                .legend-item {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    font-size: 0.875rem;
                }
                .legend-color {
                    width: 16px;
                    height: 16px;
                    border-radius: 4px;
                }
                .legend-text {
                    color: var(--color-text-secondary);
                }
                .empty-state {
                    text-align: center;
                    padding: 4rem 2rem;
                    color: var(--color-text-muted);
                }
                .empty-state h3 {
                    margin: 1rem 0 0.5rem;
                    color: var(--color-text);
                }
                .room-tabs {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 0.5rem;
                    margin-bottom: 1.5rem;
                }
                .room-tab {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    padding: 0.75rem 1.25rem;
                    background: var(--color-surface);
                    border: 2px solid var(--color-border);
                    border-radius: 0.75rem;
                    cursor: pointer;
                    font-weight: 500;
                    color: var(--color-text-secondary);
                    transition: all 0.2s;
                }
                .room-tab:hover {
                    border-color: var(--color-primary);
                    color: var(--color-primary);
                }
                .room-tab.active {
                    background: var(--color-primary);
                    border-color: var(--color-primary);
                    color: white;
                }
                .room-tab .badge {
                    padding: 0.25rem 0.5rem;
                    font-size: 0.75rem;
                    background: rgba(255,255,255,0.2);
                    border-radius: 0.5rem;
                }
                .room-tab.active .badge {
                    background: rgba(255,255,255,0.3);
                }
                .seating-section {
                    margin-bottom: 1.5rem;
                }
                .card-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 1rem 1.5rem;
                    border-bottom: 1px solid var(--color-border);
                }
                .card-header h3 {
                    margin: 0;
                    font-size: 1.125rem;
                }
                .room-info {
                    font-size: 0.875rem;
                    color: var(--color-primary);
                    font-weight: 500;
                }
                .seating-chart {
                    padding: 1.5rem;
                }
                .board-indicator {
                    background: var(--color-bg-tertiary);
                    padding: 0.75rem;
                    text-align: center;
                    font-weight: 600;
                    margin-bottom: 1.5rem;
                    border-radius: 0.5rem;
                    color: var(--color-text-secondary);
                }
                .seats-grid {
                    display: grid;
                    gap: 0.75rem;
                }
                .seat {
                    background: var(--color-surface);
                    border: 2px solid var(--color-border);
                    border-radius: 0.75rem;
                    padding: 0.75rem;
                    text-align: center;
                    min-height: 100px;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    transition: all 0.2s;
                }
                .seat.occupied:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                }
                .seat-prodi {
                    display: inline-block;
                    padding: 0.125rem 0.5rem;
                    border-radius: 0.25rem;
                    color: white;
                    font-size: 0.625rem;
                    font-weight: 700;
                    margin-bottom: 0.25rem;
                    letter-spacing: 0.5px;
                }
                .seat-number {
                    font-size: 0.875rem;
                    font-weight: 700;
                    color: var(--color-primary);
                    margin-bottom: 0.25rem;
                }
                .seat-name {
                    font-size: 0.75rem;
                    font-weight: 600;
                    color: var(--color-text);
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
                .seat-nim {
                    font-size: 0.625rem;
                    color: var(--color-text-muted);
                }
                .seat-empty {
                    color: var(--color-text-muted);
                    font-size: 1.5rem;
                }
                .prodi-badge {
                    display: inline-block;
                    padding: 0.25rem 0.75rem;
                    border-radius: 0.5rem;
                    font-size: 0.75rem;
                    font-weight: 600;
                }
                .student-list {
                    margin-top: 1.5rem;
                }
                @media (max-width: 768px) {
                    .page-header {
                        flex-direction: column;
                    }
                    .page-actions {
                        width: 100%;
                    }
                    .page-actions button {
                        flex: 1;
                    }
                    .config-row {
                        flex-direction: column;
                        gap: 1rem;
                        align-items: flex-start;
                    }
                    .seats-grid {
                        grid-template-columns: repeat(3, 1fr) !important;
                    }
                }
            `})]})}const Yp=[{id:1,kode:"DPS",nama:"D4 Pengelolaan Pelabuhan dan Pelayaran Sungai"},{id:2,kode:"DTL",nama:"D4 Transportasi Laut"},{id:3,kode:"LLASDP",nama:"D3 LLASDP"},{id:4,kode:"DKP",nama:"D4 Kepelautan"}],x1=[{id:1,matkul:"Navigasi Sungai",dosen:"Dr. Ahmad Fauzi, M.T.",kelas:"1A",prodiId:1,examType:"UTS",students:[{nim:"2024010001",name:"Budi Santoso",nilai:78,status:"lulus"},{nim:"2024010002",name:"Ani Wijaya",nilai:68,status:"mengulang"},{nim:"2024010003",name:"Citra Dewi",nilai:88,status:"lulus"},{nim:"2024010004",name:"Deni Pratama",nilai:72,status:"lulus"},{nim:"2024010005",name:"Eka Putri",nilai:85,status:"lulus"}]},{id:2,matkul:"Navigasi Sungai",dosen:"Dr. Ahmad Fauzi, M.T.",kelas:"1A",prodiId:1,examType:"UAS",students:[{nim:"2024010001",name:"Budi Santoso",nilai:85,status:"lulus"},{nim:"2024010002",name:"Ani Wijaya",nilai:72,status:"lulus"},{nim:"2024010003",name:"Citra Dewi",nilai:90,status:"lulus"},{nim:"2024010004",name:"Deni Pratama",nilai:68,status:"mengulang"},{nim:"2024010005",name:"Eka Putri",nilai:82,status:"lulus"}]},{id:3,matkul:"Keselamatan Pelayaran",dosen:"Prof. Dr. Hendra Wijaya",kelas:"1B",prodiId:1,examType:"UTS",students:[{nim:"2024010006",name:"Fani Setiawan",nilai:75,status:"lulus"},{nim:"2024010007",name:"Gita Permata",nilai:82,status:"lulus"},{nim:"2024010008",name:"Hadi Santoso",nilai:65,status:"mengulang"}]},{id:4,matkul:"Keselamatan Pelayaran",dosen:"Prof. Dr. Hendra Wijaya",kelas:"1B",prodiId:1,examType:"UAS",students:[{nim:"2024010006",name:"Fani Setiawan",nilai:78,status:"lulus"},{nim:"2024010007",name:"Gita Permata",nilai:85,status:"lulus"},{nim:"2024010008",name:"Hadi Santoso",nilai:70,status:"lulus"}]},{id:5,matkul:"Teknik Perkapalan",dosen:"Dr. Rizal Hidayat",kelas:"1A",prodiId:2,examType:"UTS",students:[{nim:"2024020001",name:"Indra Wijaya",nilai:80,status:"lulus"},{nim:"2024020002",name:"Joko Prasetyo",nilai:75,status:"lulus"}]}];function qi(){const{user:r}=Le(),{settings:c}=Wa(),[u,o]=y.useState(r?.prodiId||"all"),[h,m]=y.useState("all"),[x,g]=y.useState(null),[b,p]=y.useState("matkul"),z=y.useRef(),N=JSON.parse(localStorage.getItem(`kaprodiInfo_${r?.prodiId||"default"}`)||'{"nama":"","nip":""}'),S=x1.filter(j=>{const w=r?.role==="superadmin"?u==="all"||j.prodiId===parseInt(u):j.prodiId===r?.prodiId,C=h==="all"||j.examType===h;return w&&C}),A=j=>Yp.find(w=>w.id===j)?.kode||"-",v=()=>{let j=`<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Worksheet ss:Name="Rekap Nilai">
<Table>
<Row>
<Cell><Data ss:Type="String">Mata Kuliah</Data></Cell>
<Cell><Data ss:Type="String">Jenis Ujian</Data></Cell>
<Cell><Data ss:Type="String">Dosen</Data></Cell>
<Cell><Data ss:Type="String">Kelas</Data></Cell>
<Cell><Data ss:Type="String">NIM</Data></Cell>
<Cell><Data ss:Type="String">Nama Mahasiswa</Data></Cell>
<Cell><Data ss:Type="String">Nilai</Data></Cell>
<Cell><Data ss:Type="String">Status</Data></Cell>
</Row>`;S.forEach(k=>{k.students.forEach(Q=>{j+=`
<Row>
<Cell><Data ss:Type="String">${k.matkul}</Data></Cell>
<Cell><Data ss:Type="String">${k.examType}</Data></Cell>
<Cell><Data ss:Type="String">${k.dosen}</Data></Cell>
<Cell><Data ss:Type="String">${k.kelas}</Data></Cell>
<Cell><Data ss:Type="String">${Q.nim}</Data></Cell>
<Cell><Data ss:Type="String">${Q.name}</Data></Cell>
<Cell><Data ss:Type="Number">${Q.nilai}</Data></Cell>
<Cell><Data ss:Type="String">${Q.status==="lulus"?"Lulus":"Mengulang"}</Data></Cell>
</Row>`})}),j+=`
</Table>
</Worksheet>
</Workbook>`;const w=new Blob([j],{type:"application/vnd.ms-excel"}),C=document.createElement("a");C.href=URL.createObjectURL(w),C.download=`rekap_nilai_${new Date().toISOString().split("T")[0]}.xls`,C.click()},R=()=>{const j=window.open("","_blank");j.document.write(`
            <html>
            <head>
                <title>Rekap Nilai</title>
                <style>
                    @page { size: A4 portrait; margin: 15mm; }
                    body { font-family: 'Times New Roman', serif; padding: 20px; font-size: 12pt; }
                    .letterhead {
                        display: flex;
                        align-items: center;
                        gap: 20px;
                        border-bottom: 3px double #000;
                        padding-bottom: 15px;
                        margin-bottom: 25px;
                    }
                    .letterhead-logo {
                        width: 70px;
                        height: 70px;
                        border: 2px solid #1e3a5f;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        flex-direction: column;
                        background: white;
                    }
                    .letterhead-logo .logo-icon {
                        font-size: 24pt;
                        line-height: 1;
                    }
                    .letterhead-logo .logo-text {
                        font-size: 6pt;
                        color: #1e3a5f;
                        font-weight: bold;
                    }
                    .letterhead-text {
                        flex: 1;
                        text-align: center;
                    }
                    .letterhead-text h2 {
                        margin: 0;
                        font-size: 14pt;
                        text-transform: uppercase;
                    }
                    .letterhead-text h1 {
                        margin: 5px 0;
                        font-size: 18pt;
                        text-transform: uppercase;
                    }
                    .letterhead-text p {
                        margin: 3px 0;
                        font-size: 10pt;
                    }
                    .document-title {
                        text-align: center;
                        margin: 25px 0;
                    }
                    .document-title h3 {
                        text-decoration: underline;
                        margin: 0;
                        font-size: 14pt;
                    }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    th, td { border: 1px solid #000; padding: 6px 8px; text-align: left; font-size: 11pt; }
                    th { background: #f0f0f0; font-weight: bold; }
                    .text-center { text-align: center; }
                    .lulus { color: #166534; font-weight: bold; }
                    .mengulang { color: #dc2626; font-weight: bold; }
                    .exam-type { display: inline-block; padding: 2px 8px; background: #1e3a5f; color: white; border-radius: 4px; font-size: 10pt; margin-left: 8px; }
                    .section-title { margin: 20px 0 10px; border-bottom: 1px solid #ccc; padding-bottom: 5px; }
                    .signature-section { margin-top: 50px; display: flex; justify-content: flex-end; }
                    .signature-box { text-align: center; width: 250px; }
                    .signature-line { margin-top: 60px; padding-top: 5px; }
                </style>
            </head>
            <body>
                <div class="letterhead">
                    ${c?.logoUrl?`<img src="${c.logoUrl}" alt="Logo" class="letterhead-logo-img" style="width: 70px; height: 70px; object-fit: contain;"/>`:`<div class="letterhead-logo">
                            <span class="logo-icon">⚓</span>
                            <span class="logo-text">POLTEKTRANS</span>
                        </div>`}
                    <div class="letterhead-text">
                        <h1>${c?.institution||"Politeknik Transportasi SDP Palembang"}</h1>
                        <p>${c?.address||"Jl. Residen Abdul Rozak, Palembang, Sumatera Selatan"}</p>
                        <p>Telp: ${c?.phone||"(0711) 123456"} | Email: ${c?.email||"info@poltektrans.ac.id"}</p>
                    </div>
                </div>
                <div class="document-title">
                    <h3>REKAP NILAI MAHASISWA</h3>
                    <p>Tahun Akademik 2025/2026 ${h!=="all"?"- "+h:""}</p>
                </div>
                <p>Tanggal Cetak: ${new Date().toLocaleDateString("id-ID",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}</p>
                ${S.map(w=>`
                    <h3>${w.matkul} <span class="exam-type">${w.examType}</span></h3>
                    <p>Dosen: ${w.dosen} | Kelas: ${w.kelas}</p>
                    <table>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIM</th>
                                <th>Nama Mahasiswa</th>
                                <th class="text-center">Nilai ${w.examType}</th>
                                <th class="text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${w.students.map((C,k)=>`
                                <tr>
                                    <td>${k+1}</td>
                                    <td>${C.nim}</td>
                                    <td>${C.name}</td>
                                    <td class="text-center ${C.nilai>=70?"lulus":"mengulang"}">${C.nilai}</td>
                                    <td class="text-center ${C.status}">${C.status==="lulus"?"Lulus":"Mengulang"}</td>
                                </tr>
                            `).join("")}
                        </tbody>
                    </table>
                `).join("")}
                
                <div class="signature-section">
                    <div class="signature-box">
                        <p>Palembang, ${new Date().toLocaleDateString("id-ID")}</p>
                        <p>Ka. Program Studi</p>
                        <div class="signature-line">
                            <p><strong>${N.nama||"_________________________"}</strong></p>
                            <p>NIP. ${N.nip||"_______________"}</p>
                        </div>
                    </div>
                </div>
            </body>
            </html>
        `),j.document.close(),j.print()};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Rekap Nilai"}),a.jsx("p",{className:"page-subtitle",children:"Data nilai dari seluruh dosen yang tersinkronisasi"})]}),a.jsxs("div",{className:"header-actions",children:[a.jsxs("button",{className:"btn btn-secondary",onClick:v,children:[a.jsx(bs,{size:18}),"Export Excel"]}),a.jsxs("button",{className:"btn btn-primary",onClick:R,children:[a.jsx(da,{size:18}),"Cetak"]})]})]}),a.jsx("div",{className:"card mb-4",children:a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"view-mode-tabs mb-3",children:[a.jsx("button",{className:`view-tab ${b==="matkul"?"active":""}`,onClick:()=>p("matkul"),children:"Setiap Mata Kuliah"}),a.jsx("button",{className:`view-tab ${b==="kelas"?"active":""}`,onClick:()=>p("kelas"),children:"Setiap Kelas"}),a.jsx("button",{className:`view-tab ${b==="mahasiswa"?"active":""}`,onClick:()=>p("mahasiswa"),children:"Setiap Mahasiswa"})]}),a.jsxs("div",{className:"filters-row",children:[r?.role==="superadmin"&&a.jsxs("div",{className:"filter-group",children:[a.jsx(et,{size:16}),a.jsxs("select",{className:"form-input",value:u,onChange:j=>o(j.target.value),children:[a.jsx("option",{value:"all",children:"Semua Prodi"}),Yp.map(j=>a.jsx("option",{value:j.id,children:j.kode},j.id))]})]}),a.jsx("div",{className:"filter-group",children:a.jsxs("select",{className:"form-input",value:h,onChange:j=>m(j.target.value),children:[a.jsx("option",{value:"all",children:"Semua Jenis"}),a.jsx("option",{value:"UTS",children:"UTS"}),a.jsx("option",{value:"UAS",children:"UAS"})]})})]})]})}),a.jsx("div",{className:"card",id:"print-content",ref:z,children:a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"rekap-list",children:[S.map(j=>a.jsxs("div",{className:"rekap-item",children:[a.jsxs("div",{className:"rekap-header",onClick:()=>g(x===j.id?null:j.id),children:[a.jsxs("div",{className:"rekap-info",children:[a.jsxs("h4",{children:[j.matkul,a.jsx("span",{className:`badge badge-${j.examType==="UTS"?"primary":"error"} ml-2`,children:j.examType})]}),a.jsxs("p",{children:[a.jsx("span",{className:"badge badge-info",children:A(j.prodiId)}),a.jsxs("span",{children:["Kelas ",j.kelas]}),a.jsxs("span",{children:["• ",j.dosen]})]})]}),a.jsxs("div",{className:"rekap-meta",children:[a.jsxs("span",{className:"student-count",children:[j.students.length," mahasiswa"]}),x===j.id?a.jsx(Rf,{size:20}):a.jsx(id,{size:20})]})]}),x===j.id&&a.jsx("div",{className:"rekap-detail",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"No"}),a.jsx("th",{children:"NIM"}),a.jsx("th",{children:"Nama Mahasiswa"}),a.jsxs("th",{className:"text-center",children:["Nilai ",j.examType]}),a.jsx("th",{className:"text-center",children:"Status"})]})}),a.jsx("tbody",{children:j.students.map((w,C)=>a.jsxs("tr",{children:[a.jsx("td",{children:C+1}),a.jsx("td",{children:w.nim}),a.jsx("td",{className:"font-medium",children:w.name}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:`nilai-badge ${w.nilai>=70?"lulus":"mengulang"}`,children:w.nilai})}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:`status-label ${w.status}`,children:w.status==="lulus"?"Lulus":"Mengulang"})})]},w.nim))})]})})]},j.id)),S.length===0&&a.jsxs("div",{className:"empty-state",children:[a.jsx(Vt,{size:48}),a.jsx("h3",{children:"Tidak ada data nilai"}),a.jsx("p",{children:"Belum ada nilai yang tersinkronisasi dari dosen"})]})]})})})]}),a.jsx("style",{children:`
                .mb-4 {
                    margin-bottom: var(--space-4);
                }
                .header-actions {
                    display: flex;
                    gap: var(--space-3);
                }
                .rekap-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-4);
                }
                .rekap-item {
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-lg);
                    border: 1px solid var(--border-color);
                    overflow: hidden;
                }
                .rekap-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: var(--space-4);
                    cursor: pointer;
                    transition: background var(--transition-fast);
                }
                .rekap-header:hover {
                    background: var(--bg-secondary);
                }
                .rekap-info h4 {
                    margin: 0 0 var(--space-1);
                }
                .rekap-info p {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    margin: 0;
                    font-size: var(--font-size-sm);
                    color: var(--text-secondary);
                }
                .rekap-meta {
                    display: flex;
                    align-items: center;
                    gap: var(--space-3);
                }
                .student-count {
                    font-size: var(--font-size-sm);
                    color: var(--text-muted);
                }
                .rekap-detail {
                    padding: var(--space-4);
                    border-top: 1px solid var(--border-color);
                    background: var(--bg-secondary);
                    overflow-x: auto;
                }
                .text-center {
                    text-align: center;
                }
                .nh-badge {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    min-width: 28px;
                    padding: var(--space-1) var(--space-2);
                    border-radius: var(--radius-md);
                    font-weight: var(--font-bold);
                    font-size: var(--font-size-xs);
                    color: white;
                }
                .nh-badge.success { background: var(--success-500); }
                .nh-badge.warning { background: var(--warning-500); }
                .nh-badge.info { background: var(--info-500); }
                .nh-badge.error { background: var(--error-500); }
                .nilai-badge {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    min-width: 36px;
                    padding: var(--space-1) var(--space-2);
                    border-radius: var(--radius-md);
                    font-weight: var(--font-bold);
                    font-size: var(--font-size-sm);
                }
                .nilai-badge.lulus {
                    background: var(--success-100);
                    color: var(--success-700);
                }
                .nilai-badge.mengulang {
                    background: var(--error-100);
                    color: var(--error-700);
                }
                .status-label {
                    display: inline-block;
                    padding: var(--space-1) var(--space-2);
                    border-radius: var(--radius-md);
                    font-size: var(--font-size-xs);
                    font-weight: var(--font-medium);
                }
                .status-label.lulus {
                    background: var(--success-100);
                    color: var(--success-700);
                }
                .status-label.mengulang {
                    background: var(--error-100);
                    color: var(--error-700);
                }
                .ml-2 {
                    margin-left: var(--space-2);
                }
                .empty-state {
                    text-align: center;
                    padding: var(--space-8);
                    color: var(--text-muted);
                }
                .empty-state svg {
                    margin-bottom: var(--space-4);
                }
                .empty-state h3 {
                    margin-bottom: var(--space-2);
                    color: var(--text-secondary);
                }
                .view-mode-tabs {
                    display: flex;
                    gap: var(--space-2);
                    padding-bottom: var(--space-3);
                    border-bottom: 1px solid var(--border-color);
                }
                .view-tab {
                    padding: var(--space-2) var(--space-4);
                    border: 1px solid var(--border-color);
                    border-radius: var(--radius-lg);
                    background: var(--bg-secondary);
                    color: var(--text-secondary);
                    font-weight: var(--font-medium);
                    cursor: pointer;
                    transition: all 0.2s ease;
                }
                .view-tab:hover {
                    background: var(--bg-tertiary);
                }
                .view-tab.active {
                    background: var(--primary-500);
                    color: white;
                    border-color: var(--primary-500);
                }
                .mb-3 {
                    margin-bottom: var(--space-3);
                }
            `})]})}const Xp=[{id:1,kode:"DPS",nama:"D4 Pengelolaan Pelabuhan dan Pelayaran Sungai"},{id:2,kode:"DTL",nama:"D4 Transportasi Laut"},{id:3,kode:"LLASDP",nama:"D3 LLASDP"},{id:4,kode:"DKP",nama:"D4 Kepelautan"}],v1=[{id:1,examName:"UTS Navigasi Sungai",room:"Ruang 1",date:"2026-01-04",time:"08:00 - 10:00",prodiId:1,pengawas:"Ir. Siti Rahayu",summary:{total:25,hadir:23,sakit:1,izin:1,alpha:0}},{id:2,examName:"Quiz Keselamatan Pelayaran",room:"Ruang 2",date:"2026-01-05",time:"10:00 - 11:30",prodiId:1,pengawas:"Drs. Bambang Sutrisno",summary:{total:28,hadir:26,sakit:0,izin:1,alpha:1}},{id:3,examName:"UAS Teknik Perkapalan",room:"Lab Komputer 1",date:"2026-01-06",time:"08:00 - 10:00",prodiId:2,pengawas:"Ir. Siti Rahayu",summary:{total:22,hadir:22,sakit:0,izin:0,alpha:0}}],b1=[{id:1,nim:"2024010001",nama:"Budi Santoso",kelas:"1A",prodiId:1,attendance:[{examId:1,examName:"UTS Navigasi Sungai",date:"2026-01-04",status:"hadir"},{examId:2,examName:"Quiz Keselamatan Pelayaran",date:"2026-01-05",status:"hadir"},{examId:3,examName:"UTS Teknik Kapal",date:"2026-01-06",status:"sakit"}],total:3,hadir:2,sakit:1,izin:0,alpha:0},{id:2,nim:"2024010002",nama:"Ani Wijaya",kelas:"1A",prodiId:1,attendance:[{examId:1,examName:"UTS Navigasi Sungai",date:"2026-01-04",status:"hadir"},{examId:2,examName:"Quiz Keselamatan Pelayaran",date:"2026-01-05",status:"hadir"},{examId:3,examName:"UTS Teknik Kapal",date:"2026-01-06",status:"hadir"}],total:3,hadir:3,sakit:0,izin:0,alpha:0},{id:3,nim:"2024010003",nama:"Citra Dewi",kelas:"1B",prodiId:1,attendance:[{examId:1,examName:"UTS Navigasi Sungai",date:"2026-01-04",status:"hadir"},{examId:2,examName:"Quiz Keselamatan Pelayaran",date:"2026-01-05",status:"alpha"},{examId:3,examName:"UTS Teknik Kapal",date:"2026-01-06",status:"izin"}],total:3,hadir:1,sakit:0,izin:1,alpha:1},{id:4,nim:"2024020001",nama:"Dimas Pratama",kelas:"1A",prodiId:2,attendance:[{examId:3,examName:"UAS Teknik Perkapalan",date:"2026-01-06",status:"hadir"}],total:1,hadir:1,sakit:0,izin:0,alpha:0}];function Vp(){const{user:r}=Le(),{settings:c}=Wa(),[u,o]=y.useState("per-ujian"),[h,m]=y.useState(""),[x,g]=y.useState(r?.prodiId||"all"),[b,p]=y.useState(""),z=v1.filter(_=>{const U=r?.role==="superadmin"?x==="all"||_.prodiId===parseInt(x):_.prodiId===r?.prodiId,L=_.examName.toLowerCase().includes(h.toLowerCase())||_.pengawas.toLowerCase().includes(h.toLowerCase()),K=!b||_.date===b;return U&&L&&K}),N=_=>Xp.find(U=>U.id===_)?.kode||"-",S=_=>(_.hadir/_.total*100).toFixed(1),A=_=>(_.hadir/_.total*100).toFixed(1),v=b1.filter(_=>{const U=r?.role==="superadmin"?x==="all"||_.prodiId===parseInt(x):_.prodiId===r?.prodiId,L=_.nama.toLowerCase().includes(h.toLowerCase())||_.nim.includes(h);return U&&L}),R=z.length,j=z.reduce((_,U)=>_+U.summary.total,0),w=z.reduce((_,U)=>_+U.summary.hadir,0),C=j>0?(w/j*100).toFixed(1):0,k=()=>{let _=`<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Worksheet ss:Name="Rekap Kehadiran">
<Table>
<Row>
<Cell><Data ss:Type="String">Ujian</Data></Cell>
<Cell><Data ss:Type="String">Ruang</Data></Cell>
<Cell><Data ss:Type="String">Tanggal</Data></Cell>
<Cell><Data ss:Type="String">Waktu</Data></Cell>
<Cell><Data ss:Type="String">Prodi</Data></Cell>
<Cell><Data ss:Type="String">Pengawas</Data></Cell>
<Cell><Data ss:Type="String">Total</Data></Cell>
<Cell><Data ss:Type="String">Hadir</Data></Cell>
<Cell><Data ss:Type="String">Sakit</Data></Cell>
<Cell><Data ss:Type="String">Izin</Data></Cell>
<Cell><Data ss:Type="String">Alpha</Data></Cell>
<Cell><Data ss:Type="String">Rate</Data></Cell>
</Row>`;z.forEach(K=>{_+=`
<Row>
<Cell><Data ss:Type="String">${K.examName}</Data></Cell>
<Cell><Data ss:Type="String">${K.room}</Data></Cell>
<Cell><Data ss:Type="String">${K.date}</Data></Cell>
<Cell><Data ss:Type="String">${K.time}</Data></Cell>
<Cell><Data ss:Type="String">${N(K.prodiId)}</Data></Cell>
<Cell><Data ss:Type="String">${K.pengawas}</Data></Cell>
<Cell><Data ss:Type="Number">${K.summary.total}</Data></Cell>
<Cell><Data ss:Type="Number">${K.summary.hadir}</Data></Cell>
<Cell><Data ss:Type="Number">${K.summary.sakit}</Data></Cell>
<Cell><Data ss:Type="Number">${K.summary.izin}</Data></Cell>
<Cell><Data ss:Type="Number">${K.summary.alpha}</Data></Cell>
<Cell><Data ss:Type="String">${S(K.summary)}%</Data></Cell>
</Row>`}),_+=`
</Table>
</Worksheet>
</Workbook>`;const U=new Blob([_],{type:"application/vnd.ms-excel"}),L=document.createElement("a");L.href=URL.createObjectURL(U),L.download=`rekap_kehadiran_${b||"all"}_${new Date().toISOString().split("T")[0]}.xls`,L.click()},Q=()=>{const _=window.open("","_blank");_.document.write(`
            <html>
            <head>
                <title>Rekap Kehadiran</title>
                <style>
                    @page { size: A4 portrait; margin: 15mm; }
                    body { font-family: 'Times New Roman', serif; padding: 20px; font-size: 12pt; }
                    .letterhead {
                        display: flex;
                        align-items: center;
                        gap: 20px;
                        border-bottom: 3px double #000;
                        padding-bottom: 15px;
                        margin-bottom: 25px;
                    }
                    .letterhead-logo {
                        width: 70px;
                        height: 70px;
                        border: 2px solid #1e3a5f;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        flex-direction: column;
                        background: white;
                    }
                    .letterhead-logo .logo-icon {
                        font-size: 24pt;
                        line-height: 1;
                    }
                    .letterhead-logo .logo-text {
                        font-size: 6pt;
                        color: #1e3a5f;
                        font-weight: bold;
                    }
                    .letterhead-text { flex: 1; text-align: center; }
                    .letterhead-text h2 { margin: 0; font-size: 14pt; text-transform: uppercase; }
                    .letterhead-text h1 { margin: 5px 0; font-size: 18pt; text-transform: uppercase; }
                    .letterhead-text p { margin: 3px 0; font-size: 10pt; }
                    .document-title { text-align: center; margin: 25px 0; }
                    .document-title h3 { text-decoration: underline; margin: 0; font-size: 14pt; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    th, td { border: 1px solid #000; padding: 6px 8px; text-align: left; font-size: 11pt; }
                    th { background: #f0f0f0; font-weight: bold; }
                    .text-center { text-align: center; }
                    .summary { margin-top: 20px; padding: 10px; background: #f9f9f9; border: 1px solid #ddd; }
                </style>
            </head>
            <body>
                <div class="letterhead">
                    ${c?.logoUrl?`<img src="${c.logoUrl}" alt="Logo" style="width: 70px; height: 70px; object-fit: contain;"/>`:`<div class="letterhead-logo">
                            <span class="logo-icon">⚓</span>
                            <span class="logo-text">POLTEKTRANS</span>
                        </div>`}
                    <div class="letterhead-text">
                        <h1>${c?.institution||"Politeknik Transportasi SDP Palembang"}</h1>
                        <p>${c?.address||"Jl. Residen Abdul Rozak, Palembang, Sumatera Selatan"}</p>
                        <p>Telp: ${c?.phone||"(0711) 123456"} | Email: ${c?.email||"info@poltektrans.ac.id"}</p>
                    </div>
                </div>
                <div class="document-title">
                    <h3>REKAP KEHADIRAN UJIAN</h3>
                    <p>Tahun Akademik 2025/2026</p>
                </div>
                <p>Tanggal Cetak: ${new Date().toLocaleDateString("id-ID",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}</p>
                <table>
                    <thead>
                        <tr>
                            <th>Nama Ujian</th>
                            <th>Ruang</th>
                            <th>Tanggal</th>
                            <th>Waktu</th>
                            <th>Pengawas</th>
                            <th class="text-center">Total</th>
                            <th class="text-center">Hadir</th>
                            <th class="text-center">Sakit</th>
                            <th class="text-center">Izin</th>
                            <th class="text-center">Alpha</th>
                            <th class="text-center">%</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${z.map(U=>`
                            <tr>
                                <td>${U.examName}</td>
                                <td>${U.room}</td>
                                <td>${U.date}</td>
                                <td>${U.time}</td>
                                <td>${U.pengawas}</td>
                                <td class="text-center">${U.summary.total}</td>
                                <td class="text-center">${U.summary.hadir}</td>
                                <td class="text-center">${U.summary.sakit}</td>
                                <td class="text-center">${U.summary.izin}</td>
                                <td class="text-center">${U.summary.alpha}</td>
                                <td class="text-center">${S(U.summary)}%</td>
                            </tr>
                        `).join("")}
                    </tbody>
                </table>
                <div class="summary">
                    <strong>Rekapitulasi:</strong> Total Ujian: ${R} | Total Peserta: ${j} | Total Hadir: ${w} | Tingkat Kehadiran: ${C}%
                </div>
            </body>
            </html>
        `),_.document.close(),_.print()},$=_=>{const U=window.open("","_blank");U.document.write(`
            <html>
            <head>
                <title>Kehadiran - ${_.examName}</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    h1 { text-align: center; margin-bottom: 20px; }
                    .info { margin-bottom: 20px; }
                    .info p { margin: 5px 0; }
                    .summary { display: flex; gap: 20px; margin: 20px 0; }
                    .summary-item { padding: 10px 20px; border: 1px solid #ccc; border-radius: 4px; text-align: center; }
                    .summary-item .value { font-size: 24px; font-weight: bold; }
                    .summary-item .label { font-size: 12px; color: #666; }
                </style>
            </head>
            <body>
                <h1>Daftar Hadir Ujian</h1>
                <div class="info">
                    <p><strong>Nama Ujian:</strong> ${_.examName}</p>
                    <p><strong>Ruang:</strong> ${_.room}</p>
                    <p><strong>Tanggal:</strong> ${_.date}</p>
                    <p><strong>Waktu:</strong> ${_.time}</p>
                    <p><strong>Pengawas:</strong> ${_.pengawas}</p>
                </div>
                <div class="summary">
                    <div class="summary-item"><div class="value">${_.summary.total}</div><div class="label">Total</div></div>
                    <div class="summary-item"><div class="value">${_.summary.hadir}</div><div class="label">Hadir</div></div>
                    <div class="summary-item"><div class="value">${_.summary.sakit}</div><div class="label">Sakit</div></div>
                    <div class="summary-item"><div class="value">${_.summary.izin}</div><div class="label">Izin</div></div>
                    <div class="summary-item"><div class="value">${_.summary.alpha}</div><div class="label">Alpha</div></div>
                    <div class="summary-item"><div class="value">${S(_.summary)}%</div><div class="label">Rate</div></div>
                </div>
            </body>
            </html>
        `),U.document.close(),U.print()};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Rekap Kehadiran"}),a.jsx("p",{className:"page-subtitle",children:"Data kehadiran ujian dari pengawas yang tersinkronisasi"})]}),a.jsxs("div",{className:"header-actions",children:[a.jsxs("button",{className:"btn btn-secondary",onClick:k,children:[a.jsx(bs,{size:18}),"Export Excel"]}),a.jsxs("button",{className:"btn btn-primary",onClick:Q,children:[a.jsx(da,{size:18}),"Cetak Semua"]})]})]}),a.jsxs("div",{className:"stats-grid-sm",children:[a.jsxs("div",{className:"stat-card-sm",children:[a.jsx(va,{size:20}),a.jsxs("div",{children:[a.jsx("span",{className:"stat-value",children:R}),a.jsx("span",{className:"stat-label",children:"Total Ujian"})]})]}),a.jsxs("div",{className:"stat-card-sm",children:[a.jsx(ra,{size:20}),a.jsxs("div",{children:[a.jsx("span",{className:"stat-value",children:j}),a.jsx("span",{className:"stat-label",children:"Total Peserta"})]})]}),a.jsxs("div",{className:"stat-card-sm",children:[a.jsx(We,{size:20}),a.jsxs("div",{children:[a.jsx("span",{className:"stat-value",children:w}),a.jsx("span",{className:"stat-label",children:"Total Hadir"})]})]}),a.jsxs("div",{className:"stat-card-sm success",children:[a.jsx(ms,{size:20}),a.jsxs("div",{children:[a.jsxs("span",{className:"stat-value",children:[C,"%"]}),a.jsx("span",{className:"stat-label",children:"Tingkat Kehadiran"})]})]})]}),a.jsx("div",{className:"card mb-4",children:a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"filters-row",children:[a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:18,className:"search-icon"}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Cari ujian atau pengawas...",value:h,onChange:_=>m(_.target.value)})]}),r?.role==="superadmin"&&a.jsxs("div",{className:"filter-group",children:[a.jsx(et,{size:16}),a.jsxs("select",{className:"form-input",value:x,onChange:_=>g(_.target.value),children:[a.jsx("option",{value:"all",children:"Semua Prodi"}),Xp.map(_=>a.jsx("option",{value:_.id,children:_.kode},_.id))]})]}),a.jsxs("div",{className:"filter-group",children:[a.jsx(va,{size:16}),a.jsx("input",{type:"date",className:"form-input",value:b,onChange:_=>p(_.target.value)}),b&&a.jsx("button",{className:"btn btn-ghost btn-sm",onClick:()=>p(""),children:"Reset"})]})]})})}),a.jsxs("div",{className:"view-tabs mb-4",children:[a.jsxs("button",{className:`tab-btn ${u==="per-ujian"?"active":""}`,onClick:()=>o("per-ujian"),children:[a.jsx(va,{size:16}),"Setiap Ujian"]}),a.jsxs("button",{className:`tab-btn ${u==="per-mahasiswa"?"active":""}`,onClick:()=>o("per-mahasiswa"),children:[a.jsx(ps,{size:16}),"Setiap Mahasiswa"]})]}),u==="per-ujian"?a.jsx("div",{className:"card",children:a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"Ujian"}),a.jsx("th",{children:"Ruang"}),a.jsx("th",{children:"Tanggal"}),a.jsx("th",{children:"Pengawas"}),a.jsx("th",{className:"text-center",children:"Hadir"}),a.jsx("th",{className:"text-center",children:"Sakit"}),a.jsx("th",{className:"text-center",children:"Izin"}),a.jsx("th",{className:"text-center",children:"Alpha"}),a.jsx("th",{className:"text-center",children:"Rate"}),a.jsx("th",{children:"Aksi"})]})}),a.jsxs("tbody",{children:[z.map(_=>a.jsxs("tr",{children:[a.jsx("td",{children:a.jsxs("div",{className:"exam-name-cell",children:[a.jsx("span",{className:"font-medium",children:_.examName}),a.jsx("span",{className:"time-text",children:_.time})]})}),a.jsx("td",{children:_.room}),a.jsx("td",{children:_.date}),a.jsx("td",{children:_.pengawas}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:"count-badge success",children:_.summary.hadir})}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:"count-badge warning",children:_.summary.sakit})}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:"count-badge info",children:_.summary.izin})}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:"count-badge error",children:_.summary.alpha})}),a.jsx("td",{className:"text-center",children:a.jsxs("span",{className:`rate-badge ${parseFloat(S(_.summary))>=90?"success":parseFloat(S(_.summary))>=75?"warning":"error"}`,children:[S(_.summary),"%"]})}),a.jsx("td",{children:a.jsx("button",{className:"btn btn-ghost btn-sm",onClick:()=>$(_),children:a.jsx(da,{size:14})})})]},_.id)),z.length===0&&a.jsx("tr",{children:a.jsx("td",{colSpan:10,className:"text-center text-muted",style:{padding:"var(--space-8)"},children:"Tidak ada data kehadiran"})})]})]})})})}):a.jsx("div",{className:"card",children:a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"NIM"}),a.jsx("th",{children:"Nama Mahasiswa"}),a.jsx("th",{children:"Kelas"}),a.jsx("th",{children:"Prodi"}),a.jsx("th",{className:"text-center",children:"Total"}),a.jsx("th",{className:"text-center",children:"Hadir"}),a.jsx("th",{className:"text-center",children:"Sakit"}),a.jsx("th",{className:"text-center",children:"Izin"}),a.jsx("th",{className:"text-center",children:"Alpha"}),a.jsx("th",{className:"text-center",children:"Rate"})]})}),a.jsxs("tbody",{children:[v.map(_=>a.jsxs("tr",{children:[a.jsx("td",{className:"font-medium",children:_.nim}),a.jsx("td",{children:_.nama}),a.jsx("td",{children:_.kelas}),a.jsx("td",{children:N(_.prodiId)}),a.jsx("td",{className:"text-center",children:_.total}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:"count-badge success",children:_.hadir})}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:"count-badge warning",children:_.sakit})}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:"count-badge info",children:_.izin})}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:"count-badge error",children:_.alpha})}),a.jsx("td",{className:"text-center",children:a.jsxs("span",{className:`rate-badge ${parseFloat(A(_))>=90?"success":parseFloat(A(_))>=75?"warning":"error"}`,children:[A(_),"%"]})})]},_.id)),v.length===0&&a.jsx("tr",{children:a.jsx("td",{colSpan:10,className:"text-center text-muted",style:{padding:"var(--space-8)"},children:"Tidak ada data kehadiran mahasiswa"})})]})]})})})})]}),a.jsx("style",{children:`
                .mb-4 {
                    margin-bottom: var(--space-4);
                }
                .header-actions {
                    display: flex;
                    gap: var(--space-3);
                }
                .view-tabs {
                    display: flex;
                    gap: var(--space-2);
                    padding: var(--space-2);
                    background: var(--bg-secondary);
                    border-radius: var(--radius-lg);
                    border: 1px solid var(--border-color);
                }
                .tab-btn {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    padding: var(--space-2) var(--space-4);
                    border: none;
                    background: transparent;
                    border-radius: var(--radius-md);
                    font-size: var(--font-size-sm);
                    font-weight: var(--font-medium);
                    color: var(--text-secondary);
                    cursor: pointer;
                    transition: all var(--transition-fast);
                }
                .tab-btn:hover {
                    background: var(--bg-tertiary);
                    color: var(--text-primary);
                }
                .tab-btn.active {
                    background: var(--primary-500);
                    color: white;
                }
                .stats-grid-sm {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
                    gap: var(--space-4);
                    margin-bottom: var(--space-6);
                }
                .stat-card-sm {
                    display: flex;
                    align-items: center;
                    gap: var(--space-3);
                    padding: var(--space-4);
                    background: var(--bg-secondary);
                    border-radius: var(--radius-lg);
                    border: 1px solid var(--border-color);
                }
                .stat-card-sm svg {
                    color: var(--text-muted);
                }
                .stat-card-sm.success svg {
                    color: var(--success-500);
                }
                .stat-value {
                    display: block;
                    font-size: var(--font-size-xl);
                    font-weight: var(--font-bold);
                    color: var(--text-primary);
                }
                .stat-label {
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                }
                .exam-name-cell {
                    display: flex;
                    flex-direction: column;
                }
                .time-text {
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                }
                .count-badge {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    min-width: 28px;
                    padding: var(--space-1) var(--space-2);
                    border-radius: var(--radius-full);
                    font-size: var(--font-size-xs);
                    font-weight: var(--font-semibold);
                }
                .count-badge.success {
                    background: var(--success-100);
                    color: var(--success-700);
                }
                .count-badge.warning {
                    background: var(--warning-100);
                    color: var(--warning-700);
                }
                .count-badge.info {
                    background: var(--info-100);
                    color: var(--info-700);
                }
                .count-badge.error {
                    background: var(--error-100);
                    color: var(--error-700);
                }
                .rate-badge {
                    display: inline-block;
                    padding: var(--space-1) var(--space-2);
                    border-radius: var(--radius-md);
                    font-size: var(--font-size-xs);
                    font-weight: var(--font-bold);
                }
                .rate-badge.success {
                    background: var(--success-100);
                    color: var(--success-700);
                }
                .rate-badge.warning {
                    background: var(--warning-100);
                    color: var(--warning-700);
                }
                .rate-badge.error {
                    background: var(--error-100);
                    color: var(--error-700);
                }
            `})]})}const j1=[{id:1,kode:"DPS",nama:"D4 Pengelolaan Pelabuhan dan Pelayaran Sungai"},{id:2,kode:"DTL",nama:"D4 Transportasi Laut"},{id:3,kode:"LLASDP",nama:"D3 LLASDP"},{id:4,kode:"DKP",nama:"D4 Kepelautan"}],y1=[{id:1,examName:"UTS Navigasi Sungai",room:"Ruang 1",date:"2026-01-04",time:"08:00 - 10:00",prodiId:1,pengawas:"Ir. Siti Rahayu",nip:"198501012010012001",attendance:{total:25,hadir:23,sakit:1,izin:1,alpha:0},incidents:"Tidak ada kejadian khusus selama ujian berlangsung.",notes:"Ujian berjalan dengan lancar dan tertib.",createdAt:"2026-01-04 10:15"},{id:2,examName:"Quiz Keselamatan Pelayaran",room:"Ruang 2",date:"2026-01-05",time:"10:00 - 11:30",prodiId:1,pengawas:"Drs. Bambang Sutrisno",nip:"197803012005011001",attendance:{total:28,hadir:26,sakit:0,izin:1,alpha:1},incidents:"1 mahasiswa terlambat 15 menit (Deni Pratama, NIM: 2024010004)",notes:"Mahasiswa yang terlambat tetap diizinkan mengikuti ujian dengan pengurangan waktu.",createdAt:"2026-01-05 11:45"},{id:3,examName:"UAS Teknik Perkapalan",room:"Lab Komputer 1",date:"2026-01-06",time:"08:00 - 10:00",prodiId:2,pengawas:"Ir. Siti Rahayu",nip:"198501012010012001",attendance:{total:22,hadir:22,sakit:0,izin:0,alpha:0},incidents:"Tidak ada kejadian khusus.",notes:"Semua peserta hadir tepat waktu. Ujian berjalan lancar.",createdAt:"2026-01-06 10:10"}];function N1(){const{user:r}=Le(),[c,u]=y.useState(""),[o,h]=y.useState(r?.prodiId||"all"),[m,x]=y.useState(""),[g,b]=y.useState(null),p=y1.filter(A=>{const v=r?.role==="superadmin"?o==="all"||A.prodiId===parseInt(o):A.prodiId===r?.prodiId,R=A.examName.toLowerCase().includes(c.toLowerCase())||A.pengawas.toLowerCase().includes(c.toLowerCase()),j=!m||A.date===m;return v&&R&&j}),z=()=>{let A=`Ujian,Ruang,Tanggal,Waktu,Pengawas,NIP,Total,Hadir,Sakit,Izin,Alpha,Kejadian,Catatan,Dibuat
`;p.forEach(j=>{A+=`"${j.examName}","${j.room}","${j.date}","${j.time}","${j.pengawas}","${j.nip}",${j.attendance.total},${j.attendance.hadir},${j.attendance.sakit},${j.attendance.izin},${j.attendance.alpha},"${j.incidents}","${j.notes}","${j.createdAt}"
`});const v=new Blob([A],{type:"text/csv;charset=utf-8;"}),R=document.createElement("a");R.href=URL.createObjectURL(v),R.download=`rekap_berita_acara_${m||"all"}_${new Date().toISOString().split("T")[0]}.csv`,R.click()},N=()=>{const A=window.open("","_blank");A.document.write(`
            <html>
            <head>
                <title>Rekap Berita Acara</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    h1 { text-align: center; margin-bottom: 10px; }
                    .subtitle { text-align: center; color: #666; margin-bottom: 20px; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
                    th { background: #f0f0f0; }
                </style>
            </head>
            <body>
                <h1>Rekap Berita Acara Ujian</h1>
                <p class="subtitle">Tanggal: ${m||"Semua Tanggal"} | Dicetak: ${new Date().toLocaleDateString("id-ID")}</p>
                <table>
                    <thead>
                        <tr>
                            <th>Ujian</th>
                            <th>Ruang</th>
                            <th>Tanggal</th>
                            <th>Waktu</th>
                            <th>Pengawas</th>
                            <th>Kejadian</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${p.map(v=>`
                            <tr>
                                <td>${v.examName}</td>
                                <td>${v.room}</td>
                                <td>${v.date}</td>
                                <td>${v.time}</td>
                                <td>${v.pengawas}</td>
                                <td>${v.incidents.includes("Tidak ada")?"Normal":v.incidents}</td>
                            </tr>
                        `).join("")}
                    </tbody>
                </table>
            </body>
            </html>
        `),A.document.close(),A.print()},S=A=>{const v=window.open("","_blank");v.document.write(`
            <html>
            <head>
                <title>Berita Acara - ${A.examName}</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 40px; }
                    h1 { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 10px; }
                    .section { margin-bottom: 20px; }
                    .section h3 { margin-bottom: 10px; color: #333; border-bottom: 1px solid #ccc; padding-bottom: 5px; }
                    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
                    .field { margin-bottom: 8px; }
                    .field .label { font-weight: bold; color: #666; }
                    .summary { display: flex; gap: 20px; margin: 20px 0; }
                    .summary-item { padding: 10px 20px; border: 1px solid #ccc; text-align: center; }
                    .summary-item .value { font-size: 20px; font-weight: bold; }
                    .summary-item .label { font-size: 11px; color: #666; }
                    .signature { margin-top: 40px; display: flex; justify-content: flex-end; }
                    .signature-box { text-align: center; width: 200px; }
                    .signature-line { border-bottom: 1px solid #333; margin: 60px 0 10px; }
                </style>
            </head>
            <body>
                <h1>BERITA ACARA UJIAN</h1>
                
                <div class="section">
                    <h3>Informasi Ujian</h3>
                    <div class="grid">
                        <div class="field"><span class="label">Nama Ujian:</span> ${A.examName}</div>
                        <div class="field"><span class="label">Ruang:</span> ${A.room}</div>
                        <div class="field"><span class="label">Tanggal:</span> ${A.date}</div>
                        <div class="field"><span class="label">Waktu:</span> ${A.time}</div>
                    </div>
                </div>

                <div class="section">
                    <h3>Rekapitulasi Kehadiran</h3>
                    <div class="summary">
                        <div class="summary-item"><div class="value">${A.attendance.total}</div><div class="label">Total Peserta</div></div>
                        <div class="summary-item"><div class="value">${A.attendance.hadir}</div><div class="label">Hadir</div></div>
                        <div class="summary-item"><div class="value">${A.attendance.sakit}</div><div class="label">Sakit</div></div>
                        <div class="summary-item"><div class="value">${A.attendance.izin}</div><div class="label">Izin</div></div>
                        <div class="summary-item"><div class="value">${A.attendance.alpha}</div><div class="label">Tanpa Keterangan</div></div>
                    </div>
                </div>

                <div class="section">
                    <h3>Catatan Kejadian</h3>
                    <p>${A.incidents}</p>
                </div>

                <div class="section">
                    <h3>Catatan Tambahan</h3>
                    <p>${A.notes}</p>
                </div>

                <div class="signature">
                    <div class="signature-box">
                        <p>Palembang, ${new Date(A.date).toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"})}</p>
                        <p>Pengawas Ujian,</p>
                        <div class="signature-line"></div>
                        <p><strong>${A.pengawas}</strong></p>
                        <p>NIP. ${A.nip}</p>
                    </div>
                </div>
            </body>
            </html>
        `),v.document.close(),v.print()};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Rekap Berita Acara"}),a.jsx("p",{className:"page-subtitle",children:"Data berita acara ujian dari pengawas yang tersinkronisasi"})]}),a.jsxs("div",{className:"header-actions",children:[a.jsxs("button",{className:"btn btn-secondary",onClick:z,children:[a.jsx(bs,{size:18}),"Export Excel"]}),a.jsxs("button",{className:"btn btn-primary",onClick:N,children:[a.jsx(da,{size:18}),"Cetak Semua"]})]})]}),a.jsx("div",{className:"card mb-4",children:a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"filters-row",children:[a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:18,className:"search-icon"}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Cari ujian atau pengawas...",value:c,onChange:A=>u(A.target.value)})]}),r?.role==="superadmin"&&a.jsxs("div",{className:"filter-group",children:[a.jsx(et,{size:16}),a.jsxs("select",{className:"form-input",value:o,onChange:A=>h(A.target.value),children:[a.jsx("option",{value:"all",children:"Semua Prodi"}),j1.map(A=>a.jsx("option",{value:A.id,children:A.kode},A.id))]})]}),a.jsxs("div",{className:"filter-group",children:[a.jsx(va,{size:16}),a.jsx("input",{type:"date",className:"form-input",value:m,onChange:A=>x(A.target.value)}),m&&a.jsx("button",{className:"btn btn-ghost btn-sm",onClick:()=>x(""),children:"Reset"})]})]})})}),a.jsx("div",{className:"card",children:a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"Ujian"}),a.jsx("th",{children:"Ruang"}),a.jsx("th",{children:"Tanggal"}),a.jsx("th",{children:"Pengawas"}),a.jsx("th",{children:"Kejadian"}),a.jsx("th",{children:"Dibuat"}),a.jsx("th",{children:"Aksi"})]})}),a.jsxs("tbody",{children:[p.map(A=>a.jsxs("tr",{children:[a.jsx("td",{children:a.jsxs("div",{className:"exam-name-cell",children:[a.jsx("span",{className:"font-medium",children:A.examName}),a.jsx("span",{className:"time-text",children:A.time})]})}),a.jsx("td",{children:A.room}),a.jsx("td",{children:A.date}),a.jsx("td",{children:A.pengawas}),a.jsx("td",{children:a.jsx("span",{className:`incident-badge ${A.incidents.includes("Tidak ada")?"normal":"warning"}`,children:A.incidents.includes("Tidak ada")?"Normal":"Ada Catatan"})}),a.jsx("td",{className:"text-muted",children:A.createdAt}),a.jsx("td",{children:a.jsxs("div",{className:"action-buttons",children:[a.jsx("button",{className:"btn btn-ghost btn-sm",onClick:()=>b(A),children:a.jsx(Fa,{size:14})}),a.jsx("button",{className:"btn btn-ghost btn-sm",onClick:()=>S(A),children:a.jsx(da,{size:14})})]})})]},A.id)),p.length===0&&a.jsx("tr",{children:a.jsx("td",{colSpan:7,className:"text-center text-muted",style:{padding:"var(--space-8)"},children:"Tidak ada data berita acara"})})]})]})})})}),g&&a.jsx("div",{className:"modal-overlay",onClick:()=>b(null),children:a.jsxs("div",{className:"modal modal-lg",onClick:A=>A.stopPropagation(),children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("h3",{children:"Berita Acara Ujian"}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:()=>b(null),children:"×"})]}),a.jsx("div",{className:"modal-body",children:a.jsxs("div",{className:"ba-detail",children:[a.jsxs("div",{className:"ba-section",children:[a.jsx("h4",{children:"Informasi Ujian"}),a.jsxs("div",{className:"ba-grid",children:[a.jsxs("div",{children:[a.jsx("strong",{children:"Nama Ujian:"})," ",g.examName]}),a.jsxs("div",{children:[a.jsx("strong",{children:"Ruang:"})," ",g.room]}),a.jsxs("div",{children:[a.jsx("strong",{children:"Tanggal:"})," ",g.date]}),a.jsxs("div",{children:[a.jsx("strong",{children:"Waktu:"})," ",g.time]})]})]}),a.jsxs("div",{className:"ba-section",children:[a.jsx("h4",{children:"Kehadiran"}),a.jsxs("div",{className:"ba-attendance",children:[a.jsxs("span",{children:["Total: ",a.jsx("strong",{children:g.attendance.total})]}),a.jsxs("span",{children:["Hadir: ",a.jsx("strong",{className:"success",children:g.attendance.hadir})]}),a.jsxs("span",{children:["Sakit: ",a.jsx("strong",{children:g.attendance.sakit})]}),a.jsxs("span",{children:["Izin: ",a.jsx("strong",{children:g.attendance.izin})]}),a.jsxs("span",{children:["Alpha: ",a.jsx("strong",{className:"error",children:g.attendance.alpha})]})]})]}),a.jsxs("div",{className:"ba-section",children:[a.jsx("h4",{children:"Catatan Kejadian"}),a.jsx("p",{children:g.incidents})]}),a.jsxs("div",{className:"ba-section",children:[a.jsx("h4",{children:"Catatan Tambahan"}),a.jsx("p",{children:g.notes})]}),a.jsxs("div",{className:"ba-section",children:[a.jsx("h4",{children:"Pengawas"}),a.jsx("p",{children:a.jsx("strong",{children:g.pengawas})}),a.jsxs("p",{className:"text-muted",children:["NIP: ",g.nip]})]})]})}),a.jsxs("div",{className:"modal-footer",children:[a.jsx("button",{className:"btn btn-ghost",onClick:()=>b(null),children:"Tutup"}),a.jsxs("button",{className:"btn btn-primary",onClick:()=>S(g),children:[a.jsx(da,{size:16}),"Cetak"]})]})]})})]}),a.jsx("style",{children:`
                .mb-4 {
                    margin-bottom: var(--space-4);
                }
                .header-actions {
                    display: flex;
                    gap: var(--space-3);
                }
                .action-buttons {
                    display: flex;
                    gap: var(--space-1);
                }
                .exam-name-cell {
                    display: flex;
                    flex-direction: column;
                }
                .time-text {
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                }
                .incident-badge {
                    display: inline-flex;
                    padding: var(--space-1) var(--space-2);
                    border-radius: var(--radius-md);
                    font-size: var(--font-size-xs);
                    font-weight: var(--font-medium);
                }
                .incident-badge.normal {
                    background: var(--success-100);
                    color: var(--success-700);
                }
                .incident-badge.warning {
                    background: var(--warning-100);
                    color: var(--warning-700);
                }
                .ba-detail {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-5);
                }
                .ba-section h4 {
                    margin: 0 0 var(--space-2);
                    color: var(--text-secondary);
                    font-size: var(--font-size-sm);
                }
                .ba-section p {
                    margin: 0;
                    line-height: 1.6;
                }
                .ba-grid {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: var(--space-2);
                }
                .ba-attendance {
                    display: flex;
                    gap: var(--space-4);
                    flex-wrap: wrap;
                }
                .ba-attendance .success { color: var(--success-600); }
                .ba-attendance .error { color: var(--error-600); }
            `})]})}const k1=[{label:"Total User",value:"156",icon:ra,color:"primary",trend:"+5"},{label:"Ujian Aktif",value:"3",icon:Ja,color:"accent",trend:"+1"},{label:"Selesai Hari Ini",value:"28",icon:We,color:"success",trend:"+8"},{label:"Perlu Perhatian",value:"2",icon:qa,color:"warning",trend:"-1"}],S1=[{id:1,name:"UTS Navigasi Sungai",date:"2026-01-08",time:"08:00 - 10:00",room:"Ruang 1",participants:25,status:"upcoming"},{id:2,name:"Quiz Keselamatan Pelayaran",date:"2026-01-08",time:"10:30 - 11:30",room:"Ruang 2",participants:28,status:"upcoming"},{id:3,name:"UAS Teknik Perkapalan",date:"2026-01-10",time:"08:00 - 10:00",room:"Lab Komputer",participants:22,status:"upcoming"},{id:4,name:"UTS Manajemen Transportasi",date:"2026-01-12",time:"13:00 - 15:00",room:"Ruang 1",participants:30,status:"upcoming"}],Ko=[{id:1,name:"UTS Navigasi Sungai",room:"Lab Komputer 1",startTime:"08:00",endTime:"10:00",participants:25,online:23,pengawas:"Ir. Siti Rahayu",status:"active"},{id:2,name:"Quiz Keselamatan Pelayaran",room:"Ruang 2",startTime:"08:00",endTime:"09:00",participants:28,online:28,pengawas:"Drs. Bambang S.",status:"active"}];function w1(){const{user:r}=Le(),c=jn(),u=o=>{const h=new Date,x=new Date(o)-h;return Math.ceil(x/(1e3*60*60*24))};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsx("div",{className:"page-header",children:a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Dashboard Admin Prodi"}),a.jsxs("p",{className:"page-subtitle",children:["Selamat datang, ",r?.name,"!"]})]})}),a.jsx("div",{className:"stats-grid",children:k1.map((o,h)=>a.jsxs("div",{className:`stat-card stat-${o.color}`,children:[a.jsx("div",{className:"stat-icon",children:a.jsx(o.icon,{size:24})}),a.jsxs("div",{className:"stat-content",children:[a.jsx("span",{className:"stat-value",children:o.value}),a.jsx("span",{className:"stat-label",children:o.label})]}),a.jsxs("div",{className:"stat-trend",children:[a.jsx(Bf,{size:14}),a.jsx("span",{children:o.trend})]})]},h))}),a.jsxs("div",{className:"dashboard-grid",children:[a.jsxs("div",{className:"card card-wide",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(va,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Jadwal Ujian"})]}),a.jsx("button",{className:"btn btn-primary btn-sm",onClick:()=>c("/admin-prodi/jadwal-ujian"),children:"Kelola Jadwal"})]}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"jadwal-list",children:S1.map(o=>{const h=u(o.date);return a.jsxs("div",{className:`jadwal-item ${h<=2?"urgent":h<=5?"soon":""}`,children:[a.jsxs("div",{className:"jadwal-date",children:[a.jsx("span",{className:"day",children:new Date(o.date).getDate()}),a.jsx("span",{className:"month",children:new Date(o.date).toLocaleDateString("id-ID",{month:"short"})})]}),a.jsxs("div",{className:"jadwal-info",children:[a.jsx("h4",{children:o.name}),a.jsxs("p",{children:[a.jsx(Ve,{size:12}),o.time," • ",o.room," • ",o.participants," peserta"]})]}),a.jsx("div",{className:"jadwal-countdown",children:h===0?a.jsx("span",{className:"today",children:"Hari Ini"}):h===1?a.jsx("span",{className:"tomorrow",children:"Besok"}):a.jsxs("span",{children:[h," hari lagi"]})}),a.jsx(vs,{size:18,className:"chevron"})]},o.id)})})})]}),a.jsxs("div",{className:"card card-wide",children:[a.jsx("div",{className:"card-header",children:a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(Ji,{size:20,className:"text-success"}),a.jsx("h3",{className:"font-semibold",children:"Ujian Sedang Berlangsung"}),a.jsxs("span",{className:"badge badge-success",children:[Ko.length," Aktif"]})]})}),a.jsx("div",{className:"card-body",children:Ko.length>0?a.jsx("div",{className:"exam-ongoing-list",children:Ko.map(o=>a.jsxs("div",{className:"exam-ongoing-item",children:[a.jsx("div",{className:"exam-ongoing-indicator"}),a.jsxs("div",{className:"exam-ongoing-info",children:[a.jsx("h4",{children:o.name}),a.jsxs("div",{className:"exam-ongoing-meta",children:[a.jsxs("span",{children:[a.jsx(Ve,{size:12})," ",o.startTime," - ",o.endTime]}),a.jsxs("span",{children:["• ",o.room]})]})]}),a.jsx("div",{className:"exam-ongoing-stats",children:a.jsxs("div",{className:"stat-item",children:[a.jsxs("span",{className:"stat-number",children:[o.online,"/",o.participants]}),a.jsx("span",{className:"stat-text",children:"Online"})]})}),a.jsxs("div",{className:"exam-ongoing-pengawas",children:[a.jsx(Fa,{size:14}),a.jsx("span",{children:o.pengawas})]}),a.jsx("button",{className:"btn btn-primary btn-sm",onClick:()=>c("/admin-prodi/monitor"),children:"Monitor"})]},o.id))}):a.jsxs("div",{className:"empty-state",children:[a.jsx(Ji,{size:32,className:"text-muted"}),a.jsx("p",{children:"Tidak ada ujian yang sedang berlangsung"})]})})]})]})]}),a.jsx("style",{children:`
                .jadwal-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-3);
                }
                .jadwal-item {
                    display: flex;
                    align-items: center;
                    gap: var(--space-4);
                    padding: var(--space-3) var(--space-4);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-lg);
                    border-left: 4px solid var(--border-color);
                    transition: all var(--transition-fast);
                    cursor: pointer;
                }
                .jadwal-item:hover {
                    background: var(--bg-secondary);
                }
                .jadwal-item.urgent {
                    border-left-color: var(--error-500);
                    background: var(--error-50);
                }
                .jadwal-item.soon {
                    border-left-color: var(--warning-500);
                    background: var(--warning-50);
                }
                .jadwal-date {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    min-width: 50px;
                    padding: var(--space-2);
                    background: var(--primary-100);
                    border-radius: var(--radius-md);
                }
                .jadwal-date .day {
                    font-size: var(--font-size-xl);
                    font-weight: var(--font-bold);
                    color: var(--primary-600);
                    line-height: 1;
                }
                .jadwal-date .month {
                    font-size: var(--font-size-xs);
                    color: var(--primary-500);
                    text-transform: uppercase;
                }
                .jadwal-info {
                    flex: 1;
                }
                .jadwal-info h4 {
                    margin: 0 0 var(--space-1);
                    font-size: var(--font-size-sm);
                }
                .jadwal-info p {
                    display: flex;
                    align-items: center;
                    gap: var(--space-1);
                    margin: 0;
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                }
                .jadwal-countdown {
                    font-size: var(--font-size-sm);
                    font-weight: var(--font-medium);
                    color: var(--text-secondary);
                }
                .jadwal-countdown .today {
                    color: var(--error-600);
                    font-weight: var(--font-bold);
                }
                .jadwal-countdown .tomorrow {
                    color: var(--warning-600);
                    font-weight: var(--font-bold);
                }
                .chevron {
                    color: var(--text-muted);
                }
                [data-theme="dark"] .jadwal-date {
                    background: rgba(99, 102, 241, 0.15);
                }
                [data-theme="dark"] .jadwal-item.urgent {
                    background: rgba(239, 68, 68, 0.1);
                }
                [data-theme="dark"] .jadwal-item.soon {
                    background: rgba(245, 158, 11, 0.1);
                }
                /* Exam Ongoing Styles */
                .exam-ongoing-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-4);
                }
                .exam-ongoing-item {
                    display: flex;
                    align-items: center;
                    gap: var(--space-4);
                    padding: var(--space-4);
                    background: linear-gradient(135deg, var(--success-50) 0%, var(--bg-tertiary) 100%);
                    border: 1px solid var(--success-200);
                    border-radius: var(--radius-lg);
                }
                [data-theme="dark"] .exam-ongoing-item {
                    background: linear-gradient(135deg, rgba(34, 197, 94, 0.1) 0%, var(--bg-tertiary) 100%);
                    border-color: rgba(34, 197, 94, 0.3);
                }
                .exam-ongoing-indicator {
                    width: 12px;
                    height: 12px;
                    background: var(--success-500);
                    border-radius: 50%;
                    animation: pulse 2s infinite;
                }
                @keyframes pulse {
                    0%, 100% { opacity: 1; transform: scale(1); }
                    50% { opacity: 0.5; transform: scale(1.1); }
                }
                .exam-ongoing-info {
                    flex: 1;
                }
                .exam-ongoing-info h4 {
                    margin: 0 0 var(--space-1);
                    font-weight: var(--font-semibold);
                }
                .exam-ongoing-meta {
                    display: flex;
                    gap: var(--space-2);
                    font-size: var(--font-size-sm);
                    color: var(--text-muted);
                }
                .exam-ongoing-meta span {
                    display: flex;
                    align-items: center;
                    gap: var(--space-1);
                }
                .exam-ongoing-stats {
                    text-align: center;
                }
                .exam-ongoing-stats .stat-number {
                    display: block;
                    font-size: var(--font-size-lg);
                    font-weight: var(--font-bold);
                    color: var(--success-600);
                }
                .exam-ongoing-stats .stat-text {
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                }
                .exam-ongoing-pengawas {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    padding: var(--space-2) var(--space-3);
                    background: var(--bg-secondary);
                    border-radius: var(--radius-md);
                    font-size: var(--font-size-sm);
                    color: var(--text-secondary);
                }
                .empty-state {
                    text-align: center;
                    padding: var(--space-8);
                    color: var(--text-muted);
                }
                .empty-state p {
                    margin-top: var(--space-2);
                }
            `})]})}const z1=()=>{const r=[],c=new Date().getFullYear();for(let u=c;u>=c-2;u--)r.push({value:`${u}/${u+1}-1`,label:`${u}/${u+1} Ganjil`}),r.push({value:`${u}/${u+1}-2`,label:`${u}/${u+1} Genap`});return r},T1=z1();function A1(){const{user:r}=Le(),[c,u]=y.useState(()=>{const g=`prodiSettings_${r?.prodiId||"default"}`,b=localStorage.getItem(g);if(b)try{return{kaprodiNama:"",kaprodiNip:"",tahunAjaran:"2025/2026-1",...JSON.parse(b)}}catch{return{kaprodiNama:"",kaprodiNip:"",tahunAjaran:"2025/2026-1"}}return{kaprodiNama:"",kaprodiNip:"",tahunAjaran:"2025/2026-1"}}),[o,h]=y.useState(null),m=(g,b)=>{u(p=>({...p,[g]:b}))},x=()=>{const g=`prodiSettings_${r?.prodiId||"default"}`;localStorage.setItem(g,JSON.stringify(c)),localStorage.setItem(`kaprodiInfo_${r?.prodiId||"default"}`,JSON.stringify({nama:c.kaprodiNama,nip:c.kaprodiNip})),localStorage.setItem(`tahunAjaran_${r?.prodiId||"default"}`,c.tahunAjaran),h("success"),setTimeout(()=>h(null),3e3)};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsx("div",{className:"page-header",children:a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Pengaturan Prodi"}),a.jsx("p",{className:"page-subtitle",children:"Konfigurasi data program studi dan tahun akademik"})]})}),a.jsxs("div",{className:"settings-grid",style:{display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(400px, 1fr))",gap:"1.5rem",marginBottom:"2rem"},children:[a.jsxs("div",{className:"card",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(va,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Tahun Akademik"})]}),a.jsx("span",{className:"badge badge-primary",children:c.tahunAjaran.replace("-1"," Ganjil").replace("-2"," Genap")})]}),a.jsxs("div",{className:"card-body",children:[a.jsx("p",{className:"text-sm text-muted mb-4",children:"Pilih tahun akademik aktif. Data ujian, nilai, dan kehadiran akan disimpan berdasarkan tahun akademik ini."}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Tahun Akademik Aktif"}),a.jsx("select",{className:"form-input",value:c.tahunAjaran,onChange:g=>m("tahunAjaran",g.target.value),children:T1.map(g=>a.jsx("option",{value:g.value,children:g.label},g.value))})]})]})]}),a.jsxs("div",{className:"card",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(ps,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Ka. Program Studi"})]}),a.jsx("span",{className:"text-muted text-sm",children:"Untuk Tanda Tangan"})]}),a.jsxs("div",{className:"card-body",children:[a.jsx("p",{className:"text-sm text-muted mb-4",children:"Data Ka. Prodi akan otomatis muncul pada printout rekap nilai, kehadiran, dan berita acara."}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Nama Ka. Prodi"}),a.jsx("input",{type:"text",className:"form-input",value:c.kaprodiNama,onChange:g=>m("kaprodiNama",g.target.value),placeholder:"Dr. Nama Lengkap, M.T."})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"NIP"}),a.jsx("input",{type:"text",className:"form-input",value:c.kaprodiNip,onChange:g=>m("kaprodiNip",g.target.value),placeholder:"197012345678901234"})]})]})]})]}),a.jsx("div",{style:{display:"flex",justifyContent:"flex-end",paddingTop:"1rem",borderTop:"1px solid var(--border-color)"},children:a.jsxs("button",{className:"btn btn-primary",onClick:x,children:[a.jsx(at,{size:18}),"Simpan Pengaturan"]})}),o&&a.jsxs("div",{style:{position:"fixed",bottom:"2rem",right:"2rem",padding:"1rem 1.5rem",borderRadius:"0.75rem",display:"flex",alignItems:"center",gap:"0.75rem",color:"white",fontWeight:500,boxShadow:"0 4px 20px rgba(0,0,0,0.2)",animation:"slideIn 0.3s ease",zIndex:1e3,background:"var(--success-500)"},children:[a.jsx(il,{size:18}),"Pengaturan berhasil disimpan!"]})]}),a.jsx("style",{children:`
                @keyframes slideIn {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
            `})]})}const Vo=[{id:1,kode:"NAV101",nama:"Navigasi Sungai"},{id:2,kode:"KSL101",nama:"Keselamatan Pelayaran"},{id:3,kode:"PPL101",nama:"Pengelolaan Pelabuhan"},{id:4,kode:"MAN101",nama:"Manajemen Transportasi"}],Jp=["Ruang 1","Ruang 2","Ruang 3","Lab Komputer 1","Lab Komputer 2"],Zp=[{id:1,kode:"DPS",nama:"D4 Pengelolaan Pelabuhan dan Pelayaran Sungai"},{id:2,kode:"DTL",nama:"D4 Transportasi Laut"},{id:3,kode:"LLASDP",nama:"D3 LLASDP"},{id:4,kode:"DKP",nama:"D4 Kepelautan"}],Jo=[{id:1,nama:"1A",angkatan:2024},{id:2,nama:"1B",angkatan:2024},{id:3,nama:"2A",angkatan:2023}],C1=()=>{const r=[],c=new Date().getFullYear();for(let u=c;u>=c-2;u--)r.push({value:`${u}/${u+1} Ganjil`,label:`${u}/${u+1} Ganjil`}),r.push({value:`${u}/${u+1} Genap`,label:`${u}/${u+1} Genap`});return r},Wp=C1(),D1=[{id:1,matkulId:1,kelasId:1,prodiId:1,tipeUjian:"UTS",tahunAkademik:"2025/2026 Ganjil",tanggal:"2026-01-08",waktuMulai:"08:00",waktuSelesai:"10:00",ruang:"Ruang 1"},{id:2,matkulId:2,kelasId:2,prodiId:1,tipeUjian:"Quiz",tahunAkademik:"2025/2026 Ganjil",tanggal:"2026-01-08",waktuMulai:"10:30",waktuSelesai:"11:30",ruang:"Ruang 2"},{id:3,matkulId:3,kelasId:1,prodiId:2,tipeUjian:"UAS",tahunAkademik:"2025/2026 Ganjil",tanggal:"2026-01-10",waktuMulai:"08:00",waktuSelesai:"10:00",ruang:"Lab Komputer 1"},{id:4,matkulId:4,kelasId:3,prodiId:3,tipeUjian:"UTS",tahunAkademik:"2025/2026 Ganjil",tanggal:"2026-01-12",waktuMulai:"13:00",waktuSelesai:"15:00",ruang:"Ruang 1"},{id:5,matkulId:1,kelasId:1,prodiId:4,tipeUjian:"UAS",tahunAkademik:"2025/2026 Ganjil",tanggal:"2026-01-15",waktuMulai:"08:00",waktuSelesai:"10:00",ruang:"Ruang 3"}];function _1({isOpen:r,onClose:c,jadwal:u,onSave:o}){const[h,m]=y.useState(u||{matkulId:Vo[0]?.id||"",kelasId:Jo[0]?.id||"",tipeUjian:"UTS",tahunAkademik:Wp[0]?.value||"2025/2026 Ganjil",tanggal:"",waktuMulai:"08:00",waktuSelesai:"10:00",ruang:Jp[0]}),x=g=>{g.preventDefault(),o({...h,matkulId:Number(h.matkulId),kelasId:Number(h.kelasId)}),c()};return r?a.jsx("div",{className:"modal-overlay",onClick:c,children:a.jsxs("div",{className:"modal",onClick:g=>g.stopPropagation(),children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("h3",{children:u?"Edit Jadwal Ujian":"Tambah Jadwal Ujian"}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:c,children:a.jsx(Je,{size:20})})]}),a.jsxs("form",{onSubmit:x,children:[a.jsxs("div",{className:"modal-body",children:[a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Mata Kuliah"}),a.jsx("select",{className:"form-input",value:h.matkulId,onChange:g=>m({...h,matkulId:g.target.value}),required:!0,children:Vo.map(g=>a.jsxs("option",{value:g.id,children:[g.kode," - ",g.nama]},g.id))})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Kelas"}),a.jsx("select",{className:"form-input",value:h.kelasId,onChange:g=>m({...h,kelasId:g.target.value}),required:!0,children:Jo.map(g=>a.jsxs("option",{value:g.id,children:[g.nama," (",g.angkatan,")"]},g.id))})]})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Tipe Ujian"}),a.jsxs("select",{className:"form-input",value:h.tipeUjian,onChange:g=>m({...h,tipeUjian:g.target.value}),required:!0,children:[a.jsx("option",{value:"Quiz",children:"Quiz"}),a.jsx("option",{value:"UTS",children:"UTS"}),a.jsx("option",{value:"UAS",children:"UAS"})]})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Tahun Akademik"}),a.jsx("select",{className:"form-input",value:h.tahunAkademik,onChange:g=>m({...h,tahunAkademik:g.target.value}),required:!0,children:Wp.map(g=>a.jsx("option",{value:g.value,children:g.label},g.value))})]})]}),a.jsx("div",{className:"form-row",children:a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Ruang"}),a.jsx("select",{className:"form-input",value:h.ruang,onChange:g=>m({...h,ruang:g.target.value}),required:!0,children:Jp.map(g=>a.jsx("option",{value:g,children:g},g))})]})}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Tanggal"}),a.jsx("input",{type:"date",className:"form-input",value:h.tanggal,onChange:g=>m({...h,tanggal:g.target.value}),required:!0})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Waktu Mulai"}),a.jsx("input",{type:"time",className:"form-input",value:h.waktuMulai,onChange:g=>m({...h,waktuMulai:g.target.value}),required:!0})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Waktu Selesai"}),a.jsx("input",{type:"time",className:"form-input",value:h.waktuSelesai,onChange:g=>m({...h,waktuSelesai:g.target.value}),required:!0})]})]})]}),a.jsxs("div",{className:"modal-footer",children:[a.jsx("button",{type:"button",className:"btn btn-ghost",onClick:c,children:"Batal"}),a.jsxs("button",{type:"submit",className:"btn btn-primary",children:[a.jsx(at,{size:16}),"Simpan"]})]})]})]})}):null}function Fp(){const{user:r}=Le(),[c,u]=y.useState(D1),[o,h]=y.useState(!1),[m,x]=y.useState(null),[g,b]=y.useState(""),[p,z]=y.useState(r?.role==="superadmin"?"all":r?.prodiId||"all"),N=r?.role==="superadmin",S=c.filter(U=>{const L=!g||U.tanggal===g,K=N?p==="all"||U.prodiId===parseInt(p):U.prodiId===r?.prodiId;return L&&K}).sort((U,L)=>U.tanggal!==L.tanggal?U.tanggal.localeCompare(L.tanggal):U.waktuMulai.localeCompare(L.waktuMulai)),A=()=>{x(null),h(!0)},v=U=>{x(U),h(!0)},R=U=>{u(m?c.map(L=>L.id===m.id?{...U,id:m.id}:L):[...c,{...U,id:Date.now()}])},j=U=>{confirm("Hapus jadwal ujian ini?")&&u(c.filter(L=>L.id!==U))},w=U=>{const L=Vo.find(K=>K.id===U);return L?`${L.kode} - ${L.nama}`:"-"},C=U=>{const L=Jo.find(K=>K.id===U);return L?`Kelas ${L.nama}`:"-"},k=U=>{const L=Zp.find(K=>K.id===U);return L?L.kode:"-"},Q=U=>{switch(U){case"UAS":return"error";case"UTS":return"warning";default:return"info"}},$=S.reduce((U,L)=>(U[L.tanggal]||(U[L.tanggal]=[]),U[L.tanggal].push(L),U),{}),_=()=>{const U=`
            <html>
            <head>
                <title>Jadwal Ujian</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    h1 { text-align: center; font-size: 18px; margin-bottom: 5px; }
                    h2 { text-align: center; font-size: 14px; color: #666; margin-bottom: 20px; }
                    .date-section { margin-bottom: 20px; }
                    .date-header { font-weight: bold; background: #f0f0f0; padding: 8px; margin-bottom: 10px; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background: #f5f5f5; }
                </style>
            </head>
            <body>
                <h1>JADWAL UJIAN</h1>
                <h2>POLTEKTRANS SDP PALEMBANG</h2>
                ${Object.keys($).sort().map(K=>`
                    <div class="date-section">
                        <div class="date-header">${new Date(K).toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}</div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Waktu</th>
                                    <th>Mata Kuliah</th>
                                    <th>Kelas</th>
                                    <th>Tipe</th>
                                    <th>Ruang</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${$[K].map(V=>`
                                    <tr>
                                        <td>${V.waktuMulai} - ${V.waktuSelesai}</td>
                                        <td>${w(V.matkulId)}</td>
                                        <td>${C(V.kelasId)}</td>
                                        <td>${V.tipeUjian}</td>
                                        <td>${V.ruang}</td>
                                    </tr>
                                `).join("")}
                            </tbody>
                        </table>
                    </div>
                `).join("")}
            </body>
            </html>
        `,L=window.open("","_blank");L.document.write(U),L.document.close(),L.print()};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Jadwal Ujian"}),a.jsx("p",{className:"page-subtitle",children:N?"Lihat jadwal ujian dari seluruh program studi":"Kelola jadwal ujian untuk program studi Anda"})]}),a.jsxs("div",{className:"header-actions",children:[a.jsxs("button",{className:"btn btn-outline",onClick:_,children:[a.jsx(da,{size:18}),"Cetak"]}),!N&&a.jsxs("button",{className:"btn btn-primary",onClick:A,children:[a.jsx(Jt,{size:18}),"Tambah Jadwal"]})]})]}),a.jsxs("div",{className:"mini-stats",children:[a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:c.length}),a.jsx("span",{className:"mini-stat-label",children:"Total Jadwal"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:c.filter(U=>U.tipeUjian==="UTS").length}),a.jsx("span",{className:"mini-stat-label",children:"UTS"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:c.filter(U=>U.tipeUjian==="UAS").length}),a.jsx("span",{className:"mini-stat-label",children:"UAS"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:c.filter(U=>U.tipeUjian==="Quiz").length}),a.jsx("span",{className:"mini-stat-label",children:"Quiz"})]})]}),a.jsx("div",{className:"card mb-4",children:a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"filter-group",style:{flexWrap:"wrap",gap:"1rem"},children:[a.jsx(et,{size:16}),N&&a.jsxs(a.Fragment,{children:[a.jsx("span",{children:"Program Studi:"}),a.jsxs("select",{className:"form-input",value:p,onChange:U=>z(U.target.value),style:{width:"auto",minWidth:"200px"},children:[a.jsx("option",{value:"all",children:"Semua Prodi"}),Zp.map(U=>a.jsxs("option",{value:U.id,children:[U.kode," - ",U.nama]},U.id))]})]}),a.jsx("span",{children:"Tanggal:"}),a.jsx("input",{type:"date",className:"form-input",value:g,onChange:U=>b(U.target.value),style:{width:"auto"}}),(g||N&&p!=="all")&&a.jsx("button",{className:"btn btn-ghost btn-sm",onClick:()=>{b(""),z("all")},children:"Reset Filter"})]})})}),a.jsxs("div",{className:"jadwal-groups",children:[Object.keys($).sort().map(U=>a.jsxs("div",{className:"card mb-4",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"date-header",children:[a.jsx(va,{size:18}),a.jsx("span",{children:new Date(U).toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"})})]}),a.jsxs("span",{className:"text-muted",children:[$[U].length," ujian"]})]}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"Waktu"}),a.jsx("th",{children:"Mata Kuliah"}),a.jsx("th",{children:"Kelas"}),N&&a.jsx("th",{children:"Prodi"}),a.jsx("th",{children:"Tipe"}),a.jsx("th",{children:"Ruang"}),!N&&a.jsx("th",{children:"Aksi"})]})}),a.jsx("tbody",{children:$[U].map(L=>a.jsxs("tr",{children:[a.jsx("td",{children:a.jsxs("div",{className:"time-cell",children:[a.jsx(Ve,{size:14}),a.jsxs("span",{children:[L.waktuMulai," - ",L.waktuSelesai]})]})}),a.jsx("td",{className:"font-medium",children:w(L.matkulId)}),a.jsx("td",{children:C(L.kelasId)}),N&&a.jsx("td",{children:a.jsx("span",{className:"badge badge-primary",children:k(L.prodiId)})}),a.jsx("td",{children:a.jsx("span",{className:`badge badge-${Q(L.tipeUjian)}`,children:L.tipeUjian})}),a.jsx("td",{children:a.jsxs("div",{className:"room-cell",children:[a.jsx(cd,{size:14}),L.ruang]})}),!N&&a.jsx("td",{children:a.jsxs("div",{className:"flex gap-2",children:[a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm",onClick:()=>v(L),children:a.jsx(kt,{size:14})}),a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm text-error",onClick:()=>j(L.id),children:a.jsx(dl,{size:14})})]})})]},L.id))})]})})})]},U)),Object.keys($).length===0&&a.jsxs("div",{className:"empty-state",children:[a.jsx(va,{size:48}),a.jsx("h3",{children:"Tidak ada jadwal"}),a.jsx("p",{children:"Belum ada jadwal ujian yang dibuat"}),a.jsxs("button",{className:"btn btn-primary",onClick:A,children:[a.jsx(Jt,{size:16}),"Tambah Jadwal"]})]})]}),a.jsx(_1,{isOpen:o,onClose:()=>h(!1),jadwal:m,onSave:R})]}),a.jsx("style",{children:`
                .mb-4 {
                    margin-bottom: var(--space-4);
                }
                .filter-group {
                    display: flex;
                    align-items: center;
                    gap: var(--space-3);
                }
                .date-header {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    font-weight: var(--font-semibold);
                }
                .time-cell, .room-cell {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                }
                .time-cell {
                    color: var(--primary-600);
                    font-weight: var(--font-medium);
                }
                .room-cell {
                    color: var(--text-secondary);
                }
                .empty-state {
                    text-align: center;
                    padding: var(--space-12);
                    color: var(--text-muted);
                }
                .empty-state svg {
                    margin-bottom: var(--space-4);
                    opacity: 0.5;
                }
                .empty-state h3 {
                    margin-bottom: var(--space-2);
                    color: var(--text-secondary);
                }
                .empty-state p {
                    margin-bottom: var(--space-4);
                }
                .text-error {
                    color: var(--error-500);
                }
                .form-row {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: var(--space-4);
                }
            `})]})}const M1=[{label:"Total Soal",value:"156",icon:xs,color:"primary"},{label:"Ujian Selesai",value:"5",icon:Ja,color:"accent"},{label:"Peserta",value:"124",icon:ra,color:"success"},{label:"Perlu Koreksi",value:"28",icon:Ve,color:"warning"}],E1=[{id:1,examName:"UTS Navigasi Sungai",kelas:"1A",deadline:"2026-01-10",daysLeft:4,pending:10},{id:2,examName:"Quiz Keselamatan",kelas:"1B",deadline:"2026-01-08",daysLeft:2,pending:5},{id:3,examName:"UAS Teknik Perkapalan",kelas:"2A",deadline:"2026-01-12",daysLeft:6,pending:22}],R1=[{id:1,nama:"Navigasi Sungai",kelas:"1A",totalSoal:45},{id:2,nama:"Keselamatan Pelayaran",kelas:"1B",totalSoal:32},{id:3,nama:"Teknik Perkapalan",kelas:"2A",totalSoal:28}];function U1(){const{user:r}=Le(),c=jn(),u=o=>o<=2?"urgent":o<=4?"warning":"normal";return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsx("h1",{className:"page-title",children:"Dashboard Dosen"}),a.jsxs("p",{className:"page-subtitle",children:["Selamat datang, ",r?.name,"!"]})]}),a.jsx("div",{className:"stats-grid",children:M1.map((o,h)=>a.jsxs("div",{className:`stat-card stat-${o.color}`,children:[a.jsx("div",{className:"stat-icon",children:a.jsx(o.icon,{size:24})}),a.jsxs("div",{className:"stat-content",children:[a.jsx("span",{className:"stat-value",children:o.value}),a.jsx("span",{className:"stat-label",children:o.label})]})]},h))}),a.jsxs("div",{className:"dashboard-grid",children:[a.jsxs("div",{className:"card card-wide",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(qa,{size:20,className:"text-warning"}),a.jsx("h3",{className:"font-semibold",children:"Deadline Koreksi Ujian"})]}),a.jsx("button",{className:"btn btn-primary btn-sm",onClick:()=>c("/dosen/koreksi"),children:"Koreksi Sekarang"})]}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"deadline-list",children:E1.map(o=>a.jsxs("div",{className:`deadline-item ${u(o.daysLeft)}`,onClick:()=>c("/dosen/koreksi"),children:[a.jsxs("div",{className:"deadline-info",children:[a.jsx("h4",{children:o.examName}),a.jsxs("p",{children:["Kelas ",o.kelas," • ",o.pending," jawaban pending"]})]}),a.jsxs("div",{className:"deadline-meta",children:[a.jsxs("div",{className:"deadline-date",children:[a.jsx(Ve,{size:14}),o.daysLeft<=0?a.jsx("span",{className:"overdue",children:"Terlambat!"}):o.daysLeft===1?a.jsx("span",{children:"Besok!"}):a.jsxs("span",{children:[o.daysLeft," hari lagi"]})]}),a.jsx("span",{className:"text-muted",children:o.deadline})]}),a.jsx(vs,{size:18,className:"chevron"})]},o.id))})})]}),a.jsxs("div",{className:"card",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(xs,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Mata Kuliah"})]}),a.jsx("button",{className:"btn btn-ghost btn-sm",onClick:()=>c("/dosen/buat-soal"),children:"Kelola Soal"})]}),a.jsxs("div",{className:"card-body",children:[a.jsx("div",{className:"matkul-list",children:R1.map(o=>a.jsxs("div",{className:"matkul-item",children:[a.jsxs("div",{className:"matkul-info",children:[a.jsx("span",{className:"matkul-name",children:o.nama}),a.jsxs("span",{className:"matkul-kelas",children:["Kelas ",o.kelas]})]}),a.jsxs("span",{className:"matkul-soal",children:[o.totalSoal," soal"]})]},o.id))}),a.jsxs("button",{className:"btn btn-outline",style:{width:"100%",marginTop:"var(--space-4)"},onClick:()=>c("/dosen/buat-soal"),children:[a.jsx(Cp,{size:16}),"Tambah Soal"]})]})]}),a.jsxs("div",{className:"card",children:[a.jsx("div",{className:"card-header",children:a.jsx("h3",{className:"font-semibold",children:"Aksi Cepat"})}),a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"quick-actions",children:[a.jsxs("button",{className:"btn btn-primary",onClick:()=>c("/dosen/buat-soal"),children:[a.jsx(Cp,{size:18}),"Buat Soal Baru"]}),a.jsxs("button",{className:"btn btn-secondary",onClick:()=>c("/dosen/koreksi"),children:[a.jsx(We,{size:18}),"Koreksi Jawaban"]}),a.jsxs("button",{className:"btn btn-outline",onClick:()=>c("/dosen/nilai-akhir"),children:[a.jsx(Vt,{size:18}),"Input Nilai"]})]})})]})]})]}),a.jsx("style",{children:`
                .deadline-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-3);
                }
                .deadline-item {
                    display: flex;
                    align-items: center;
                    gap: var(--space-4);
                    padding: var(--space-4);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-lg);
                    border-left: 4px solid var(--border-color);
                    cursor: pointer;
                    transition: all var(--transition-fast);
                }
                .deadline-item:hover {
                    background: var(--bg-secondary);
                }
                .deadline-item.urgent {
                    border-left-color: var(--error-500);
                    background: var(--error-50);
                }
                .deadline-item.warning {
                    border-left-color: var(--warning-500);
                    background: var(--warning-50);
                }
                .deadline-item.normal {
                    border-left-color: var(--success-500);
                }
                .deadline-info {
                    flex: 1;
                }
                .deadline-info h4 {
                    margin: 0 0 var(--space-1);
                    font-size: var(--font-size-sm);
                }
                .deadline-info p {
                    margin: 0;
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                }
                .deadline-meta {
                    text-align: right;
                }
                .deadline-date {
                    display: flex;
                    align-items: center;
                    gap: var(--space-1);
                    font-weight: var(--font-semibold);
                    margin-bottom: var(--space-1);
                }
                .deadline-item.urgent .deadline-date {
                    color: var(--error-600);
                }
                .deadline-item.warning .deadline-date {
                    color: var(--warning-600);
                }
                .deadline-date .overdue {
                    color: var(--error-600);
                }
                .chevron {
                    color: var(--text-muted);
                }
                .matkul-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-3);
                }
                .matkul-item {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: var(--space-3);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-lg);
                }
                .matkul-info {
                    display: flex;
                    flex-direction: column;
                }
                .matkul-name {
                    font-size: var(--font-size-sm);
                    font-weight: var(--font-medium);
                    color: var(--text-primary);
                }
                .matkul-kelas {
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                }
                .matkul-soal {
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                }
            `})]})}const cs=[{id:1,nama:"Navigasi Sungai",prodiId:1,kelasId:1},{id:2,nama:"Keselamatan Pelayaran",prodiId:1,kelasId:2},{id:3,nama:"Teknik Perkapalan",prodiId:2,kelasId:3}],L1=[{id:1,text:"Apa yang dimaksud dengan navigasi sungai?",type:"pilihan_ganda",matkulId:1,points:20,image:null,options:[{text:"Navigasi di laut",image:null},{text:"Navigasi di sungai dan perairan darat",image:null},{text:"Navigasi di udara",image:null},{text:"Navigasi di darat",image:null}],correctAnswer:1},{id:2,text:"Jelaskan prosedur keselamatan dasar saat berlayar di perairan sungai.",type:"essay",matkulId:1,points:30,image:null},{id:3,text:"Kapal feri termasuk jenis kapal penumpang.",type:"benar_salah",matkulId:1,points:10,image:null,correctAnswer:!0},{id:4,text:"Cocokkan istilah berikut dengan definisinya:",type:"mencocokan",matkulId:1,points:40,image:null,pairs:[{left:"Haluan",right:"Bagian depan kapal"},{left:"Buritan",right:"Bagian belakang kapal"},{left:"Lambung",right:"Badan kapal"},{left:"Geladak",right:"Lantai kapal"}],examType:"uts"}];function O1({isOpen:r,onClose:c,onSelectQuestions:u}){const[o,h]=y.useState([]),[m,x]=y.useState("all"),g=[{id:101,text:"Apa fungsi utama rambu navigasi?",type:"pilihan_ganda",examType:"uts",points:10},{id:102,text:"Jelaskan prosedur darurat saat kapal kandas.",type:"essay",examType:"uas",points:20},{id:103,text:"Kapal tongkang dapat berlayar di laut lepas.",type:"benar_salah",examType:"uts",points:10},{id:104,text:"Sebutkan 5 alat keselamatan wajib di kapal.",type:"essay",examType:"uas",points:25}],b=g.filter(N=>m==="all"||N.examType===m),p=N=>{h(S=>S.includes(N)?S.filter(A=>A!==N):[...S,N])},z=()=>{const N=g.filter(S=>o.includes(S.id));u(N),h([]),c()};return r?a.jsx("div",{className:"modal-overlay",onClick:c,children:a.jsxs("div",{className:"modal modal-lg",onClick:N=>N.stopPropagation(),children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("h3",{children:"Ambil dari Bank Soal"}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:c,children:a.jsx(Je,{size:20})})]}),a.jsxs("div",{className:"modal-body",children:[a.jsx("div",{className:"bank-soal-filters",children:a.jsxs("select",{className:"form-input",value:m,onChange:N=>x(N.target.value),children:[a.jsx("option",{value:"all",children:"Semua Tipe"}),a.jsx("option",{value:"uts",children:"UTS"}),a.jsx("option",{value:"uas",children:"UAS"})]})}),a.jsx("div",{className:"bank-soal-list",children:b.map(N=>a.jsxs("div",{className:`bank-soal-item ${o.includes(N.id)?"selected":""}`,onClick:()=>p(N.id),children:[a.jsx("div",{className:"bank-soal-check",children:o.includes(N.id)?a.jsx(We,{size:18}):a.jsx(Uf,{size:18})}),a.jsxs("div",{className:"bank-soal-content",children:[a.jsx("p",{children:N.text}),a.jsxs("div",{className:"bank-soal-meta",children:[a.jsx("span",{className:"badge badge-primary",children:N.examType.toUpperCase()}),a.jsx("span",{className:"badge badge-outline",children:N.type}),a.jsxs("span",{children:[N.points," poin"]})]})]})]},N.id))})]}),a.jsxs("div",{className:"modal-footer",children:[a.jsxs("span",{children:[o.length," soal dipilih"]}),a.jsxs("div",{children:[a.jsx("button",{className:"btn btn-ghost",onClick:c,children:"Batal"}),a.jsxs("button",{className:"btn btn-primary",onClick:z,disabled:o.length===0,children:[a.jsx(rd,{size:16}),"Import Soal"]})]})]})]})}):null}function H1({isOpen:r,onClose:c,question:u,onSave:o,matkul:h,currentExamType:m}){const[x,g]=y.useState(u||{text:"",type:"pilihan_ganda",matkulId:h[0]?.id||1,points:10,image:null,options:[{text:"",image:null},{text:"",image:null},{text:"",image:null},{text:"",image:null}],correctAnswer:0,pairs:[{left:"",right:""},{left:"",right:""}],examType:m||"uts"}),b=y.useRef(null),p=(R,j,w=null)=>{const C=R.target.files[0];if(C){const k=new FileReader;k.onload=Q=>{if(j==="question")g({...x,image:Q.target.result});else if(j==="option"&&w!==null){const $=[...x.options];$[w]={...$[w],image:Q.target.result},g({...x,options:$})}},k.readAsDataURL(C)}},z=(R,j,w)=>{const C=[...x.options];C[R]={...C[R],[j]:w},g({...x,options:C})},N=(R,j,w)=>{const C=[...x.pairs];C[R]={...C[R],[j]:w},g({...x,pairs:C})},S=()=>{g({...x,pairs:[...x.pairs,{left:"",right:""}]})},A=R=>{const j=x.pairs.filter((w,C)=>C!==R);g({...x,pairs:j})},v=R=>{R.preventDefault(),o(x),c()};return r?a.jsx("div",{className:"modal-overlay",onClick:c,children:a.jsxs("div",{className:"modal modal-lg",onClick:R=>R.stopPropagation(),children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("h3",{children:u?"Edit Soal":"Tambah Soal Baru"}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:c,children:a.jsx(Je,{size:20})})]}),a.jsxs("form",{onSubmit:v,children:[a.jsxs("div",{className:"modal-body",children:[a.jsxs("div",{className:"form-row form-row-2",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Mata Kuliah"}),a.jsx("select",{className:"form-input",value:x.matkulId,onChange:R=>g({...x,matkulId:parseInt(R.target.value)}),children:h.map(R=>a.jsx("option",{value:R.id,children:R.nama},R.id))})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Bobot Nilai"}),a.jsx("input",{type:"number",className:"form-input",value:x.points,onChange:R=>g({...x,points:parseInt(R.target.value)}),min:1,max:100})]})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Tipe Soal"}),a.jsx("div",{className:"type-selector",children:[{value:"pilihan_ganda",label:"Pilihan Ganda"},{value:"essay",label:"Essay"},{value:"benar_salah",label:"Benar/Salah"},{value:"mencocokan",label:"Mencocokan"}].map(R=>a.jsx("button",{type:"button",className:`type-btn ${x.type===R.value?"active":""}`,onClick:()=>g({...x,type:R.value}),children:R.label},R.value))})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Pertanyaan"}),a.jsx("textarea",{className:"form-input form-textarea",rows:3,value:x.text,onChange:R=>g({...x,text:R.target.value}),placeholder:"Tuliskan pertanyaan...",required:!0})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Gambar Soal (Opsional)"}),a.jsxs("div",{className:"image-upload-area",children:[x.image?a.jsxs("div",{className:"image-preview",children:[a.jsx("img",{src:x.image,alt:"Preview"}),a.jsx("button",{type:"button",className:"remove-image",onClick:()=>g({...x,image:null}),children:a.jsx(Je,{size:16})})]}):a.jsxs("button",{type:"button",className:"btn btn-outline",onClick:()=>b.current?.click(),children:[a.jsx(Xo,{size:18}),"Upload Gambar"]}),a.jsx("input",{type:"file",ref:b,accept:"image/*",style:{display:"none"},onChange:R=>p(R,"question")})]})]}),x.type==="pilihan_ganda"&&a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Pilihan Jawaban"}),a.jsx("div",{className:"options-list",children:x.options.map((R,j)=>a.jsxs("div",{className:"option-row-extended",children:[a.jsx("button",{type:"button",className:`option-radio ${x.correctAnswer===j?"selected":""}`,onClick:()=>g({...x,correctAnswer:j}),children:x.correctAnswer===j?a.jsx(We,{size:18}):a.jsx(Uf,{size:18})}),a.jsxs("div",{className:"option-content",children:[a.jsx("input",{type:"text",className:"form-input",value:R.text,onChange:w=>z(j,"text",w.target.value),placeholder:`Pilihan ${String.fromCharCode(65+j)}`}),R.image?a.jsxs("div",{className:"option-image-preview",children:[a.jsx("img",{src:R.image,alt:`Option ${j}`}),a.jsx("button",{type:"button",className:"remove-image-sm",onClick:()=>z(j,"image",null),children:a.jsx(Je,{size:12})})]}):a.jsx("button",{type:"button",className:"btn btn-ghost btn-sm",onClick:()=>{const w=document.createElement("input");w.type="file",w.accept="image/*",w.onchange=C=>p(C,"option",j),w.click()},children:a.jsx(Xo,{size:14})})]})]},j))}),a.jsx("p",{className:"form-hint",children:"Klik lingkaran untuk menandai jawaban benar"})]}),x.type==="benar_salah"&&a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Jawaban Benar"}),a.jsxs("div",{className:"radio-group",children:[a.jsxs("label",{className:"radio-label",children:[a.jsx("input",{type:"radio",name:"correctAnswer",checked:x.correctAnswer===!0,onChange:()=>g({...x,correctAnswer:!0})}),a.jsx("span",{children:"Benar"})]}),a.jsxs("label",{className:"radio-label",children:[a.jsx("input",{type:"radio",name:"correctAnswer",checked:x.correctAnswer===!1,onChange:()=>g({...x,correctAnswer:!1})}),a.jsx("span",{children:"Salah"})]})]})]}),x.type==="mencocokan"&&a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Pasangan (Kiri - Kanan)"}),a.jsx("div",{className:"matching-list",children:x.pairs.map((R,j)=>a.jsxs("div",{className:"matching-row",children:[a.jsx("input",{type:"text",className:"form-input",value:R.left,onChange:w=>N(j,"left",w.target.value),placeholder:"Item kiri"}),a.jsx(sd,{size:18,className:"matching-arrow"}),a.jsx("input",{type:"text",className:"form-input",value:R.right,onChange:w=>N(j,"right",w.target.value),placeholder:"Item kanan"}),x.pairs.length>2&&a.jsx("button",{type:"button",className:"btn btn-icon btn-ghost btn-sm",onClick:()=>A(j),children:a.jsx(Je,{size:16})})]},j))}),a.jsxs("button",{type:"button",className:"btn btn-outline btn-sm",onClick:S,style:{marginTop:"0.5rem"},children:[a.jsx(Jt,{size:16}),"Tambah Pasangan"]})]})]}),a.jsxs("div",{className:"modal-footer",children:[a.jsx("button",{type:"button",className:"btn btn-ghost",onClick:c,children:"Batal"}),a.jsxs("button",{type:"submit",className:"btn btn-primary",children:[a.jsx(at,{size:16}),"Simpan Soal"]})]})]})]})}):null}function K1(){Le();const[r,c]=y.useState(L1),[u,o]=y.useState(""),[h,m]=y.useState("all"),[x,g]=y.useState("all"),[b,p]=y.useState("all"),[z,N]=y.useState(!1),[S,A]=y.useState(null),[v,R]=y.useState(null),[j,w]=y.useState(!1),C={pilihan_ganda:"Pilihan Ganda",essay:"Essay",benar_salah:"Benar/Salah",mencocokan:"Mencocokan"},k=r.filter(V=>{const X=V.text.toLowerCase().includes(u.toLowerCase()),se=h==="all"||V.matkulId===parseInt(h),xe=x==="all"||V.type===x,ve=b==="all"||V.examType===b;return X&&se&&xe&&ve}),Q=()=>{A(null),N(!0)},$=V=>{A(V),N(!0)},_=V=>{c(S?r.map(X=>X.id===S.id?{...V,id:S.id}:X):[...r,{...V,id:Date.now()}])},U=V=>{confirm("Apakah Anda yakin ingin menghapus soal ini?")&&c(r.filter(X=>X.id!==V))},L=V=>{const X=V.map(se=>({...se,id:Date.now()+Math.random(),matkulId:cs[0]?.id||1}));c([...r,...X])},K=V=>cs.find(X=>X.id===V)?.nama||"-";return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Buat Soal"}),a.jsx("p",{className:"page-subtitle",children:"Kelola soal untuk ujian mata kuliah Anda"})]}),a.jsxs("div",{className:"header-actions",children:[a.jsxs("button",{className:"btn btn-secondary",onClick:()=>w(!0),children:[a.jsx(Eb,{size:18}),"Ambil dari Bank Soal"]}),a.jsxs("button",{className:"btn btn-primary",onClick:Q,children:[a.jsx(Jt,{size:18}),"Tambah Soal"]})]})]}),a.jsx("div",{className:"score-info-card",children:a.jsxs("div",{className:"score-info-text",children:[a.jsx("span",{children:"📝 Skala nilai: 0-100"}),a.jsx("span",{className:"divider",children:"|"}),a.jsx("span",{children:"✓ Batas nilai lulus ujian: 70"})]})}),a.jsx("div",{className:"card",children:a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"filters-row",children:[a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:18,className:"search-icon"}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Cari soal...",value:u,onChange:V=>o(V.target.value)})]}),a.jsxs("select",{className:"form-input",value:h,onChange:V=>m(V.target.value),style:{width:"auto",minWidth:"180px"},children:[a.jsx("option",{value:"all",children:"Semua Mata Kuliah"}),cs.map(V=>a.jsx("option",{value:V.id,children:V.nama},V.id))]}),a.jsxs("select",{className:"form-input",value:x,onChange:V=>g(V.target.value),style:{width:"auto",minWidth:"150px"},children:[a.jsx("option",{value:"all",children:"Semua Tipe Soal"}),a.jsx("option",{value:"pilihan_ganda",children:"Pilihan Ganda"}),a.jsx("option",{value:"essay",children:"Essay"}),a.jsx("option",{value:"benar_salah",children:"Benar/Salah"}),a.jsx("option",{value:"mencocokan",children:"Mencocokan"})]}),a.jsxs("select",{className:"form-input exam-type-filter",value:b,onChange:V=>p(V.target.value),style:{width:"auto",minWidth:"120px"},children:[a.jsx("option",{value:"all",children:"Semua Ujian"}),a.jsx("option",{value:"uts",children:"UTS"}),a.jsx("option",{value:"uas",children:"UAS"})]})]}),a.jsx("div",{className:"questions-list",children:k.length===0?a.jsxs("div",{className:"empty-state",children:[a.jsx(xs,{size:48}),a.jsx("h3",{children:"Belum ada soal"}),a.jsx("p",{children:'Klik tombol "Tambah Soal" untuk membuat soal baru'})]}):k.map((V,X)=>a.jsxs("div",{className:"question-card",children:[a.jsxs("div",{className:"question-header",children:[a.jsxs("div",{className:"question-meta",children:[a.jsxs("span",{className:"question-number",children:["#",X+1]}),a.jsx("span",{className:`badge badge-${V.type==="pilihan_ganda"?"primary":V.type==="essay"?"accent":V.type==="benar_salah"?"success":"info"}`,children:C[V.type]}),a.jsx("span",{className:"badge badge-outline",children:K(V.matkulId)})]}),a.jsxs("span",{className:"question-points",children:[V.points," poin"]})]}),a.jsx("p",{className:"question-text",children:V.text}),V.image&&a.jsx("div",{className:"question-image-thumb",children:a.jsx("img",{src:V.image,alt:"Question"})}),a.jsxs("div",{className:"question-actions",children:[a.jsxs("button",{className:"btn btn-ghost btn-sm",onClick:()=>R(V),children:[a.jsx(Fa,{size:16}),"Preview"]}),a.jsxs("button",{className:"btn btn-ghost btn-sm",onClick:()=>$(V),children:[a.jsx(kt,{size:16}),"Edit"]}),a.jsxs("button",{className:"btn btn-ghost btn-sm text-error",onClick:()=>U(V.id),children:[a.jsx(dl,{size:16}),"Hapus"]})]})]},V.id))})]})}),a.jsx(H1,{isOpen:z,onClose:()=>N(!1),question:S,onSave:_,matkul:cs,currentExamType:b!=="all"?b:"uts"}),a.jsx(O1,{isOpen:j,onClose:()=>w(!1),onSelectQuestions:L,matkul:cs}),v&&a.jsx("div",{className:"modal-overlay",onClick:()=>R(null),children:a.jsxs("div",{className:"modal",onClick:V=>V.stopPropagation(),children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("h3",{children:"Preview Soal"}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:()=>R(null),children:a.jsx(Je,{size:20})})]}),a.jsxs("div",{className:"modal-body",children:[a.jsxs("div",{className:"preview-meta",children:[a.jsx("span",{className:`badge badge-${v.type==="pilihan_ganda"?"primary":v.type==="essay"?"accent":v.type==="benar_salah"?"success":"info"}`,children:C[v.type]}),a.jsxs("span",{children:[v.points," poin"]})]}),a.jsx("p",{className:"preview-question",children:v.text}),v.image&&a.jsx("img",{src:v.image,alt:"Question",className:"preview-image"}),v.type==="pilihan_ganda"&&v.options&&a.jsx("div",{className:"preview-options",children:v.options.map((V,X)=>a.jsxs("div",{className:`preview-option ${X===v.correctAnswer?"correct":""}`,children:[a.jsx("span",{className:"option-letter",children:String.fromCharCode(65+X)}),a.jsxs("div",{className:"option-content-preview",children:[a.jsx("span",{children:V.text}),V.image&&a.jsx("img",{src:V.image,alt:`Option ${X}`})]}),X===v.correctAnswer&&a.jsx(We,{size:16})]},X))}),v.type==="benar_salah"&&a.jsxs("div",{className:"preview-options",children:[a.jsxs("div",{className:`preview-option ${v.correctAnswer===!0?"correct":""}`,children:[a.jsx("span",{children:"Benar"}),v.correctAnswer===!0&&a.jsx(We,{size:16})]}),a.jsxs("div",{className:`preview-option ${v.correctAnswer===!1?"correct":""}`,children:[a.jsx("span",{children:"Salah"}),v.correctAnswer===!1&&a.jsx(We,{size:16})]})]}),v.type==="mencocokan"&&v.pairs&&a.jsx("div",{className:"preview-matching",children:v.pairs.map((V,X)=>a.jsxs("div",{className:"preview-pair",children:[a.jsx("span",{className:"pair-left",children:V.left}),a.jsx(sd,{size:16}),a.jsx("span",{className:"pair-right",children:V.right})]},X))}),v.type==="essay"&&a.jsx("div",{className:"preview-essay-hint",children:a.jsx("span",{children:"Jawaban berupa essay (akan dikoreksi manual)"})})]})]})})]}),a.jsx("style",{children:`
                .page-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    flex-wrap: wrap;
                    gap: var(--space-4);
                }
                .total-points-card {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: var(--space-4) var(--space-5);
                    border-radius: var(--radius-lg);
                    margin-bottom: var(--space-5);
                }
                .total-points-card.valid {
                    background: var(--success-50);
                    border: 1px solid var(--success-200);
                }
                .total-points-card.invalid {
                    background: var(--warning-50);
                    border: 1px solid var(--warning-200);
                }
                .points-info {
                    display: flex;
                    align-items: center;
                    gap: var(--space-3);
                }
                .points-label {
                    font-weight: var(--font-medium);
                    color: var(--text-secondary);
                }
                .points-value {
                    font-size: var(--font-size-xl);
                    font-weight: var(--font-bold);
                    color: var(--text-primary);
                }
                .points-warning {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    color: var(--warning-600);
                    font-size: var(--font-size-sm);
                }
                .filters-row {
                    display: flex;
                    gap: var(--space-4);
                    margin-bottom: var(--space-5);
                    flex-wrap: wrap;
                }
                .search-box {
                    position: relative;
                    flex: 1;
                    min-width: 200px;
                }
                .search-icon {
                    position: absolute;
                    left: var(--space-4);
                    top: 50%;
                    transform: translateY(-50%);
                    color: var(--text-muted);
                }
                .search-box .form-input {
                    padding-left: calc(var(--space-4) + 24px);
                }
                .questions-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-4);
                }
                .question-card {
                    padding: var(--space-5);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-lg);
                    border: 1px solid var(--border-color);
                    transition: all var(--transition-fast);
                }
                .question-card:hover {
                    border-color: var(--primary-300);
                    box-shadow: var(--shadow-md);
                }
                .question-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: var(--space-3);
                    flex-wrap: wrap;
                    gap: var(--space-2);
                }
                .question-meta {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    flex-wrap: wrap;
                }
                .question-number {
                    font-size: var(--font-size-sm);
                    font-weight: var(--font-bold);
                    color: var(--text-muted);
                }
                .question-points {
                    font-size: var(--font-size-sm);
                    font-weight: var(--font-semibold);
                    color: var(--accent-600);
                    background: var(--accent-50);
                    padding: var(--space-1) var(--space-3);
                    border-radius: var(--radius-full);
                }
                .question-text {
                    font-size: var(--font-size-base);
                    color: var(--text-primary);
                    margin-bottom: var(--space-4);
                    line-height: 1.6;
                }
                .question-image-thumb {
                    margin-bottom: var(--space-4);
                }
                .question-image-thumb img {
                    max-height: 100px;
                    border-radius: var(--radius-md);
                }
                .question-actions {
                    display: flex;
                    gap: var(--space-2);
                    flex-wrap: wrap;
                }
                .text-error {
                    color: var(--error-500) !important;
                }
                .badge-outline {
                    background: transparent;
                    border: 1px solid var(--border-color);
                    color: var(--text-secondary);
                }
                .empty-state {
                    text-align: center;
                    padding: var(--space-8);
                    color: var(--text-muted);
                }
                .empty-state svg {
                    margin-bottom: var(--space-4);
                }
                .empty-state h3 {
                    margin-bottom: var(--space-2);
                    color: var(--text-secondary);
                }
                .modal-lg {
                    max-width: 700px;
                }
                .form-row-2 {
                    display: grid;
                    grid-template-columns: 2fr 1fr;
                    gap: var(--space-4);
                }
                .form-textarea {
                    resize: vertical;
                    min-height: 80px;
                }
                .type-selector {
                    display: flex;
                    gap: var(--space-2);
                    flex-wrap: wrap;
                }
                .type-btn {
                    padding: var(--space-2) var(--space-4);
                    border: 2px solid var(--border-color);
                    border-radius: var(--radius-lg);
                    background: var(--bg-tertiary);
                    cursor: pointer;
                    font-size: var(--font-size-sm);
                    transition: all var(--transition-fast);
                }
                .type-btn:hover {
                    border-color: var(--primary-300);
                }
                .type-btn.active {
                    border-color: var(--primary-500);
                    background: var(--primary-50);
                    color: var(--primary-700);
                }
                .image-upload-area {
                    padding: var(--space-4);
                    border: 2px dashed var(--border-color);
                    border-radius: var(--radius-lg);
                    text-align: center;
                }
                .image-preview {
                    position: relative;
                    display: inline-block;
                }
                .image-preview img {
                    max-height: 150px;
                    border-radius: var(--radius-md);
                }
                .remove-image {
                    position: absolute;
                    top: -8px;
                    right: -8px;
                    width: 24px;
                    height: 24px;
                    border-radius: 50%;
                    background: var(--error-500);
                    color: white;
                    border: none;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .options-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-3);
                }
                .option-row-extended {
                    display: flex;
                    align-items: flex-start;
                    gap: var(--space-3);
                }
                .option-content {
                    flex: 1;
                    display: flex;
                    gap: var(--space-2);
                    align-items: center;
                }
                .option-content .form-input {
                    flex: 1;
                }
                .option-radio {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    width: 32px;
                    height: 32px;
                    border: none;
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-full);
                    color: var(--text-muted);
                    cursor: pointer;
                    transition: all var(--transition-fast);
                    flex-shrink: 0;
                    margin-top: 4px;
                }
                .option-radio:hover {
                    background: var(--primary-50);
                    color: var(--primary-600);
                }
                .option-radio.selected {
                    background: var(--success-500);
                    color: white;
                }
                .option-image-preview {
                    position: relative;
                    flex-shrink: 0;
                }
                .option-image-preview img {
                    height: 40px;
                    width: 40px;
                    object-fit: cover;
                    border-radius: var(--radius-md);
                }
                .remove-image-sm {
                    position: absolute;
                    top: -4px;
                    right: -4px;
                    width: 16px;
                    height: 16px;
                    border-radius: 50%;
                    background: var(--error-500);
                    color: white;
                    border: none;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .radio-group {
                    display: flex;
                    gap: var(--space-4);
                }
                .radio-label {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    cursor: pointer;
                }
                .radio-label input {
                    width: 18px;
                    height: 18px;
                    accent-color: var(--primary-600);
                }
                .matching-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-3);
                }
                .matching-row {
                    display: flex;
                    align-items: center;
                    gap: var(--space-3);
                }
                .matching-row .form-input {
                    flex: 1;
                }
                .matching-arrow {
                    color: var(--text-muted);
                    flex-shrink: 0;
                }
                .form-hint {
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                    margin-top: var(--space-2);
                }
                .preview-meta {
                    display: flex;
                    align-items: center;
                    gap: var(--space-3);
                    margin-bottom: var(--space-4);
                }
                .preview-question {
                    font-size: var(--font-size-lg);
                    font-weight: var(--font-medium);
                    color: var(--text-primary);
                    margin-bottom: var(--space-4);
                }
                .preview-image {
                    max-width: 100%;
                    max-height: 200px;
                    border-radius: var(--radius-md);
                    margin-bottom: var(--space-4);
                }
                .preview-options {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-2);
                }
                .preview-option {
                    display: flex;
                    align-items: center;
                    gap: var(--space-3);
                    padding: var(--space-3);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-md);
                    border: 2px solid transparent;
                }
                .preview-option.correct {
                    background: var(--success-50);
                    border-color: var(--success-300);
                }
                .preview-option.correct svg {
                    color: var(--success-500);
                }
                .option-letter {
                    width: 24px;
                    height: 24px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: var(--primary-100);
                    color: var(--primary-700);
                    border-radius: var(--radius-full);
                    font-size: var(--font-size-sm);
                    font-weight: var(--font-bold);
                }
                .option-content-preview {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-2);
                }
                .option-content-preview img {
                    max-height: 60px;
                    border-radius: var(--radius-sm);
                }
                .preview-matching {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-2);
                }
                .preview-pair {
                    display: flex;
                    align-items: center;
                    gap: var(--space-3);
                    padding: var(--space-3);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-md);
                }
                .pair-left {
                    flex: 1;
                    font-weight: var(--font-medium);
                }
                .pair-right {
                    flex: 1;
                    color: var(--text-secondary);
                }
                .preview-essay-hint {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    padding: var(--space-4);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-md);
                    color: var(--text-muted);
                }
                /* Score Info Card */
                .score-info-card {
                    background: linear-gradient(135deg, var(--primary-50) 0%, var(--accent-50) 100%);
                    border: 1px solid var(--primary-200);
                    border-radius: var(--radius-lg);
                    padding: var(--space-3) var(--space-4);
                    margin-bottom: var(--space-4);
                }
                .score-info-text {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: var(--space-4);
                    font-size: var(--font-size-sm);
                    color: var(--primary-700);
                    font-weight: 500;
                }
                .score-info-text .divider {
                    color: var(--primary-300);
                }
                @media (max-width: 768px) {
                    .form-row-2 {
                        grid-template-columns: 1fr;
                    }
                    .filters-row {
                        flex-direction: column;
                    }
                }
            `})]})}const B1=[{id:1,name:"UTS Navigasi Sungai",matkul:"Navigasi Sungai",kelas:"1A",date:"2026-01-04",deadline:"2026-01-10",totalStudents:25,corrected:15,status:"in_progress"},{id:2,name:"Quiz Keselamatan Pelayaran",matkul:"Keselamatan Pelayaran",kelas:"1B",date:"2026-01-05",deadline:"2026-01-08",totalStudents:28,corrected:28,status:"completed"},{id:3,name:"UAS Teknik Perkapalan",matkul:"Teknik Perkapalan",kelas:"2A",date:"2026-01-06",deadline:"2026-01-12",totalStudents:22,corrected:0,status:"pending"}],$1=[{id:1,studentName:"Budi Santoso",nim:"2024010001",submittedAt:"2026-01-04 10:25",totalScore:null,answers:[{questionId:1,type:"pilihan_ganda",answer:1,correctAnswer:1,maxPoints:20,earnedPoints:20,autoCorrect:!0},{questionId:2,type:"essay",answer:"Prosedur keselamatan dasar meliputi...",correctAnswer:null,maxPoints:30,earnedPoints:null,autoCorrect:!1},{questionId:3,type:"benar_salah",answer:!0,correctAnswer:!0,maxPoints:10,earnedPoints:10,autoCorrect:!0},{questionId:4,type:"mencocokan",answer:{0:0,1:1,2:2,3:3},correctAnswer:{0:0,1:1,2:2,3:3},maxPoints:40,earnedPoints:40,autoCorrect:!0}]},{id:2,studentName:"Ani Wijaya",nim:"2024010002",submittedAt:"2026-01-04 10:15",totalScore:null,answers:[{questionId:1,type:"pilihan_ganda",answer:2,correctAnswer:1,maxPoints:20,earnedPoints:0,autoCorrect:!0},{questionId:2,type:"essay",answer:"Keselamatan pelayaran sangat penting karena...",correctAnswer:null,maxPoints:30,earnedPoints:null,autoCorrect:!1},{questionId:3,type:"benar_salah",answer:!1,correctAnswer:!0,maxPoints:10,earnedPoints:0,autoCorrect:!0},{questionId:4,type:"mencocokan",answer:{0:1,1:0,2:2,3:3},correctAnswer:{0:0,1:1,2:2,3:3},maxPoints:40,earnedPoints:20,autoCorrect:!0}]},{id:3,studentName:"Citra Dewi",nim:"2024010003",submittedAt:"2026-01-04 10:30",totalScore:85,answers:[{questionId:1,type:"pilihan_ganda",answer:1,correctAnswer:1,maxPoints:20,earnedPoints:20,autoCorrect:!0},{questionId:2,type:"essay",answer:"Prosedur keselamatan dasar terdiri dari beberapa langkah...",correctAnswer:null,maxPoints:30,earnedPoints:25,autoCorrect:!1},{questionId:3,type:"benar_salah",answer:!0,correctAnswer:!0,maxPoints:10,earnedPoints:10,autoCorrect:!0},{questionId:4,type:"mencocokan",answer:{0:0,1:1,2:2,3:3},correctAnswer:{0:0,1:1,2:2,3:3},maxPoints:40,earnedPoints:30,autoCorrect:!0}]}],q1=[{id:1,text:"Apa yang dimaksud dengan navigasi sungai?",type:"pilihan_ganda",options:["Navigasi di laut","Navigasi di sungai dan perairan darat","Navigasi di udara","Navigasi di darat"]},{id:2,text:"Jelaskan prosedur keselamatan dasar saat berlayar di perairan sungai.",type:"essay"},{id:3,text:"Kapal feri termasuk jenis kapal penumpang.",type:"benar_salah"},{id:4,text:"Cocokkan istilah berikut dengan definisinya:",type:"mencocokan",pairs:[{left:"Haluan",right:"Bagian depan kapal"},{left:"Buritan",right:"Bagian belakang kapal"},{left:"Lambung",right:"Badan kapal"},{left:"Geladak",right:"Lantai kapal"}]}];function I1({isOpen:r,onClose:c,student:u,questions:o,onSave:h}){const[m,x]=y.useState(u?.answers||[]),g=(S,A)=>{const v=[...m];v[S]={...v[S],earnedPoints:Math.min(A,v[S].maxPoints)},x(v)},b=()=>{const S=m.reduce((A,v)=>A+(v.earnedPoints||0),0);h({...u,answers:m,totalScore:S}),c()};if(!r||!u)return null;const p=m.map((S,A)=>({...S,originalIndex:A})).filter(S=>S.type==="essay"),z=m.reduce((S,A)=>S+(A.earnedPoints||0),0),N=m.reduce((S,A)=>S+A.maxPoints,0);return a.jsx("div",{className:"modal-overlay",onClick:c,children:a.jsxs("div",{className:"modal modal-md",onClick:S=>S.stopPropagation(),children:[a.jsxs("div",{className:"modal-header",children:[a.jsxs("div",{children:[a.jsx("h3",{children:"Koreksi Jawaban"}),a.jsxs("p",{className:"modal-subtitle",children:[u.studentName," - ",u.nim]})]}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:c,children:a.jsx(Je,{size:20})})]}),a.jsx("div",{className:"modal-body correction-body-simple",children:p.length>0?a.jsx("div",{className:"essay-grading-list",children:p.map((S,A)=>{const v=o.find(R=>R.id===S.questionId);return a.jsxs("div",{className:"essay-grading-item",children:[a.jsxs("div",{className:"essay-q-header",children:[a.jsxs("span",{className:"essay-q-label",children:["Soal Essay ",A+1]}),a.jsxs("span",{className:"essay-max-points",children:["Maks: ",S.maxPoints," poin"]})]}),a.jsx("p",{className:"essay-question-text",children:v?.text}),a.jsxs("div",{className:"essay-answer-box",children:[a.jsx("strong",{children:"Jawaban:"}),a.jsx("p",{children:S.answer})]}),a.jsxs("div",{className:"essay-score-input",children:[a.jsx("label",{children:"Nilai:"}),a.jsx("input",{type:"number",className:"form-input points-input-simple",value:S.earnedPoints??"",onChange:R=>g(S.originalIndex,parseInt(R.target.value)||0),min:0,max:S.maxPoints,placeholder:"0"}),a.jsxs("span",{className:"points-max-label",children:["/ ",S.maxPoints]})]})]},A)})}):a.jsxs("div",{className:"no-essay-message",children:[a.jsx("p",{children:"Tidak ada soal essay yang perlu dikoreksi manual."}),a.jsx("p",{children:"Semua soal telah dikoreksi otomatis."})]})}),a.jsxs("div",{className:"modal-footer",children:[a.jsxs("div",{className:"total-score-simple",children:["Total: ",a.jsx("strong",{className:"score-value",children:z})," / ",N]}),a.jsxs("div",{className:"modal-actions",children:[a.jsx("button",{className:"btn btn-ghost",onClick:c,children:"Batal"}),a.jsxs("button",{className:"btn btn-primary",onClick:b,children:[a.jsx(at,{size:16}),"Simpan Koreksi"]})]})]})]})})}function P1(){Le();const[r]=y.useState(B1),[c,u]=y.useState(null),[o,h]=y.useState($1),[m,x]=y.useState({open:!1,student:null}),g=S=>{u(S)},b=S=>{x({open:!0,student:S})},p=S=>{h(o.map(A=>A.id===S.id?S:A))},z=S=>{const A=new Date,v=new Date(S);return Math.ceil((v-A)/(1e3*60*60*24))},N=S=>{switch(S){case"completed":return a.jsx("span",{className:"badge badge-success",children:"Selesai"});case"in_progress":return a.jsx("span",{className:"badge badge-warning",children:"Berlangsung"});default:return a.jsx("span",{className:"badge badge-info",children:"Pending"})}};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsx("div",{className:"page-header",children:a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Koreksi Ujian"}),a.jsx("p",{className:"page-subtitle",children:"Koreksi jawaban ujian mahasiswa"})]})}),c?a.jsxs(a.Fragment,{children:[a.jsx("button",{className:"btn btn-ghost mb-4",onClick:()=>u(null),children:"← Kembali ke Daftar Ujian"}),a.jsx("div",{className:"exam-detail-header card mb-4",children:a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"exam-detail-info",children:[a.jsx("h2",{children:c.name}),a.jsxs("p",{children:[c.matkul," - Kelas ",c.kelas]})]}),a.jsxs("div",{className:"exam-detail-stats",children:[a.jsxs("div",{className:"stat-item",children:[a.jsx(ra,{size:18}),a.jsxs("span",{children:[c.totalStudents," Peserta"]})]}),a.jsxs("div",{className:"stat-item",children:[a.jsx(Zi,{size:18}),a.jsxs("span",{children:[c.corrected," Terkoreksi"]})]}),a.jsxs("div",{className:"stat-item",children:[a.jsx(Ve,{size:18}),a.jsxs("span",{children:["Deadline: ",c.deadline]})]})]})]})}),a.jsxs("div",{className:"card",children:[a.jsx("div",{className:"card-header",children:a.jsx("h3",{children:"Daftar Jawaban Mahasiswa"})}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"No"}),a.jsx("th",{children:"Nama"}),a.jsx("th",{children:"NIM"}),a.jsx("th",{children:"Submit"}),a.jsx("th",{children:"Status"}),a.jsx("th",{children:"Nilai"}),a.jsx("th",{children:"Aksi"})]})}),a.jsx("tbody",{children:o.map((S,A)=>{const v=S.answers.some(R=>R.type==="essay"&&R.earnedPoints===null);return a.jsxs("tr",{children:[a.jsx("td",{children:A+1}),a.jsx("td",{className:"font-medium",children:S.studentName}),a.jsx("td",{children:S.nim}),a.jsx("td",{className:"text-muted",children:S.submittedAt}),a.jsx("td",{children:S.totalScore!==null?a.jsx("span",{className:"badge badge-success",children:"Selesai"}):v?a.jsx("span",{className:"badge badge-warning",children:"Essay Pending"}):a.jsx("span",{className:"badge badge-info",children:"Auto-corrected"})}),a.jsx("td",{children:S.totalScore!==null?a.jsx("span",{className:"score-badge",children:S.totalScore}):a.jsx("span",{className:"text-muted",children:"-"})}),a.jsx("td",{children:a.jsx("button",{className:"btn btn-primary btn-sm",onClick:()=>b(S),children:S.totalScore!==null?a.jsxs(a.Fragment,{children:[a.jsx(Fa,{size:14}),"Lihat"]}):a.jsxs(a.Fragment,{children:[a.jsx(kt,{size:14}),"Koreksi"]})})})]},S.id)})})]})})})]})]}):a.jsx(a.Fragment,{children:a.jsxs("div",{className:"card",children:[a.jsx("div",{className:"card-header",children:a.jsx("h3",{children:"Ujian Perlu Dikoreksi"})}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"exam-list",children:r.map(S=>{const A=z(S.deadline),v=A<=2&&S.status!=="completed";return a.jsxs("div",{className:`exam-item ${v?"urgent":""}`,onClick:()=>g(S),children:[a.jsxs("div",{className:"exam-info",children:[a.jsx("h4",{children:S.name}),a.jsxs("p",{children:[S.matkul," - Kelas ",S.kelas]}),a.jsxs("p",{className:"exam-date",children:["Tanggal: ",S.date]})]}),a.jsxs("div",{className:"exam-meta",children:[N(S.status),a.jsxs("div",{className:"correction-progress",children:[a.jsx("div",{className:"progress-bar-container",children:a.jsx("div",{className:"progress-bar-fill",style:{width:`${S.corrected/S.totalStudents*100}%`}})}),a.jsxs("span",{children:[S.corrected,"/",S.totalStudents]})]}),a.jsxs("div",{className:`deadline ${v?"urgent":""}`,children:[a.jsx(Ve,{size:14}),A>0?a.jsxs("span",{children:[A," hari lagi"]}):A===0?a.jsx("span",{children:"Hari ini!"}):a.jsxs("span",{className:"overdue",children:["Terlambat ",Math.abs(A)," hari"]})]})]}),a.jsx(vs,{size:20,className:"chevron"})]},S.id)})})})]})}),a.jsx(I1,{isOpen:m.open,onClose:()=>x({open:!1,student:null}),student:m.student,questions:q1,onSave:p})]}),a.jsx("style",{children:`
                .page-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    flex-wrap: wrap;
                    gap: var(--space-4);
                    margin-bottom: var(--space-6);
                }
                .card-header {
                    padding: var(--space-4) var(--space-5);
                    border-bottom: 1px solid var(--border-color);
                }
                .card-header h3 {
                    margin: 0;
                    font-size: var(--font-size-lg);
                }
                .exam-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-3);
                }
                .exam-item {
                    display: flex;
                    align-items: center;
                    gap: var(--space-4);
                    padding: var(--space-4);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-lg);
                    border: 2px solid transparent;
                    cursor: pointer;
                    transition: all var(--transition-fast);
                }
                .exam-item:hover {
                    border-color: var(--primary-300);
                }
                .exam-item.urgent {
                    border-color: var(--warning-300);
                    background: var(--warning-50);
                }
                .exam-info {
                    flex: 1;
                }
                .exam-info h4 {
                    margin: 0 0 var(--space-1);
                    font-size: var(--font-size-base);
                }
                .exam-info p {
                    margin: 0;
                    font-size: var(--font-size-sm);
                    color: var(--text-secondary);
                }
                .exam-date {
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                }
                .exam-meta {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-2);
                    align-items: flex-end;
                }
                .correction-progress {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    font-size: var(--font-size-xs);
                }
                .progress-bar-container {
                    width: 60px;
                    height: 6px;
                    background: var(--border-color);
                    border-radius: 3px;
                    overflow: hidden;
                }
                .progress-bar-fill {
                    height: 100%;
                    background: var(--primary-500);
                    border-radius: 3px;
                }
                .deadline {
                    display: flex;
                    align-items: center;
                    gap: var(--space-1);
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                }
                .deadline.urgent {
                    color: var(--warning-600);
                }
                .deadline .overdue {
                    color: var(--error-500);
                }
                .chevron {
                    color: var(--text-muted);
                }
                .mb-4 {
                    margin-bottom: var(--space-4);
                }
                .exam-detail-header .card-body {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    flex-wrap: wrap;
                    gap: var(--space-4);
                }
                .exam-detail-info h2 {
                    margin: 0 0 var(--space-1);
                }
                .exam-detail-info p {
                    margin: 0;
                    color: var(--text-secondary);
                }
                .exam-detail-stats {
                    display: flex;
                    gap: var(--space-4);
                }
                .stat-item {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    padding: var(--space-2) var(--space-4);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-md);
                    font-size: var(--font-size-sm);
                }
                .score-badge {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    min-width: 36px;
                    padding: var(--space-1) var(--space-2);
                    background: var(--success-100);
                    color: var(--success-700);
                    font-weight: var(--font-bold);
                    border-radius: var(--radius-md);
                }
                .modal-xl {
                    max-width: 900px;
                    max-height: 90vh;
                }
                .modal-subtitle {
                    margin: var(--space-1) 0 0;
                    font-size: var(--font-size-sm);
                    color: var(--text-muted);
                }
                .correction-body {
                    max-height: 60vh;
                    overflow-y: auto;
                }
                .correction-item {
                    padding: var(--space-4);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-lg);
                    margin-bottom: var(--space-4);
                    position: relative;
                }
                .correction-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: var(--space-3);
                }
                .correction-q-info {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                }
                .q-number {
                    font-weight: var(--font-bold);
                    color: var(--text-secondary);
                }
                .correction-points {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                }
                .points-input {
                    width: 60px;
                    padding: var(--space-2);
                    border: 2px solid var(--border-color);
                    border-radius: var(--radius-md);
                    font-size: var(--font-size-base);
                    font-weight: var(--font-bold);
                    text-align: center;
                }
                .points-input:focus {
                    border-color: var(--primary-500);
                    outline: none;
                }
                .max-points {
                    font-size: var(--font-size-sm);
                    color: var(--text-muted);
                }
                .correction-question {
                    font-weight: var(--font-medium);
                    margin-bottom: var(--space-3);
                }
                .correction-answer {
                    padding: var(--space-3);
                    background: var(--bg-secondary);
                    border-radius: var(--radius-md);
                }
                .answer-label {
                    display: block;
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                    margin-bottom: var(--space-2);
                }
                .answer-content {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-1);
                }
                .answer-content .correct {
                    color: var(--success-600);
                }
                .answer-content .incorrect {
                    color: var(--error-600);
                }
                .correct-answer {
                    font-size: var(--font-size-sm);
                    color: var(--success-600);
                    font-style: italic;
                }
                .essay-answer {
                    padding: var(--space-3);
                    background: white;
                    border-radius: var(--radius-md);
                    border: 1px solid var(--border-color);
                }
                .essay-answer p {
                    margin: 0;
                    line-height: 1.6;
                }
                .matching-answer {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-2);
                }
                .match-item {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    font-size: var(--font-size-sm);
                }
                .match-item .correct {
                    color: var(--success-600);
                }
                .match-item .incorrect {
                    color: var(--error-600);
                }
                .auto-correct-badge {
                    display: inline-flex;
                    align-items: center;
                    gap: var(--space-1);
                    position: absolute;
                    top: var(--space-3);
                    right: var(--space-3);
                    font-size: var(--font-size-xs);
                    color: var(--success-600);
                    background: var(--success-50);
                    padding: var(--space-1) var(--space-2);
                    border-radius: var(--radius-full);
                }
                .modal-footer {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                .total-score {
                    font-size: var(--font-size-lg);
                }
                .total-score strong {
                    color: var(--primary-600);
                }
                .modal-actions {
                    display: flex;
                    gap: var(--space-2);
                }
                /* Simplified Essay Grading Styles */
                .correction-body-simple {
                    padding: var(--space-4);
                    max-height: 60vh;
                    overflow-y: auto;
                }
                .essay-grading-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-4);
                }
                .essay-grading-item {
                    background: var(--gray-50);
                    border: 1px solid var(--gray-200);
                    border-radius: var(--radius-lg);
                    padding: var(--space-4);
                }
                .essay-q-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: var(--space-2);
                }
                .essay-q-label {
                    font-weight: 600;
                    color: var(--primary-600);
                }
                .essay-max-points {
                    font-size: var(--font-size-sm);
                    color: var(--accent-600);
                    font-weight: 500;
                    background: var(--accent-50);
                    padding: var(--space-1) var(--space-2);
                    border-radius: var(--radius-full);
                }
                .essay-question-text {
                    font-size: var(--font-size-sm);
                    color: var(--gray-700);
                    margin-bottom: var(--space-3);
                    line-height: 1.5;
                }
                .essay-answer-box {
                    background: white;
                    border: 1px solid var(--gray-200);
                    border-radius: var(--radius-md);
                    padding: var(--space-3);
                    margin-bottom: var(--space-3);
                }
                .essay-answer-box strong {
                    font-size: var(--font-size-sm);
                    color: var(--gray-500);
                    display: block;
                    margin-bottom: var(--space-1);
                }
                .essay-answer-box p {
                    font-size: var(--font-size-sm);
                    color: var(--gray-800);
                    line-height: 1.6;
                }
                .essay-score-input {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                }
                .essay-score-input label {
                    font-weight: 500;
                    font-size: var(--font-size-sm);
                    color: var(--gray-600);
                }
                .points-input-simple {
                    width: 80px;
                    text-align: center;
                    font-weight: 600;
                    font-size: var(--font-size-lg);
                }
                .points-max-label {
                    font-size: var(--font-size-sm);
                    color: var(--gray-500);
                }
                .no-essay-message {
                    text-align: center;
                    padding: var(--space-8);
                    color: var(--gray-500);
                }
                .no-essay-message p {
                    margin: var(--space-1) 0;
                }
                .total-score-simple {
                    font-size: var(--font-size-lg);
                    display: flex;
                    align-items: center;
                    gap: var(--space-1);
                }
                .total-score-simple .score-value {
                    color: var(--primary-600);
                    font-size: var(--font-size-xl);
                }
                @media (max-width: 768px) {
                    .exam-item {
                        flex-direction: column;
                        align-items: flex-start;
                    }
                    .exam-meta {
                        align-items: flex-start;
                    }
                    .exam-detail-stats {
                        flex-wrap: wrap;
                    }
                }
            `})]})}const G1=[{id:1,examName:"UTS Navigasi Sungai",examType:"uts",matkul:"Navigasi Sungai",kelas:"1A",date:"2026-01-04",students:[{id:1,name:"Budi Santoso",nim:"2024010001",score:85},{id:2,name:"Ani Wijaya",nim:"2024010002",score:65},{id:3,name:"Citra Dewi",nim:"2024010003",score:90},{id:4,name:"Deni Pratama",nim:"2024010004",score:55},{id:5,name:"Eka Putri",nim:"2024010005",score:78}]},{id:2,examName:"UAS Navigasi Sungai",examType:"uas",matkul:"Navigasi Sungai",kelas:"1A",date:"2026-01-10",students:[{id:1,name:"Budi Santoso",nim:"2024010001",score:88},{id:2,name:"Ani Wijaya",nim:"2024010002",score:72},{id:3,name:"Citra Dewi",nim:"2024010003",score:92},{id:4,name:"Deni Pratama",nim:"2024010004",score:68},{id:5,name:"Eka Putri",nim:"2024010005",score:80}]},{id:3,examName:"UTS Keselamatan Pelayaran",examType:"uts",matkul:"Keselamatan Pelayaran",kelas:"1B",date:"2026-01-05",students:[{id:6,name:"Fani Kusuma",nim:"2024010006",score:82},{id:7,name:"Gunawan Susilo",nim:"2024010007",score:60},{id:8,name:"Hesti Nurmala",nim:"2024010008",score:88}]}];function Q1({isOpen:r,onClose:c,student:u,onSave:o}){const[h,m]=y.useState(u?.score||0);if(!r||!u)return null;const x=()=>{o(u.id,parseInt(h)),c()};return a.jsx("div",{className:"modal-overlay",onClick:c,children:a.jsxs("div",{className:"modal modal-sm",onClick:g=>g.stopPropagation(),children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("h3",{children:"Edit Nilai"}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:c,children:a.jsx(Je,{size:20})})]}),a.jsxs("div",{className:"modal-body",children:[a.jsxs("p",{children:[a.jsx("strong",{children:u.name})," - ",u.nim]}),a.jsxs("div",{className:"form-group",style:{marginTop:"var(--space-4)"},children:[a.jsx("label",{className:"form-label",children:"Nilai"}),a.jsx("input",{type:"number",className:"form-input",value:h,onChange:g=>m(g.target.value),min:0,max:100})]})]}),a.jsxs("div",{className:"modal-footer",children:[a.jsx("button",{className:"btn btn-ghost",onClick:c,children:"Batal"}),a.jsxs("button",{className:"btn btn-primary",onClick:x,children:[a.jsx(at,{size:16}),"Simpan"]})]})]})})}function ef(){const{user:r}=Le(),[c,u]=y.useState(G1),[o,h]=y.useState(null),[m,x]=y.useState(""),[g,b]=y.useState("name"),[p,z]=y.useState("asc"),[N,S]=y.useState("all"),[A,v]=y.useState({open:!1,student:null,examId:null}),R=X=>{h(o===X?null:X)},j=c.filter(X=>N==="all"||X.examType===N),w=X=>[...X].sort((se,xe)=>{let ve=0;return g==="name"?ve=se.name.localeCompare(xe.name):g==="score"&&(ve=se.score-xe.score),p==="asc"?ve:-ve}),C=X=>m?X.filter(se=>se.name.toLowerCase().includes(m.toLowerCase())||se.nim.includes(m)):X,k=X=>X.length===0?0:(X.reduce((xe,ve)=>xe+ve.score,0)/X.length).toFixed(1),Q=X=>X>=70?"success":X>=60?"warning":"error",$=X=>X.filter(se=>se.score<70).length,_=(X,se)=>{v({open:!0,student:X,examId:se})},U=(X,se)=>{u(c.map(xe=>xe.id===A.examId?{...xe,students:xe.students.map(ve=>ve.id===X?{...ve,score:se}:ve)}:xe))},L=X=>{let se=`No,NIM,Nama,Nilai,Keterangan
`;X.students.forEach((Oe,I)=>{const G=Oe.score<70?"MENGULANG":"LULUS";se+=`${I+1},"${Oe.nim}","${Oe.name}",${Oe.score},${G}
`});const xe=new Blob([se],{type:"text/csv;charset=utf-8;"}),ve=document.createElement("a");ve.href=URL.createObjectURL(xe),ve.download=`nilai_${X.examType}_${X.matkul.replace(/\s/g,"_")}_${X.kelas}.csv`,ve.click()},K=()=>{const X=`NIM,Nama,Nilai
2024010001,Contoh Mahasiswa,85
`,se=new Blob([X],{type:"text/csv;charset=utf-8;"}),xe=document.createElement("a");xe.href=URL.createObjectURL(se),xe.download="template_import_nilai.csv",xe.click()},V=X=>{const se=`
            <html>
            <head>
                <title>Nilai ${X.examType.toUpperCase()} - ${X.matkul}</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    h1 { font-size: 18px; margin-bottom: 5px; }
                    h2 { font-size: 14px; color: #666; margin-bottom: 20px; }
                    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background: #f5f5f5; }
                    .mengulang { color: red; font-weight: bold; }
                </style>
            </head>
            <body>
                <h1>${X.examName}</h1>
                <h2>${X.matkul} - Kelas ${X.kelas} | Tanggal: ${X.date}</h2>
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIM</th>
                            <th>Nama</th>
                            <th>Nilai</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${X.students.map((ve,Oe)=>`
                            <tr>
                                <td>${Oe+1}</td>
                                <td>${ve.nim}</td>
                                <td>${ve.name}</td>
                                <td>${ve.score}</td>
                                <td class="${ve.score<70?"mengulang":""}">${ve.score<70?"MENGULANG":"LULUS"}</td>
                            </tr>
                        `).join("")}
                    </tbody>
                </table>
            </body>
            </html>
        `,xe=window.open("","_blank");xe.document.write(se),xe.document.close(),xe.print()};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Nilai UAS dan UTS"}),a.jsx("p",{className:"page-subtitle",children:"Hasil nilai ujian tengah dan akhir semester"})]}),a.jsx("div",{className:"header-actions",children:a.jsxs("button",{className:"btn btn-outline",onClick:K,children:[a.jsx(rd,{size:16}),"Template Import"]})})]}),a.jsxs("div",{className:"exam-type-tabs",children:[a.jsx("button",{className:`tab-btn ${N==="all"?"active":""}`,onClick:()=>S("all"),children:"Semua"}),a.jsx("button",{className:`tab-btn ${N==="uts"?"active":""}`,onClick:()=>S("uts"),children:"UTS"}),a.jsx("button",{className:`tab-btn ${N==="uas"?"active":""}`,onClick:()=>S("uas"),children:"UAS"})]}),a.jsx("div",{className:"exam-results-list",children:j.map(X=>{const se=o===X.id,xe=C(X.students),ve=w(xe),Oe=k(X.students),I=$(X.students);return a.jsxs("div",{className:"exam-result-card",children:[a.jsxs("div",{className:"exam-result-header",onClick:()=>R(X.id),children:[a.jsxs("div",{className:"exam-result-info",children:[a.jsxs("div",{className:"exam-title-row",children:[a.jsx("span",{className:`badge badge-${X.examType==="uts"?"primary":"accent"}`,children:X.examType.toUpperCase()}),a.jsx("h3",{children:X.examName})]}),a.jsxs("p",{children:[X.matkul," - Kelas ",X.kelas]})]}),a.jsxs("div",{className:"exam-result-meta",children:[a.jsxs("div",{className:"meta-item",children:[a.jsx("span",{className:"meta-label",children:"Tanggal"}),a.jsx("span",{className:"meta-value",children:X.date})]}),a.jsxs("div",{className:"meta-item",children:[a.jsx("span",{className:"meta-label",children:"Peserta"}),a.jsx("span",{className:"meta-value",children:X.students.length})]}),a.jsxs("div",{className:"meta-item",children:[a.jsx("span",{className:"meta-label",children:"Rata-rata"}),a.jsx("span",{className:`meta-value score-${Q(Oe)}`,children:Oe})]}),I>0&&a.jsxs("div",{className:"meta-item mengulang-badge",children:[a.jsx(qa,{size:14}),a.jsxs("span",{children:[I," Mengulang"]})]}),se?a.jsx(Rf,{size:20}):a.jsx(id,{size:20})]})]}),se&&a.jsxs("div",{className:"exam-result-body",children:[a.jsxs("div",{className:"result-toolbar",children:[a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:16}),a.jsx("input",{type:"text",placeholder:"Cari mahasiswa...",value:m,onChange:G=>x(G.target.value)})]}),a.jsxs("div",{className:"sort-controls",children:[a.jsxs("select",{value:g,onChange:G=>b(G.target.value),children:[a.jsx("option",{value:"name",children:"Nama"}),a.jsx("option",{value:"score",children:"Nilai"})]}),a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm",onClick:()=>z(p==="asc"?"desc":"asc"),children:p==="asc"?"↑":"↓"})]}),a.jsxs("button",{className:"btn btn-outline btn-sm",onClick:()=>L(X),children:[a.jsx(bs,{size:14}),"Export Excel"]}),a.jsxs("button",{className:"btn btn-outline btn-sm",onClick:()=>V(X),children:[a.jsx(da,{size:14}),"Cetak"]})]}),a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"No"}),a.jsx("th",{children:"Nama"}),a.jsx("th",{children:"NIM"}),a.jsx("th",{children:"Nilai"}),a.jsx("th",{children:"Keterangan"}),a.jsx("th",{children:"Aksi"})]})}),a.jsx("tbody",{children:ve.map((G,W)=>a.jsxs("tr",{children:[a.jsx("td",{children:W+1}),a.jsx("td",{className:"font-medium",children:G.name}),a.jsx("td",{children:G.nim}),a.jsx("td",{children:a.jsx("span",{className:`score-badge score-${Q(G.score)}`,children:G.score})}),a.jsx("td",{children:G.score<70?a.jsx("span",{className:"badge badge-error",children:"MENGULANG"}):a.jsx("span",{className:"badge badge-success",children:"LULUS"})}),a.jsx("td",{children:a.jsxs("div",{className:"action-buttons",children:[a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm",title:"Lihat",children:a.jsx(Fa,{size:16})}),a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm",title:"Edit",onClick:oe=>{oe.stopPropagation(),_(G,X.id)},children:a.jsx(kt,{size:16})})]})})]},G.id))})]})})]})]},X.id)})}),a.jsx(Q1,{isOpen:A.open,onClose:()=>v({open:!1,student:null,examId:null}),student:A.student,onSave:U})]}),a.jsx("style",{children:`
                .page-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    flex-wrap: wrap;
                    gap: var(--space-4);
                    margin-bottom: var(--space-4);
                }
                .header-actions {
                    display: flex;
                    gap: var(--space-2);
                }
                .exam-type-tabs {
                    display: flex;
                    gap: var(--space-2);
                    margin-bottom: var(--space-5);
                    background: var(--bg-tertiary);
                    padding: var(--space-1);
                    border-radius: var(--radius-lg);
                    width: fit-content;
                }
                .tab-btn {
                    padding: var(--space-2) var(--space-4);
                    border: none;
                    background: transparent;
                    border-radius: var(--radius-md);
                    font-weight: var(--font-medium);
                    cursor: pointer;
                    transition: all var(--transition-fast);
                    color: var(--text-secondary);
                }
                .tab-btn:hover {
                    background: var(--bg-secondary);
                }
                .tab-btn.active {
                    background: var(--primary-500);
                    color: white;
                }
                .exam-results-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-4);
                }
                .exam-result-card {
                    background: var(--bg-secondary);
                    border: 1px solid var(--border-color);
                    border-radius: var(--radius-lg);
                    overflow: hidden;
                }
                .exam-result-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: var(--space-4) var(--space-5);
                    cursor: pointer;
                    transition: background var(--transition-fast);
                }
                .exam-result-header:hover {
                    background: var(--bg-tertiary);
                }
                .exam-title-row {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    margin-bottom: var(--space-1);
                }
                .exam-title-row h3 {
                    margin: 0;
                    font-size: var(--font-size-base);
                }
                .exam-result-info p {
                    margin: 0;
                    font-size: var(--font-size-sm);
                    color: var(--text-secondary);
                }
                .exam-result-meta {
                    display: flex;
                    align-items: center;
                    gap: var(--space-4);
                }
                .meta-item {
                    text-align: center;
                }
                .meta-label {
                    display: block;
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                }
                .meta-value {
                    font-weight: var(--font-bold);
                }
                .mengulang-badge {
                    display: flex;
                    align-items: center;
                    gap: var(--space-1);
                    background: var(--error-100);
                    color: var(--error-700);
                    padding: var(--space-1) var(--space-2);
                    border-radius: var(--radius-full);
                    font-size: var(--font-size-xs);
                    font-weight: var(--font-medium);
                }
                .score-success {
                    color: var(--success-600);
                }
                .score-warning {
                    color: var(--warning-600);
                }
                .score-error {
                    color: var(--error-600);
                }
                .exam-result-body {
                    padding: var(--space-4) var(--space-5);
                    border-top: 1px solid var(--border-color);
                    background: var(--bg-tertiary);
                }
                .result-toolbar {
                    display: flex;
                    gap: var(--space-3);
                    margin-bottom: var(--space-4);
                    flex-wrap: wrap;
                }
                .result-toolbar .search-box {
                    flex: 1;
                    min-width: 200px;
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    padding: var(--space-2) var(--space-3);
                    background: var(--bg-secondary);
                    border: 1px solid var(--border-color);
                    border-radius: var(--radius-md);
                }
                .result-toolbar .search-box input {
                    border: none;
                    background: transparent;
                    outline: none;
                    flex: 1;
                    font-size: var(--font-size-sm);
                }
                .sort-controls {
                    display: flex;
                    gap: var(--space-2);
                    align-items: center;
                }
                .sort-controls select {
                    padding: var(--space-2) var(--space-3);
                    border: 1px solid var(--border-color);
                    border-radius: var(--radius-md);
                    background: var(--bg-secondary);
                    font-size: var(--font-size-sm);
                }
                .score-badge {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    min-width: 40px;
                    padding: var(--space-1) var(--space-2);
                    border-radius: var(--radius-md);
                    font-weight: var(--font-bold);
                }
                .score-badge.score-success {
                    background: var(--success-100);
                    color: var(--success-700);
                }
                .score-badge.score-warning {
                    background: var(--warning-100);
                    color: var(--warning-700);
                }
                .score-badge.score-error {
                    background: var(--error-100);
                    color: var(--error-700);
                }
                .action-buttons {
                    display: flex;
                    gap: var(--space-1);
                }
                .modal-sm {
                    max-width: 400px;
                }
                @media (max-width: 768px) {
                    .exam-result-header {
                        flex-direction: column;
                        align-items: flex-start;
                        gap: var(--space-3);
                    }
                    .exam-result-meta {
                        width: 100%;
                        justify-content: space-between;
                        flex-wrap: wrap;
                    }
                }
            `})]})}const Bo=[{id:1,nama:"Navigasi Sungai",kelas:"1A",hasPraktek:!0},{id:2,nama:"Keselamatan Pelayaran",kelas:"1B",hasPraktek:!1},{id:3,nama:"Teknik Perkapalan",kelas:"2A",hasPraktek:!0}],Y1={1:[{id:1,name:"Budi Santoso",nim:"2024010001",nt:85,nuts:78,nutsSystem:78,nutsManual:!1,np:82,uas:85},{id:2,name:"Ani Wijaya",nim:"2024010002",nt:72,nuts:65,nutsSystem:65,nutsManual:!1,np:75,uas:72},{id:3,name:"Citra Dewi",nim:"2024010003",nt:90,nuts:88,nutsSystem:88,nutsManual:!1,np:85,uas:90},{id:4,name:"Deni Pratama",nim:"2024010004",nt:68,nuts:55,nutsSystem:55,nutsManual:!1,np:70,uas:68},{id:5,name:"Eka Putri",nim:"2024010005",nt:78,nuts:75,nutsSystem:75,nutsManual:!1,np:80,uas:78}],2:[{id:6,name:"Fani Kusuma",nim:"2024010006",nt:82,nuts:80,nutsSystem:80,nutsManual:!1,np:null,uas:82},{id:7,name:"Gunawan Susilo",nim:"2024010007",nt:75,nuts:60,nutsSystem:60,nutsManual:!1,np:null,uas:75},{id:8,name:"Hesti Nurmala",nim:"2024010008",nt:88,nuts:85,nutsSystem:85,nutsManual:!1,np:null,uas:88}]},af=(r,c)=>c?r.nt*.1+r.nuts*.2+r.np*.2+r.uas*.5:r.nt*.1+r.nuts*.3+r.uas*.6,tf=r=>r>80?"A":r>75?"AB":r>69?"B":r>60?"BC":r>55?"C":r>44?"D":"E",nf=r=>r>80?4:r>75?3.5:r>69?3:r>60?2.5:r>55?2:r>44?1:0,X1=r=>{switch(r){case"A":case"AB":return"success";case"B":case"BC":return"warning";case"C":return"info";default:return"error"}};function V1(){const{user:r}=Le(),[c,u]=y.useState(Bo[0]),[o,h]=y.useState(Y1),[m,x]=y.useState(""),[g,b]=y.useState(null),[p,z]=y.useState({}),S=(o[c.id]||[]).filter(k=>k.name.toLowerCase().includes(m.toLowerCase())||k.nim.includes(m)),A=k=>{const Q=Bo.find($=>$.id===parseInt(k));u(Q),b(null)},v=k=>{b(k.id),z({nt:k.nt,nuts:k.nuts,np:k.np,uas:k.uas})},R=()=>{b(null),z({})},j=k=>{h(Q=>({...Q,[c.id]:Q[c.id].map($=>$.id===k?{...$,...p}:$)})),b(null),z({})},w=(k,Q)=>{const $=Math.min(100,Math.max(0,parseInt(Q)||0));z(k==="nuts"?_=>({..._,[k]:$,nutsManual:!0}):_=>({..._,[k]:$}))},C=()=>{let k=`No,NIM,Nama,NT (10%),NUTS (${c.hasPraktek?"20%":"30%"}),${c.hasPraktek?"NP (20%),":""}UAS (${c.hasPraktek?"50%":"60%"}),NAK,NH,Score
`;S.forEach((_,U)=>{const L=af(_,c.hasPraktek),K=tf(L),V=nf(L);c.hasPraktek?k+=`${U+1},"${_.nim}","${_.name}",${_.nt},${_.nuts},${_.np},${_.uas},${L.toFixed(2)},${K},${V}
`:k+=`${U+1},"${_.nim}","${_.name}",${_.nt},${_.nuts},${_.uas},${L.toFixed(2)},${K},${V}
`});const Q=new Blob([k],{type:"text/csv;charset=utf-8;"}),$=document.createElement("a");$.href=URL.createObjectURL(Q),$.download=`nilai_akhir_${c.nama.replace(/\s/g,"_")}_${c.kelas}.csv`,$.click()};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Nilai Akhir Semester"}),a.jsx("p",{className:"page-subtitle",children:"Perhitungan nilai akhir dengan bobot komponen"})]}),a.jsxs("button",{className:"btn btn-primary",onClick:C,children:[a.jsx(bs,{size:18}),"Export Nilai"]})]}),a.jsx("div",{className:"card mb-4",children:a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"matkul-selector",children:[a.jsx("label",{children:"Mata Kuliah:"}),a.jsx("select",{className:"form-input",value:c.id,onChange:k=>A(k.target.value),children:Bo.map(k=>a.jsxs("option",{value:k.id,children:[k.nama," - Kelas ",k.kelas]},k.id))})]})})}),a.jsxs("div",{className:"bobot-info-card mb-4",children:[a.jsx(Of,{size:18}),a.jsxs("div",{className:"bobot-content",children:[a.jsxs("strong",{children:["Rumus Nilai ",c.hasPraktek?"(Dengan Praktek)":"(Tanpa Praktek)",":"]}),c.hasPraktek?a.jsx("span",{children:"NT (10%) + NUTS (20%) + NP (20%) + UAS (50%) = NAK"}):a.jsx("span",{children:"NT (10%) + NUTS (30%) + UAS (60%) = NAK"})]})]}),a.jsxs("div",{className:"conversion-card mb-4",children:[a.jsx("div",{className:"conversion-header",children:"Konversi Nilai"}),a.jsxs("div",{className:"conversion-grid",children:[a.jsxs("div",{className:"conv-item",children:[a.jsx("span",{className:"nh success",children:"A"}),a.jsx("span",{children:">80-100"}),a.jsx("span",{className:"score",children:"4.0"})]}),a.jsxs("div",{className:"conv-item",children:[a.jsx("span",{className:"nh success",children:"AB"}),a.jsx("span",{children:">75-80"}),a.jsx("span",{className:"score",children:"3.5"})]}),a.jsxs("div",{className:"conv-item",children:[a.jsx("span",{className:"nh warning",children:"B"}),a.jsx("span",{children:">69-75"}),a.jsx("span",{className:"score",children:"3.0"})]}),a.jsxs("div",{className:"conv-item",children:[a.jsx("span",{className:"nh warning",children:"BC"}),a.jsx("span",{children:">60-69"}),a.jsx("span",{className:"score",children:"2.5"})]}),a.jsxs("div",{className:"conv-item",children:[a.jsx("span",{className:"nh info",children:"C"}),a.jsx("span",{children:">55-60"}),a.jsx("span",{className:"score",children:"2.0"})]}),a.jsxs("div",{className:"conv-item",children:[a.jsx("span",{className:"nh error",children:"D"}),a.jsx("span",{children:">44-55"}),a.jsx("span",{className:"score",children:"1.0"})]}),a.jsxs("div",{className:"conv-item",children:[a.jsx("span",{className:"nh error",children:"E"}),a.jsx("span",{children:"<44"}),a.jsx("span",{className:"score",children:"0"})]})]})]}),a.jsxs("div",{className:"card",children:[a.jsxs("div",{className:"card-header grades-header",children:[a.jsx("h3",{children:"Daftar Nilai Mahasiswa"}),a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:16}),a.jsx("input",{type:"text",placeholder:"Cari mahasiswa...",value:m,onChange:k=>x(k.target.value)})]})]}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"table-container table-scroll",children:a.jsxs("table",{className:"table grades-table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"No"}),a.jsx("th",{children:"Nama"}),a.jsx("th",{children:"NIM"}),a.jsxs("th",{className:"text-center",children:["NT",a.jsx("br",{}),a.jsx("small",{children:"10%"})]}),a.jsxs("th",{className:"text-center",children:["NUTS",a.jsx("br",{}),a.jsx("small",{children:c.hasPraktek?"20%":"30%"})]}),c.hasPraktek&&a.jsxs("th",{className:"text-center",children:["NP",a.jsx("br",{}),a.jsx("small",{children:"20%"})]}),a.jsxs("th",{className:"text-center",children:["UAS",a.jsx("br",{}),a.jsx("small",{children:c.hasPraktek?"50%":"60%"})]}),a.jsx("th",{className:"text-center",children:"NAK"}),a.jsx("th",{className:"text-center",children:"NH"}),a.jsx("th",{className:"text-center",children:"Score"}),a.jsx("th",{children:"Aksi"})]})}),a.jsx("tbody",{children:S.map((k,Q)=>{const $=g===k.id,_=$?p:k,U=af($?{...k,...p}:k,c.hasPraktek),L=tf(U),K=nf(U);return a.jsxs("tr",{children:[a.jsx("td",{children:Q+1}),a.jsx("td",{className:"font-medium",children:k.name}),a.jsx("td",{children:k.nim}),a.jsx("td",{className:"text-center",children:$?a.jsx("input",{type:"number",className:"grade-input",value:_.nt,onChange:V=>w("nt",V.target.value),min:"0",max:"100"}):k.nt}),a.jsx("td",{className:"text-center",children:$?a.jsx("input",{type:"number",className:"grade-input",value:_.nuts,onChange:V=>w("nuts",V.target.value),min:"0",max:"100"}):k.nuts}),c.hasPraktek&&a.jsx("td",{className:"text-center",children:$?a.jsx("input",{type:"number",className:"grade-input",value:_.np,onChange:V=>w("np",V.target.value),min:"0",max:"100"}):k.np}),a.jsx("td",{className:"text-center",children:$?a.jsx("input",{type:"number",className:"grade-input",value:_.uas,onChange:V=>w("uas",V.target.value),min:"0",max:"100"}):k.uas}),a.jsx("td",{className:"text-center",children:a.jsx("strong",{children:U.toFixed(2)})}),a.jsx("td",{className:"text-center",children:a.jsx("span",{className:`nh-badge ${X1(L)}`,children:L})}),a.jsx("td",{className:"text-center",children:a.jsx("strong",{children:K})}),a.jsx("td",{children:$?a.jsxs("div",{className:"action-btns",children:[a.jsx("button",{className:"btn btn-icon btn-success btn-sm",onClick:()=>j(k.id),children:a.jsx(il,{size:14})}),a.jsx("button",{className:"btn btn-icon btn-ghost btn-sm",onClick:R,children:a.jsx(Je,{size:14})})]}):a.jsxs("button",{className:"btn btn-ghost btn-sm",onClick:()=>v(k),children:[a.jsx(kt,{size:14}),"Edit"]})})]},k.id)})})]})})})]})]}),a.jsx("style",{children:`
                .page-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    flex-wrap: wrap;
                    gap: var(--space-4);
                    margin-bottom: var(--space-6);
                }
                .mb-4 {
                    margin-bottom: var(--space-4);
                }
                .matkul-selector {
                    display: flex;
                    align-items: center;
                    gap: var(--space-3);
                }
                .matkul-selector label {
                    font-weight: var(--font-medium);
                }
                .matkul-selector .form-input {
                    min-width: 300px;
                }
                .bobot-info-card {
                    display: flex;
                    align-items: center;
                    gap: var(--space-3);
                    padding: var(--space-4);
                    background: var(--info-50);
                    border: 1px solid var(--info-200);
                    border-radius: var(--radius-lg);
                    color: var(--info-700);
                }
                .bobot-content {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-1);
                }
                .bobot-content strong {
                    font-size: var(--font-size-sm);
                }
                .bobot-content span {
                    font-size: var(--font-size-sm);
                }
                .conversion-card {
                    background: var(--bg-secondary);
                    border: 1px solid var(--border-color);
                    border-radius: var(--radius-lg);
                    overflow: hidden;
                }
                .conversion-header {
                    padding: var(--space-3) var(--space-4);
                    background: var(--bg-tertiary);
                    font-weight: var(--font-semibold);
                    font-size: var(--font-size-sm);
                    border-bottom: 1px solid var(--border-color);
                }
                .conversion-grid {
                    display: flex;
                    flex-wrap: wrap;
                    padding: var(--space-3);
                    gap: var(--space-2);
                }
                .conv-item {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    padding: var(--space-2) var(--space-3);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-md);
                    font-size: var(--font-size-sm);
                }
                .conv-item .nh {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    width: 28px;
                    height: 28px;
                    border-radius: var(--radius-md);
                    font-weight: var(--font-bold);
                    color: white;
                }
                .conv-item .nh.success { background: var(--success-500); }
                .conv-item .nh.warning { background: var(--warning-500); }
                .conv-item .nh.info { background: var(--info-500); }
                .conv-item .nh.error { background: var(--error-500); }
                .conv-item .score {
                    font-weight: var(--font-bold);
                    color: var(--primary-600);
                }
                .grades-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    flex-wrap: wrap;
                    gap: var(--space-3);
                }
                .grades-header h3 {
                    margin: 0;
                }
                .grades-header .search-box {
                    display: flex;
                    align-items: center;
                    gap: var(--space-2);
                    padding: var(--space-2) var(--space-3);
                    background: var(--bg-tertiary);
                    border: 1px solid var(--border-color);
                    border-radius: var(--radius-md);
                }
                .grades-header .search-box input {
                    border: none;
                    background: transparent;
                    outline: none;
                    font-size: var(--font-size-sm);
                }
                .table-scroll {
                    overflow-x: auto;
                }
                .grades-table th {
                    white-space: nowrap;
                }
                .grades-table th small {
                    font-weight: normal;
                    color: var(--text-muted);
                }
                .text-center {
                    text-align: center;
                }
                .grade-input {
                    width: 50px;
                    padding: var(--space-1);
                    border: 2px solid var(--primary-300);
                    border-radius: var(--radius-md);
                    text-align: center;
                    font-size: var(--font-size-sm);
                }
                .grade-input:focus {
                    outline: none;
                    border-color: var(--primary-500);
                }
                .nh-badge {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    min-width: 32px;
                    padding: var(--space-1) var(--space-2);
                    border-radius: var(--radius-md);
                    font-weight: var(--font-bold);
                    color: white;
                }
                .nh-badge.success { background: var(--success-500); }
                .nh-badge.warning { background: var(--warning-500); }
                .nh-badge.info { background: var(--info-500); }
                .nh-badge.error { background: var(--error-500); }
                .action-btns {
                    display: flex;
                    gap: var(--space-1);
                }
                .btn-success {
                    background: var(--success-500);
                    color: white;
                    border: none;
                }
                .btn-success:hover {
                    background: var(--success-600);
                }
                @media (max-width: 768px) {
                    .matkul-selector {
                        flex-direction: column;
                        align-items: flex-start;
                    }
                    .matkul-selector .form-input {
                        min-width: 100%;
                    }
                    .conversion-grid {
                        justify-content: center;
                    }
                }
            `})]})}const lf=[{id:1,name:"UTS Navigasi Sungai",subject:"Navigasi",date:"2026-01-10",time:"09:00",duration:90,questions:50,status:"upcoming"},{id:2,name:"Quiz Keselamatan Pelayaran",subject:"Keselamatan",date:"2026-01-12",time:"13:00",duration:45,questions:25,status:"upcoming"}],J1=[{id:1,name:"UAS Teknik Perkapalan",date:"2025-12-20",score:85,status:"passed"},{id:2,name:"UTS Manajemen Transportasi",date:"2025-11-15",score:78,status:"passed"},{id:3,name:"Quiz Kelistrikan Kapal",date:"2025-11-01",score:92,status:"passed"}],Z1=[{label:"Ujian Selesai",value:"12",icon:We,color:"success"},{label:"Ujian Mendatang",value:"2",icon:va,color:"primary"},{label:"Rata-rata Nilai",value:"85",icon:Vt,color:"accent"},{label:"Menunggu Hasil",value:"1",icon:Ve,color:"warning"}];function W1(){const{user:r}=Le();return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsx("h1",{className:"page-title",children:"Dashboard Mahasiswa"}),a.jsxs("p",{className:"page-subtitle",children:["Selamat datang, ",r?.name,"! NIM: ",r?.nim]})]}),a.jsx("div",{className:"stats-grid",children:Z1.map((c,u)=>a.jsxs("div",{className:`stat-card stat-${c.color}`,children:[a.jsx("div",{className:"stat-icon",children:a.jsx(c.icon,{size:24})}),a.jsxs("div",{className:"stat-content",children:[a.jsx("span",{className:"stat-value",children:c.value}),a.jsx("span",{className:"stat-label",children:c.label})]})]},u))}),a.jsxs("div",{className:"dashboard-grid",children:[a.jsxs("div",{className:"card card-wide",children:[a.jsx("div",{className:"card-header",children:a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(Xi,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Ujian Mendatang"})]})}),a.jsx("div",{className:"card-body",children:lf.length>0?a.jsx("div",{className:"exam-cards",children:lf.map(c=>a.jsxs("div",{className:"exam-card",children:[a.jsxs("div",{className:"exam-card-header",children:[a.jsx("span",{className:"exam-subject",children:c.subject}),a.jsx("span",{className:"badge badge-primary",children:c.status==="upcoming"?"Mendatang":"Aktif"})]}),a.jsx("h4",{className:"exam-name",children:c.name}),a.jsxs("div",{className:"exam-details",children:[a.jsxs("div",{className:"exam-detail",children:[a.jsx(va,{size:14}),a.jsx("span",{children:c.date})]}),a.jsxs("div",{className:"exam-detail",children:[a.jsx(Ve,{size:14}),a.jsxs("span",{children:[c.time," | ",c.duration," menit"]})]})]}),a.jsxs("button",{className:"btn btn-primary btn-sm exam-start-btn",children:["Lihat Detail",a.jsx(sd,{size:16})]})]},c.id))}):a.jsxs("div",{className:"empty-state",children:[a.jsx(us,{size:48,className:"text-muted"}),a.jsx("p",{children:"Tidak ada ujian mendatang"})]})})]}),a.jsxs("div",{className:"card",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(Ja,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Hasil Ujian Terbaru"})]}),a.jsx("button",{className:"btn btn-ghost btn-sm",children:"Lihat Semua"})]}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"history-list",children:J1.map(c=>a.jsxs("div",{className:"history-item",children:[a.jsxs("div",{className:"history-info",children:[a.jsx("span",{className:"history-name",children:c.name}),a.jsx("span",{className:"history-date",children:c.date})]}),a.jsx("div",{className:`history-score ${c.score>=75?"score-pass":"score-fail"}`,children:c.score})]},c.id))})})]}),a.jsxs("div",{className:"card",children:[a.jsx("div",{className:"card-header",children:a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(qa,{size:20,className:"text-warning"}),a.jsx("h3",{className:"font-semibold",children:"Peraturan Ujian"})]})}),a.jsx("div",{className:"card-body",children:a.jsxs("ul",{className:"rules-list",children:[a.jsxs("li",{children:[a.jsx("strong",{children:"1."})," Mahasiswa wajib hadir 15 menit sebelum ujian dimulai"]}),a.jsxs("li",{children:[a.jsx("strong",{children:"2."})," Dilarang membawa alat komunikasi ke dalam ruang ujian"]}),a.jsxs("li",{children:[a.jsx("strong",{children:"3."})," Dilarang membuka tab/aplikasi lain selama ujian berlangsung"]}),a.jsxs("li",{children:[a.jsx("strong",{children:"4."})," Jawaban yang sudah dikumpulkan tidak dapat diubah"]}),a.jsxs("li",{children:[a.jsx("strong",{children:"5."})," Pelanggaran akan mengakibatkan diskualifikasi"]})]})})]})]})]}),a.jsx("style",{children:`
        .exam-cards {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: var(--space-4);
        }
        
        .exam-card {
          padding: var(--space-5);
          background: linear-gradient(135deg, var(--primary-50) 0%, var(--accent-50) 100%);
          border: 1px solid var(--border-color);
          border-radius: var(--radius-xl);
          transition: all var(--transition-normal);
        }
        
        [data-theme="dark"] .exam-card {
          background: linear-gradient(135deg, rgba(59, 103, 159, 0.1) 0%, rgba(0, 168, 168, 0.1) 100%);
        }
        
        .exam-card:hover {
          transform: translateY(-4px);
          box-shadow: var(--shadow-lg);
        }
        
        .exam-card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: var(--space-2);
        }
        
        .exam-subject {
          font-size: var(--font-size-xs);
          font-weight: var(--font-semibold);
          color: var(--primary-600);
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .exam-name {
          font-size: var(--font-size-lg);
          font-weight: var(--font-semibold);
          color: var(--text-primary);
          margin-bottom: var(--space-3);
        }
        
        .exam-details {
          display: flex;
          flex-direction: column;
          gap: var(--space-2);
          margin-bottom: var(--space-4);
        }
        
        .exam-detail {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          font-size: var(--font-size-sm);
          color: var(--text-secondary);
        }
        
        .exam-start-btn {
          width: 100%;
        }
        
        .history-list {
          display: flex;
          flex-direction: column;
          gap: var(--space-3);
        }
        
        .history-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: var(--space-3);
          background: var(--bg-tertiary);
          border-radius: var(--radius-lg);
        }
        
        .history-info {
          display: flex;
          flex-direction: column;
        }
        
        .history-name {
          font-size: var(--font-size-sm);
          font-weight: var(--font-medium);
          color: var(--text-primary);
        }
        
        .history-date {
          font-size: var(--font-size-xs);
          color: var(--text-muted);
        }
        
        .history-score {
          font-size: var(--font-size-lg);
          font-weight: var(--font-bold);
          padding: var(--space-2) var(--space-3);
          border-radius: var(--radius-lg);
        }
        
        .score-pass {
          background: var(--success-50);
          color: var(--success-600);
        }
        
        .score-fail {
          background: var(--error-50);
          color: var(--error-600);
        }
        
        .empty-state {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: var(--space-8);
          text-align: center;
          color: var(--text-muted);
        }
        
        .rules-list {
          list-style: none;
          display: flex;
          flex-direction: column;
          gap: var(--space-3);
        }
        
        .rules-list li {
          font-size: var(--font-size-sm);
          color: var(--text-secondary);
          padding: var(--space-2) var(--space-3);
          background: var(--warning-50);
          border-left: 3px solid var(--warning-500);
          border-radius: 0 var(--radius-md) var(--radius-md) 0;
        }
        
        [data-theme="dark"] .rules-list li {
          background: rgba(245, 158, 11, 0.1);
        }
        
        .rules-list li strong {
          color: var(--warning-600);
          margin-right: var(--space-2);
        }
      `})]})}const $o={name:"UTS Navigasi Sungai",duration:90,questions:[{id:1,type:"pilihan_ganda",text:"Apa yang dimaksud dengan navigasi sungai?",points:10,options:["Navigasi yang dilakukan di laut lepas","Navigasi di sungai dan perairan darat","Navigasi menggunakan sistem GPS","Navigasi dengan bantuan satelit"]},{id:2,type:"pilihan_ganda",text:"Berapa jarak aman minimal saat kapal akan bersandar di dermaga menurut standar keselamatan pelayaran?",points:15,options:["5 meter","10 meter","15 meter","20 meter"]},{id:3,type:"benar_salah",text:"Kapal feri termasuk jenis kapal penumpang yang digunakan untuk menyeberangkan penumpang dan kendaraan.",points:5},{id:4,type:"essay",text:"Jelaskan prosedur keselamatan dasar yang harus dipatuhi saat berlayar di perairan sungai. Sebutkan minimal 5 prosedur penting.",points:25},{id:5,type:"pilihan_ganda",text:"Alat navigasi yang digunakan untuk menentukan kedalaman air disebut?",points:10,options:["Kompas","Echosounder","Radar","GPS"]},{id:6,type:"benar_salah",text:"Arus sungai selalu mengalir dari hulu ke hilir dengan kecepatan yang konstan.",points:5},{id:7,type:"essay",text:"Sebutkan dan jelaskan 5 komponen utama sistem kelistrikan pada kapal.",points:30}]};function sf(){const{user:r}=Le(),[c,u]=y.useState(0),[o,h]=y.useState({}),[m,x]=y.useState(new Set),[g,b]=y.useState($o.duration*60),[p,z]=y.useState(!1),[N,S]=y.useState(!1),[A,v]=y.useState(0),[R,j]=y.useState(!1),[w,C]=y.useState(!1),[k,Q]=y.useState(!1),$=$o,_=$.questions[c],U=$.questions.length,L=Object.keys(o).length,K=m.size;y.useEffect(()=>{if(R||g<=0)return;const G=setInterval(()=>{b(W=>W<=1?(Oe(),0):W-1)},1e3);return()=>clearInterval(G)},[R,g]);const V=G=>{const W=Math.floor(G/3600),oe=Math.floor(G%3600/60),Ne=G%60;return W>0?`${W}:${oe.toString().padStart(2,"0")}:${Ne.toString().padStart(2,"0")}`:`${oe.toString().padStart(2,"0")}:${Ne.toString().padStart(2,"0")}`};y.useEffect(()=>{const G=()=>{document.hidden&&!R&&(v(W=>W+1),S(!0))};return document.addEventListener("visibilitychange",G),()=>document.removeEventListener("visibilitychange",G)},[R]),y.useEffect(()=>{const G=oe=>{oe.preventDefault(),v(Ne=>Ne+1)},W=oe=>{oe.preventDefault()};return document.addEventListener("copy",G),document.addEventListener("contextmenu",W),()=>{document.removeEventListener("copy",G),document.removeEventListener("contextmenu",W)}},[]);const X=y.useCallback(()=>{document.fullscreenElement?(document.exitFullscreen(),z(!1)):(document.documentElement.requestFullscreen(),z(!0))},[]),se=G=>{h(W=>({...W,[_.id]:G}))},xe=()=>{x(G=>{const W=new Set(G);return W.has(_.id)?W.delete(_.id):W.add(_.id),W})},ve=G=>{u(G),Q(!1)},Oe=()=>{j(!0),C(!1)},I=()=>{let G=0,W=0;return $.questions.forEach(oe=>{W+=oe.points,oe.type==="pilihan_ganda"&&o[oe.id]!==void 0&&o[oe.id]===1&&(G+=oe.points),oe.type==="benar_salah"&&o[oe.id]!==void 0&&o[oe.id]===!0&&(G+=oe.points)}),{score:G,total:W}};if(R){const{score:G,total:W}=I();return a.jsx("div",{className:"exam-result-page",children:a.jsxs("div",{className:"result-card animate-scaleIn",children:[a.jsx("div",{className:"result-icon success",children:a.jsx(We,{size:64})}),a.jsx("h1",{children:"Ujian Selesai!"}),a.jsx("p",{className:"result-exam-name",children:$.name}),a.jsxs("div",{className:"result-stats",children:[a.jsxs("div",{className:"result-stat",children:[a.jsxs("span",{className:"result-stat-value",children:[L,"/",U]}),a.jsx("span",{className:"result-stat-label",children:"Soal Dijawab"})]}),a.jsxs("div",{className:"result-stat",children:[a.jsx("span",{className:"result-stat-value",children:V($o.duration*60-g)}),a.jsx("span",{className:"result-stat-label",children:"Waktu Pengerjaan"})]}),a.jsxs("div",{className:"result-stat",children:[a.jsx("span",{className:"result-stat-value",children:A}),a.jsx("span",{className:"result-stat-label",children:"Peringatan"})]})]}),a.jsxs("div",{className:"result-score",children:[a.jsx("span",{className:"score-label",children:"Skor Sementara"}),a.jsx("span",{className:"score-value",children:G}),a.jsxs("span",{className:"score-total",children:["/ ",W]})]}),a.jsx("p",{className:"result-note",children:"Hasil akhir akan diumumkan setelah semua jawaban essay dikoreksi oleh dosen."}),a.jsx("a",{href:"/mahasiswa",className:"btn btn-primary btn-lg",children:"Kembali ke Dashboard"})]})})}return a.jsxs("div",{className:"take-exam-page",children:[N&&a.jsx("div",{className:"warning-overlay",children:a.jsxs("div",{className:"warning-modal animate-shake",children:[a.jsx(qa,{size:48,className:"warning-icon"}),a.jsx("h2",{children:"Peringatan!"}),a.jsx("p",{children:"Anda terdeteksi meninggalkan halaman ujian."}),a.jsxs("p",{children:["Peringatan ke-",A,". Aktivitas ini akan dilaporkan ke pengawas."]}),a.jsx("button",{className:"btn btn-primary",onClick:()=>S(!1),children:"Saya Mengerti"})]})}),w&&a.jsx("div",{className:"modal-overlay",children:a.jsxs("div",{className:"modal animate-scaleIn",children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("h3",{children:"Konfirmasi Submit"}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:()=>C(!1),children:a.jsx(Je,{size:20})})]}),a.jsxs("div",{className:"modal-body",children:[a.jsx("p",{children:"Apakah Anda yakin ingin mengakhiri ujian?"}),a.jsxs("div",{className:"submit-summary",children:[a.jsxs("div",{className:"summary-item",children:[a.jsx("span",{children:"Soal dijawab:"}),a.jsxs("span",{children:[L," dari ",U]})]}),a.jsxs("div",{className:"summary-item",children:[a.jsx("span",{children:"Soal ditandai:"}),a.jsx("span",{children:K})]}),a.jsxs("div",{className:"summary-item",children:[a.jsx("span",{children:"Sisa waktu:"}),a.jsx("span",{children:V(g)})]})]}),L<U&&a.jsxs("div",{className:"warning-text",children:[a.jsx(qa,{size:16}),a.jsxs("span",{children:["Masih ada ",U-L," soal yang belum dijawab!"]})]})]}),a.jsxs("div",{className:"modal-footer",children:[a.jsx("button",{className:"btn btn-ghost",onClick:()=>C(!1),children:"Kembali"}),a.jsxs("button",{className:"btn btn-primary",onClick:Oe,children:[a.jsx(Mp,{size:16}),"Submit Ujian"]})]})]})}),a.jsxs("header",{className:"exam-header",children:[a.jsxs("div",{className:"exam-info",children:[a.jsx("h1",{children:$.name}),a.jsxs("span",{className:"exam-student",children:[r?.name," • ",r?.nim]})]}),a.jsxs("div",{className:"exam-timer-container",children:[a.jsxs("div",{className:`exam-timer ${g<300?"warning":""} ${g<60?"danger":""}`,children:[a.jsx(Ve,{size:20}),a.jsx("span",{children:V(g)})]}),a.jsx("button",{className:"btn btn-icon btn-ghost",onClick:X,title:"Fullscreen",children:a.jsx(ej,{size:20})})]})]}),a.jsxs("div",{className:"exam-content",children:[a.jsxs("button",{className:"navigator-toggle",onClick:()=>Q(!k),children:["Navigasi Soal (",L,"/",U,")"]}),a.jsxs("aside",{className:`question-navigator ${k?"open":""}`,children:[a.jsxs("div",{className:"navigator-header",children:[a.jsx("h3",{children:"Navigasi Soal"}),a.jsx("button",{className:"btn btn-icon btn-ghost navigator-close",onClick:()=>Q(!1),children:a.jsx(Je,{size:20})})]}),a.jsx("div",{className:"question-grid",children:$.questions.map((G,W)=>a.jsxs("button",{className:`question-number-btn 
                  ${c===W?"current":""} 
                  ${o[G.id]!==void 0?"answered":""} 
                  ${m.has(G.id)?"flagged":""}
                `,onClick:()=>ve(W),children:[W+1,m.has(G.id)&&a.jsx(_p,{size:10,className:"flag-icon"})]},G.id))}),a.jsxs("div",{className:"navigator-legend",children:[a.jsxs("div",{className:"legend-item",children:[a.jsx("span",{className:"legend-dot current"}),a.jsx("span",{children:"Sekarang"})]}),a.jsxs("div",{className:"legend-item",children:[a.jsx("span",{className:"legend-dot answered"}),a.jsx("span",{children:"Dijawab"})]}),a.jsxs("div",{className:"legend-item",children:[a.jsx("span",{className:"legend-dot flagged"}),a.jsx("span",{children:"Ditandai"})]}),a.jsxs("div",{className:"legend-item",children:[a.jsx("span",{className:"legend-dot"}),a.jsx("span",{children:"Belum"})]})]}),a.jsxs("div",{className:"navigator-stats",children:[a.jsxs("div",{children:["Dijawab: ",a.jsxs("strong",{children:[L,"/",U]})]}),a.jsxs("div",{children:["Ditandai: ",a.jsx("strong",{children:K})]})]})]}),a.jsxs("main",{className:"question-area",children:[a.jsxs("div",{className:"question-card",children:[a.jsxs("div",{className:"question-header",children:[a.jsxs("div",{className:"question-meta",children:[a.jsxs("span",{className:"question-number",children:["Soal ",c+1," dari ",U]}),a.jsx("span",{className:`badge badge-${_.type==="pilihan_ganda"?"primary":_.type==="essay"?"accent":"success"}`,children:_.type==="pilihan_ganda"?"Pilihan Ganda":_.type==="essay"?"Essay":"Benar/Salah"}),a.jsxs("span",{className:"question-points",children:[_.points," poin"]})]}),a.jsxs("button",{className:`flag-btn ${m.has(_.id)?"flagged":""}`,onClick:xe,children:[a.jsx(_p,{size:18}),m.has(_.id)?"Ditandai":"Tandai"]})]}),a.jsx("div",{className:"question-text",children:a.jsx("p",{children:_.text})}),a.jsxs("div",{className:"answer-area",children:[_.type==="pilihan_ganda"&&a.jsx("div",{className:"options-list",children:_.options.map((G,W)=>a.jsxs("label",{className:`option-item ${o[_.id]===W?"selected":""}`,children:[a.jsx("input",{type:"radio",name:`question-${_.id}`,checked:o[_.id]===W,onChange:()=>se(W)}),a.jsx("span",{className:"option-letter",children:String.fromCharCode(65+W)}),a.jsx("span",{className:"option-text",children:G}),o[_.id]===W&&a.jsx(We,{size:20,className:"option-check"})]},W))}),_.type==="benar_salah"&&a.jsxs("div",{className:"true-false-options",children:[a.jsxs("label",{className:`tf-option ${o[_.id]===!0?"selected":""}`,children:[a.jsx("input",{type:"radio",name:`question-${_.id}`,checked:o[_.id]===!0,onChange:()=>se(!0)}),a.jsx(We,{size:24}),a.jsx("span",{children:"Benar"})]}),a.jsxs("label",{className:`tf-option ${o[_.id]===!1?"selected":""}`,children:[a.jsx("input",{type:"radio",name:`question-${_.id}`,checked:o[_.id]===!1,onChange:()=>se(!1)}),a.jsx(Je,{size:24}),a.jsx("span",{children:"Salah"})]})]}),_.type==="essay"&&a.jsxs("div",{className:"essay-area",children:[a.jsx("textarea",{className:"essay-input",placeholder:"Tulis jawaban Anda di sini...",value:o[_.id]||"",onChange:G=>se(G.target.value),rows:8}),a.jsxs("div",{className:"essay-info",children:[a.jsx(Ja,{size:14}),a.jsxs("span",{children:[(o[_.id]||"").length," karakter"]})]})]})]})]}),a.jsxs("div",{className:"question-navigation",children:[a.jsxs("button",{className:"btn btn-outline",disabled:c===0,onClick:()=>u(G=>G-1),children:[a.jsx(Ef,{size:18}),"Sebelumnya"]}),c<U-1?a.jsxs("button",{className:"btn btn-primary",onClick:()=>u(G=>G+1),children:["Selanjutnya",a.jsx(vs,{size:18})]}):a.jsxs("button",{className:"btn btn-accent",onClick:()=>C(!0),children:[a.jsx(Mp,{size:18}),"Submit Ujian"]})]})]})]})]})}const F1=[{id:1,name:"Quiz Sistem Propulsi Kapal",matkul:"Sistem Propulsi Kapal",dosen:"Dr. Ahmad Fauzi, M.T.",date:"2026-01-06",time:"20:00",endTime:"22:00",duration:120,questions:30,room:"Lab Komputer 1",completed:!1,description:"Quiz untuk materi Sistem Propulsi Kapal. Ujian ini SEDANG BERLANGSUNG dan dapat dikerjakan sekarang."},{id:2,name:"UTS Navigasi Sungai",matkul:"Navigasi Sungai",dosen:"Dr. Ahmad Fauzi, M.T.",date:"2026-01-07",time:"09:00",endTime:"11:00",duration:120,questions:50,room:"Lab Komputer 1",completed:!1,description:"Ujian Tengah Semester untuk mata kuliah Navigasi Sungai. Materi mencakup BAB 1-5."},{id:3,name:"Quiz Keselamatan Pelayaran",matkul:"Keselamatan Pelayaran",dosen:"Prof. Dr. Hendra Wijaya",date:"2026-01-12",time:"13:00",endTime:"14:00",duration:60,questions:25,room:"Ruang 2",completed:!1,description:"Quiz mingguan untuk materi Prosedur Keselamatan Dasar."},{id:4,name:"UAS Teknik Perkapalan",matkul:"Teknik Perkapalan",dosen:"Dr. Ahmad Fauzi, M.T.",date:"2026-01-20",time:"08:00",endTime:"10:30",duration:150,questions:75,room:"Lab Komputer 2",completed:!1,description:"Ujian Akhir Semester mencakup seluruh materi yang telah dipelajari."}];function ey(){const{user:r}=Le(),c=jn(),[u,o]=y.useState(F1),h=p=>{const z=new Date(p),N=new Date;N.setHours(0,0,0,0),z.setHours(0,0,0,0);const S=z-N;return Math.ceil(S/(1e3*60*60*24))},m=p=>{if(p.completed)return"completed";const z=new Date,N=new Date(`${p.date}T${p.time}`),S=new Date(`${p.date}T${p.endTime}`);return z>=N&&z<=S?"active":z>S?"expired":"upcoming"},x=p=>{const z=m(p);if(z==="completed")return a.jsxs("span",{className:"badge badge-success",children:[a.jsx(We,{size:12})," Sudah Dikerjakan"]});if(z==="active")return a.jsxs("span",{className:"badge badge-success",children:[a.jsx(Up,{size:12})," Sedang Berlangsung"]});if(z==="expired")return a.jsxs("span",{className:"badge badge-error",children:[a.jsx(us,{size:12})," Waktu Habis"]});const N=h(p.date);return N===0?a.jsxs("span",{className:"badge badge-warning",children:[a.jsx(Ve,{size:12})," Hari Ini"]}):N<=3?a.jsxs("span",{className:"badge badge-warning",children:[a.jsx(us,{size:12})," ",N," Hari Lagi"]}):a.jsxs("span",{className:"badge badge-info",children:[a.jsx(Ve,{size:12})," ",N," Hari Lagi"]})},g=p=>{c(`/mahasiswa/take-exam/${p.id}`)},b=p=>{const z=m(p);return z==="completed"?a.jsxs("button",{className:"btn btn-outline",disabled:!0,children:[a.jsx(We,{size:18}),"Sudah Dikerjakan"]}):z==="active"?a.jsxs("button",{className:"btn btn-primary",onClick:()=>g(p),children:[a.jsx(Up,{size:18}),"Mulai Ujian"]}):z==="expired"?a.jsxs("button",{className:"btn btn-outline",disabled:!0,children:[a.jsx(us,{size:18}),"Waktu Habis"]}):a.jsxs("button",{className:"btn btn-outline",disabled:!0,children:[a.jsx(Ve,{size:18}),"Belum Tersedia"]})};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsx("div",{className:"page-header",children:a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Jadwal Ujian"}),a.jsx("p",{className:"page-subtitle",children:"Daftar ujian yang akan dan sedang Anda ikuti"})]})}),a.jsxs("div",{className:"mini-stats",children:[a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:u.length}),a.jsx("span",{className:"mini-stat-label",children:"Total Ujian"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:u.filter(p=>m(p)==="active").length}),a.jsx("span",{className:"mini-stat-label",children:"Aktif"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:u.filter(p=>p.name.includes("UTS")).length}),a.jsx("span",{className:"mini-stat-label",children:"UTS"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:u.filter(p=>p.name.includes("UAS")).length}),a.jsx("span",{className:"mini-stat-label",children:"UAS"})]})]}),a.jsxs("div",{className:"exam-list",children:[u.map(p=>{const z=h(p.date),N=m(p),S=N==="active",A=N==="expired";return a.jsxs("div",{className:`exam-card-full ${S?"exam-today":z<=3&&!A?"exam-soon":""}`,children:[a.jsx("div",{className:"exam-card-header",children:a.jsxs("div",{className:"exam-badges",children:[a.jsx("span",{className:`badge badge-${p.name.includes("UTS")?"primary":p.name.includes("UAS")?"error":"accent"}`,children:p.name.includes("UTS")?"UTS":p.name.includes("UAS")?"UAS":"Quiz"}),x(p)]})}),a.jsxs("div",{className:"exam-card-body",children:[a.jsx("h3",{className:"exam-title",children:p.name}),a.jsxs("p",{className:"exam-matkul",children:[p.matkul," • ",p.dosen]}),a.jsxs("div",{className:"exam-details-grid",children:[a.jsxs("div",{className:"exam-detail-item",children:[a.jsx(va,{size:16}),a.jsxs("div",{children:[a.jsx("span",{className:"detail-label",children:"Tanggal"}),a.jsx("span",{className:"detail-value",children:new Date(p.date).toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"})})]})]}),a.jsxs("div",{className:"exam-detail-item",children:[a.jsx(Ve,{size:16}),a.jsxs("div",{children:[a.jsx("span",{className:"detail-label",children:"Waktu"}),a.jsxs("span",{className:"detail-value",children:[p.time," - ",p.endTime," (",p.duration," menit)"]})]})]}),a.jsxs("div",{className:"exam-detail-item",children:[a.jsx(cd,{size:16}),a.jsxs("div",{children:[a.jsx("span",{className:"detail-label",children:"Ruang"}),a.jsx("span",{className:"detail-value",children:p.room})]})]}),a.jsxs("div",{className:"exam-detail-item",children:[a.jsx(Xi,{size:16}),a.jsxs("div",{children:[a.jsx("span",{className:"detail-label",children:"Jumlah Soal"}),a.jsxs("span",{className:"detail-value",children:[p.questions," soal"]})]})]})]}),p.description&&a.jsx("p",{className:"exam-description",children:p.description})]}),a.jsx("div",{className:"exam-card-footer",children:b(p)})]},p.id)}),u.length===0&&a.jsxs("div",{className:"empty-state",children:[a.jsx(Xi,{size:48}),a.jsx("h3",{children:"Tidak ada ujian"}),a.jsx("p",{children:"Anda tidak memiliki jadwal ujian"})]})]})]}),a.jsx("style",{children:`
                .exam-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-4);
                }
                .exam-card-full {
                    background: var(--bg-secondary);
                    border: 1px solid var(--border-color);
                    border-radius: var(--radius-xl);
                    overflow: hidden;
                    transition: all var(--transition-normal);
                }
                .exam-card-full:hover {
                    box-shadow: var(--shadow-lg);
                    transform: translateY(-2px);
                }
                .exam-today {
                    border-color: var(--success-500);
                    background: linear-gradient(135deg, var(--success-50) 0%, var(--bg-secondary) 100%);
                }
                [data-theme="dark"] .exam-today {
                    background: linear-gradient(135deg, rgba(34, 197, 94, 0.1) 0%, var(--bg-secondary) 100%);
                }
                .exam-soon {
                    border-color: var(--warning-500);
                    background: linear-gradient(135deg, var(--warning-50) 0%, var(--bg-secondary) 100%);
                }
                [data-theme="dark"] .exam-soon {
                    background: linear-gradient(135deg, rgba(245, 158, 11, 0.1) 0%, var(--bg-secondary) 100%);
                }
                .exam-card-header {
                    padding: var(--space-4);
                    border-bottom: 1px solid var(--border-color);
                }
                .exam-badges {
                    display: flex;
                    gap: var(--space-2);
                }
                .exam-card-body {
                    padding: var(--space-4);
                }
                .exam-title {
                    font-size: var(--font-size-xl);
                    font-weight: var(--font-bold);
                    margin-bottom: var(--space-1);
                }
                .exam-matkul {
                    font-size: var(--font-size-sm);
                    color: var(--text-secondary);
                    margin-bottom: var(--space-4);
                }
                .exam-details-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: var(--space-3);
                    margin-bottom: var(--space-4);
                }
                .exam-detail-item {
                    display: flex;
                    align-items: flex-start;
                    gap: var(--space-2);
                    padding: var(--space-3);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-md);
                }
                .exam-detail-item svg {
                    color: var(--primary-500);
                    flex-shrink: 0;
                    margin-top: 2px;
                }
                .exam-detail-item > div {
                    display: flex;
                    flex-direction: column;
                }
                .detail-label {
                    font-size: var(--font-size-xs);
                    color: var(--text-muted);
                    text-transform: uppercase;
                }
                .detail-value {
                    font-size: var(--font-size-sm);
                    font-weight: var(--font-medium);
                }
                .exam-description {
                    font-size: var(--font-size-sm);
                    color: var(--text-secondary);
                    padding: var(--space-3);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-md);
                    border-left: 3px solid var(--primary-500);
                }
                .exam-card-footer {
                    padding: var(--space-4);
                    background: var(--bg-tertiary);
                    border-top: 1px solid var(--border-color);
                }
                .exam-card-footer .btn {
                    width: 100%;
                }
                .empty-state {
                    text-align: center;
                    padding: var(--space-12);
                    color: var(--text-muted);
                }
                .empty-state svg {
                    margin-bottom: var(--space-4);
                    opacity: 0.5;
                }
                .empty-state h3 {
                    margin-bottom: var(--space-2);
                    color: var(--text-secondary);
                }
            `})]})}const bn=[{id:1,name:"UTS Navigasi Sungai",matkul:"Navigasi Sungai",dosen:"Dr. Ahmad Fauzi, M.T.",date:"2026-01-04",type:"UTS",totalQuestions:50,correctAnswers:42,score:84,status:"graded",nt:85,nuts:84,np:null,uas:null,nak:null,nh:null},{id:2,name:"Quiz Keselamatan Pelayaran",matkul:"Keselamatan Pelayaran",dosen:"Prof. Dr. Hendra Wijaya",date:"2026-01-05",type:"Quiz",totalQuestions:25,correctAnswers:null,score:null,status:"pending",nt:null,nuts:null,np:null,uas:null,nak:null,nh:null},{id:3,name:"UAS Teknik Perkapalan",matkul:"Teknik Perkapalan",dosen:"Dr. Ahmad Fauzi, M.T.",date:"2025-12-20",type:"UAS",totalQuestions:60,correctAnswers:51,score:85,status:"graded",nt:80,nuts:78,np:82,uas:85,nak:82.4,nh:"A"}];function ay(){const{user:r}=Le(),[c,u]=y.useState(""),[o,h]=y.useState("all"),[m,x]=y.useState("all"),[g,b]=y.useState(null),p=bn.filter(v=>{const R=v.name.toLowerCase().includes(c.toLowerCase())||v.matkul.toLowerCase().includes(c.toLowerCase()),j=o==="all"||v.type===o,w=m==="all"||v.status===m;return R&&j&&w}),z=v=>v==="graded"?a.jsxs("span",{className:"badge badge-success",children:[a.jsx(We,{size:12})," Dinilai"]}):a.jsxs("span",{className:"badge badge-warning",children:[a.jsx(Ve,{size:12})," Belum Dinilai"]}),N=v=>v===null?"":v>=80?"score-excellent":v>=70?"score-good":v>=60?"score-average":"score-poor",S=v=>{const R=window.open("","_blank");R.document.write(`
            <html>
            <head>
                <title>Hasil Ujian - ${v.name}</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 40px; }
                    h1 { text-align: center; margin-bottom: 5px; font-size: 18px; }
                    h2 { text-align: center; font-size: 14px; color: #666; margin-bottom: 30px; }
                    .info-section { margin-bottom: 30px; }
                    .info-row { display: flex; margin-bottom: 10px; }
                    .info-label { width: 150px; font-weight: bold; }
                    .info-value { flex: 1; }
                    .score-section { text-align: center; margin: 30px 0; padding: 20px; border: 2px solid #333; }
                    .score-value { font-size: 48px; font-weight: bold; color: ${v.score>=70?"#22c55e":"#ef4444"}; }
                    .score-label { font-size: 14px; color: #666; }
                    .grade-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                    .grade-table th, .grade-table td { border: 1px solid #ccc; padding: 10px; text-align: center; }
                    .grade-table th { background: #f0f0f0; }
                    .footer { margin-top: 50px; text-align: right; }
                    .signature { margin-top: 60px; }
                </style>
            </head>
            <body>
                <h1>HASIL UJIAN</h1>
                <h2>POLTEKTRANS SDP PALEMBANG</h2>
                
                <div class="info-section">
                    <div class="info-row"><div class="info-label">Nama Mahasiswa</div><div class="info-value">: ${r?.name}</div></div>
                    <div class="info-row"><div class="info-label">NIM</div><div class="info-value">: ${r?.nim}</div></div>
                    <div class="info-row"><div class="info-label">Mata Kuliah</div><div class="info-value">: ${v.matkul}</div></div>
                    <div class="info-row"><div class="info-label">Jenis Ujian</div><div class="info-value">: ${v.name}</div></div>
                    <div class="info-row"><div class="info-label">Tanggal Ujian</div><div class="info-value">: ${v.date}</div></div>
                    <div class="info-row"><div class="info-label">Dosen Pengampu</div><div class="info-value">: ${v.dosen}</div></div>
                </div>
                
                ${v.status==="graded"?`
                    <div class="score-section">
                        <div class="score-value">${v.score}</div>
                        <div class="score-label">NILAI UJIAN</div>
                    </div>
                    
                    ${v.nak!==null?`
                        <table class="grade-table">
                            <thead>
                                <tr>
                                    <th>NT (10%)</th>
                                    <th>NUTS (${v.np!==null?"20%":"30%"})</th>
                                    ${v.np!==null?"<th>NP (20%)</th>":""}
                                    <th>UAS (${v.np!==null?"50%":"60%"})</th>
                                    <th>NAK</th>
                                    <th>NH</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>${v.nt??"-"}</td>
                                    <td>${v.nuts??"-"}</td>
                                    ${v.np!==null?`<td>${v.np}</td>`:""}
                                    <td>${v.uas??"-"}</td>
                                    <td><strong>${v.nak?.toFixed(1)??"-"}</strong></td>
                                    <td><strong>${v.nh??"-"}</strong></td>
                                </tr>
                            </tbody>
                        </table>
                    `:""}
                `:`
                    <div class="score-section">
                        <div class="score-value" style="color: #f59e0b;">-</div>
                        <div class="score-label">BELUM DINILAI</div>
                    </div>
                `}
                
                <div class="footer">
                    <p>Palembang, ${new Date().toLocaleDateString("id-ID")}</p>
                    <p>Dosen Pengampu,</p>
                    <div class="signature">
                        <p>${v.dosen}</p>
                    </div>
                </div>
            </body>
            </html>
        `),R.document.close(),R.print()},A=()=>{const v=bn.filter(j=>j.status==="graded");if(v.length===0){alert("Tidak ada hasil ujian yang sudah dinilai.");return}const R=window.open("","_blank");R.document.write(`
            <html>
            <head>
                <title>Rekap Hasil Ujian - ${r?.name}</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 40px; }
                    h1 { text-align: center; margin-bottom: 5px; font-size: 18px; }
                    h2 { text-align: center; font-size: 14px; color: #666; margin-bottom: 30px; }
                    .info-section { margin-bottom: 30px; }
                    .info-row { display: flex; margin-bottom: 8px; }
                    .info-label { width: 150px; font-weight: bold; }
                    .info-value { flex: 1; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
                    th { background: #3b679f; color: white; }
                    tr:nth-child(even) { background: #f5f5f5; }
                    .passing { color: #22c55e; font-weight: bold; }
                    .failing { color: #ef4444; font-weight: bold; }
                    .summary { margin-top: 30px; padding: 20px; background: #f0f8ff; border-radius: 8px; }
                    .footer { margin-top: 50px; text-align: right; }
                    .signature { margin-top: 60px; }
                </style>
            </head>
            <body>
                <h1>REKAP HASIL UJIAN</h1>
                <h2>POLTEKTRANS SDP PALEMBANG</h2>
                
                <div class="info-section">
                    <div class="info-row"><div class="info-label">Nama Mahasiswa</div><div class="info-value">: ${r?.name}</div></div>
                    <div class="info-row"><div class="info-label">NIM</div><div class="info-value">: ${r?.nim}</div></div>
                    <div class="info-row"><div class="info-label">Semester</div><div class="info-value">: Ganjil 2025/2026</div></div>
                </div>
                
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Mata Kuliah</th>
                            <th>Jenis Ujian</th>
                            <th>Tanggal</th>
                            <th>Dosen</th>
                            <th>Nilai</th>
                            <th>NAK</th>
                            <th>NH</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${v.map((j,w)=>`
                            <tr>
                                <td>${w+1}</td>
                                <td style="text-align: left;">${j.matkul}</td>
                                <td>${j.type}</td>
                                <td>${j.date}</td>
                                <td style="text-align: left;">${j.dosen}</td>
                                <td class="${j.score>=70?"passing":"failing"}">${j.score}</td>
                                <td>${j.nak?.toFixed(1)??"-"}</td>
                                <td><strong>${j.nh??"-"}</strong></td>
                            </tr>
                        `).join("")}
                    </tbody>
                </table>
                
                <div class="summary">
                    <strong>Ringkasan:</strong><br>
                    Total Ujian Dinilai: ${v.length}<br>
                    Rata-rata Nilai: ${(v.reduce((j,w)=>j+w.score,0)/v.length).toFixed(1)}
                </div>
                
                <div class="footer">
                    <p>Palembang, ${new Date().toLocaleDateString("id-ID")}</p>
                    <p>Ka. Prodi,</p>
                    <div class="signature">
                        <p>___________________</p>
                        <p>NIP.</p>
                    </div>
                </div>
            </body>
            </html>
        `),R.document.close(),R.print()};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Hasil Ujian"}),a.jsx("p",{className:"page-subtitle",children:"Lihat hasil ujian yang telah Anda ikuti"})]}),a.jsxs("button",{className:"btn btn-primary",onClick:A,children:[a.jsx(da,{size:16}),"Cetak Semua Hasil"]})]}),a.jsxs("div",{className:"mini-stats",children:[a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:bn.length}),a.jsx("span",{className:"mini-stat-label",children:"Total Ujian"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:bn.filter(v=>v.status==="graded").length}),a.jsx("span",{className:"mini-stat-label",children:"Sudah Dinilai"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:bn.filter(v=>v.status==="pending").length}),a.jsx("span",{className:"mini-stat-label",children:"Menunggu Nilai"})]}),a.jsxs("div",{className:"mini-stat",children:[a.jsx("span",{className:"mini-stat-value",children:Math.round(bn.filter(v=>v.score!==null).reduce((v,R)=>v+R.score,0)/bn.filter(v=>v.score!==null).length)||0}),a.jsx("span",{className:"mini-stat-label",children:"Rata-rata"})]})]}),a.jsx("div",{className:"card mb-4",children:a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"filters-row",children:[a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:18,className:"search-icon"}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Cari ujian...",value:c,onChange:v=>u(v.target.value)})]}),a.jsxs("div",{className:"filter-group",children:[a.jsx(et,{size:16}),a.jsxs("select",{className:"form-input",value:o,onChange:v=>h(v.target.value),children:[a.jsx("option",{value:"all",children:"Semua Jenis"}),a.jsx("option",{value:"UTS",children:"UTS"}),a.jsx("option",{value:"UAS",children:"UAS"}),a.jsx("option",{value:"Quiz",children:"Quiz"})]})]}),a.jsx("div",{className:"filter-group",children:a.jsxs("select",{className:"form-input",value:m,onChange:v=>x(v.target.value),children:[a.jsx("option",{value:"all",children:"Semua Status"}),a.jsx("option",{value:"graded",children:"Sudah Dinilai"}),a.jsx("option",{value:"pending",children:"Belum Dinilai"})]})})]})})}),a.jsx("div",{className:"card",children:a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"results-list",children:[p.map(v=>a.jsxs("div",{className:"result-card",children:[a.jsxs("div",{className:"result-main",children:[a.jsxs("div",{className:"result-info",children:[a.jsxs("div",{className:"result-header",children:[a.jsx("span",{className:`badge badge-${v.type==="UTS"?"primary":v.type==="UAS"?"error":"info"}`,children:v.type}),z(v.status)]}),a.jsx("h4",{className:"result-name",children:v.name}),a.jsxs("p",{className:"result-matkul",children:[v.matkul," • ",v.dosen]}),a.jsx("div",{className:"result-meta",children:a.jsxs("span",{children:[a.jsx(va,{size:14})," ",v.date]})})]}),a.jsx("div",{className:"result-score-section",children:v.status==="graded"?a.jsxs("div",{className:`result-score ${N(v.score)}`,children:[a.jsx("span",{className:"score-number",children:v.score}),a.jsx("span",{className:"score-label",children:"Nilai"})]}):a.jsxs("div",{className:"result-score score-pending",children:[a.jsx(Ve,{size:24}),a.jsx("span",{className:"score-label",children:"Menunggu"})]})})]}),a.jsx("div",{className:"result-actions",children:v.status==="graded"&&a.jsxs("button",{className:"btn btn-primary btn-sm",onClick:()=>S(v),children:[a.jsx(da,{size:14}),"Cetak Hasil"]})})]},v.id)),p.length===0&&a.jsxs("div",{className:"empty-state",children:[a.jsx(Vt,{size:48}),a.jsx("h3",{children:"Tidak ada hasil ujian"}),a.jsx("p",{children:"Belum ada ujian yang Anda ikuti"})]})]})})})]}),a.jsx("style",{children:`
                .mb-4 {
                    margin-bottom: var(--space-4);
                }
                .results-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-4);
                }
                .result-card {
                    padding: var(--space-4);
                    background: var(--bg-tertiary);
                    border-radius: var(--radius-lg);
                    border: 1px solid var(--border-color);
                }
                .result-main {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    gap: var(--space-4);
                }
                .result-info {
                    flex: 1;
                }
                .result-header {
                    display: flex;
                    gap: var(--space-2);
                    margin-bottom: var(--space-2);
                }
                .result-name {
                    font-size: var(--font-size-lg);
                    font-weight: var(--font-semibold);
                    margin-bottom: var(--space-1);
                }
                .result-matkul {
                    font-size: var(--font-size-sm);
                    color: var(--text-secondary);
                    margin-bottom: var(--space-2);
                }
                .result-meta {
                    display: flex;
                    gap: var(--space-3);
                    font-size: var(--font-size-sm);
                    color: var(--text-muted);
                }
                .result-meta span {
                    display: flex;
                    align-items: center;
                    gap: var(--space-1);
                }
                .result-score-section {
                    display: flex;
                    align-items: center;
                }
                .result-score {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    min-width: 80px;
                    padding: var(--space-3);
                    border-radius: var(--radius-lg);
                    text-align: center;
                }
                .score-number {
                    font-size: var(--font-size-2xl);
                    font-weight: var(--font-bold);
                }
                .score-label {
                    font-size: var(--font-size-xs);
                    text-transform: uppercase;
                }
                .score-excellent {
                    background: var(--success-100);
                    color: var(--success-700);
                }
                .score-good {
                    background: var(--primary-100);
                    color: var(--primary-700);
                }
                .score-average {
                    background: var(--warning-100);
                    color: var(--warning-700);
                }
                .score-poor {
                    background: var(--error-100);
                    color: var(--error-700);
                }
                .score-pending {
                    background: var(--bg-secondary);
                    color: var(--text-muted);
                }
                .result-actions {
                    display: flex;
                    gap: var(--space-2);
                    margin-top: var(--space-3);
                    padding-top: var(--space-3);
                    border-top: 1px solid var(--border-color);
                }
                .empty-state {
                    text-align: center;
                    padding: var(--space-8);
                    color: var(--text-muted);
                }
                .empty-state svg {
                    margin-bottom: var(--space-4);
                    opacity: 0.5;
                }
                .empty-state h3 {
                    margin-bottom: var(--space-2);
                    color: var(--text-secondary);
                }
            `})]})}const ty=[{label:"Ujian Berlangsung",value:"2",icon:od,color:"primary"},{label:"Peserta Aktif",value:"87",icon:ra,color:"success"},{label:"Peringatan",value:"5",icon:qa,color:"warning"},{label:"Selesai Hari Ini",value:"3",icon:We,color:"accent"}],ny=[{id:1,name:"UTS Navigasi Sungai",room:"Lab Komputer 1",startTime:"09:00",endTime:"10:30",participants:45,active:42,warnings:3},{id:2,name:"Quiz Keselamatan Pelayaran",room:"Lab Komputer 2",startTime:"09:00",endTime:"09:45",participants:52,active:45,warnings:2}],ly=[{id:1,student:"Budi Santoso",action:"Tab switch detected",time:"09:15",severity:"warning"},{id:2,student:"Ani Wijaya",action:"Fullscreen exit attempt",time:"09:12",severity:"warning"},{id:3,student:"Rizky Pratama",action:"Right-click attempt",time:"09:08",severity:"info"},{id:4,student:"Dewi Sartika",action:"Copy attempt blocked",time:"09:05",severity:"info"}];function sy(){const{user:r}=Le();return a.jsxs(Ee,{children:[a.jsxs("div",{className:"dashboard-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsx("h1",{className:"page-title",children:"Dashboard Pengawas"}),a.jsxs("p",{className:"page-subtitle",children:["Selamat datang, ",r?.name,"! Pantau ujian yang sedang berlangsung."]})]}),a.jsx("div",{className:"stats-grid",children:ty.map((c,u)=>a.jsxs("div",{className:`stat-card stat-${c.color}`,children:[a.jsx("div",{className:"stat-icon",children:a.jsx(c.icon,{size:24})}),a.jsxs("div",{className:"stat-content",children:[a.jsx("span",{className:"stat-value",children:c.value}),a.jsx("span",{className:"stat-label",children:c.label})]})]},u))}),a.jsxs("div",{className:"dashboard-grid",children:[a.jsxs("div",{className:"card card-wide",children:[a.jsx("div",{className:"card-header",children:a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(od,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Ujian Sedang Berlangsung"})]})}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"monitor-cards",children:ny.map(c=>a.jsxs("div",{className:"monitor-card",children:[a.jsxs("div",{className:"monitor-card-header",children:[a.jsxs("div",{children:[a.jsx("h4",{className:"monitor-exam-name",children:c.name}),a.jsx("p",{className:"monitor-exam-room",children:c.room})]}),a.jsx("span",{className:"badge badge-success animate-pulse",children:"LIVE"})]}),a.jsxs("div",{className:"monitor-stats",children:[a.jsxs("div",{className:"monitor-stat",children:[a.jsx(Ve,{size:16}),a.jsxs("span",{children:[c.startTime," - ",c.endTime]})]}),a.jsxs("div",{className:"monitor-stat",children:[a.jsx(ra,{size:16}),a.jsxs("span",{children:[c.active,"/",c.participants," aktif"]})]}),c.warnings>0&&a.jsxs("div",{className:"monitor-stat warning",children:[a.jsx(qa,{size:16}),a.jsxs("span",{children:[c.warnings," peringatan"]})]})]}),a.jsxs("div",{className:"monitor-progress",children:[a.jsx("div",{className:"progress",children:a.jsx("div",{className:"progress-bar",style:{width:`${c.active/c.participants*100}%`}})}),a.jsxs("span",{className:"monitor-progress-text",children:[Math.round(c.active/c.participants*100),"% aktif"]})]}),a.jsxs("button",{className:"btn btn-primary btn-sm",style:{width:"100%"},children:[a.jsx(Fa,{size:16}),"Monitor Ujian"]})]},c.id))})})]}),a.jsxs("div",{className:"card",children:[a.jsx("div",{className:"card-header",children:a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(Kf,{size:20,className:"text-secondary"}),a.jsx("h3",{className:"font-semibold",children:"Alert Terbaru"})]})}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"alert-list",children:ly.map(c=>a.jsxs("div",{className:`alert-item alert-${c.severity}`,children:[a.jsx("div",{className:"alert-icon",children:c.severity==="warning"?a.jsx(qa,{size:16}):a.jsx(Yo,{size:16})}),a.jsxs("div",{className:"alert-content",children:[a.jsx("span",{className:"alert-student",children:c.student}),a.jsx("span",{className:"alert-action",children:c.action})]}),a.jsx("span",{className:"alert-time",children:c.time})]},c.id))})})]})]})]}),a.jsx("style",{children:`
        .monitor-cards {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
          gap: var(--space-4);
        }
        
        .monitor-card {
          padding: var(--space-5);
          background: var(--bg-tertiary);
          border: 1px solid var(--border-color);
          border-radius: var(--radius-xl);
        }
        
        .monitor-card-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: var(--space-4);
        }
        
        .monitor-exam-name {
          font-size: var(--font-size-lg);
          font-weight: var(--font-semibold);
          color: var(--text-primary);
        }
        
        .monitor-exam-room {
          font-size: var(--font-size-sm);
          color: var(--text-muted);
        }
        
        .monitor-stats {
          display: flex;
          flex-wrap: wrap;
          gap: var(--space-4);
          margin-bottom: var(--space-4);
        }
        
        .monitor-stat {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          font-size: var(--font-size-sm);
          color: var(--text-secondary);
        }
        
        .monitor-stat.warning {
          color: var(--warning-600);
        }
        
        .monitor-progress {
          margin-bottom: var(--space-4);
        }
        
        .monitor-progress-text {
          font-size: var(--font-size-xs);
          color: var(--text-muted);
          display: block;
          margin-top: var(--space-2);
          text-align: right;
        }
        
        .alert-list {
          display: flex;
          flex-direction: column;
          gap: var(--space-3);
        }
        
        .alert-item {
          display: flex;
          align-items: center;
          gap: var(--space-3);
          padding: var(--space-3);
          background: var(--bg-tertiary);
          border-radius: var(--radius-lg);
          border-left: 3px solid;
        }
        
        .alert-warning {
          border-left-color: var(--warning-500);
        }
        
        .alert-info {
          border-left-color: var(--info-500);
        }
        
        .alert-icon {
          flex-shrink: 0;
        }
        
        .alert-warning .alert-icon {
          color: var(--warning-500);
        }
        
        .alert-info .alert-icon {
          color: var(--info-500);
        }
        
        .alert-content {
          flex: 1;
          min-width: 0;
          display: flex;
          flex-direction: column;
        }
        
        .alert-student {
          font-size: var(--font-size-sm);
          font-weight: var(--font-medium);
          color: var(--text-primary);
        }
        
        .alert-action {
          font-size: var(--font-size-xs);
          color: var(--text-muted);
        }
        
        .alert-time {
          font-size: var(--font-size-xs);
          color: var(--text-muted);
          flex-shrink: 0;
        }
      `})]})}const iy=[{id:1,name:"Lab Komputer 1",exam:"UTS Navigasi Sungai",startTime:"09:00",endTime:"10:30",pengawas:null,pengawasName:null,participants:25,status:"available"},{id:2,name:"Lab Komputer 2",exam:"Quiz Keselamatan Pelayaran",startTime:"09:00",endTime:"10:00",pengawas:4,pengawasName:"Drs. Bambang S.",participants:28,status:"occupied"},{id:3,name:"Ruang 2",exam:"UAS Teknik Perkapalan",startTime:"10:00",endTime:"12:00",pengawas:null,pengawasName:null,participants:22,status:"available"}],rf={totalQuestions:50},ry=[{id:1,name:"Budi Santoso",nim:"2024010001",status:"active",progress:35,currentQuestion:18,warnings:0,lastActivity:"Mengerjakan soal 18",startTime:"09:00"},{id:2,name:"Ani Wijaya",nim:"2024010002",status:"active",progress:42,currentQuestion:21,warnings:2,lastActivity:"Tab switch detected",startTime:"09:00"},{id:3,name:"Rizky Pratama",nim:"2024010003",status:"active",progress:28,currentQuestion:14,warnings:1,lastActivity:"Mengerjakan soal 14",startTime:"09:01"},{id:4,name:"Dewi Sartika",nim:"2024010004",status:"submitted",progress:100,currentQuestion:50,warnings:0,lastActivity:"Submitted",startTime:"09:00"},{id:5,name:"Eko Prasetyo",nim:"2024010005",status:"active",progress:15,currentQuestion:8,warnings:0,lastActivity:"Mengerjakan soal 8",startTime:"09:02"},{id:6,name:"Fitri Handayani",nim:"2024010006",status:"disconnected",progress:22,currentQuestion:11,warnings:1,lastActivity:"Connection lost",startTime:"09:00"},{id:7,name:"Gunawan Sucipto",nim:"2024010007",status:"active",progress:50,currentQuestion:25,warnings:0,lastActivity:"Mengerjakan soal 25",startTime:"09:00"},{id:8,name:"Hesti Nurmala",nim:"2024010008",status:"warning",progress:30,currentQuestion:15,warnings:3,lastActivity:"Multiple violations detected",startTime:"09:01"}],cy=[{id:1,studentId:2,student:"Ani Wijaya",action:"Tab switch detected",time:"09:15:32",severity:"warning"},{id:2,studentId:8,student:"Hesti Nurmala",action:"Copy attempt blocked",time:"09:14:45",severity:"warning"},{id:3,studentId:3,student:"Rizky Pratama",action:"Fullscreen exit attempt",time:"09:12:20",severity:"info"},{id:4,studentId:8,student:"Hesti Nurmala",action:"Right-click attempt",time:"09:10:15",severity:"info"},{id:5,studentId:6,student:"Fitri Handayani",action:"Connection lost",time:"09:08:00",severity:"error"},{id:6,studentId:8,student:"Hesti Nurmala",action:"Tab switch detected",time:"09:05:30",severity:"warning"}];function qo(){const{user:r}=Le(),[c,u]=y.useState(iy),[o,h]=y.useState(null),[m,x]=y.useState(ry),[g,b]=y.useState(cy),[p,z]=y.useState(""),[N,S]=y.useState("all"),[A,v]=y.useState(null),[R,j]=y.useState(!1),w=K=>!!(["superadmin","admin_prodi"].includes(r?.role)||K.status==="available"||K.pengawas===r?.id),C=K=>{if(!w(K)){alert(`Ruangan ini sudah diawasi oleh ${K.pengawasName}. Pengawas lain tidak dapat mengakses.`);return}r?.role==="pengawas"&&K.status==="available"&&u(V=>V.map(X=>X.id===K.id?{...X,status:"occupied",pengawas:r.id,pengawasName:r.name}:X)),h(K)},k=()=>{r?.role==="pengawas"&&o&&u(K=>K.map(V=>V.id===o.id?{...V,status:"available",pengawas:null,pengawasName:null}:V)),h(null)};y.useEffect(()=>{const K=setInterval(()=>{x(V=>V.map(X=>{if(X.status==="active"&&Math.random()>.7){const se=Math.min(X.progress+2,100),xe=Math.min(X.currentQuestion+1,rf.totalQuestions);return{...X,progress:se,currentQuestion:xe,lastActivity:`Mengerjakan soal ${xe}`}}return X}))},5e3);return()=>clearInterval(K)},[]);const Q=async()=>{j(!0),await new Promise(K=>setTimeout(K,1e3)),j(!1)},$=K=>{confirm("Apakah Anda yakin ingin mengeluarkan peserta ini dari ujian?")&&(x(V=>V.map(X=>X.id===K?{...X,status:"kicked"}:X)),b(V=>[{id:Date.now(),studentId:K,student:m.find(X=>X.id===K)?.name,action:"Kicked by supervisor",time:new Date().toLocaleTimeString("id-ID"),severity:"error"},...V]))},_=K=>{const V=m.find(X=>X.id===K);V&&(x(X=>X.map(se=>se.id===K?{...se,warnings:se.warnings+1}:se)),b(X=>[{id:Date.now(),studentId:K,student:V.name,action:"Warning sent by supervisor",time:new Date().toLocaleTimeString("id-ID"),severity:"warning"},...X]))},U=m.filter(K=>{const V=K.name.toLowerCase().includes(p.toLowerCase())||K.nim.includes(p),X=N==="all"||K.status===N;return V&&X}),L={total:m.length,active:m.filter(K=>K.status==="active").length,submitted:m.filter(K=>K.status==="submitted").length,issues:m.filter(K=>K.warnings>0||K.status==="disconnected"||K.status==="warning").length};return a.jsxs(Ee,{children:[a.jsx("div",{className:"dashboard-page animate-fadeIn",children:o?a.jsxs(a.Fragment,{children:[a.jsxs("div",{className:"monitor-header",children:[a.jsxs("div",{children:[a.jsx("button",{className:"btn btn-ghost btn-sm mb-2",onClick:k,children:"← Kembali ke Daftar Ruangan"}),a.jsx("h1",{className:"page-title",children:o.exam}),a.jsxs("p",{className:"page-subtitle",children:[o.name," • ",o.startTime," - ",o.endTime]})]}),a.jsxs("div",{className:"monitor-header-actions",children:[a.jsxs("div",{className:"exam-live-indicator",children:[a.jsx("span",{className:"live-dot"}),"LIVE"]}),a.jsxs("button",{className:`btn btn-outline btn-sm ${R?"loading":""}`,onClick:Q,children:[a.jsx(gj,{size:16,className:R?"spin":""}),"Refresh"]})]})]}),a.jsxs("div",{className:"monitor-stats-row",children:[a.jsxs("div",{className:"monitor-stat-card",children:[a.jsx(ra,{size:20}),a.jsxs("div",{children:[a.jsx("span",{className:"stat-value",children:L.total}),a.jsx("span",{className:"stat-label",children:"Total Peserta"})]})]}),a.jsxs("div",{className:"monitor-stat-card success",children:[a.jsx(Yo,{size:20}),a.jsxs("div",{children:[a.jsx("span",{className:"stat-value",children:L.active}),a.jsx("span",{className:"stat-label",children:"Sedang Mengerjakan"})]})]}),a.jsxs("div",{className:"monitor-stat-card primary",children:[a.jsx(We,{size:20}),a.jsxs("div",{children:[a.jsx("span",{className:"stat-value",children:L.submitted}),a.jsx("span",{className:"stat-label",children:"Sudah Submit"})]})]}),a.jsxs("div",{className:"monitor-stat-card warning",children:[a.jsx(qa,{size:20}),a.jsxs("div",{children:[a.jsx("span",{className:"stat-value",children:L.issues}),a.jsx("span",{className:"stat-label",children:"Perlu Perhatian"})]})]})]}),a.jsxs("div",{className:"monitor-content-grid",children:[a.jsxs("div",{className:"card monitor-participants-card",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(od,{size:20}),a.jsx("h3",{className:"font-semibold",children:"Daftar Peserta"})]}),a.jsxs("div",{className:"participant-filters",children:[a.jsxs("div",{className:"search-box-sm",children:[a.jsx(ba,{size:16}),a.jsx("input",{type:"text",placeholder:"Cari...",value:p,onChange:K=>z(K.target.value)})]}),a.jsxs("select",{className:"filter-select",value:N,onChange:K=>S(K.target.value),children:[a.jsx("option",{value:"all",children:"Semua Status"}),a.jsx("option",{value:"active",children:"Aktif"}),a.jsx("option",{value:"submitted",children:"Selesai"}),a.jsx("option",{value:"disconnected",children:"Terputus"}),a.jsx("option",{value:"warning",children:"Peringatan"})]})]})]}),a.jsx("div",{className:"card-body participant-list",children:U.map(K=>a.jsxs("div",{className:`participant-item ${K.status} ${A===K.id?"selected":""}`,onClick:()=>v(K.id),children:[a.jsxs("div",{className:"participant-avatar",children:[K.name.charAt(0),a.jsx("span",{className:`status-dot ${K.status}`})]}),a.jsxs("div",{className:"participant-info",children:[a.jsxs("div",{className:"participant-name",children:[K.name,K.warnings>0&&a.jsx("span",{className:"warning-badge",children:K.warnings})]}),a.jsxs("div",{className:"participant-meta",children:[K.nim," • Soal ",K.currentQuestion,"/",rf.totalQuestions]})]}),a.jsx("div",{className:"participant-progress",children:a.jsxs("div",{className:"progress-circle",children:[a.jsxs("svg",{viewBox:"0 0 36 36",children:[a.jsx("path",{className:"progress-bg",d:"M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"}),a.jsx("path",{className:"progress-fill",strokeDasharray:`${K.progress}, 100`,d:"M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"})]}),a.jsxs("span",{className:"progress-text",children:[K.progress,"%"]})]})}),a.jsxs("div",{className:"participant-actions",children:[a.jsx("button",{className:"action-btn warning",title:"Kirim Peringatan",onClick:V=>{V.stopPropagation(),_(K.id)},children:a.jsx(lj,{size:14})}),a.jsx("button",{className:"action-btn danger",title:"Keluarkan",onClick:V=>{V.stopPropagation(),$(K.id)},children:a.jsx(db,{size:14})})]})]},K.id))})]}),a.jsxs("div",{className:"card monitor-activity-card",children:[a.jsxs("div",{className:"card-header",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(Kf,{size:20}),a.jsx("h3",{className:"font-semibold",children:"Log Aktivitas"})]}),a.jsxs("span",{className:"activity-count",children:[g.length," kejadian"]})]}),a.jsx("div",{className:"card-body activity-log",children:g.map(K=>a.jsxs("div",{className:`activity-item ${K.severity}`,children:[a.jsx("div",{className:"activity-icon",children:K.severity==="error"?a.jsx(zb,{size:16}):K.severity==="warning"?a.jsx(qa,{size:16}):a.jsx(Yo,{size:16})}),a.jsxs("div",{className:"activity-content",children:[a.jsx("span",{className:"activity-student",children:K.student}),a.jsx("span",{className:"activity-action",children:K.action})]}),a.jsx("span",{className:"activity-time",children:K.time})]},K.id))})]})]})]}):a.jsxs(a.Fragment,{children:[a.jsx("div",{className:"page-header",children:a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Pilih Ruangan Ujian"}),a.jsx("p",{className:"page-subtitle",children:"Pilih ruangan yang akan Anda awasi"})]})}),a.jsx("div",{className:"room-selection-grid",children:c.map(K=>a.jsxs("div",{className:`room-card ${K.status} ${w(K)?"":"locked"}`,onClick:()=>C(K),children:[a.jsxs("div",{className:"room-header",children:[a.jsx(cd,{size:20}),a.jsx("h3",{children:K.name}),K.status==="occupied"&&a.jsx(Hf,{size:16,className:"lock-icon"})]}),a.jsx("div",{className:"room-exam",children:K.exam}),a.jsxs("div",{className:"room-time",children:[a.jsx(Ve,{size:14}),K.startTime," - ",K.endTime]}),a.jsxs("div",{className:"room-participants",children:[a.jsx(ra,{size:14}),K.participants," Peserta"]}),K.status==="occupied"&&a.jsxs("div",{className:"room-pengawas",children:[a.jsx(Fa,{size:14}),"Diawasi oleh: ",K.pengawasName]}),a.jsx("div",{className:`room-status-badge ${K.status}`,children:K.status==="available"?"Tersedia":"Sedang Diawasi"})]},K.id))})]})}),a.jsx("style",{children:`
        .monitor-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: var(--space-6);
          flex-wrap: wrap;
          gap: var(--space-4);
        }
        
        .monitor-header-actions {
          display: flex;
          align-items: center;
          gap: var(--space-3);
        }
        
        .exam-live-indicator {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          padding: var(--space-2) var(--space-4);
          background: var(--error-50);
          color: var(--error-600);
          border-radius: var(--radius-full);
          font-size: var(--font-size-xs);
          font-weight: var(--font-bold);
          letter-spacing: 1px;
        }
        
        .live-dot {
          width: 8px;
          height: 8px;
          background: var(--error-500);
          border-radius: 50%;
          animation: pulse 1.5s ease-in-out infinite;
        }
        
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        .spin {
          animation: spin 1s linear infinite;
        }
        
        .monitor-stats-row {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
          gap: var(--space-4);
          margin-bottom: var(--space-6);
        }
        
        .monitor-stat-card {
          display: flex;
          align-items: center;
          gap: var(--space-4);
          padding: var(--space-4);
          background: var(--bg-secondary);
          border-radius: var(--radius-lg);
          border: 1px solid var(--border-color);
        }
        
        .monitor-stat-card svg {
          color: var(--text-muted);
        }
        
        .monitor-stat-card.success svg { color: var(--success-500); }
        .monitor-stat-card.primary svg { color: var(--primary-500); }
        .monitor-stat-card.warning svg { color: var(--warning-500); }
        
        .stat-value {
          display: block;
          font-size: var(--font-size-xl);
          font-weight: var(--font-bold);
          color: var(--text-primary);
        }
        
        .stat-label {
          font-size: var(--font-size-xs);
          color: var(--text-muted);
        }
        
        .monitor-content-grid {
          display: grid;
          grid-template-columns: 2fr 1fr;
          gap: var(--space-6);
        }
        
        @media (max-width: 1024px) {
          .monitor-content-grid {
            grid-template-columns: 1fr;
          }
        }
        
        .participant-filters {
          display: flex;
          gap: var(--space-3);
        }
        
        .search-box-sm {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          padding: var(--space-2) var(--space-3);
          background: var(--bg-tertiary);
          border: 1px solid var(--border-color);
          border-radius: var(--radius-lg);
        }
        
        .search-box-sm input {
          border: none;
          background: transparent;
          outline: none;
          font-size: var(--font-size-sm);
          color: var(--text-primary);
          width: 120px;
        }
        
        .search-box-sm svg {
          color: var(--text-muted);
        }
        
        .filter-select {
          padding: var(--space-2) var(--space-3);
          background: var(--bg-tertiary);
          border: 1px solid var(--border-color);
          border-radius: var(--radius-lg);
          font-size: var(--font-size-sm);
          color: var(--text-primary);
          cursor: pointer;
        }
        
        .participant-list {
          display: flex;
          flex-direction: column;
          gap: var(--space-2);
          max-height: 500px;
          overflow-y: auto;
        }
        
        .participant-item {
          display: flex;
          align-items: center;
          gap: var(--space-3);
          padding: var(--space-3);
          border-radius: var(--radius-lg);
          cursor: pointer;
          transition: all var(--transition-fast);
          border: 2px solid transparent;
        }
        
        .participant-item:hover {
          background: var(--bg-tertiary);
        }
        
        .participant-item.selected {
          background: var(--primary-50);
          border-color: var(--primary-300);
        }
        
        .participant-item.warning {
          background: var(--warning-50);
        }
        
        .participant-item.disconnected {
          opacity: 0.6;
        }
        
        .participant-avatar {
          position: relative;
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, var(--primary-500), var(--accent-500));
          color: white;
          border-radius: 50%;
          font-weight: var(--font-semibold);
          flex-shrink: 0;
        }
        
        .status-dot {
          position: absolute;
          bottom: 0;
          right: 0;
          width: 12px;
          height: 12px;
          border-radius: 50%;
          border: 2px solid var(--bg-secondary);
        }
        
        .status-dot.active { background: var(--success-500); }
        .status-dot.submitted { background: var(--primary-500); }
        .status-dot.disconnected { background: var(--error-500); }
        .status-dot.warning { background: var(--warning-500); }
        .status-dot.kicked { background: var(--gray-500); }
        
        .participant-info {
          flex: 1;
          min-width: 0;
        }
        
        .participant-name {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          font-size: var(--font-size-sm);
          font-weight: var(--font-medium);
          color: var(--text-primary);
        }
        
        .warning-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 18px;
          height: 18px;
          background: var(--warning-500);
          color: white;
          border-radius: 50%;
          font-size: 10px;
          font-weight: var(--font-bold);
        }
        
        .participant-meta {
          font-size: var(--font-size-xs);
          color: var(--text-muted);
        }
        
        .participant-progress {
          flex-shrink: 0;
        }
        
        .progress-circle {
          position: relative;
          width: 44px;
          height: 44px;
        }
        
        .progress-circle svg {
          width: 100%;
          height: 100%;
          transform: rotate(-90deg);
        }
        
        .progress-bg {
          fill: none;
          stroke: var(--border-color);
          stroke-width: 3;
        }
        
        .progress-fill {
          fill: none;
          stroke: var(--primary-500);
          stroke-width: 3;
          stroke-linecap: round;
        }
        
        .progress-text {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          font-size: 10px;
          font-weight: var(--font-bold);
          color: var(--text-primary);
        }
        
        .participant-actions {
          display: flex;
          gap: var(--space-1);
        }
        
        .action-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 28px;
          height: 28px;
          border: none;
          border-radius: var(--radius-md);
          cursor: pointer;
          transition: all var(--transition-fast);
        }
        
        .action-btn.warning {
          background: var(--warning-50);
          color: var(--warning-600);
        }
        
        .action-btn.danger {
          background: var(--error-50);
          color: var(--error-600);
        }
        
        .action-btn:hover {
          transform: scale(1.1);
        }
        
        .activity-count {
          font-size: var(--font-size-xs);
          color: var(--text-muted);
        }
        
        .activity-log {
          display: flex;
          flex-direction: column;
          gap: var(--space-2);
          max-height: 500px;
          overflow-y: auto;
        }
        
        .activity-item {
          display: flex;
          align-items: flex-start;
          gap: var(--space-3);
          padding: var(--space-3);
          background: var(--bg-tertiary);
          border-radius: var(--radius-lg);
          border-left: 3px solid;
        }
        
        .activity-item.error { border-left-color: var(--error-500); }
        .activity-item.warning { border-left-color: var(--warning-500); }
        .activity-item.info { border-left-color: var(--info-500); }
        
        .activity-icon {
          flex-shrink: 0;
          margin-top: 2px;
        }
        
        .activity-item.error .activity-icon { color: var(--error-500); }
        .activity-item.warning .activity-icon { color: var(--warning-500); }
        .activity-item.info .activity-icon { color: var(--info-500); }
        
        .activity-content {
          flex: 1;
          min-width: 0;
        }
        
        .activity-student {
          display: block;
          font-size: var(--font-size-sm);
          font-weight: var(--font-medium);
          color: var(--text-primary);
        }
        
        .activity-action {
          font-size: var(--font-size-xs);
          color: var(--text-muted);
        }
        
        .activity-time {
          font-size: var(--font-size-xs);
          color: var(--text-muted);
          white-space: nowrap;
        }
        
        [data-theme="dark"] .exam-live-indicator {
          background: rgba(239, 68, 68, 0.15);
        }
        
        [data-theme="dark"] .participant-item.selected {
          background: rgba(59, 103, 159, 0.15);
        }
        
        [data-theme="dark"] .participant-item.warning {
          background: rgba(245, 158, 11, 0.15);
        }
        
        [data-theme="dark"] .action-btn.warning {
          background: rgba(245, 158, 11, 0.15);
        }
        
        [data-theme="dark"] .action-btn.danger {
          background: rgba(239, 68, 68, 0.15);
        }
        
        /* Room Selection Styles */
        .room-selection-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: var(--space-4);
        }
        .room-card {
          padding: var(--space-5);
          background: var(--bg-secondary);
          border: 2px solid var(--border-color);
          border-radius: var(--radius-xl);
          cursor: pointer;
          transition: all var(--transition-normal);
        }
        .room-card:hover {
          transform: translateY(-4px);
          box-shadow: var(--shadow-lg);
          border-color: var(--primary-300);
        }
        .room-card.available {
          border-left: 4px solid var(--success-500);
        }
        .room-card.occupied {
          border-left: 4px solid var(--warning-500);
          background: var(--warning-50);
        }
        .room-card.locked {
          opacity: 0.7;
          cursor: not-allowed;
        }
        .room-header {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          margin-bottom: var(--space-3);
        }
        .room-header h3 {
          flex: 1;
          margin: 0;
          font-size: var(--font-size-lg);
        }
        .lock-icon {
          color: var(--warning-600);
        }
        .room-exam {
          font-weight: var(--font-semibold);
          color: var(--primary-600);
          margin-bottom: var(--space-3);
        }
        .room-time, .room-participants, .room-pengawas {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          font-size: var(--font-size-sm);
          color: var(--text-secondary);
          margin-bottom: var(--space-2);
        }
        .room-pengawas {
          color: var(--warning-600);
          font-weight: var(--font-medium);
        }
        .room-status-badge {
          display: inline-block;
          padding: var(--space-1) var(--space-3);
          border-radius: var(--radius-full);
          font-size: var(--font-size-xs);
          font-weight: var(--font-semibold);
          margin-top: var(--space-3);
        }
        .room-status-badge.available {
          background: var(--success-100);
          color: var(--success-700);
        }
        .room-status-badge.occupied {
          background: var(--warning-100);
          color: var(--warning-700);
        }
        [data-theme="dark"] .room-card.occupied {
          background: rgba(245, 158, 11, 0.1);
        }
        .mb-2 {
          margin-bottom: var(--space-2);
        }
      `})]})}const cf=[{id:1,name:"Ruang 1",capacity:25},{id:2,name:"Ruang 2",capacity:25}],oy=[{id:1,kode:"DPS",nama:"D4 Pengelolaan Pelabuhan dan Pelayaran Sungai",color:"#ef4444"},{id:2,kode:"DTL",nama:"D4 Transportasi Laut",color:"#3b82f6"},{id:3,kode:"LLASDP",nama:"D3 LLASDP",color:"#22c55e"},{id:4,kode:"DKP",nama:"D4 Kepelautan",color:"#a855f7"}],os={name:"UTS Navigasi Sungai",date:"2026-01-06",time:"09:00 - 10:30"},Io={1:[{id:1,examNumber:"UJIAN-001",name:"Budi Santoso",nim:"2024010001",prodiId:1,isWorking:!0},{id:2,examNumber:"UJIAN-002",name:"Rizky Pratama",nim:"2024020001",prodiId:2,isWorking:!0},{id:5,examNumber:"UJIAN-003",name:"Eko Prasetyo",nim:"2024030001",prodiId:3,isWorking:!1},{id:6,examNumber:"UJIAN-004",name:"Fitri Handayani",nim:"2024040001",prodiId:4,isWorking:!0},{id:4,examNumber:"UJIAN-005",name:"Dewi Sartika",nim:"2024010003",prodiId:1,isWorking:!0},{id:8,examNumber:"UJIAN-006",name:"Hana Permata",nim:"2024020002",prodiId:2,isWorking:!1},{id:9,examNumber:"UJIAN-007",name:"Irfan Hakim",nim:"2024030002",prodiId:3,isWorking:!0},{id:10,examNumber:"UJIAN-008",name:"Joko Widodo",nim:"2024040002",prodiId:4,isWorking:!0},{id:11,examNumber:"UJIAN-009",name:"Kartini Dewi",nim:"2024010005",prodiId:1,isWorking:!0},{id:12,examNumber:"UJIAN-010",name:"Lukman Hakim",nim:"2024020003",prodiId:2,isWorking:!0}],2:[{id:26,examNumber:"UJIAN-026",name:"Zara Amelia",nim:"2024040006",prodiId:4,isWorking:!0},{id:27,examNumber:"UJIAN-027",name:"Ahmad Fauzi",nim:"2024010009",prodiId:1,isWorking:!1},{id:28,examNumber:"UJIAN-028",name:"Bella Cantika",nim:"2024020007",prodiId:2,isWorking:!0},{id:29,examNumber:"UJIAN-029",name:"Candra Wijaya",nim:"2024030007",prodiId:3,isWorking:!0},{id:30,examNumber:"UJIAN-030",name:"Diana Sari",nim:"2024040007",prodiId:4,isWorking:!1}]},of=[{value:"",label:"Pilih Keterangan"},{value:"sakit",label:"Sakit"},{value:"izin",label:"Izin Khusus"},{value:"alpha",label:"Tanpa Keterangan"}];function dy(){const{settings:r}=Wa(),{user:c}=Le(),[u,o]=y.useState(""),[h,m]=y.useState(""),[x,g]=y.useState({}),b=y.useRef(null),p=u?Io[u]||[]:[],z=p.filter(C=>C.name.toLowerCase().includes(h.toLowerCase())||C.nim.includes(h)||C.examNumber.includes(h.toUpperCase())),N=C=>{o(C);const k=Io[C]||[],Q={};k.forEach($=>{Q[$.id]={status:$.isWorking?"hadir":"tidak_hadir",reason:$.isWorking?"":"alpha"}}),g(Q)},S=(C,k)=>{g(Q=>({...Q,[C]:{...Q[C],status:k,reason:k==="hadir"?"":Q[C]?.reason||"alpha"}}))},A=(C,k)=>{g(Q=>({...Q,[C]:{...Q[C],reason:k}}))},v=C=>oy.find(Q=>Q.id===C)||{kode:"-",color:"#6b7280"},R=()=>cf.find(C=>C.id===Number(u)),j={total:p.length,hadir:Object.values(x).filter(C=>C.status==="hadir").length,sakit:Object.values(x).filter(C=>C.status==="tidak_hadir"&&C.reason==="sakit").length,izin:Object.values(x).filter(C=>C.status==="tidak_hadir"&&C.reason==="izin").length,alpha:Object.values(x).filter(C=>C.status==="tidak_hadir"&&C.reason==="alpha").length},w=()=>{const C=b.current,k=document.body.innerHTML;document.body.innerHTML=C.innerHTML,window.print(),document.body.innerHTML=k,window.location.reload()};return a.jsxs(Ee,{children:[a.jsxs("div",{className:"attendance-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Kehadiran Peserta Ujian"}),a.jsx("p",{className:"page-subtitle",children:"Absensi dan pencatatan kehadiran peserta per ruangan"})]}),a.jsx("div",{className:"page-actions",children:u&&a.jsxs("button",{className:"btn btn-primary",onClick:w,children:[a.jsx(da,{size:18}),"Print Daftar Hadir"]})})]}),a.jsx("div",{className:"card mb-4",children:a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"room-selector",children:[a.jsxs("div",{className:"selector-item",children:[a.jsx("label",{children:"Pilih Ruangan:"}),a.jsxs("select",{className:"form-input",value:u,onChange:C=>N(C.target.value),children:[a.jsx("option",{value:"",children:"-- Pilih Ruang --"}),cf.map(C=>a.jsxs("option",{value:C.id,children:[C.name," (",Io[C.id]?.length||0," peserta)"]},C.id))]})]}),u&&a.jsxs(a.Fragment,{children:[a.jsxs("div",{className:"selector-item",children:[a.jsx("label",{children:"Sesi Ujian:"}),a.jsx("span",{className:"session-info",children:os.name})]}),a.jsxs("div",{className:"selector-item",children:[a.jsx("label",{children:"Waktu:"}),a.jsx("span",{className:"session-info",children:os.time})]})]})]})})}),u?a.jsxs(a.Fragment,{children:[a.jsxs("div",{className:"attendance-stats",children:[a.jsxs("div",{className:"att-stat",children:[a.jsx("span",{className:"att-stat-value",children:j.total}),a.jsx("span",{className:"att-stat-label",children:"Total"})]}),a.jsxs("div",{className:"att-stat success",children:[a.jsx("span",{className:"att-stat-value",children:j.hadir}),a.jsx("span",{className:"att-stat-label",children:"Hadir"})]}),a.jsxs("div",{className:"att-stat warning",children:[a.jsx("span",{className:"att-stat-value",children:j.sakit}),a.jsx("span",{className:"att-stat-label",children:"Sakit"})]}),a.jsxs("div",{className:"att-stat info",children:[a.jsx("span",{className:"att-stat-value",children:j.izin}),a.jsx("span",{className:"att-stat-label",children:"Izin"})]}),a.jsxs("div",{className:"att-stat error",children:[a.jsx("span",{className:"att-stat-value",children:j.alpha}),a.jsx("span",{className:"att-stat-label",children:"Alpha"})]})]}),a.jsx("div",{className:"search-filter card mb-4",children:a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"search-box",children:[a.jsx(ba,{size:18,className:"search-icon"}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Cari nama, NIM, atau no. peserta...",value:h,onChange:C=>m(C.target.value)})]})})}),a.jsxs("div",{className:"card",children:[a.jsx("div",{className:"card-header",children:a.jsxs("h3",{children:[R()?.name," - Daftar Hadir"]})}),a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"table-container",children:a.jsxs("table",{className:"table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{style:{width:"50px"},children:"No"}),a.jsx("th",{children:"No. Peserta"}),a.jsx("th",{children:"Nama"}),a.jsx("th",{children:"NIM"}),a.jsx("th",{children:"Prodi"}),a.jsx("th",{style:{width:"120px"},children:"Status"}),a.jsx("th",{style:{width:"180px"},children:"Keterangan"})]})}),a.jsx("tbody",{children:z.map((C,k)=>{const Q=x[C.id]||{status:"tidak_hadir",reason:"alpha"},$=v(C.prodiId);return a.jsxs("tr",{children:[a.jsx("td",{children:k+1}),a.jsx("td",{children:a.jsx("span",{className:"badge badge-primary",children:C.examNumber})}),a.jsx("td",{className:"font-medium",children:C.name}),a.jsx("td",{children:C.nim}),a.jsx("td",{children:a.jsx("span",{className:"prodi-badge",style:{background:`${$.color}20`,color:$.color},children:$.kode})}),a.jsx("td",{children:a.jsxs("div",{className:"status-toggle",children:[a.jsx("button",{className:`toggle-btn hadir ${Q.status==="hadir"?"active":""}`,onClick:()=>S(C.id,"hadir"),children:a.jsx(il,{size:14})}),a.jsx("button",{className:`toggle-btn tidak ${Q.status==="tidak_hadir"?"active":""}`,onClick:()=>S(C.id,"tidak_hadir"),children:a.jsx(Je,{size:14})})]})}),a.jsx("td",{children:Q.status==="tidak_hadir"?a.jsx("select",{className:"form-input form-input-sm",value:Q.reason,onChange:_=>A(C.id,_.target.value),children:of.map(_=>a.jsx("option",{value:_.value,children:_.label},_.value))}):a.jsx("span",{className:"text-success",children:"-"})})]},C.id)})})]})})})]})]}):a.jsx("div",{className:"empty-state card",children:a.jsxs("div",{className:"card-body",children:[a.jsx(ms,{size:64}),a.jsx("h3",{children:"Pilih Ruangan"}),a.jsx("p",{children:"Pilih ruangan ujian untuk melihat dan mengelola kehadiran peserta"})]})})]}),a.jsx("div",{style:{display:"none"},children:a.jsxs("div",{ref:b,children:[a.jsx("style",{children:`
                        @page { size: A4 portrait; margin: 15mm; }
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        body { font-family: 'Times New Roman', serif; font-size: 11pt; }
                        .print-header {
                            display: flex;
                            align-items: center;
                            gap: 15px;
                            border-bottom: 3px double #000;
                            padding-bottom: 10px;
                            margin-bottom: 20px;
                        }
                        .print-logo {
                            width: 60px;
                            height: 60px;
                            object-fit: contain;
                        }
                        .print-logo-placeholder {
                            width: 60px;
                            height: 60px;
                            background: #333;
                            border-radius: 8px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            color: white;
                            font-weight: bold;
                            font-size: 16pt;
                        }
                        .print-institution {
                            flex: 1;
                            text-align: center;
                        }
                        .print-institution h2 {
                            font-size: 14pt;
                            margin: 0;
                            text-transform: uppercase;
                        }
                        .print-institution p {
                            font-size: 10pt;
                            margin: 3px 0 0;
                        }
                        .print-title {
                            text-align: center;
                            margin: 20px 0;
                        }
                        .print-title h3 {
                            font-size: 13pt;
                            text-decoration: underline;
                            margin-bottom: 10px;
                        }
                        .print-info {
                            margin-bottom: 15px;
                        }
                        .print-info table {
                            border-collapse: collapse;
                        }
                        .print-info td {
                            padding: 3px 10px 3px 0;
                            vertical-align: top;
                        }
                        .print-table {
                            width: 100%;
                            border-collapse: collapse;
                            margin: 15px 0;
                        }
                        .print-table th, .print-table td {
                            border: 1px solid #000;
                            padding: 6px 8px;
                            text-align: left;
                        }
                        .print-table th {
                            background: #f0f0f0;
                            font-weight: bold;
                            text-align: center;
                        }
                        .print-table td.center {
                            text-align: center;
                        }
                        .print-summary {
                            margin: 20px 0;
                        }
                        .print-summary table {
                            border-collapse: collapse;
                        }
                        .print-summary td {
                            padding: 3px 20px 3px 0;
                        }
                        .print-footer {
                            margin-top: 40px;
                            display: flex;
                            justify-content: space-between;
                        }
                        .print-sign {
                            text-align: center;
                            width: 200px;
                        }
                        .print-sign-line {
                            border-bottom: 1px solid #000;
                            margin-top: 60px;
                            margin-bottom: 5px;
                        }
                    `}),a.jsxs("div",{className:"print-header",children:[r?.logoUrl?a.jsx("img",{src:r.logoUrl,alt:"Logo",className:"print-logo"}):a.jsx("div",{className:"print-logo-placeholder",children:"CAT"}),a.jsxs("div",{className:"print-institution",children:[a.jsx("h2",{children:r?.institution||"Politeknik Transportasi SDP Palembang"}),a.jsx("p",{children:r?.address||"Jl. Residen Abdul Rozak, Palembang"}),r?.phone&&a.jsxs("p",{children:["Telp: ",r.phone]})]})]}),a.jsx("div",{className:"print-title",children:a.jsx("h3",{children:"DAFTAR HADIR PESERTA UJIAN"})}),a.jsx("div",{className:"print-info",children:a.jsx("table",{children:a.jsxs("tbody",{children:[a.jsxs("tr",{children:[a.jsx("td",{children:"Mata Ujian"}),a.jsxs("td",{children:[": ",os.name]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Ruangan"}),a.jsxs("td",{children:[": ",R()?.name]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Hari/Tanggal"}),a.jsxs("td",{children:[": ",new Date(os.date).toLocaleDateString("id-ID",{weekday:"long",year:"numeric",month:"long",day:"numeric"})]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Waktu"}),a.jsxs("td",{children:[": ",os.time]})]})]})})}),a.jsxs("table",{className:"print-table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{style:{width:"40px"},children:"No"}),a.jsx("th",{children:"No. Peserta"}),a.jsx("th",{children:"Nama"}),a.jsx("th",{children:"NIM"}),a.jsx("th",{style:{width:"80px"},children:"Hadir"}),a.jsx("th",{style:{width:"120px"},children:"Keterangan"})]})}),a.jsx("tbody",{children:p.map((C,k)=>{const Q=x[C.id]||{status:"tidak_hadir",reason:"alpha"},$=of.find(_=>_.value===Q.reason)?.label||"-";return a.jsxs("tr",{children:[a.jsx("td",{className:"center",children:k+1}),a.jsx("td",{children:C.examNumber}),a.jsx("td",{children:C.name}),a.jsx("td",{children:C.nim}),a.jsx("td",{className:"center",children:Q.status==="hadir"?"✓":"-"}),a.jsx("td",{children:Q.status==="tidak_hadir"?$:"-"})]},C.id)})})]}),a.jsx("div",{className:"print-summary",children:a.jsx("table",{children:a.jsxs("tbody",{children:[a.jsxs("tr",{children:[a.jsx("td",{children:a.jsx("strong",{children:"Jumlah Hadir"})}),a.jsxs("td",{children:[": ",j.hadir," orang"]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:a.jsx("strong",{children:"Sakit"})}),a.jsxs("td",{children:[": ",j.sakit," orang"]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:a.jsx("strong",{children:"Izin"})}),a.jsxs("td",{children:[": ",j.izin," orang"]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:a.jsx("strong",{children:"Tanpa Keterangan"})}),a.jsxs("td",{children:[": ",j.alpha," orang"]})]})]})})}),a.jsxs("div",{className:"print-footer",children:[a.jsx("div",{}),a.jsxs("div",{className:"print-sign",children:[a.jsxs("p",{children:["Palembang, ",new Date().toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"})]}),a.jsx("p",{children:"Pengawas Ujian,"}),a.jsx("div",{className:"print-sign-line"}),a.jsx("p",{children:a.jsx("strong",{children:c?.name||"________________________"})})]})]})]})}),a.jsx("style",{children:`
                .attendance-page { padding: 0; }
                .page-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    flex-wrap: wrap;
                    gap: 1rem;
                    margin-bottom: 1.5rem;
                }
                .page-actions { display: flex; gap: 0.75rem; }
                .mb-4 { margin-bottom: 1.5rem; }
                .room-selector {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 2rem;
                    align-items: center;
                }
                .selector-item {
                    display: flex;
                    align-items: center;
                    gap: 0.75rem;
                }
                .selector-item label {
                    font-weight: 500;
                    color: var(--color-text-secondary);
                }
                .selector-item .form-input {
                    min-width: 200px;
                }
                .session-info {
                    font-weight: 600;
                    color: var(--color-primary);
                }
                .empty-state {
                    text-align: center;
                    padding: 4rem 2rem;
                    color: var(--color-text-muted);
                }
                .empty-state h3 {
                    margin: 1rem 0 0.5rem;
                    color: var(--color-text);
                }
                .attendance-stats {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 1rem;
                    margin-bottom: 1.5rem;
                }
                .att-stat {
                    background: var(--color-surface);
                    border: 1px solid var(--color-border);
                    border-radius: 0.75rem;
                    padding: 1rem 1.5rem;
                    text-align: center;
                    min-width: 100px;
                }
                .att-stat-value {
                    display: block;
                    font-size: 1.5rem;
                    font-weight: 700;
                    color: var(--color-text);
                }
                .att-stat-label {
                    font-size: 0.75rem;
                    color: var(--color-text-muted);
                }
                .att-stat.success .att-stat-value { color: var(--color-success); }
                .att-stat.warning .att-stat-value { color: var(--color-warning); }
                .att-stat.info .att-stat-value { color: var(--color-info); }
                .att-stat.error .att-stat-value { color: var(--color-error); }
                .search-box {
                    position: relative;
                }
                .search-box .search-icon {
                    position: absolute;
                    left: 1rem;
                    top: 50%;
                    transform: translateY(-50%);
                    color: var(--color-text-muted);
                }
                .search-box .form-input {
                    padding-left: 2.75rem;
                }
                .card-header {
                    padding: 1rem 1.5rem;
                    border-bottom: 1px solid var(--color-border);
                }
                .card-header h3 {
                    margin: 0;
                    font-size: 1rem;
                }
                .prodi-badge {
                    display: inline-block;
                    padding: 0.25rem 0.5rem;
                    border-radius: 0.375rem;
                    font-size: 0.75rem;
                    font-weight: 600;
                }
                .status-toggle {
                    display: flex;
                    gap: 0.25rem;
                }
                .toggle-btn {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    width: 32px;
                    height: 32px;
                    border: 2px solid var(--color-border);
                    border-radius: 0.5rem;
                    background: var(--color-surface);
                    cursor: pointer;
                    transition: all 0.2s;
                }
                .toggle-btn.hadir.active {
                    background: var(--color-success);
                    border-color: var(--color-success);
                    color: white;
                }
                .toggle-btn.tidak.active {
                    background: var(--color-error);
                    border-color: var(--color-error);
                    color: white;
                }
                .toggle-btn:hover {
                    transform: scale(1.05);
                }
                .form-input-sm {
                    padding: 0.375rem 0.5rem;
                    font-size: 0.875rem;
                }
                .text-success { color: var(--color-success); }
                @media (max-width: 768px) {
                    .page-header { flex-direction: column; }
                    .room-selector { flex-direction: column; align-items: flex-start; gap: 1rem; }
                    .selector-item { flex-direction: column; align-items: flex-start; }
                }
            `})]})}const df=[{id:1,name:"Ruang 1",capacity:25},{id:2,name:"Ruang 2",capacity:25}],Po={name:"UTS Navigasi Sungai",subject:"Navigasi Sungai",date:"2026-01-06"},uy={1:{total:10,hadir:8,sakit:1,izin:0,alpha:1},2:{total:5,hadir:3,sakit:0,izin:1,alpha:1}};function my(){const{settings:r}=Wa(),{user:c}=Le(),[u,o]=y.useState(""),[h,m]=y.useState({examName:Po.name,subject:Po.subject,date:Po.date,startTime:"09:00",endTime:"10:30",incidents:"",notes:"",supervisorName:c?.name||"",supervisorNIP:""}),x=y.useRef(null),g=()=>df.find(S=>S.id===Number(u)),b=()=>uy[u]||{total:0,hadir:0,sakit:0,izin:0,alpha:0},p=(S,A)=>{m(v=>({...v,[S]:A}))},z=()=>{const S=x.current,A=document.body.innerHTML;document.body.innerHTML=S.innerHTML,window.print(),document.body.innerHTML=A,window.location.reload()},N=b();return a.jsxs(Ee,{children:[a.jsxs("div",{className:"berita-acara-page animate-fadeIn",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsx("h1",{className:"page-title",children:"Berita Acara Ujian"}),a.jsx("p",{className:"page-subtitle",children:"Formulir laporan pelaksanaan ujian"})]}),a.jsx("div",{className:"page-actions",children:u&&a.jsxs("button",{className:"btn btn-primary",onClick:z,children:[a.jsx(da,{size:18}),"Print Berita Acara"]})})]}),a.jsx("div",{className:"card mb-4",children:a.jsx("div",{className:"card-body",children:a.jsx("div",{className:"room-selector",children:a.jsxs("div",{className:"selector-item",children:[a.jsx("label",{children:"Pilih Ruangan:"}),a.jsxs("select",{className:"form-input",value:u,onChange:S=>o(S.target.value),children:[a.jsx("option",{value:"",children:"-- Pilih Ruang --"}),df.map(S=>a.jsx("option",{value:S.id,children:S.name},S.id))]})]})})})}),u?a.jsxs("div",{className:"form-grid",children:[a.jsxs("div",{className:"card",children:[a.jsx("div",{className:"card-header",children:a.jsxs("h3",{children:[a.jsx(Ve,{size:18})," Informasi Ujian"]})}),a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Nama Ujian"}),a.jsx("input",{type:"text",className:"form-input",value:h.examName,onChange:S=>p("examName",S.target.value)})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Mata Kuliah"}),a.jsx("input",{type:"text",className:"form-input",value:h.subject,onChange:S=>p("subject",S.target.value)})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Tanggal"}),a.jsx("input",{type:"date",className:"form-input",value:h.date,onChange:S=>p("date",S.target.value)})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Ruangan"}),a.jsx("input",{type:"text",className:"form-input",value:g()?.name||"",disabled:!0})]})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Waktu Mulai"}),a.jsx("input",{type:"time",className:"form-input",value:h.startTime,onChange:S=>p("startTime",S.target.value)})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Waktu Selesai"}),a.jsx("input",{type:"time",className:"form-input",value:h.endTime,onChange:S=>p("endTime",S.target.value)})]})]})]})]}),a.jsxs("div",{className:"card",children:[a.jsx("div",{className:"card-header",children:a.jsxs("h3",{children:[a.jsx(ra,{size:18})," Rekapitulasi Kehadiran"]})}),a.jsx("div",{className:"card-body",children:a.jsxs("div",{className:"attendance-recap",children:[a.jsxs("div",{className:"recap-item",children:[a.jsx("span",{className:"recap-label",children:"Jumlah Peserta Terdaftar"}),a.jsxs("span",{className:"recap-value",children:[N.total," orang"]})]}),a.jsxs("div",{className:"recap-item success",children:[a.jsx("span",{className:"recap-label",children:"Hadir"}),a.jsxs("span",{className:"recap-value",children:[N.hadir," orang"]})]}),a.jsxs("div",{className:"recap-item warning",children:[a.jsx("span",{className:"recap-label",children:"Sakit"}),a.jsxs("span",{className:"recap-value",children:[N.sakit," orang"]})]}),a.jsxs("div",{className:"recap-item info",children:[a.jsx("span",{className:"recap-label",children:"Izin Khusus"}),a.jsxs("span",{className:"recap-value",children:[N.izin," orang"]})]}),a.jsxs("div",{className:"recap-item error",children:[a.jsx("span",{className:"recap-label",children:"Tanpa Keterangan"}),a.jsxs("span",{className:"recap-value",children:[N.alpha," orang"]})]})]})})]}),a.jsxs("div",{className:"card card-wide",children:[a.jsx("div",{className:"card-header",children:a.jsxs("h3",{children:[a.jsx(us,{size:18})," Catatan Kejadian"]})}),a.jsxs("div",{className:"card-body",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Kejadian Penting Selama Ujian"}),a.jsx("textarea",{className:"form-input form-textarea",rows:4,placeholder:"Tuliskan kejadian penting yang terjadi selama ujian berlangsung (jika tidak ada, tulis 'Tidak ada kejadian khusus')...",value:h.incidents,onChange:S=>p("incidents",S.target.value)})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Catatan Tambahan"}),a.jsx("textarea",{className:"form-input form-textarea",rows:3,placeholder:"Catatan tambahan lainnya (opsional)...",value:h.notes,onChange:S=>p("notes",S.target.value)})]})]})]}),a.jsxs("div",{className:"card card-wide",children:[a.jsx("div",{className:"card-header",children:a.jsxs("h3",{children:[a.jsx(We,{size:18})," Data Pengawas"]})}),a.jsxs("div",{className:"card-body",children:[a.jsx("p",{className:"text-sm text-muted mb-3",children:"Data pengawas diambil otomatis dari akun yang login."}),a.jsxs("div",{className:"form-row",children:[a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Nama Terang Pengawas"}),a.jsx("input",{type:"text",className:"form-input",value:c?.name||"",readOnly:!0,style:{background:"var(--bg-tertiary)"}})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"NIP"}),a.jsx("input",{type:"text",className:"form-input",value:c?.nip||"198501012010011001",readOnly:!0,style:{background:"var(--bg-tertiary)"}})]})]})]})]})]}):a.jsx("div",{className:"empty-state card",children:a.jsxs("div",{className:"card-body",children:[a.jsx(Ja,{size:64}),a.jsx("h3",{children:"Pilih Ruangan"}),a.jsx("p",{children:"Pilih ruangan ujian untuk mengisi berita acara"})]})})]}),a.jsx("div",{style:{display:"none"},children:a.jsxs("div",{ref:x,children:[a.jsx("style",{children:`
                        @page { size: A4 portrait; margin: 20mm; }
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        body { font-family: 'Times New Roman', serif; font-size: 12pt; line-height: 1.5; }
                        .print-header {
                            display: flex;
                            align-items: center;
                            gap: 15px;
                            border-bottom: 3px double #000;
                            padding-bottom: 15px;
                            margin-bottom: 25px;
                        }
                        .print-logo {
                            width: 70px;
                            height: 70px;
                            object-fit: contain;
                        }
                        .print-logo-placeholder {
                            width: 70px;
                            height: 70px;
                            background: #333;
                            border-radius: 8px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            color: white;
                            font-weight: bold;
                            font-size: 18pt;
                        }
                        .print-institution {
                            flex: 1;
                            text-align: center;
                        }
                        .print-institution h2 {
                            font-size: 16pt;
                            margin: 0;
                            text-transform: uppercase;
                        }
                        .print-institution p {
                            font-size: 11pt;
                            margin: 3px 0 0;
                        }
                        .print-title {
                            text-align: center;
                            margin: 25px 0;
                        }
                        .print-title h3 {
                            font-size: 14pt;
                            text-decoration: underline;
                            margin-bottom: 5px;
                        }
                        .print-title p {
                            font-size: 11pt;
                        }
                        .print-section {
                            margin-bottom: 20px;
                        }
                        .print-section h4 {
                            font-size: 12pt;
                            margin-bottom: 10px;
                            border-bottom: 1px solid #ccc;
                            padding-bottom: 5px;
                        }
                        .print-info-table {
                            width: 100%;
                            border-collapse: collapse;
                        }
                        .print-info-table td {
                            padding: 5px 0;
                            vertical-align: top;
                        }
                        .print-info-table td:first-child {
                            width: 180px;
                        }
                        .print-attendance-table {
                            width: 100%;
                            border-collapse: collapse;
                            margin: 10px 0;
                        }
                        .print-attendance-table th,
                        .print-attendance-table td {
                            border: 1px solid #000;
                            padding: 8px 12px;
                            text-align: left;
                        }
                        .print-attendance-table th {
                            background: #f0f0f0;
                        }
                        .print-attendance-table td:last-child {
                            text-align: center;
                        }
                        .print-notes {
                            background: #fafafa;
                            border: 1px solid #ddd;
                            padding: 15px;
                            min-height: 80px;
                            margin-top: 10px;
                        }
                        .print-footer {
                            margin-top: 50px;
                            display: flex;
                            justify-content: flex-end;
                        }
                        .print-sign {
                            text-align: center;
                            width: 250px;
                        }
                        .print-sign-line {
                            border-bottom: 1px solid #000;
                            margin-top: 80px;
                            margin-bottom: 5px;
                        }
                        .print-sign p {
                            margin: 3px 0;
                        }
                    `}),a.jsxs("div",{className:"print-header",children:[r?.logoUrl?a.jsx("img",{src:r.logoUrl,alt:"Logo",className:"print-logo"}):a.jsx("div",{className:"print-logo-placeholder",children:"CAT"}),a.jsxs("div",{className:"print-institution",children:[a.jsx("h2",{children:r?.institution||"Politeknik Transportasi SDP Palembang"}),a.jsx("p",{children:r?.address||"Jl. Residen Abdul Rozak, Palembang"}),r?.phone&&a.jsxs("p",{children:["Telp: ",r.phone," | Email: ",r?.email]})]})]}),a.jsxs("div",{className:"print-title",children:[a.jsx("h3",{children:"BERITA ACARA PELAKSANAAN UJIAN"}),a.jsxs("p",{children:["Nomor: ......../BA-UJIAN/",new Date().getFullYear()]})]}),a.jsxs("div",{className:"print-section",children:[a.jsx("h4",{children:"I. Informasi Ujian"}),a.jsx("table",{className:"print-info-table",children:a.jsxs("tbody",{children:[a.jsxs("tr",{children:[a.jsx("td",{children:"Nama Ujian"}),a.jsxs("td",{children:[": ",h.examName]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Mata Kuliah"}),a.jsxs("td",{children:[": ",h.subject]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Hari/Tanggal"}),a.jsxs("td",{children:[": ",new Date(h.date).toLocaleDateString("id-ID",{weekday:"long",year:"numeric",month:"long",day:"numeric"})]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Waktu Pelaksanaan"}),a.jsxs("td",{children:[": ",h.startTime," - ",h.endTime," WIB"]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Ruangan"}),a.jsxs("td",{children:[": ",g()?.name]})]})]})})]}),a.jsxs("div",{className:"print-section",children:[a.jsx("h4",{children:"II. Rekapitulasi Kehadiran"}),a.jsxs("table",{className:"print-attendance-table",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"Keterangan"}),a.jsx("th",{children:"Jumlah"})]})}),a.jsxs("tbody",{children:[a.jsxs("tr",{children:[a.jsx("td",{children:"Jumlah Peserta Terdaftar"}),a.jsxs("td",{children:[N.total," orang"]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Hadir"}),a.jsxs("td",{children:[N.hadir," orang"]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Sakit"}),a.jsxs("td",{children:[N.sakit," orang"]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Izin Khusus"}),a.jsxs("td",{children:[N.izin," orang"]})]}),a.jsxs("tr",{children:[a.jsx("td",{children:"Tanpa Keterangan (Alpha)"}),a.jsxs("td",{children:[N.alpha," orang"]})]})]})]})]}),a.jsxs("div",{className:"print-section",children:[a.jsx("h4",{children:"III. Catatan Kejadian Selama Ujian"}),a.jsx("div",{className:"print-notes",children:h.incidents||"Tidak ada kejadian khusus selama ujian berlangsung."})]}),h.notes&&a.jsxs("div",{className:"print-section",children:[a.jsx("h4",{children:"IV. Catatan Tambahan"}),a.jsx("div",{className:"print-notes",children:h.notes})]}),a.jsx("p",{style:{marginTop:"20px"},children:"Demikian berita acara ini dibuat dengan sebenarnya untuk dapat dipergunakan sebagaimana mestinya."}),a.jsx("div",{className:"print-footer",children:a.jsxs("div",{className:"print-sign",children:[a.jsxs("p",{children:["Palembang, ",new Date().toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"})]}),a.jsx("p",{children:"Pengawas Ujian,"}),a.jsx("div",{className:"print-sign-line"}),a.jsx("p",{children:a.jsx("strong",{children:c?.name||"________________________"})}),a.jsxs("p",{children:["NIP. ",c?.nip||"198501012010011001"]})]})})]})}),a.jsx("style",{children:`
                .berita-acara-page { padding: 0; }
                .page-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    flex-wrap: wrap;
                    gap: 1rem;
                    margin-bottom: 1.5rem;
                }
                .page-actions { display: flex; gap: 0.75rem; }
                .mb-4 { margin-bottom: 1.5rem; }
                .room-selector {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 2rem;
                    align-items: center;
                }
                .selector-item {
                    display: flex;
                    align-items: center;
                    gap: 0.75rem;
                }
                .selector-item label {
                    font-weight: 500;
                    color: var(--color-text-secondary);
                }
                .selector-item .form-input {
                    min-width: 200px;
                }
                .empty-state {
                    text-align: center;
                    padding: 4rem 2rem;
                    color: var(--color-text-muted);
                }
                .empty-state h3 {
                    margin: 1rem 0 0.5rem;
                    color: var(--color-text);
                }
                .form-grid {
                    display: grid;
                    grid-template-columns: repeat(2, 1fr);
                    gap: 1.5rem;
                }
                .card-wide {
                    grid-column: span 2;
                }
                .card-header {
                    padding: 1rem 1.5rem;
                    border-bottom: 1px solid var(--color-border);
                }
                .card-header h3 {
                    margin: 0;
                    font-size: 1rem;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                }
                .form-group {
                    margin-bottom: 1rem;
                }
                .form-label {
                    display: block;
                    margin-bottom: 0.5rem;
                    font-weight: 500;
                    color: var(--color-text-secondary);
                    font-size: 0.875rem;
                }
                .form-row {
                    display: grid;
                    grid-template-columns: repeat(2, 1fr);
                    gap: 1rem;
                }
                .form-textarea {
                    resize: vertical;
                    min-height: 80px;
                }
                .attendance-recap {
                    display: flex;
                    flex-direction: column;
                    gap: 0.75rem;
                }
                .recap-item {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 0.75rem 1rem;
                    background: var(--color-bg-tertiary);
                    border-radius: 0.5rem;
                    border-left: 3px solid var(--color-border);
                }
                .recap-item.success { border-left-color: var(--color-success); }
                .recap-item.warning { border-left-color: var(--color-warning); }
                .recap-item.info { border-left-color: var(--color-info); }
                .recap-item.error { border-left-color: var(--color-error); }
                .recap-label {
                    font-size: 0.875rem;
                    color: var(--color-text-secondary);
                }
                .recap-value {
                    font-weight: 600;
                    color: var(--color-text);
                }
                @media (max-width: 768px) {
                    .page-header { flex-direction: column; }
                    .form-grid { grid-template-columns: 1fr; }
                    .card-wide { grid-column: span 1; }
                    .form-row { grid-template-columns: 1fr; }
                }
            `})]})}const $f=y.createContext(null);function Le(){return y.useContext($f)}function ce({children:r,allowedRoles:c}){const{user:u,isLoading:o}=Le();return o?a.jsx("div",{className:"flex items-center justify-center",style:{minHeight:"100vh"},children:a.jsx("div",{className:"spinner-lg"})}):u?c&&!c.includes(u.role)?a.jsx(ds,{to:`/${u.role.replace("_","-")}`,replace:!0}):r:a.jsx(ds,{to:"/login",replace:!0})}function hy(){const[r,c]=y.useState(null),[u,o]=y.useState(!0),[h,m]=y.useState("light");y.useEffect(()=>{const z=localStorage.getItem("cat_user"),N=localStorage.getItem("cat_theme")||"light";if(z)try{c(JSON.parse(z))}catch{localStorage.removeItem("cat_user")}m(N),document.documentElement.setAttribute("data-theme",N),o(!1)},[]);const p={user:r,isLoading:u,login:z=>{c(z),localStorage.setItem("cat_user",JSON.stringify(z))},logout:()=>{c(null),localStorage.removeItem("cat_user")},theme:h,toggleTheme:()=>{const z=h==="light"?"dark":"light";m(z),localStorage.setItem("cat_theme",z),document.documentElement.setAttribute("data-theme",z)}};return a.jsx(Zv,{children:a.jsx($f.Provider,{value:p,children:a.jsxs(xv,{children:[a.jsx(ie,{path:"/login",element:r?a.jsx(ds,{to:`/${r.role.replace("_","-")}`,replace:!0}):a.jsx(Vj,{})}),a.jsx(ie,{path:"/superadmin",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(Hp,{})})}),a.jsx(ie,{path:"/superadmin/users",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(Uo,{})})}),a.jsx(ie,{path:"/superadmin/prodi",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(Bp,{})})}),a.jsx(ie,{path:"/superadmin/kelas",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(Lo,{})})}),a.jsx(ie,{path:"/superadmin/matkul",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(Oo,{})})}),a.jsx(ie,{path:"/superadmin/student-card",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(Gp,{})})}),a.jsx(ie,{path:"/superadmin/exam-room",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(Qp,{})})}),a.jsx(ie,{path:"/superadmin/rekap-nilai",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(qi,{})})}),a.jsx(ie,{path:"/superadmin/rekap-kehadiran",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(Vp,{})})}),a.jsx(ie,{path:"/superadmin/reports",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(qp,{})})}),a.jsx(ie,{path:"/superadmin/settings",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(Ip,{})})}),a.jsx(ie,{path:"/superadmin/monitor-ujian",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(qo,{})})}),a.jsx(ie,{path:"/superadmin/rekap-nilai-mahasiswa",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(qi,{})})}),a.jsx(ie,{path:"/superadmin/jadwal-ujian",element:a.jsx(ce,{allowedRoles:["superadmin"],children:a.jsx(Fp,{})})}),a.jsx(ie,{path:"/admin-prodi",element:a.jsx(ce,{allowedRoles:["admin_prodi"],children:a.jsx(w1,{})})}),a.jsx(ie,{path:"/admin-prodi/users",element:a.jsx(ce,{allowedRoles:["admin_prodi"],children:a.jsx(Uo,{})})}),a.jsx(ie,{path:"/admin-prodi/kelas",element:a.jsx(ce,{allowedRoles:["admin_prodi"],children:a.jsx(Lo,{})})}),a.jsx(ie,{path:"/admin-prodi/matkul",element:a.jsx(ce,{allowedRoles:["admin_prodi"],children:a.jsx(Oo,{})})}),a.jsx(ie,{path:"/admin-prodi/rekap-nilai",element:a.jsx(ce,{allowedRoles:["admin_prodi"],children:a.jsx(qi,{})})}),a.jsx(ie,{path:"/admin-prodi/rekap-kehadiran",element:a.jsx(ce,{allowedRoles:["admin_prodi"],children:a.jsx(Vp,{})})}),a.jsx(ie,{path:"/admin-prodi/rekap-berita-acara",element:a.jsx(ce,{allowedRoles:["admin_prodi"],children:a.jsx(N1,{})})}),a.jsx(ie,{path:"/admin-prodi/jadwal-ujian",element:a.jsx(ce,{allowedRoles:["admin_prodi"],children:a.jsx(Fp,{})})}),a.jsx(ie,{path:"/admin-prodi/settings",element:a.jsx(ce,{allowedRoles:["admin_prodi"],children:a.jsx(A1,{})})}),a.jsx(ie,{path:"/admin-prodi/rekap-nilai-mahasiswa",element:a.jsx(ce,{allowedRoles:["admin_prodi"],children:a.jsx(qi,{})})}),a.jsx(ie,{path:"/admin",element:a.jsx(ce,{allowedRoles:["admin"],children:a.jsx(Hp,{})})}),a.jsx(ie,{path:"/admin/users",element:a.jsx(ce,{allowedRoles:["admin"],children:a.jsx(Uo,{})})}),a.jsx(ie,{path:"/admin/prodi",element:a.jsx(ce,{allowedRoles:["admin"],children:a.jsx(Bp,{})})}),a.jsx(ie,{path:"/admin/kelas",element:a.jsx(ce,{allowedRoles:["admin"],children:a.jsx(Lo,{})})}),a.jsx(ie,{path:"/admin/matkul",element:a.jsx(ce,{allowedRoles:["admin"],children:a.jsx(Oo,{})})}),a.jsx(ie,{path:"/admin/reports",element:a.jsx(ce,{allowedRoles:["admin"],children:a.jsx(qp,{})})}),a.jsx(ie,{path:"/admin/settings",element:a.jsx(ce,{allowedRoles:["admin"],children:a.jsx(Ip,{})})}),a.jsx(ie,{path:"/admin/student-card",element:a.jsx(ce,{allowedRoles:["admin"],children:a.jsx(Gp,{})})}),a.jsx(ie,{path:"/admin/exam-room",element:a.jsx(ce,{allowedRoles:["admin"],children:a.jsx(Qp,{})})}),a.jsx(ie,{path:"/dosen",element:a.jsx(ce,{allowedRoles:["dosen"],children:a.jsx(U1,{})})}),a.jsx(ie,{path:"/dosen/buat-soal",element:a.jsx(ce,{allowedRoles:["dosen"],children:a.jsx(K1,{})})}),a.jsx(ie,{path:"/dosen/koreksi",element:a.jsx(ce,{allowedRoles:["dosen"],children:a.jsx(P1,{})})}),a.jsx(ie,{path:"/dosen/nilai-uas",element:a.jsx(ce,{allowedRoles:["dosen"],children:a.jsx(ef,{})})}),a.jsx(ie,{path:"/dosen/nilai-ujian",element:a.jsx(ce,{allowedRoles:["dosen"],children:a.jsx(ef,{})})}),a.jsx(ie,{path:"/dosen/nilai-akhir",element:a.jsx(ce,{allowedRoles:["dosen"],children:a.jsx(V1,{})})}),a.jsx(ie,{path:"/mahasiswa",element:a.jsx(ce,{allowedRoles:["mahasiswa"],children:a.jsx(W1,{})})}),a.jsx(ie,{path:"/mahasiswa/ujian/:id",element:a.jsx(ce,{allowedRoles:["mahasiswa"],children:a.jsx(sf,{})})}),a.jsx(ie,{path:"/mahasiswa/ujian",element:a.jsx(ce,{allowedRoles:["mahasiswa"],children:a.jsx(ey,{})})}),a.jsx(ie,{path:"/mahasiswa/hasil",element:a.jsx(ce,{allowedRoles:["mahasiswa"],children:a.jsx(ay,{})})}),a.jsx(ie,{path:"/mahasiswa/take-exam/:id",element:a.jsx(ce,{allowedRoles:["mahasiswa"],children:a.jsx(sf,{})})}),a.jsx(ie,{path:"/pengawas",element:a.jsx(ce,{allowedRoles:["pengawas"],children:a.jsx(sy,{})})}),a.jsx(ie,{path:"/pengawas/monitor",element:a.jsx(ce,{allowedRoles:["pengawas"],children:a.jsx(qo,{})})}),a.jsx(ie,{path:"/pengawas/monitor/:id",element:a.jsx(ce,{allowedRoles:["pengawas"],children:a.jsx(qo,{})})}),a.jsx(ie,{path:"/pengawas/attendance",element:a.jsx(ce,{allowedRoles:["pengawas"],children:a.jsx(dy,{})})}),a.jsx(ie,{path:"/pengawas/berita-acara",element:a.jsx(ce,{allowedRoles:["pengawas"],children:a.jsx(my,{})})}),a.jsx(ie,{path:"/",element:a.jsx(ds,{to:"/login",replace:!0})}),a.jsx(ie,{path:"*",element:a.jsx(ds,{to:"/login",replace:!0})})]})})})}j0.createRoot(document.getElementById("root")).render(a.jsx(y.StrictMode,{children:a.jsx($v,{children:a.jsx(hy,{})})}));
